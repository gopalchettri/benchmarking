$(function () {

  /* ── DATA ───────────────────────────────────────── */
  const scenarios = [
    {
      id:"credential-theft", name:"Credential Theft Campaign", severity:"critical",
      status:"Active", affected:"Identity and regulated data",
      overview:"External actor targets executives with phishing, steals access, exploits low visibility, and moves to data exfiltration.",
      criticalPaths:2, highRiskConditions:3,
      severityMeta:"Immediate executive attention recommended",
      treeHeading:"Credential Theft to Data Exfiltration",
      criticalNodeId:"condition-telemetry",
      criticalNodeIds:["actor","action","vector-session","condition-telemetry","impact"],
      nodes:[
        {id:"actor",type:"actor",severity:"critical",x:510,y:80,width:380,height:54,label:"Financially motivated external intruder",actor:"Financially motivated external intruder",action:"Establish trusted enterprise access",vector:"Session hijack or phishing",condition:"Identity telemetry gaps",impact:"Regulated data exfiltration",posture:"Partial",description:"The attack begins with an external operator focused on monetizing access through theft and extortion.",narrative:"The actor is not generic noise. This is a focused operator pursuing high-value data with a financially clear motive.",actions:["Harden executive and privileged identities first.","Align monitoring to attacker monetization objectives.","Escalate actor-driven scenarios into leadership reporting."],path:["Threat Actor","Action","Path/Vector","Condition","Impact"]},
        {id:"action",type:"action",severity:"critical",x:520,y:220,width:360,height:52,label:"Obtain trusted enterprise access",actor:"Financially motivated external intruder",action:"Obtain trusted enterprise access",vector:"Phishing and token replay",condition:"Control fatigue and weak visibility",impact:"Privileged access to sensitive systems",posture:"Partial",description:"The actor's main action is to convert identity compromise into access that looks valid to the environment.",narrative:"Once the attacker appears trusted, the organization starts losing the advantage of perimeter-based detection.",actions:["Add phishing-resistant MFA for privileged users.","Reduce session lifetime and standing privilege.","Use adaptive access checks for sensitive workflows."],path:["Threat Actor","Trusted Access","Vector Choice"]},
        {id:"vector-phishing",type:"vector",severity:"high",x:160,y:372,width:320,height:56,label:"Spear phishing and credential capture",actor:"External intruder",action:"Harvest credentials",vector:"Targeted phishing",condition:"User susceptibility",impact:"Stolen passwords and session seeds",posture:"Moderate",description:"A tailored lure reaches a high-value target and collects credentials or redirect-based session artifacts.",narrative:"This is still one of the fastest ways to turn executive attention into enterprise access.",actions:["Prioritize executive phishing-resistant authentication.","Use real-time email banners for external senders.","Continuously test targeted phishing exposure."],path:["Threat Actor","Credential Harvesting","Targeted Email"]},
        {id:"vector-session",type:"vector",severity:"critical",x:545,y:372,width:320,height:56,label:"Session hijack through VPN token replay",actor:"External intruder",action:"Replay trusted session",vector:"VPN token hijack",condition:"Low visibility into token misuse",impact:"Silent remote access into enterprise environment",posture:"Low",description:"The attacker uses a stolen session or token to bypass normal friction and blend into valid remote access.",narrative:"This is the most concerning vector because it compresses time to impact while looking operationally normal.",actions:["Bind sessions to device posture and geographic expectations.","Revalidate risky sessions more aggressively.","Create alerts around token reuse anomalies."],path:["Threat Actor","Trusted Access","VPN Token Replay"]},
        {id:"vector-vendor",type:"vector",severity:"medium",x:930,y:372,width:320,height:56,label:"Compromised third-party vendor account",actor:"External intruder",action:"Pivot through vendor trust",vector:"Third-party access path",condition:"Weak segmentation",impact:"Indirect access into internal workflows",posture:"Moderate",description:"A weaker partner account is used to access shared systems or internal-facing services.",narrative:"Third-party trust quietly widens the attack surface beyond direct employee compromise.",actions:["Tighten vendor access segmentation.","Review partner privileges like internal privileges.","Monitor partner-originating privileged activity."],path:["Threat Actor","Partner Pivot","Vendor Access"]},
        {id:"condition-mfa",type:"condition",severity:"high",x:160,y:536,width:320,height:56,label:"Users can be coerced into MFA approval",actor:"External intruder",action:"Exploit human friction",vector:"Prompt fatigue",condition:"Push-based MFA acceptance",impact:"Access confirmation by the victim",posture:"Moderate",description:"The environment permits repeated prompts that can pressure users into accidental approval.",narrative:"The control exists, but the user interaction model makes it exploitable.",actions:["Move to number matching or phishing-resistant MFA.","Throttle repeated prompts.","Escalate fatigue patterns into SOC response."],path:["Threat Actor","Action","Prompt Fatigue","Condition"]},
        {id:"condition-telemetry",type:"condition",severity:"critical",x:545,y:536,width:320,height:56,label:"Limited visibility on session and data staging",actor:"External intruder",action:"Operate without prompt detection",vector:"Session hijack and staging",condition:"Low telemetry coverage",impact:"Late recognition of high-consequence activity",posture:"Low",description:"This condition enables the attacker to progress from access to staging and impact before defenders react.",narrative:"The condition layer is the executive priority because it determines whether the attack becomes an incident or a crisis.",actions:["Increase monitoring on session anomalies and bulk access.","Correlate identity, device, and data movement telemetry.","Tune detection specifically for crown-jewel datasets."],path:["Threat Actor","Action","VPN Replay","Low Visibility","Impact"]},
        {id:"condition-thirdparty",type:"condition",severity:"medium",x:930,y:536,width:320,height:56,label:"Vendor access is broad and lightly segmented",actor:"External intruder",action:"Abuse inherited trust",vector:"Third-party portal access",condition:"Overbroad vendor permissions",impact:"Faster lateral reach into business processes",posture:"Moderate",description:"The enterprise permits vendor access patterns that expose more systems than necessary.",narrative:"This condition raises risk even when the direct employee path is better protected.",actions:["Reduce shared third-party access.","Apply stronger monitoring to vendor routes.","Revalidate least privilege in partner workflows."],path:["Threat Actor","Vendor Path","Broad Access Condition"]},
        {id:"impact",type:"impact",severity:"critical",x:500,y:704,width:400,height:60,label:"Regulated data exfiltration and executive crisis",actor:"Financially motivated external intruder",action:"Extract sensitive data",vector:"Validated trusted access path",condition:"Delayed detection of staging and egress",impact:"Regulatory, contractual, and reputational damage",posture:"Partial",description:"The attack culminates in sensitive data leaving the environment, creating a business and governance event.",narrative:"This is the board-level failure state that the upstream chain must be designed to interrupt.",actions:["Instrument outbound channels tied to attacker tradecraft.","Pair cyber response with legal and communications response.","Test whether upstream controls can break this path early."],path:["Threat Actor","Action","Vector","Condition","Impact"]}
      ],
      edges:[{from:"actor",to:"action",critical:true},{from:"action",to:"vector-phishing",critical:false},{from:"action",to:"vector-session",critical:true},{from:"action",to:"vector-vendor",critical:false},{from:"vector-phishing",to:"condition-mfa",critical:false},{from:"vector-session",to:"condition-telemetry",critical:true},{from:"vector-vendor",to:"condition-thirdparty",critical:false},{from:"condition-mfa",to:"impact",critical:false},{from:"condition-telemetry",to:"impact",critical:true},{from:"condition-thirdparty",to:"impact",critical:false}]
    },
    {
      id:"ransomware-pivot", name:"Ransomware Lateral Pivot", severity:"high",
      status:"Escalated", affected:"Endpoint fleet and operations",
      overview:"Operator lands on a user endpoint, pivots laterally, exploits weak admin controls, and drives enterprise-wide disruption.",
      criticalPaths:1, highRiskConditions:2,
      severityMeta:"Operational disruption risk is elevated",
      treeHeading:"Endpoint Compromise to Ransomware Impact",
      criticalNodeId:"condition-admin",
      criticalNodeIds:["actor","action","vector-endpoint","condition-admin","impact"],
      nodes:[
        {id:"actor",type:"actor",severity:"high",x:510,y:80,width:380,height:54,label:"Ransomware affiliate operator",actor:"Ransomware affiliate operator",action:"Gain a foothold on a corporate endpoint",vector:"Malware drop or stolen remote tool",condition:"Weak administrative segmentation",impact:"Broad operational disruption",posture:"Partial",description:"A ransomware-oriented actor is attempting to turn one compromised endpoint into enterprise-wide leverage.",narrative:"The actor's goal is speed, scale, and disruption rather than quiet long-term persistence.",actions:["Prioritize detection around ransomware pre-staging behaviors.","Separate admin paths from standard user paths.","Use business criticality to rank response urgency."],path:["Threat Actor","Endpoint Foothold","Admin Weakness","Impact"]},
        {id:"action",type:"action",severity:"high",x:520,y:220,width:360,height:52,label:"Expand from one endpoint to admin reach",actor:"Ransomware affiliate operator",action:"Move laterally and gain admin reach",vector:"Remote tooling or credential theft",condition:"Flat internal trust",impact:"Wider blast radius",posture:"Partial",description:"The attacker focuses on converting one machine compromise into control over more valuable systems.",narrative:"This is the decisive step where a localized intrusion becomes an enterprise resilience problem.",actions:["Reduce lateral movement pathways.","Restrict remote administration tooling.","Add segmentation between user and server tiers."],path:["Threat Actor","Action","Lateral Pivot"]},
        {id:"vector-endpoint",type:"vector",severity:"critical",x:545,y:372,width:320,height:56,label:"Malware drop on user workstation",actor:"Ransomware affiliate operator",action:"Land malware",vector:"Endpoint execution",condition:"Insufficient endpoint hardening",impact:"Initial access and persistence",posture:"Moderate",description:"A compromised workstation becomes the launch point for credential theft, discovery, and lateral movement.",narrative:"This vector remains highly efficient because user endpoints are the closest asset to daily business operations.",actions:["Harden administrative endpoints separately.","Expand behavioral EDR policies.","Control script and binary execution paths."],path:["Threat Actor","Endpoint Execution","Lateral Preparation"]},
        {id:"vector-tooling",type:"vector",severity:"medium",x:160,y:372,width:320,height:56,label:"Abuse legitimate remote administration tools",actor:"Ransomware affiliate operator",action:"Blend with admin tooling",vector:"Remote management software",condition:"Tool trust without context",impact:"Detection delay",posture:"Moderate",description:"The actor hides behind normal administrative protocols and tooling to reduce suspicion.",narrative:"Trusted tools without behavioral context can create blind spots in incident response.",actions:["Baseline legitimate remote tool usage.","Alert on after-hours or anomalous tool execution.","Review privileged tool distribution."],path:["Threat Actor","Trusted Tool Abuse","Detection Delay"]},
        {id:"vector-credential",type:"vector",severity:"medium",x:930,y:372,width:320,height:56,label:"Local credential harvesting from memory",actor:"Ransomware affiliate operator",action:"Steal local credentials",vector:"Credential dumping",condition:"Legacy privilege exposure",impact:"Privilege expansion",posture:"Moderate",description:"Credentials harvested from a compromised host help the operator move toward privileged systems.",narrative:"Local secrets continue to fuel ransomware scale when endpoint protections are inconsistent.",actions:["Reduce local admin presence.","Harden memory credential protection.","Contain high-risk credential exposure fast."],path:["Threat Actor","Credential Theft","Privilege Expansion"]},
        {id:"condition-admin",type:"condition",severity:"critical",x:545,y:536,width:320,height:56,label:"Administrative paths are weakly segmented",actor:"Ransomware affiliate operator",action:"Escalate to broad admin reach",vector:"Endpoint pivot",condition:"Weak admin segmentation",impact:"Fast spread across infrastructure",posture:"Low",description:"Poor separation between administrative paths and standard endpoints enables rapid attacker expansion.",narrative:"This condition is the biggest amplifier in the scenario because it converts local compromise into systemic disruption.",actions:["Separate privileged access infrastructure.","Enforce just-in-time admin elevation.","Monitor privilege boundary crossings."],path:["Threat Actor","Action","Endpoint Pivot","Weak Admin Segmentation","Impact"]},
        {id:"condition-backup",type:"condition",severity:"high",x:160,y:536,width:320,height:56,label:"Recovery controls are not isolated",actor:"Ransomware affiliate operator",action:"Target recovery capability",vector:"Backup discovery",condition:"Shared trust with production",impact:"Longer outage and higher leverage",posture:"Moderate",description:"Recovery systems are exposed enough that the attacker can degrade the organization's resilience before encryption.",narrative:"If recovery is reachable from production, the business pays twice: once in disruption and once in slower restoration.",actions:["Isolate backup infrastructure.","Monitor recovery admin access tightly.","Test recovery paths under attack conditions."],path:["Threat Actor","Action","Recovery Targeting","Condition"]},
        {id:"condition-detection",type:"condition",severity:"medium",x:930,y:536,width:320,height:56,label:"Endpoint telemetry coverage is inconsistent",actor:"Ransomware affiliate operator",action:"Avoid early containment",vector:"Selective endpoint visibility",condition:"Uneven EDR deployment",impact:"Longer dwell time before containment",posture:"Moderate",description:"Partial sensor coverage gives the attacker room to expand before the response team sees the full chain.",narrative:"Inconsistent coverage forces response teams to infer instead of observe.",actions:["Close EDR coverage gaps.","Prioritize business critical endpoints.","Correlate endpoint visibility with privilege level."],path:["Threat Actor","Action","Telemetry Gaps","Condition"]},
        {id:"impact",type:"impact",severity:"high",x:500,y:704,width:400,height:60,label:"Enterprise-wide encryption and business disruption",actor:"Ransomware affiliate operator",action:"Disrupt operations",vector:"Admin-enabled spread",condition:"Recovery and admin weaknesses",impact:"Material business interruption and extortion pressure",posture:"Partial",description:"The outcome is widespread operational impact that forces crisis management, recovery, and stakeholder communication.",narrative:"This is the resilience failure state leadership must avoid by interrupting admin escalation early.",actions:["Model business-critical service outage scenarios.","Exercise cross-functional ransomware response.","Validate segmentation through red-team testing."],path:["Threat Actor","Action","Privilege Expansion","Condition","Impact"]}
      ],
      edges:[{from:"actor",to:"action",critical:true},{from:"action",to:"vector-tooling",critical:false},{from:"action",to:"vector-endpoint",critical:true},{from:"action",to:"vector-credential",critical:false},{from:"vector-tooling",to:"condition-backup",critical:false},{from:"vector-endpoint",to:"condition-admin",critical:true},{from:"vector-credential",to:"condition-detection",critical:false},{from:"condition-backup",to:"impact",critical:false},{from:"condition-admin",to:"impact",critical:true},{from:"condition-detection",to:"impact",critical:false}]
    },
    {
      id:"supply-chain-abuse", name:"Supply Chain Access Abuse", severity:"medium",
      status:"Monitoring", affected:"Vendor access and cloud collaboration",
      overview:"Attacker abuses partner trust, enters through shared access, exploits weak segmentation, and reaches sensitive business workflows.",
      criticalPaths:1, highRiskConditions:2,
      severityMeta:"Monitoring required for vendor-facing exposure",
      treeHeading:"Partner Trust Abuse to Sensitive Workflow Impact",
      criticalNodeId:"condition-segmentation",
      criticalNodeIds:["actor","action","vector-partner","condition-segmentation","impact"],
      nodes:[
        {id:"actor",type:"actor",severity:"medium",x:510,y:80,width:380,height:54,label:"Access broker using partner compromise",actor:"Access broker using partner compromise",action:"Leverage third-party trust",vector:"Compromised partner identity",condition:"Weak vendor segmentation",impact:"Sensitive workflow exposure",posture:"Moderate",description:"An access broker uses a compromised partner identity to get closer to the enterprise without attacking it directly first.",narrative:"The actor is using someone else's trust relationship as the initial foothold.",actions:["Rank third-party access by business consequence.","Monitor partner identities like privileged identities.","Limit inherited trust from vendors."],path:["Threat Actor","Partner Compromise","Trust Abuse","Impact"]},
        {id:"action",type:"action",severity:"medium",x:520,y:220,width:360,height:52,label:"Pivot from partner access into core workflow",actor:"Access broker",action:"Move from partner to internal workflow",vector:"Federated or portal access",condition:"Broad trust boundaries",impact:"Unauthorized operational access",posture:"Moderate",description:"The adversary's action is to turn legitimate partner access into unauthorized internal influence.",narrative:"The issue is not only identity compromise but also how much business power partner access already carries.",actions:["Review federated trust carefully.","Minimize portal-level inherited permissions.","Add business workflow monitoring for partner accounts."],path:["Threat Actor","Action","Business Workflow Pivot"]},
        {id:"vector-portal",type:"vector",severity:"medium",x:160,y:372,width:320,height:56,label:"Shared collaboration portal entry",actor:"Access broker",action:"Enter through shared portal",vector:"Cloud collaboration route",condition:"Broad sharing",impact:"Visibility into internal documents and process flow",posture:"Moderate",description:"Shared portals can expose sensitive context even before deeper system access occurs.",narrative:"Low-friction collaboration often expands the intelligence value of third-party compromise.",actions:["Reduce broad document sharing.","Monitor partner document access anomalies.","Restrict high-value collaboration spaces."],path:["Threat Actor","Portal Entry","Shared Content"]},
        {id:"vector-partner",type:"vector",severity:"critical",x:545,y:372,width:320,height:56,label:"Compromised partner SSO account",actor:"Access broker",action:"Use federated trust",vector:"Partner SSO compromise",condition:"Weak partner-boundary validation",impact:"Trusted access to business systems",posture:"Low",description:"The attacker inherits trust through a compromised partner identity that is already allowed into core workflows.",narrative:"This vector is dangerous because it looks contractually legitimate to the environment.",actions:["Add stronger controls to federated partner access.","Review partner risk continuously.","Require context-aware checks at trust boundaries."],path:["Threat Actor","Partner SSO","Trusted Workflow Access"]},
        {id:"vector-api",type:"vector",severity:"medium",x:930,y:372,width:320,height:56,label:"Abuse of partner API integration",actor:"Access broker",action:"Use machine-to-machine trust",vector:"Integration API route",condition:"Weak service-level governance",impact:"Systematic data or workflow misuse",posture:"Moderate",description:"Partner API credentials can provide quieter and more systematic access than a user-facing portal.",narrative:"Machine trust can move faster than human review when governance is weak.",actions:["Rotate and scope partner API credentials.","Monitor unusual API usage baselines.","Separate low-trust from high-trust integrations."],path:["Threat Actor","API Abuse","Workflow Manipulation"]},
        {id:"condition-sharing",type:"condition",severity:"medium",x:160,y:536,width:320,height:56,label:"Collaboration spaces expose too much context",actor:"Access broker",action:"Gather internal intelligence",vector:"Shared content sprawl",condition:"Over-sharing",impact:"Faster and better-informed pivoting",posture:"Moderate",description:"Even if the initial access is limited, overexposed context helps the actor map the organization quickly.",narrative:"Context exposure makes downstream attacks cheaper and faster.",actions:["Limit access to sensitive collaboration spaces.","Review external sharing posture.","Alert on unusual partner content access."],path:["Threat Actor","Portal Use","Over-Sharing Condition"]},
        {id:"condition-segmentation",type:"condition",severity:"critical",x:545,y:536,width:320,height:56,label:"Vendor and internal workflows are weakly segmented",actor:"Access broker",action:"Move into sensitive process flow",vector:"Partner trust path",condition:"Weak segmentation",impact:"Business process compromise",posture:"Low",description:"Weak boundaries between partner workflows and internal workflows let the attacker cross into more sensitive business operations.",narrative:"This condition is the real risk driver because it converts a vendor issue into an enterprise issue.",actions:["Segment partner from internal workflows.","Review trust boundaries at process level.","Apply stronger control checks to workflow transitions."],path:["Threat Actor","Action","Partner SSO","Weak Segmentation","Impact"]},
        {id:"condition-governance",type:"condition",severity:"high",x:930,y:536,width:320,height:56,label:"Service integration governance is inconsistent",actor:"Access broker",action:"Remain under governance thresholds",vector:"Integration abuse",condition:"Uneven API oversight",impact:"Extended misuse before detection",posture:"Moderate",description:"Inconsistent governance over partner integrations delays recognition of misuse and weakens response confidence.",narrative:"Uneven governance makes machine-driven abuse harder to spot than user-driven abuse.",actions:["Standardize partner API governance.","Apply consistent anomaly thresholds.","Map business criticality to integration control strength."],path:["Threat Actor","Action","API Route","Governance Gap"]},
        {id:"impact",type:"impact",severity:"medium",x:500,y:704,width:400,height:60,label:"Sensitive workflow exposure and business trust erosion",actor:"Access broker",action:"Exploit business trust",vector:"Partner trust boundary",condition:"Weak workflow segmentation",impact:"Operational and reputational harm from partner-borne compromise",posture:"Moderate",description:"The business impact is unauthorized influence over sensitive workflows and a loss of confidence in partner security boundaries.",narrative:"The leadership issue is not only cyber exposure but also trust erosion across business relationships.",actions:["Prioritize partner-risk governance.","Test workflow segmentation controls.","Align vendor security reviews to actual business access."],path:["Threat Actor","Action","Partner Trust","Condition","Impact"]}
      ],
      edges:[{from:"actor",to:"action",critical:true},{from:"action",to:"vector-portal",critical:false},{from:"action",to:"vector-partner",critical:true},{from:"action",to:"vector-api",critical:false},{from:"vector-portal",to:"condition-sharing",critical:false},{from:"vector-partner",to:"condition-segmentation",critical:true},{from:"vector-api",to:"condition-governance",critical:false},{from:"condition-sharing",to:"impact",critical:false},{from:"condition-segmentation",to:"impact",critical:true},{from:"condition-governance",to:"impact",critical:false}]
    }
  ];

  /* ── STATE ──────────────────────────────────────── */
  const scenarioMap = {};
  let currentScenario = null, selectedNodeId = null, activeFilter = "all";
  const SVG_W = 1400, SVG_H = 820;
  let zoom = 1, panX = 0, panY = 0;
  const ZOOM_MIN = 0.25, ZOOM_MAX = 3.0, ZOOM_STEP = 0.15;
  scenarios.forEach(s => { scenarioMap[s.id] = s; });

  /* ── HELPERS ────────────────────────────────────── */
  const cap = v => v.charAt(0).toUpperCase() + v.slice(1);
  const escXml = v => String(v).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");

  function updateClock() {
    $("#clock2").text(new Date().toLocaleTimeString([], { hour12: false }));
  }

  /* ── VIEWS ──────────────────────────────────────── */
  function showInventory() {
    $("#invView").show();
    $("#detailView").attr("hidden", true);
    $("#breadcrumb").attr("hidden", true);
    window.scrollTo({ top: 0, behavior: "instant" });
  }
  function showDetail() {
    $("#invView").hide();
    $("#detailView").removeAttr("hidden");
    $("#breadcrumb").removeAttr("hidden");
    window.scrollTo({ top: 0, behavior: "instant" });
  }

  /* ── CARDS ──────────────────────────────────────── */
  function renderCards() {
    const html = scenarios.map((s, i) => {
      const active = currentScenario && s.id === currentScenario.id;
      const critEdges = s.edges.filter(e => e.critical).length;
      const highConds = s.nodes.filter(n => n.type === "condition" && (n.severity === "critical" || n.severity === "high")).length;
      const vectors   = s.nodes.filter(n => n.type === "vector").length;
      return `
        <div class="sc-card ${s.severity}${active ? " active" : ""}"
             data-scenario-id="${s.id}" tabindex="0" role="button" aria-pressed="${active}">
          <div class="sc-card-accent"></div>
          <div class="sc-card-body">
            <div class="sc-card-top">
              <span class="sc-num">${String(i+1).padStart(2,"0")}</span>
              <span class="sc-sev-pill ${s.severity}">${cap(s.severity)}</span>
              <span class="sc-status ${s.status.toLowerCase()}">${s.status}</span>
            </div>
            <div class="sc-name">${s.name}</div>
            <div class="sc-overview">${s.overview}</div>
          </div>
          <div class="sc-card-stats">
            <div class="sc-stat">
              <div class="sc-stat-val">${critEdges}</div>
              <div class="sc-stat-lbl">Critical Paths</div>
            </div>
            <div class="sc-stat">
              <div class="sc-stat-val">${highConds}</div>
              <div class="sc-stat-lbl">High-Risk Conditions</div>
            </div>
            <div class="sc-stat">
              <div class="sc-stat-val">${vectors}</div>
              <div class="sc-stat-lbl">Attack Vectors</div>
            </div>
          </div>
        </div>`;
    }).join("");
    $("#scenarioGrid2").html(html);
  }

  /* ── SUMMARY ────────────────────────────────────── */
  function updateSummary() {
    $("#bcName").text(currentScenario.name);
    $("#d-name").text(currentScenario.name);
    $("#d-meta").text(currentScenario.severityMeta);
    $("#d-paths").text(currentScenario.criticalPaths);
    $("#d-conds").text(currentScenario.highRiskConditions);
    $("#treeTitle2").text(currentScenario.treeHeading);
    $("#d-sev").removeClass("critical high medium").addClass(currentScenario.severity).text(cap(currentScenario.severity));
  }

  /* ── TREE ───────────────────────────────────────── */
  function findNode(id) { return currentScenario.nodes.find(n => n.id === id); }

  function renderTree() {
    const edgeHtml = currentScenario.edges.map(edge => {
      const f = findNode(edge.from), t = findNode(edge.to);
      const x1 = f.x + f.width/2, y1 = f.y + f.height;
      const x2 = t.x + t.width/2, y2 = t.y;
      const my = (y1 + y2) / 2;
      return `<path class="edge${edge.critical?" critical":""}"
        data-edge-from="${edge.from}" data-edge-to="${edge.to}"
        d="M${x1} ${y1} C${x1} ${my},${x2} ${my},${x2} ${y2}"
        marker-end="url(#${edge.critical?"arrowCrit2":"arrow2"})"/>`;
    }).join("");

    const nodeHtml = currentScenario.nodes.map(n => {
      const r = 10;
      const lbl = n.type === "vector" ? "PATH / VECTOR" : n.type.toUpperCase();
      return `<g class="node ${n.type}-node" tabindex="0"
           data-node-id="${n.id}" data-type="${n.type}"
           transform="translate(${n.x},${n.y})" filter="url(#nodeShadow)">
          <rect class="nbg" width="${n.width}" height="${n.height}" rx="${r}"/>
          <rect class="nacc" x="0" y="6" width="4" height="${n.height-12}" rx="2"/>
          <text x="18" y="19" class="ntype">${lbl}</text>
          <text x="18" y="39" class="nlbl">${escXml(n.label)}</text>
        </g>`;
    }).join("");

    $("#edgeLayer2").html(edgeHtml);
    $("#nodeLayer2").html(nodeHtml);
  }

  /* ── ZOOM / PAN ─────────────────────────────────── */
  function applyTransform() {
    const pct = Math.round(zoom * 100) + "%";
    document.getElementById("zoomLayer2").style.transform = `translate(${panX}px,${panY}px) scale(${zoom})`;
    $("#zPct2").text(pct);
    $("#zBadge2").text(pct);
  }
  function fitToView() {
    const wrap = document.getElementById("canvasWrap2");
    const cw = wrap.clientWidth || wrap.offsetWidth;
    const ch = wrap.clientHeight || wrap.offsetHeight;
    zoom = Math.min(cw/SVG_W, ch/SVG_H) * 0.92;
    panX = (cw - SVG_W*zoom) / 2;
    panY = (ch - SVG_H*zoom) / 2;
    applyTransform();
  }
  function zoomBy(delta, cx, cy) {
    const nz = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, zoom + delta));
    if (nz === zoom) return;
    const wrap = document.getElementById("canvasWrap2");
    const rect = wrap.getBoundingClientRect();
    const x = (cx !== undefined ? cx - rect.left : rect.width  / 2);
    const y = (cy !== undefined ? cy - rect.top  : rect.height / 2);
    const r = nz / zoom;
    panX = x - r*(x - panX); panY = y - r*(y - panY); zoom = nz;
    applyTransform();
  }

  document.getElementById("canvasWrap2").addEventListener("wheel", e => {
    e.preventDefault();
    zoomBy(e.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP, e.clientX, e.clientY);
  }, { passive: false });

  (function () {
    let drag = false, sx, sy, spx, spy;
    const wrap = document.getElementById("canvasWrap2");
    wrap.addEventListener("mousedown", e => {
      if (e.button !== 0 || e.target.closest(".node")) return;
      drag = true; sx = e.clientX; sy = e.clientY; spx = panX; spy = panY;
    });
    window.addEventListener("mousemove", e => {
      if (!drag) return;
      panX = spx + (e.clientX - sx); panY = spy + (e.clientY - sy);
      applyTransform();
    });
    window.addEventListener("mouseup", () => { drag = false; });
  }());

  /* ── DETAILS ────────────────────────────────────── */
  function renderDetails(nodeId) {
    const n = findNode(nodeId);
    if (!n) return;
    $("#briefPanel").removeAttr("hidden");
    const typeLabel = n.type === "vector" ? "Path / Vector" : cap(n.type);
    $("#bp-type").attr("class", "node-type-badge " + n.type + "-badge").text(typeLabel);
    $("#bp-title").text(n.label);
    $("#bp-desc").text(n.description);
    $("#bp-sev").removeClass("critical high medium").addClass(n.severity).text(cap(n.severity));
    $("#bp-actor").text(n.actor);
    $("#bp-action").text(n.action);
    $("#bp-vector").text(n.vector);
    $("#bp-condition").text(n.condition);
    $("#bp-impact").text(n.impact);
    $("#bp-posture").text(n.posture);
    $("#bp-narrative").text(n.narrative);
    $("#bp-actions").html(n.actions.map(a => `<li>${a}</li>`).join(""));
    $("#bp-path").html(n.path.map((s,i) =>
      (i > 0 ? `<span class="p-arr">→</span>` : "") + `<span class="p-step">${s}</span>`
    ).join(""));
  }

  function selectNode(nodeId) {
    selectedNodeId = nodeId;
    $(".node").removeClass("selected");
    $(`.node[data-node-id="${nodeId}"]`).addClass("selected");
    renderDetails(nodeId);
  }

  /* ── FILTER ─────────────────────────────────────── */
  function applyFilter(filter) {
    activeFilter = filter;
    $(".f-tab").removeClass("active");
    $(`.f-tab[data-filter="${filter}"]`).addClass("active");
    $(".node, .edge").removeClass("dimmed critical-path");
    if (filter === "critical") {
      $(".node, .edge").addClass("dimmed");
      currentScenario.criticalNodeIds.forEach(id => {
        $(`.node[data-node-id="${id}"]`).removeClass("dimmed").addClass("critical-path");
      });
      currentScenario.edges.forEach(e => {
        if (e.critical) $(`.edge[data-edge-from="${e.from}"][data-edge-to="${e.to}"]`).removeClass("dimmed").addClass("critical-path");
      });
    } else if (filter === "condition") {
      $(".node").each(function() { if ($(this).data("type") !== "condition") $(this).addClass("dimmed"); });
      $(".edge").addClass("dimmed");
    }
  }

  /* ── SCENARIO LOAD ──────────────────────────────── */
  function renderScenario(id) {
    currentScenario = scenarioMap[id];
    activeFilter = "all";
    showDetail(); renderCards(); updateSummary(); renderTree();
    requestAnimationFrame(() => requestAnimationFrame(() => {
      fitToView(); applyFilter("all"); selectNode("actor");
    }));
    updateClock();
  }

  /* ── EVENTS ─────────────────────────────────────── */
  $(document).on("click", ".sc-card", function() { renderScenario($(this).data("scenario-id")); });
  $(document).on("keydown", ".sc-card", function(e) {
    if (e.key !== "Enter" && e.key !== " ") return;
    e.preventDefault(); renderScenario($(this).data("scenario-id"));
  });

  $("#backBtn").on("click", function() {
    currentScenario = null; selectedNodeId = null; activeFilter = "all";
    showInventory(); renderCards(); updateClock();
    $("#briefPanel").attr("hidden", true);
  });

  $(document).on("click keydown", ".node", function(e) {
    if (e.type === "keydown" && e.key !== "Enter" && e.key !== " ") return;
    e.stopPropagation(); selectNode($(this).data("node-id"));
  });
  $(document).on("click", ".f-tab", function() { if (currentScenario) applyFilter($(this).data("filter")); });

  $("#zIn2").on("click",   () => zoomBy(+ZOOM_STEP));
  $("#zOut2").on("click",  () => zoomBy(-ZOOM_STEP));
  $("#zFit2").on("click",  () => fitToView());
  $("#zCrit2").on("click", function() {
    if (!currentScenario) return;
    applyFilter("critical"); selectNode(currentScenario.criticalNodeId);
  });

  /* ── INIT ───────────────────────────────────────── */
  renderCards(); updateClock();
  setInterval(updateClock, 1000);
});
