#FINAL ONE
# 1. Create the virtual environment (Python 3.11+)
py -3.12 -m venv venv


# 2. Activate it
# On Windows (PowerShell):
venv\Scripts\Activate.ps1
# On Windows (CMD):
venv\Scripts\activate.bat
# On Git Bash / WSL:
source venv/Scripts/activate
venv\Scripts\Activate.ps1

# 3. Upgrade pip
pip install --upgrade pip
or
python -m pip install --upgrade pip

# 4. Install all dependencies
pip install -r requirements.txt

# 5. Verify no dependency conflicts
pip check