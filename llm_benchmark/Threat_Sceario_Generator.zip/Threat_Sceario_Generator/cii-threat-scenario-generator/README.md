# CII Threat Scenario Generator

Backend MVP for generating defensive Critical Information Infrastructure threat scenarios from eight required inputs. The deterministic pipeline decides relevance, applicability, ranking, controls, and evidence. The LLM only turns the approved input pack into readable scenario text.

## Architecture Flow

1. User Selection / Input Capture
2. Input Normalization and Validation
3. Context Builder
4. Threat Identification Engine
5. Threat Applicability Filter
6. Threat Ranking / Prioritisation
7. Control Identification Engine
8. Evidence and Gap Builder
9. LLM Scenario Input Pack Builder
10. LLM Scenario Generator
11. Scenario Validation
12. Final Threat Scenario Output

## Setup

```bash
python -m venv .venv
```

For macOS/Linux:

```bash
source .venv/bin/activate
```

For Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Install:

```bash
pip install -r requirements.txt
```

## Environment Variables

Copy the example file:

```bash
cp .env.example .env
```

Variables:

- `APP_ENV`: application environment.
- `LLM_PROVIDER`: `mock`, `openai`, or `azure_openai`.
- `OPENAI_API_KEY`: required only when `LLM_PROVIDER=openai`.
- `OPENAI_MODEL`: configurable OpenAI model, default `gpt-4o-mini`.
- `AZURE_OPENAI_API_KEY`: required only when `LLM_PROVIDER=azure_openai`.
- `AZURE_OPENAI_ENDPOINT`: Azure OpenAI resource endpoint.
- `AZURE_OPENAI_DEPLOYMENT_NAME`: Azure deployment name, default `gpt-5-mini`.
- `AZURE_OPENAI_API_VERSION`: Azure API version, default `2024-12-01-preview`.
- `LLM_TEMPERATURE`: generation temperature passed to OpenAI/Azure clients.
- `SCENARIO_AUDIT_LOG_PATH`: JSONL audit log path.
- `LOG_LEVEL`: logging level.
- `MAX_REQUEST_BYTES`: maximum accepted request size based on `Content-Length`.
- `CORS_ALLOWED_ORIGINS`: comma-separated browser origins allowed to call the API.

## Run In Mock Mode

```bash
cp .env.example .env
# edit .env and keep LLM_PROVIDER=mock
uvicorn app.main:app --reload
```

Mock mode requires no API key and returns deterministic scenario output for local testing and automated tests.

## Run In OpenAI Mode

Edit `.env`:

```bash
LLM_PROVIDER=openai
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4o-mini
```

Then run:

```bash
uvicorn app.main:app --reload
```

OpenAI mode uses the Responses API with structured output validation against the `ScenarioOutput` Pydantic model or JSON schema fallback.

## Run In Azure OpenAI Mode

Edit `.env`:

```bash
LLM_PROVIDER=azure_openai
AZURE_OPENAI_API_KEY=your_azure_openai_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource-name.cognitiveservices.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-5-mini
AZURE_OPENAI_API_VERSION=2024-12-01-preview
LLM_TEMPERATURE=1.0
```

Then run:

```bash
uvicorn app.main:app --reload
```

Azure OpenAI mode uses the configured Azure deployment with structured output validation against the `ScenarioOutput` Pydantic model or JSON schema fallback. The key must stay in `.env` or the host environment and must not be committed.

## API Examples

Health:

```bash
curl http://localhost:8000/health
```

Generate scenario:

```bash
curl -X POST http://localhost:8000/generate-scenario \
  -H "Content-Type: application/json" \
  -d '{
    "threat_category": "Denial of Service",
    "threat_type": "DDoS Attack on Nodes",
    "threat_actor": "Malicious insiders, Hackers",
    "threat_sector": "Industry",
    "threat_name": "Disruption of MES service nodes affecting production scheduling",
    "control_name": "High Availability Architecture, Network Segmentation, Spare Capacity, Tested Failover, Manual Operating Procedures",
    "asset": "Manufacturing Execution Platform",
    "service": "Manufacturing Execution and Production Scheduling"
  }'
```

Metadata:

```bash
curl http://localhost:8000/metadata/threat-categories
curl http://localhost:8000/metadata/threat-types
curl http://localhost:8000/metadata/assets
curl http://localhost:8000/metadata/services
```

Fetch stored scenario:

```bash
curl http://localhost:8000/scenarios/GEN-IND-IN-A-01-DOS-A1B2C3
```

## Batch Example

```bash
curl -X POST http://localhost:8000/generate-scenario/batch \
  -H "Content-Type: application/json" \
  -d '{
    "items": [
      {
        "threat_category": "Denial of Service",
        "threat_type": "DDoS Attack on Nodes",
        "threat_actor": "Malicious insiders, Hackers",
        "threat_sector": "Industry",
        "threat_name": "Disruption of MES service nodes affecting production scheduling",
        "control_name": "High Availability Architecture, Network Segmentation, Spare Capacity, Tested Failover, Manual Operating Procedures",
        "asset": "Manufacturing Execution Platform",
        "service": "Manufacturing Execution and Production Scheduling"
      }
    ]
  }'
```

## CLI

```bash
python -m app.cli generate --sample
python -m app.cli generate --input-file sample_request.json
```

## Tests And Lint

Run tests:

```bash
pytest -q
```

Run lint:

```bash
ruff check .
```

## Docker

```bash
docker compose up --build
```

The compose service mounts `./data` so `data/generated_scenarios.jsonl` persists on the host.

## Rejected Applicability Cases

The applicability engine blocks threats that require technology not evidenced by the selected asset context. For example, `51% Attack` requires `uses_blockchain=true`. The Manufacturing Execution Platform seed asset has `uses_blockchain=false`, so the API returns HTTP 200 with `status="Rejected"` and does not call the LLM.

## Security And Safety Notes

- The API key is read only from environment variables and is never logged.
- The LLM receives only the scenario input pack, not raw files or environment variables.
- The deterministic engines decide threat relevance, applicability, ranking, controls, and evidence.
- The validator blocks invented assets, services, controls, actors, and unsafe exploit-like phrases.
- Output is defensive and high-level. Exploit steps, payloads, bypass procedures, and code are intentionally excluded.
- CORS is not enabled for the MVP.

## Seed Data Documentation

- `docs/SEED_DATA_DATABASE_SCHEMA.md`: database table design for seed/master data.
- `docs/SEED_DATA_COLUMN_RATIONALE.md`: rationale for each seed-data column and how it is used in scenario generation.
