from app.models.request_models import GenerateScenarioRequest
from app.services.context_builder import build_context
from app.services.normalizer import normalize_request
from tests.conftest import SAMPLE_REQUEST


def test_context_builder_finds_manufacturing_execution_platform():
    normalized = normalize_request(GenerateScenarioRequest.model_validate(SAMPLE_REQUEST))
    context = build_context(normalized)
    assert context.asset_id == "IN-A-01"
    assert context.environment_type == "OT / industrial operations"
    assert context.criticality == "High"
    assert "ERP" in context.dependent_systems
