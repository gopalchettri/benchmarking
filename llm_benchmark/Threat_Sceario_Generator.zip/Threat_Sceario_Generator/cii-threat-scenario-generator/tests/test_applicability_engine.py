from app.models.request_models import GenerateScenarioRequest
from app.services.applicability_engine import evaluate
from app.services.context_builder import build_context
from app.services.normalizer import normalize_request
from app.services.threat_identifier import identify
from tests.conftest import SAMPLE_REQUEST


def test_applicability_passes_ddos_for_mes():
    normalized = normalize_request(GenerateScenarioRequest.model_validate(SAMPLE_REQUEST))
    context = build_context(normalized)
    result = evaluate(normalized, context, identify(normalized, context))
    assert result.status == "Pass"
    assert result.applicability_score >= 0.9


def test_applicability_rejects_51_percent_attack_for_non_blockchain_asset():
    payload = dict(SAMPLE_REQUEST)
    payload["threat_category"] = "Tampering"
    payload["threat_type"] = "51% Attack"
    payload["threat_name"] = "Blockchain consensus manipulation"
    normalized = normalize_request(GenerateScenarioRequest.model_validate(payload))
    context = build_context(normalized)
    result = evaluate(normalized, context, identify(normalized, context))
    assert result.status == "Rejected"
    assert "blockchain" in result.rejection_reason.lower()
