import pytest

from app.config import Settings


def test_azure_openai_provider_requires_azure_settings():
    settings = Settings(
        LLM_PROVIDER="azure_openai",
        AZURE_OPENAI_API_KEY="",
        AZURE_OPENAI_ENDPOINT="",
        AZURE_OPENAI_DEPLOYMENT_NAME="",
        AZURE_OPENAI_API_VERSION="",
        _env_file=None,
    )
    with pytest.raises(RuntimeError, match="AZURE_OPENAI_API_KEY"):
        settings.validate_azure_openai_ready()


def test_azure_openai_provider_accepts_required_settings():
    settings = Settings(
        LLM_PROVIDER="azure_openai",
        AZURE_OPENAI_API_KEY="test-key",
        AZURE_OPENAI_ENDPOINT="https://example.openai.azure.com/",
        AZURE_OPENAI_DEPLOYMENT_NAME="gpt-5-mini",
        AZURE_OPENAI_API_VERSION="2024-12-01-preview",
        LLM_TEMPERATURE=1.0,
        _env_file=None,
    )
    settings.validate_azure_openai_ready()
    assert settings.llm_temperature == 1.0
