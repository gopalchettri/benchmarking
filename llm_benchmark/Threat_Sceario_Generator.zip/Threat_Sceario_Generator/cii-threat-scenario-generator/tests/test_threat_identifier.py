from app.models.request_models import GenerateScenarioRequest
from app.services.context_builder import build_context
from app.services.normalizer import normalize_request
from app.services.threat_identifier import identify
from tests.conftest import SAMPLE_REQUEST


def test_threat_identifier_exact_match():
    normalized = normalize_request(GenerateScenarioRequest.model_validate(SAMPLE_REQUEST))
    threat = identify(normalized, build_context(normalized))
    assert threat.threat_category == "Denial of Service"
    assert threat.threat_type == "DDoS Attack on Nodes"
    assert threat.match_status == "ExactMatch"
