from app.models.request_models import GenerateScenarioRequest
from app.services import (
    applicability_engine,
    context_builder,
    control_identifier,
    evidence_builder,
    llm_input_builder,
    normalizer,
    ranking_engine,
    threat_identifier,
)
from app.services.llm_client import MockLLMClient
from tests.conftest import SAMPLE_REQUEST


def test_mock_llm_returns_scenario_output():
    normalized = normalizer.normalize_request(
        GenerateScenarioRequest.model_validate(SAMPLE_REQUEST)
    )
    context = context_builder.build_context(normalized)
    threat = threat_identifier.identify(normalized, context)
    applicability = applicability_engine.evaluate(normalized, context, threat)
    risk = ranking_engine.rank(normalized, context, threat, applicability)
    controls = control_identifier.identify(normalized, context, threat)
    evidence = evidence_builder.build(controls)
    scenario = MockLLMClient().generate_scenario(
        llm_input_builder.build(
            normalized, context, threat, applicability, risk, controls, evidence
        )
    )
    assert scenario.target_asset == "Manufacturing Execution Platform"
    assert scenario.mapped_controls
