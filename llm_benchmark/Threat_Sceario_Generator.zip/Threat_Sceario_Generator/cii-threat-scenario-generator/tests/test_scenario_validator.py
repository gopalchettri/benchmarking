from app.models.llm_models import ScenarioOutput
from app.models.request_models import GenerateScenarioRequest
from app.services import (
    applicability_engine,
    context_builder,
    control_identifier,
    evidence_builder,
    llm_input_builder,
    normalizer,
    ranking_engine,
    scenario_validator,
    threat_identifier,
)
from app.services.llm_client import MockLLMClient
from tests.conftest import SAMPLE_REQUEST


def test_scenario_validator_rejects_invented_asset():
    normalized = normalizer.normalize_request(
        GenerateScenarioRequest.model_validate(SAMPLE_REQUEST)
    )
    context = context_builder.build_context(normalized)
    threat = threat_identifier.identify(normalized, context)
    applicability = applicability_engine.evaluate(normalized, context, threat)
    risk = ranking_engine.rank(normalized, context, threat, applicability)
    controls = control_identifier.identify(normalized, context, threat)
    evidence = evidence_builder.build(controls)
    scenario = MockLLMClient().generate_scenario(
        llm_input_builder.build(
            normalized, context, threat, applicability, risk, controls, evidence
        )
    )
    bad = ScenarioOutput.model_validate({**scenario.model_dump(), "target_asset": "Invented Asset"})
    result = scenario_validator.validate(
        bad, normalized, context, applicability, risk, controls, evidence
    )
    assert result.validation_status == "Failed"
