from app.models.request_models import GenerateScenarioRequest
from app.services.normalizer import normalize_request
from tests.conftest import SAMPLE_REQUEST


def test_normalizer_splits_threat_actor_csv():
    normalized = normalize_request(GenerateScenarioRequest.model_validate(SAMPLE_REQUEST))
    assert normalized.threat_actor == ["Malicious insider", "Hacker"]


def test_normalizer_splits_control_name_csv():
    normalized = normalize_request(GenerateScenarioRequest.model_validate(SAMPLE_REQUEST))
    assert "Network Segmentation" in normalized.control_name
    assert len(normalized.control_name) == 5
