from tests.conftest import SAMPLE_REQUEST


def test_health_endpoint_returns_ok(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["llm_provider"] == "mock"


def test_generate_scenario_mock_success(client, sample_request):
    response = client.post("/generate-scenario", json=sample_request)
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "Generated"
    assert body["scenario"]["scenario_title"] == (
        "Denial-of-Service Disruption of the Manufacturing Execution Platform "
        "Supporting Production Scheduling"
    )
    assert body["validation_result"]["validation_status"] == "Passed"


def test_generate_scenario_rejects_empty_fields(client, sample_request):
    sample_request["asset"] = " "
    response = client.post("/generate-scenario", json=sample_request)
    assert response.status_code == 422


def test_batch_generation_success(client):
    response = client.post(
        "/generate-scenario/batch", json={"items": [SAMPLE_REQUEST, SAMPLE_REQUEST]}
    )
    assert response.status_code == 200
    assert len(response.json()["results"]) == 2


def test_audit_log_written(client, sample_request, audit_log_path):
    response = client.post("/generate-scenario", json=sample_request)
    assert response.status_code == 200
    assert audit_log_path.exists()
    assert response.json()["generated_scenario_id"] in audit_log_path.read_text(encoding="utf-8")
