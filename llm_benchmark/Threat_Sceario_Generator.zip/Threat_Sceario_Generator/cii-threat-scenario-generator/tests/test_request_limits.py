def test_request_body_limit_returns_413(client):
    response = client.post("/generate-scenario", content=b"x" * 262145)
    assert response.status_code == 413
