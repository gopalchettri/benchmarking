from app.models.request_models import GenerateScenarioRequest
from app.services.context_builder import build_context
from app.services.control_identifier import identify as identify_controls
from app.services.normalizer import normalize_request
from app.services.threat_identifier import identify as identify_threat
from tests.conftest import SAMPLE_REQUEST


def test_control_identifier_resolves_controls():
    normalized = normalize_request(GenerateScenarioRequest.model_validate(SAMPLE_REQUEST))
    context = build_context(normalized)
    profile = identify_controls(normalized, context, identify_threat(normalized, context))
    assert profile.control_coverage_score == 0.8
    assert all(item["match_status"] == "Resolved" for item in profile.mapped_controls)
