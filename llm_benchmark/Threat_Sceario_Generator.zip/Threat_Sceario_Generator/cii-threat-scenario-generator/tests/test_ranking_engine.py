from app.models.request_models import GenerateScenarioRequest
from app.services.applicability_engine import evaluate
from app.services.context_builder import build_context
from app.services.normalizer import normalize_request
from app.services.ranking_engine import rank
from app.services.threat_identifier import identify
from tests.conftest import SAMPLE_REQUEST


def test_ranking_returns_high_for_mes_ddos():
    normalized = normalize_request(GenerateScenarioRequest.model_validate(SAMPLE_REQUEST))
    context = build_context(normalized)
    threat = identify(normalized, context)
    applicability = evaluate(normalized, context, threat)
    risk = rank(normalized, context, threat, applicability)
    assert risk.priority_rating == "High"
    assert risk.priority_score == 20
