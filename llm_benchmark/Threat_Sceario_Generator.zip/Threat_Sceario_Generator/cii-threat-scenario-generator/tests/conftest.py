import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.config import get_settings
from app.main import app

SAMPLE_REQUEST = {
    "threat_category": "Denial of Service",
    "threat_type": "DDoS Attack on Nodes",
    "threat_actor": "Malicious insiders, Hackers",
    "threat_sector": "Industry",
    "threat_name": "Disruption of MES service nodes affecting production scheduling",
    "control_name": (
        "High Availability Architecture, Network Segmentation, Spare Capacity, Tested Failover, "
        "Manual Operating Procedures"
    ),
    "asset": "Manufacturing Execution Platform",
    "service": "Manufacturing Execution and Production Scheduling",
}


@pytest.fixture(autouse=True)
def mock_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("SCENARIO_AUDIT_LOG_PATH", str(tmp_path / "generated_scenarios.jsonl"))
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture
def client() -> TestClient:
    return TestClient(app)


@pytest.fixture
def sample_request() -> dict:
    return dict(SAMPLE_REQUEST)


@pytest.fixture
def audit_log_path() -> Path:
    return Path(os.environ["SCENARIO_AUDIT_LOG_PATH"])
