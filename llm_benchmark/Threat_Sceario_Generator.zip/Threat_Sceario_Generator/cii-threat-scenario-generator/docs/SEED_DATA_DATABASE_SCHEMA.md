# Minimum Seed Data Database Schema

This document defines the minimum database schema required to support the current CII Threat Scenario Generator.

The schema is aligned with the current JSON seed files and the deterministic scenario-generation code. It intentionally excludes removed/non-required columns.

The current MVP uses JSON seed files. This database schema is the normalized MSSQL form of those JSON files. JSON array fields are represented as child tables in the database schema:

| JSON Seed Field | Normalized Database Table |
|---|---|
| `asset_metadata.functions[]` | `asset_function` |
| `asset_metadata.data_handled[]` | `asset_data_handled` |
| `asset_metadata.dependent_systems[]` | `asset_dependent_system` |
| `asset_metadata.privilege_context[]` | `asset_privilege_context` |
| `asset_metadata.interfaces[]` | `asset_interface` |
| `control_library.required_evidence[]` | `control_required_evidence` |
| `threat_control_mappings.mapped_control_names[]` | `threat_control_mapping` |
| `applicability_rules.technology_gates[]` | `applicability_technology_gate` |
| `applicability_rules.threat_type_relevance_rules[]` | `threat_type_relevance_rule` |
| `applicability_rules.category_objectives{}` | `threat_category_objective` |
| `applicability_rules.applicability_weights{}` | `applicability_weight` |
| `scoring_rules.risk_matrix{}` | `scoring_rule` |
| `scoring_rules.criticality_scores{}` | `scoring_rule` |
| `scoring_rules.availability_scores{}` | `scoring_rule` |
| `scoring_rules.context_confidence_penalties{}` | `scoring_rule` |
| `scoring_rules.control_coverage_scores{}` | `scoring_rule` |
| `scoring_rules.threat_match_confidence{}` | `scoring_rule` |
| `scoring_rules.evidence_confidence_scores{}` | `scoring_rule` |
| `scoring_rules.category_codes{}` | `threat_category_code` |

## Excel Compatibility

The user-provided Excel sheet can populate these columns directly:

| Excel Column | Database Column |
|---|---|
| `CII Sector Name` | `sector` |
| `Service` | `service` |
| `Entity` | `entity` |
| `CII Asset Name` | `asset` |
| `What functions does the system platform` | `asset_function.function_name`, `service_metadata.service_function` |
| `What data is handled` | `asset_data_handled.data_name` |
| `Threat Category1 - Spoofing` | `threat_library.threat_category` |
| `Threat Category2 - Tampering` | `threat_library.threat_category` |
| `Threat Category3 - Repudation` | `threat_library.threat_category` |
| `Threat Category4 - Information Disclousure` | `threat_library.threat_category` |
| `Threat Category5 - Denial of Service` | `threat_library.threat_category` |
| `Threat Category6 - Elevation of privilege` | `threat_library.threat_category` |

The remaining fields should be enriched, defaulted, or managed as separate master data.

## Minimum Table List

| Table | Purpose |
|---|---|
| `business_taxonomy` | Asset-service-sector/entity mapping |
| `asset_metadata` | Asset context, criticality, requirements, and applicability flags |
| `asset_function` | Operational functions supported by the asset |
| `asset_data_handled` | Data processed by the asset |
| `asset_dependent_system` | Systems connected to or dependent on the asset |
| `asset_privilege_context` | Privileged roles/access paths |
| `asset_interface` | Integration/access paths |
| `service_metadata` | Service function, criticality, and availability |
| `threat_library` | Known threat category/type/name/sector records |
| `control_library` | Control name, purpose, and evidence |
| `control_required_evidence` | Evidence required for a control |
| `threat_control_mapping` | Threat-to-control mapping |
| `applicability_technology_gate` | Technology-gated rejection rules |
| `threat_type_relevance_rule` | Threat-type applicability context rules |
| `threat_category_objective` | Category-to-security-objective mapping |
| `applicability_weight` | Applicability scoring weights |
| `threat_category_code` | Category abbreviations used in scenario IDs |
| `scoring_rule` | Risk matrix and scoring values |

## 1. Business Taxonomy

### Table: `business_taxonomy`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `sector` | `NVARCHAR(200)` | Yes | Excel: `CII Sector Name` |
| `subsector` | `NVARCHAR(300)` | Yes | Enrichment/default |
| `entity` | `NVARCHAR(300)` | Yes | Excel: `Entity` |
| `service` | `NVARCHAR(300)` | Yes | Excel: `Service` |
| `asset` | `NVARCHAR(300)` | Yes | Excel: `CII Asset Name` |

Recommended key:

```sql
UNIQUE (sector, subsector, entity, service, asset)
```

## 2. Asset Metadata

### Table: `asset_metadata`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `asset_id` | `NVARCHAR(50)` | Yes | Generated/enriched |
| `asset` | `NVARCHAR(300)` | Yes | Excel: `CII Asset Name` |
| `sector` | `NVARCHAR(200)` | Yes | Excel: `CII Sector Name` |
| `service` | `NVARCHAR(300)` | Yes | Excel: `Service` |
| `environment_type` | `NVARCHAR(300)` | Yes | Enrichment/default |
| `criticality` | `NVARCHAR(50)` | Yes | Enrichment/default |
| `availability_requirement` | `NVARCHAR(100)` | Yes | Enrichment/default |
| `integrity_requirement` | `NVARCHAR(100)` | Yes | Enrichment/default |
| `confidentiality_requirement` | `NVARCHAR(100)` | Yes | Enrichment/default |
| `has_service_nodes` | `BIT` | Yes | Derived/default |
| `has_remote_access` | `BIT` | Yes | Derived/default |
| `has_privileged_access` | `BIT` | Yes | Derived/default |
| `uses_blockchain` | `BIT` | Yes | Derived/default |
| `uses_biometric_data` | `BIT` | Yes | Derived/default |
| `uses_gps_or_location_dependency` | `BIT` | Yes | Derived/default |

Recommended keys/indexes:

```sql
PRIMARY KEY (asset_id);
UNIQUE (asset);
CREATE INDEX IX_asset_metadata_asset ON asset_metadata(asset);
CREATE INDEX IX_asset_metadata_service ON asset_metadata(service);
CREATE INDEX IX_asset_metadata_sector ON asset_metadata(sector);
```

### Table: `asset_function`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `asset_id` | `NVARCHAR(50)` | Yes | Parent asset |
| `sequence_no` | `INT` | Yes | Generated order |
| `function_name` | `NVARCHAR(500)` | Yes | Excel: `What functions does the system platform` |

### Table: `asset_data_handled`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `asset_id` | `NVARCHAR(50)` | Yes | Parent asset |
| `sequence_no` | `INT` | Yes | Generated order |
| `data_name` | `NVARCHAR(300)` | Yes | Excel: `What data is handled` |

### Table: `asset_dependent_system`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `asset_id` | `NVARCHAR(50)` | Yes | Parent asset |
| `sequence_no` | `INT` | Yes | Generated order |
| `dependent_system` | `NVARCHAR(300)` | Yes | Enrichment/default |

### Table: `asset_privilege_context`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `asset_id` | `NVARCHAR(50)` | Yes | Parent asset |
| `sequence_no` | `INT` | Yes | Generated order |
| `privilege_context` | `NVARCHAR(300)` | Yes | Enrichment/default |

### Table: `asset_interface`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `asset_id` | `NVARCHAR(50)` | Yes | Parent asset |
| `sequence_no` | `INT` | Yes | Generated order |
| `interface_name` | `NVARCHAR(300)` | Yes | Enrichment/default |

## 3. Service Metadata

### Table: `service_metadata`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `service` | `NVARCHAR(300)` | Yes | Excel: `Service` |
| `sector` | `NVARCHAR(200)` | Yes | Excel: `CII Sector Name` |
| `service_function` | `NVARCHAR(MAX)` | Yes | Excel functions/enrichment |
| `service_criticality` | `NVARCHAR(50)` | Yes | Enrichment/default |
| `availability_requirement` | `NVARCHAR(100)` | Yes | Enrichment/default |

Recommended key:

```sql
PRIMARY KEY (service);
```

## 4. Threat Library

### Table: `threat_library`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `threat_category` | `NVARCHAR(200)` | Yes | Excel threat category columns |
| `threat_type` | `NVARCHAR(300)` | Yes | Enrichment/default |
| `threat_name` | `NVARCHAR(500)` | Yes | Enrichment/default |
| `threat_sector` | `NVARCHAR(200)` | Yes | Excel sector or `All sectors` |

Recommended key:

```sql
PRIMARY KEY (threat_category, threat_type);
```

## 5. Control Library

### Table: `control_library`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `control_name` | `NVARCHAR(300)` | Yes | Separate control master |
| `control_description` | `NVARCHAR(MAX)` | Yes | Separate control master |

Recommended key:

```sql
PRIMARY KEY (control_name);
```

### Table: `control_required_evidence`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `control_name` | `NVARCHAR(300)` | Yes | Parent control |
| `sequence_no` | `INT` | Yes | Generated order |
| `evidence_name` | `NVARCHAR(300)` | Yes | Separate control/evidence master |

## 6. Threat Control Mappings

### Table: `threat_control_mapping`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `threat_category` | `NVARCHAR(200)` | Yes | Threat library/control mapping |
| `threat_type` | `NVARCHAR(300)` | Yes | Threat library/control mapping |
| `control_name` | `NVARCHAR(300)` | Yes | Control library |
| `sequence_no` | `INT` | Yes | Generated order |

Recommended key:

```sql
PRIMARY KEY (threat_category, threat_type, control_name);
```

## 7. Applicability Rules

### Table: `applicability_technology_gate`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `threat_type` | `NVARCHAR(300)` | Yes | Rule master |
| `required_flag` | `NVARCHAR(100)` | Yes | Rule master |
| `reject_reason` | `NVARCHAR(MAX)` | Yes | Rule master |

Recommended key:

```sql
PRIMARY KEY (threat_type);
```

### Table: `threat_category_objective`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `threat_category` | `NVARCHAR(200)` | Yes | Excel threat category columns |
| `security_objective` | `NVARCHAR(100)` | Yes | Rule master |

Recommended key:

```sql
PRIMARY KEY (threat_category);
```

### Table: `threat_type_relevance_rule`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `threat_type` | `NVARCHAR(300)` | Yes | Rule master |
| `any_flags_json` | `NVARCHAR(MAX)` | Yes | Rule master |
| `any_context_fields_json` | `NVARCHAR(MAX)` | Yes | Rule master |
| `any_context_values_json` | `NVARCHAR(MAX)` | Yes | Rule master |

Recommended key:

```sql
PRIMARY KEY (threat_type);
```

### Table: `applicability_weight`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `check_name` | `NVARCHAR(100)` | Yes | Rule master |
| `weight_value` | `DECIMAL(10,4)` | Yes | Rule master |

Recommended key:

```sql
PRIMARY KEY (check_name);
```

## 8. Scoring Rules

### Table: `scoring_rule`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `rule_group` | `NVARCHAR(100)` | Yes | Rule master |
| `rule_name` | `NVARCHAR(100)` | Yes | Rule master |
| `rule_value` | `DECIMAL(10,2)` | Yes | Rule master |

Allowed `rule_group` values:

```text
Risk Matrix
Criticality Score
Availability Score
Context Confidence Penalty
Control Coverage Score
Threat Match Confidence
Evidence Confidence Score
```

Recommended key:

```sql
PRIMARY KEY (rule_group, rule_name);
```

### Table: `threat_category_code`

| Column | Type | Required | Source |
|---|---:|---:|---|
| `threat_category` | `NVARCHAR(200)` | Yes | Rule master |
| `category_code` | `NVARCHAR(20)` | Yes | Rule master |

Recommended key:

```sql
PRIMARY KEY (threat_category);
```

## Suggested MSSQL DDL

```sql
CREATE TABLE business_taxonomy (
    sector NVARCHAR(200) NOT NULL,
    subsector NVARCHAR(300) NOT NULL,
    entity NVARCHAR(300) NOT NULL,
    service NVARCHAR(300) NOT NULL,
    asset NVARCHAR(300) NOT NULL,
    CONSTRAINT UQ_business_taxonomy UNIQUE (sector, subsector, entity, service, asset)
);

CREATE TABLE asset_metadata (
    asset_id NVARCHAR(50) NOT NULL PRIMARY KEY,
    asset NVARCHAR(300) NOT NULL UNIQUE,
    sector NVARCHAR(200) NOT NULL,
    service NVARCHAR(300) NOT NULL,
    environment_type NVARCHAR(300) NOT NULL,
    criticality NVARCHAR(50) NOT NULL,
    availability_requirement NVARCHAR(100) NOT NULL,
    integrity_requirement NVARCHAR(100) NOT NULL,
    confidentiality_requirement NVARCHAR(100) NOT NULL,
    has_service_nodes BIT NOT NULL DEFAULT 0,
    has_remote_access BIT NOT NULL DEFAULT 0,
    has_privileged_access BIT NOT NULL DEFAULT 0,
    uses_blockchain BIT NOT NULL DEFAULT 0,
    uses_biometric_data BIT NOT NULL DEFAULT 0,
    uses_gps_or_location_dependency BIT NOT NULL DEFAULT 0
);

CREATE TABLE asset_function (
    asset_id NVARCHAR(50) NOT NULL,
    sequence_no INT NOT NULL,
    function_name NVARCHAR(500) NOT NULL,
    CONSTRAINT PK_asset_function PRIMARY KEY (asset_id, sequence_no),
    CONSTRAINT FK_asset_function_asset FOREIGN KEY (asset_id)
        REFERENCES asset_metadata(asset_id)
);

CREATE TABLE asset_data_handled (
    asset_id NVARCHAR(50) NOT NULL,
    sequence_no INT NOT NULL,
    data_name NVARCHAR(300) NOT NULL,
    CONSTRAINT PK_asset_data_handled PRIMARY KEY (asset_id, sequence_no),
    CONSTRAINT FK_asset_data_handled_asset FOREIGN KEY (asset_id)
        REFERENCES asset_metadata(asset_id)
);

CREATE TABLE asset_dependent_system (
    asset_id NVARCHAR(50) NOT NULL,
    sequence_no INT NOT NULL,
    dependent_system NVARCHAR(300) NOT NULL,
    CONSTRAINT PK_asset_dependent_system PRIMARY KEY (asset_id, sequence_no),
    CONSTRAINT FK_asset_dependent_system_asset FOREIGN KEY (asset_id)
        REFERENCES asset_metadata(asset_id)
);

CREATE TABLE asset_privilege_context (
    asset_id NVARCHAR(50) NOT NULL,
    sequence_no INT NOT NULL,
    privilege_context NVARCHAR(300) NOT NULL,
    CONSTRAINT PK_asset_privilege_context PRIMARY KEY (asset_id, sequence_no),
    CONSTRAINT FK_asset_privilege_context_asset FOREIGN KEY (asset_id)
        REFERENCES asset_metadata(asset_id)
);

CREATE TABLE asset_interface (
    asset_id NVARCHAR(50) NOT NULL,
    sequence_no INT NOT NULL,
    interface_name NVARCHAR(300) NOT NULL,
    CONSTRAINT PK_asset_interface PRIMARY KEY (asset_id, sequence_no),
    CONSTRAINT FK_asset_interface_asset FOREIGN KEY (asset_id)
        REFERENCES asset_metadata(asset_id)
);

CREATE TABLE service_metadata (
    service NVARCHAR(300) NOT NULL PRIMARY KEY,
    sector NVARCHAR(200) NOT NULL,
    service_function NVARCHAR(MAX) NOT NULL,
    service_criticality NVARCHAR(50) NOT NULL,
    availability_requirement NVARCHAR(100) NOT NULL
);

CREATE TABLE threat_library (
    threat_category NVARCHAR(200) NOT NULL,
    threat_type NVARCHAR(300) NOT NULL,
    threat_name NVARCHAR(500) NOT NULL,
    threat_sector NVARCHAR(200) NOT NULL,
    CONSTRAINT PK_threat_library PRIMARY KEY (threat_category, threat_type)
);

CREATE TABLE control_library (
    control_name NVARCHAR(300) NOT NULL PRIMARY KEY,
    control_description NVARCHAR(MAX) NOT NULL
);

CREATE TABLE control_required_evidence (
    control_name NVARCHAR(300) NOT NULL,
    sequence_no INT NOT NULL,
    evidence_name NVARCHAR(300) NOT NULL,
    CONSTRAINT PK_control_required_evidence PRIMARY KEY (control_name, sequence_no),
    CONSTRAINT FK_control_required_evidence_control FOREIGN KEY (control_name)
        REFERENCES control_library(control_name)
);

CREATE TABLE threat_control_mapping (
    threat_category NVARCHAR(200) NOT NULL,
    threat_type NVARCHAR(300) NOT NULL,
    control_name NVARCHAR(300) NOT NULL,
    sequence_no INT NOT NULL,
    CONSTRAINT PK_threat_control_mapping PRIMARY KEY (
        threat_category,
        threat_type,
        control_name
    ),
    CONSTRAINT FK_threat_control_mapping_threat FOREIGN KEY (
        threat_category,
        threat_type
    ) REFERENCES threat_library(threat_category, threat_type),
    CONSTRAINT FK_threat_control_mapping_control FOREIGN KEY (control_name)
        REFERENCES control_library(control_name)
);

CREATE TABLE applicability_technology_gate (
    threat_type NVARCHAR(300) NOT NULL PRIMARY KEY,
    required_flag NVARCHAR(100) NOT NULL,
    reject_reason NVARCHAR(MAX) NOT NULL
);

CREATE TABLE threat_category_objective (
    threat_category NVARCHAR(200) NOT NULL PRIMARY KEY,
    security_objective NVARCHAR(100) NOT NULL
);

CREATE TABLE threat_type_relevance_rule (
    threat_type NVARCHAR(300) NOT NULL PRIMARY KEY,
    any_flags_json NVARCHAR(MAX) NOT NULL,
    any_context_fields_json NVARCHAR(MAX) NOT NULL,
    any_context_values_json NVARCHAR(MAX) NOT NULL
);

CREATE TABLE applicability_weight (
    check_name NVARCHAR(100) NOT NULL PRIMARY KEY,
    weight_value DECIMAL(10,4) NOT NULL
);

CREATE TABLE scoring_rule (
    rule_group NVARCHAR(100) NOT NULL,
    rule_name NVARCHAR(100) NOT NULL,
    rule_value DECIMAL(10,2) NOT NULL,
    CONSTRAINT PK_scoring_rule PRIMARY KEY (rule_group, rule_name)
);

CREATE TABLE threat_category_code (
    threat_category NVARCHAR(200) NOT NULL PRIMARY KEY,
    category_code NVARCHAR(20) NOT NULL
);
```

## Runtime Query Needs

### Context Builder

```text
asset_metadata by asset
service_metadata by service
business_taxonomy by asset + service
asset_function by asset_id
asset_data_handled by asset_id
asset_dependent_system by asset_id
asset_privilege_context by asset_id
asset_interface by asset_id
```

### Threat Identifier

```text
threat_library by threat_category + threat_type
threat_category_objective by threat_category
```

### Applicability Engine

```text
applicability_technology_gate by threat_type
threat_type_relevance_rule by threat_type
threat_category_objective by threat_category
applicability_weight by check_name
asset_metadata flags
```

### Ranking Engine

```text
scoring_rule where rule_group = Risk Matrix
scoring_rule where rule_group = Criticality Score
scoring_rule where rule_group = Availability Score
scoring_rule where rule_group = Context Confidence Penalty
scoring_rule where rule_group = Control Coverage Score
scoring_rule where rule_group = Threat Match Confidence
scoring_rule where rule_group = Evidence Confidence Score
threat_category_code by threat_category
```

### Control And Evidence

```text
threat_control_mapping by threat_category + threat_type
control_library by control_name
control_required_evidence by control_name
```
