# Minimum Master Data Column Rationale

This document defines the minimum master-data columns required by the current CII Threat Scenario Generator.

The Excel sheet (desc_cii_threat_based_risk_assessment_31MAR.xls) is used as a primary source for asset, service, entity, system function, data handled, and threat category inputs. Some runtime columns are still required as defaults or separate master data because they drive applicability, scoring, control mapping, and evidence output.

Core principle:

```text
The deterministic engine decides context, applicability, risk, controls, and evidence.
The LLM only writes the final scenario from approved deterministic context.
```

## Excel Source Mapping

| Excel Column                                   | Can Be Used? | Maps To                                    |
| ---------------------------------------------- | -----------: | ------------------------------------------ |
| `CII Sector Name`                            |          Yes | `sector`                                 |
| `Service`                                    |          Yes | `service`                                |
| `Entity`                                     |          Yes | `entity`                                 |
| `CII Asset Name`                             |          Yes | `asset`                                  |
| `What functions does the system platform`    |          Yes | `functions`, partly `service_function` |
| `What data is handled`                       |          Yes | `data_handled`                           |
| `Threat Category1 - Spoofing`                |          Yes | `threat_category`                        |
| `Threat Category2 - Tampering`               |          Yes | `threat_category`                        |
| `Threat Category3 - Repudation`              |          Yes | `threat_category`                        |
| `Threat Category4 - Information Disclousure` |          Yes | `threat_category`                        |
| `Threat Category5 - Denial of Service`       |          Yes | `threat_category`                        |
| `Threat Category6 - Elevation of privilege`  |          Yes | `threat_category`                        |

The Excel sheet does not directly provide all fields needed for deterministic generation. Missing fields can be added by enrichment, defaults, or separate master tables.

## Master Tables

| Master Table                | Why It Is Required                                                          |
| --------------------------- | --------------------------------------------------------------------------- |
| `business_taxonomy`       | Links sector, entity, service, and asset                                    |
| `asset_metadata`          | Provides asset context, risk factors, dependencies, and applicability flags |
| `service_metadata`        | Describes the service function, criticality, and availability need          |
| `threat_library`          | Defines known threat category/type/name/sector records                      |
| `control_library`         | Defines control purpose and evidence requirements                           |
| `threat_control_mappings` | Maps each threat category/type to relevant controls                         |
| `applicability_rules`     | Prevents irrelevant threat generation                                       |
| `scoring_rules`           | Calculates likelihood, impact, and priority                                 |

## 1. Business Taxonomy

Purpose:

Confirms the selected asset and service belong to the expected sector and entity context.

| Column        | Required? |    Can Come From Excel? | Why It Is Needed                           | How It Is Used                                            | Practical Example                                      |
| ------------- | --------: | ----------------------: | ------------------------------------------ | --------------------------------------------------------- | ------------------------------------------------------ |
| `sector`    |       Yes |                     Yes | Identifies the CII sector.                 | Used for sector context and sector matching.              | `Industry` confirms the scenario is industrial.      |
| `subsector` |       Yes | No, unless Excel has it | Adds more specific business context.       | Used in context profile for stakeholder readability.      | `Manufacturing / Industrial Operations`.             |
| `entity`    |       Yes |                     Yes | Identifies the entity/operator.            | Used to describe where the asset/service sits.            | `JAFZA` or `Emergency Services Authority`.         |
| `service`   |       Yes |                     Yes | Identifies the supported critical service. | Used to map asset to service and validate context.        | `Manufacturing Execution and Production Scheduling`. |
| `asset`     |       Yes |                     Yes | Identifies the supporting CII asset.       | Used to find asset metadata and generate scenario output. | `Manufacturing Execution Platform`.                  |

Example:

```text
Excel says:
CII Sector Name = Industry
Entity = JAFZA
Service = Manufacturing Execution and Production Scheduling
CII Asset Name = Manufacturing Execution Platform

System uses this to confirm the asset-service-sector context.
```

## 2. Asset Metadata

Purpose:

Provides the technical and business context needed for applicability, scoring, and scenario wording.

| Column                              | Required? | Can Come From Excel? | Why It Is Needed                      | How It Is Used                                             | Practical Example                                          |
| ----------------------------------- | --------: | -------------------: | ------------------------------------- | ---------------------------------------------------------- | ---------------------------------------------------------- |
| `asset_id`                        |       Yes |      No, generate it | Stable asset code.                    | Used in `generated_scenario_id`.                         | `IN-A-01` in `GEN-IND-IN-A-01-DOS-...`.                |
| `asset`                           |       Yes |                  Yes | Asset display name.                   | Used for lookup, context, and final scenario target asset. | `Manufacturing Execution Platform`.                      |
| `sector`                          |       Yes |                  Yes | Sector owning the asset.              | Used for sector match and context.                         | `Industry`.                                              |
| `service`                         |       Yes |                  Yes | Service supported by the asset.       | Used to link asset metadata to service metadata.           | MES supports production scheduling.                        |
| `environment_type`                |       Yes |   No, enrich/default | Provides operating environment.       | Used to make scenario context realistic.                   | `OT / industrial operations`.                            |
| `criticality`                     |       Yes |   No, enrich/default | Shows business importance.            | Used in impact score and human-review decision.            | `High` drives high impact.                               |
| `availability_requirement`        |       Yes |   No, enrich/default | Shows uptime need.                    | Used for DoS applicability and impact scoring.             | `24x7`.                                                  |
| `integrity_requirement`           |       Yes |   No, enrich/default | Shows correctness need.               | Used for tampering and integrity risk context.             | `High`.                                                  |
| `confidentiality_requirement`     |       Yes |   No, enrich/default | Shows sensitivity need.               | Used for information disclosure context.                   | `Medium to High`.                                        |
| `functions`                       |       Yes |                  Yes | Lists operational functions.          | Used in scenario statement and operational impact.         | `Schedule production orders`, `Track WIP`.             |
| `data_handled`                    |       Yes |                  Yes | Lists important data processed.       | Used for disclosure/tampering context.                     | `Batch IDs`, `Operator actions`.                       |
| `dependent_systems`               |       Yes |   No, enrich/default | Lists connected/downstream systems.   | Used for CII/cascading impact wording.                     | `ERP`, `Quality systems`.                              |
| `privilege_context`               |       Yes |   No, enrich/default | Lists privileged roles/access points. | Used for elevation-of-privilege applicability.             | `Admin`, `Engineering workstation`.                    |
| `interfaces`                      |       Yes |   No, enrich/default | Lists integration/access paths.       | Used for exposure scoring and spoofing/DoS context.        | `Remote access path`, `Service-to-service interfaces`. |
| `has_service_nodes`               |       Yes |   No, derive/default | Indicates service nodes exist.        | Used for DDoS and node impersonation applicability.        | `true` allows DDoS on nodes.                             |
| `has_remote_access`               |       Yes |   No, derive/default | Indicates remote access exists.       | Used to increase likelihood/exposure score.                | `true` raises likelihood.                                |
| `has_privileged_access`           |       Yes |   No, derive/default | Indicates privileged access exists.   | Used for access-control and privilege threats.             | `true` supports EoP scenario.                            |
| `uses_blockchain`                 |       Yes |   No, derive/default | Indicates blockchain dependency.      | Used to reject blockchain-only threats when false.         | `51% Attack` rejected when `false`.                    |
| `uses_biometric_data`             |       Yes |   No, derive/default | Indicates biometric data usage.       | Used to reject biometric-only threats when false.          | Biometric data threat rejected when `false`.             |
| `uses_gps_or_location_dependency` |       Yes |   No, derive/default | Indicates GPS/location dependency.    | Used to reject GPS/location threats when false.            | GPS spoofing rejected when `false`.                      |

Example:

```text
For MES DDoS:
has_service_nodes = true
availability_requirement = 24x7
criticality = High

The system decides DDoS on service nodes is applicable and high impact.
```

## 3. Service Metadata

Purpose:

Explains what the selected service does and how critical it is.

| Column                       | Required? |       Can Come From Excel? | Why It Is Needed                       | How It Is Used                               | Practical Example                                      |
| ---------------------------- | --------: | -------------------------: | -------------------------------------- | -------------------------------------------- | ------------------------------------------------------ |
| `service`                  |       Yes |                        Yes | Service display name.                  | Used for service lookup and scenario output. | `Manufacturing Execution and Production Scheduling`. |
| `sector`                   |       Yes |                        Yes | Service sector.                        | Used for sector alignment.                   | `Industry`.                                          |
| `service_function`         |       Yes | Yes, from functions column | Business-readable service description. | Used directly in scenario output.            | Supports scheduling, WIP tracking, line instructions.  |
| `service_criticality`      |       Yes |         No, enrich/default | Shows service importance.              | Used in impact scoring.                      | `High`.                                              |
| `availability_requirement` |       Yes |         No, enrich/default | Shows service uptime need.             | Used for availability impact.                | `24x7`.                                              |

Example:

```text
Excel function text:
Supports emergency call intake, dispatch coordination, and case handling.

System uses it as service_function in the scenario.
```

## 4. Threat Library

Purpose:

Defines the known threat records that the user can select or the UI can list. Detailed objective and applicability logic lives in `applicability_rules`, not in this table.

| Column              | Required? |        Can Come From Excel? | Why It Is Needed                 | How It Is Used                                                | Practical Example                                                    |
| ------------------- | --------: | --------------------------: | -------------------------------- | ------------------------------------------------------------- | -------------------------------------------------------------------- |
| `threat_category` |       Yes |                         Yes | Broad STRIDE-like category.      | Used for matching, objective derivation, and control mapping. | `Denial of Service`.                                               |
| `threat_type`     |       Yes | Partly; may need enrichment | Specific threat type.            | Used for exact threat match and applicability gates.          | `DDoS Attack on Nodes`.                                            |
| `threat_name`     |       Yes | Partly; may need enrichment | Business-readable threat name.   | Used in scenario title/output.                                | `Disruption of MES service nodes affecting production scheduling`. |
| `threat_sector`   |       Yes |                         Yes | Sector where threat is relevant. | Used for sector applicability.                                | `Industry` or `All sectors`.                                     |

Example:

```text
Excel gives category = Denial of Service.
System still needs threat_type = DDoS Attack on Nodes for a precise scenario.
```

## 5. Control Library

Purpose:

Defines control purpose and the evidence needed to validate the control.

| Column                  | Required? |        Can Come From Excel? | Why It Is Needed                        | How It Is Used                                 | Practical Example                        |
| ----------------------- | --------: | --------------------------: | --------------------------------------- | ---------------------------------------------- | ---------------------------------------- |
| `control_name`        |       Yes | No, separate control master | Control display name.                   | Used to resolve input/mapped controls.         | `High Availability Architecture`.      |
| `control_description` |       Yes | No, separate control master | Explains control purpose.               | Used in mapped controls section.               | Maintains availability during overload.  |
| `required_evidence`   |       Yes | No, separate control master | Lists proof needed to validate control. | Used in evidence requirements and gap summary. | `HA design`, `Failover test report`. |

Example:

```text
Control = Tested Failover
Evidence = Failover test report, DR test evidence, recovery-time results
```

## 6. Threat Control Mappings

Purpose:

Connects each threat category/type to relevant controls.

| Column                   | Required? |        Can Come From Excel? | Why It Is Needed                 | How It Is Used                                   | Practical Example                           |
| ------------------------ | --------: | --------------------------: | -------------------------------- | ------------------------------------------------ | ------------------------------------------- |
| `threat_category`      |       Yes |                         Yes | Broad threat category.           | Used with threat type to find controls.          | `Denial of Service`.                      |
| `threat_type`          |       Yes | Partly; may need enrichment | Specific threat type.            | Used for exact mapping.                          | `DDoS Attack on Nodes`.                   |
| `mapped_control_names` |       Yes | No, separate mapping master | Controls relevant to the threat. | Used to build control profile and evidence list. | HA, segmentation, spare capacity, failover. |

Example:

```text
Denial of Service + DDoS Attack on Nodes maps to:
High Availability Architecture
Network Segmentation
Spare Capacity
Tested Failover
Manual Operating Procedures
```

## 7. Applicability Rules

Purpose:

Prevents irrelevant threat scenarios from being generated and derives security objective from threat category.

| Column / Structure                         | Required? |        Can Come From Excel? | Why It Is Needed                         | How It Is Used                                       | Practical Example                      |
| ------------------------------------------ | --------: | --------------------------: | ---------------------------------------- | ---------------------------------------------------- | -------------------------------------- |
| `technology_gates.threat_type`           |       Yes | Partly; may need enrichment | Identifies gated threat type.            | Used to find technology-specific rejection rules.    | `51% Attack`.                        |
| `technology_gates.required_flag`         |       Yes |             No, rule master | Asset flag required for the threat.      | Checked against `asset_metadata.technology_flags`. | `uses_blockchain`.                   |
| `technology_gates.reject_reason`         |       Yes |             No, rule master | Explains why scenario is rejected.       | Returned in API/UI for rejected cases.               | Blockchain required but not evidenced. |
| `threat_type_relevance_rules`            |       Yes |             No, rule master | Defines asset/context conditions that make a threat type relevant. | Used to calculate `threat_type_match`. | DDoS can require `has_service_nodes` or `24x7`. |
| `category_objectives.threat_category`    |       Yes |                         Yes | Threat category.                         | Used to derive security objective.                   | `Denial of Service`.                 |
| `category_objectives.security_objective` |       Yes |             No, rule master | Security objective affected by category. | Used in `identified_threat.security_objective`.    | `Availability`.                      |
| `applicability_weights`                  |       Yes |             No, rule master | Defines how much each applicability check contributes. | Used to calculate `applicability_score`. | `asset_context_match = 0.20`. |

Example:

```text
Threat Type = 51% Attack
Required flag = uses_blockchain
Asset uses_blockchain = false

System returns Rejected and does not call the LLM.
```

## 8. Scoring Rules

Purpose:

Defines the deterministic scoring thresholds and score values.

| Column / Structure         | Required? | Can Come From Excel? | Why It Is Needed                                      | How It Is Used                     | Practical Example               |
| -------------------------- | --------: | -------------------: | ----------------------------------------------------- | ---------------------------------- | ------------------------------- |
| `risk_matrix.low_max`    |       Yes |      No, rule master | Upper threshold for Low.                              | Converts priority score to rating. | `6`.                          |
| `risk_matrix.medium_max` |       Yes |      No, rule master | Upper threshold for Medium.                           | Converts priority score to rating. | `12`.                         |
| `risk_matrix.high_max`   |       Yes |      No, rule master | Upper threshold for High.                             | Converts priority score to rating. | `20`; above this is Critical. |
| `criticality_scores`     |       Yes |      No, rule master | Converts criticality labels to numeric impact values. | Used in impact scoring.            | `High = 5`.                   |
| `availability_scores`    |       Yes |      No, rule master | Converts availability needs to numeric impact values. | Used in impact scoring.            | `24x7 = 5`.                   |
| `category_codes`         |       Yes |      No, rule master | Defines category abbreviation for scenario IDs.       | Used in `generated_scenario_id`.   | `Denial of Service = DOS`.    |
| `context_confidence_penalties` | Yes | No, rule master | Defines confidence reduction when master data is missing. | Used in context builder. | Missing asset metadata reduces confidence by `0.35`. |
| `control_coverage_scores` | Yes | No, rule master | Defines control coverage score by resolution level. | Used in control profile. | Three or more resolved controls = `0.8`. |
| `threat_match_confidence` | Yes | No, rule master | Defines confidence for exact, partial, or custom threat match. | Used in threat identification. | Exact match = `1.0`. |
| `evidence_confidence_scores` | Yes | No, rule master | Defines evidence confidence before uploaded evidence exists. | Used in evidence requirements. | Pending validation = `0.4`. |

Example:

```text
criticality = High -> 5
availability_requirement = 24x7 -> 5
likelihood = 4
priority_score = 4 * 5 = 20
priority_rating = High
```

## Final Minimum Column Set

### Business Taxonomy

```text
sector
subsector
entity
service
asset
```

### Asset Metadata

```text
asset_id
asset
sector
service
environment_type
criticality
availability_requirement
integrity_requirement
confidentiality_requirement
functions
data_handled
dependent_systems
privilege_context
interfaces
has_service_nodes
has_remote_access
has_privileged_access
uses_blockchain
uses_biometric_data
uses_gps_or_location_dependency
```

### Service Metadata

```text
service
sector
service_function
service_criticality
availability_requirement
```

### Threat Library

```text
threat_category
threat_type
threat_name
threat_sector
```

### Control Library

```text
control_name
control_description
required_evidence
```

### Threat Control Mappings

```text
threat_category
threat_type
mapped_control_names
```

### Applicability Rules

```text
technology_gates.threat_type
technology_gates.required_flag
technology_gates.reject_reason
threat_type_relevance_rules
category_objectives.threat_category
category_objectives.security_objective
applicability_weights
```

### Scoring Rules

```text
risk_matrix.low_max
risk_matrix.medium_max
risk_matrix.high_max
criticality_scores
availability_scores
category_codes
context_confidence_penalties
control_coverage_scores
threat_match_confidence
evidence_confidence_scores
```

## End-to-End Example

Input:

```text
Asset = Manufacturing Execution Platform
Service = Manufacturing Execution and Production Scheduling
Threat Category = Denial of Service
Threat Type = DDoS Attack on Nodes
```

Flow:

1. Business taxonomy confirms the asset/service belongs to Industry.
2. Asset metadata confirms `has_service_nodes = true`, `criticality = High`, and `availability_requirement = 24x7`.
3. Service metadata explains the service function.
4. Threat library confirms the category/type/name/sector threat record.
5. Applicability rules derive `security_objective = Availability` and confirm the threat applies.
6. Threat-control mappings find relevant controls.
7. Control library provides purpose and required evidence.
8. Scoring rules calculate `priority_score = 20`, `priority_rating = High`.
9. The LLM receives only approved context and writes the final defensive scenario.
