import json
from typing import Any

SYSTEM_PROMPT = (
    "You are a defensive cyber risk scenario generator for Critical Information Infrastructure. "
    "Generate clear, business-readable, defensive threat scenarios from the supplied structured "
    "input only. Do not invent assets, services, controls, evidence, or unsupported facts. Do not "
    "provide exploit instructions, procedural attack steps, payloads, bypass techniques, or code. "
    "Use high-level risk language. Include business impact, operational impact, relevant controls, "
    "evidence requirements, and residual control concern. If information is missing, state it as "
    "an assumption or gap."
)


def build_user_prompt(scenario_input_pack: dict[str, Any]) -> str:
    return (
        "Generate a CII threat scenario from this approved scenario input pack. "
        "Use only the values in the JSON. Return output that matches the required "
        "ScenarioOutput schema.\n\n"
        "Scenario input pack:\n"
        f"{json.dumps(scenario_input_pack, indent=2)}"
    )
