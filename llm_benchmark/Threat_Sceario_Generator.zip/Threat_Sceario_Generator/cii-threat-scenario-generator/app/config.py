from functools import lru_cache

from dotenv import load_dotenv
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = Field(default="local", alias="APP_ENV")
    llm_provider: str = Field(default="mock", alias="LLM_PROVIDER")
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4o-mini", alias="OPENAI_MODEL")
    azure_openai_api_key: str = Field(default="", alias="AZURE_OPENAI_API_KEY")
    azure_openai_endpoint: str = Field(default="", alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_deployment_name: str = Field(
        default="gpt-5-mini", alias="AZURE_OPENAI_DEPLOYMENT_NAME"
    )
    azure_openai_api_version: str = Field(
        default="2024-12-01-preview", alias="AZURE_OPENAI_API_VERSION"
    )
    llm_temperature: float = Field(default=1.0, alias="LLM_TEMPERATURE", ge=0.0, le=2.0)
    scenario_audit_log_path: str = Field(
        default="data/generated_scenarios.jsonl", alias="SCENARIO_AUDIT_LOG_PATH"
    )
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    max_request_bytes: int = Field(default=262144, alias="MAX_REQUEST_BYTES")
    cors_allowed_origins: str = Field(
        default="http://127.0.0.1:5500,http://localhost:5500",
        alias="CORS_ALLOWED_ORIGINS",
    )

    @field_validator("llm_provider")
    @classmethod
    def validate_llm_provider(cls, value: str) -> str:
        normalized = value.lower().strip()
        if normalized not in {"mock", "openai", "azure_openai"}:
            raise ValueError("LLM_PROVIDER must be mock, openai, or azure_openai")
        return normalized

    def validate_openai_ready(self) -> None:
        if self.llm_provider == "openai" and not self.openai_api_key:
            raise RuntimeError("LLM_PROVIDER=openai requires OPENAI_API_KEY to be configured")

    def validate_azure_openai_ready(self) -> None:
        if self.llm_provider != "azure_openai":
            return
        missing = []
        if not self.azure_openai_api_key:
            missing.append("AZURE_OPENAI_API_KEY")
        if not self.azure_openai_endpoint:
            missing.append("AZURE_OPENAI_ENDPOINT")
        if not self.azure_openai_deployment_name:
            missing.append("AZURE_OPENAI_DEPLOYMENT_NAME")
        if not self.azure_openai_api_version:
            missing.append("AZURE_OPENAI_API_VERSION")
        if missing:
            raise RuntimeError(
                "LLM_PROVIDER=azure_openai requires these settings: " + ", ".join(missing)
            )

    @property
    def cors_origins(self) -> list[str]:
        return [
            origin.strip()
            for origin in self.cors_allowed_origins.split(",")
            if origin.strip()
        ]


@lru_cache
def get_settings() -> Settings:
    return Settings()
