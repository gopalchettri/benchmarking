from pydantic import BaseModel, ConfigDict, Field


class ControlOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    control_name: str
    control_purpose: str
    required_evidence: list[str] = Field(default_factory=list)


class RiskSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    applicability_score: float
    likelihood_score: int
    impact_score: int
    priority_score: int
    priority_rating: str
    residual_concern: str


class ScenarioOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scenario_title: str
    scenario_statement: str
    threat_actor: list[str]
    threat_category: str
    threat_type: str
    threat_name: str
    target_sector: str
    target_asset: str
    supported_service: str
    service_function: str
    high_level_attack_path: str
    business_impact: list[str]
    operational_impact: list[str]
    cii_impact: list[str]
    mapped_controls: list[ControlOutput]
    required_evidence: list[str]
    control_gap_summary: str
    risk_summary: RiskSummary
    assumptions: list[str]
    excluded_details: list[str]
