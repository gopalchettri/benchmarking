from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from app.models.domain_models import (
    ApplicabilityResult,
    ContextProfile,
    ControlProfile,
    EvidenceRequirements,
    IdentifiedThreat,
    NormalizedInput,
    RiskAssessment,
    ScenarioValidationResult,
)
from app.models.llm_models import ScenarioOutput


class GenerateScenarioResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    generated_scenario_id: str
    request_id: str
    status: Literal["Generated", "Rejected"] = "Generated"
    rejection_reason: str | None = None
    input_parameters: dict[str, Any]
    normalized_input: NormalizedInput
    context_profile: ContextProfile
    identified_threat: IdentifiedThreat
    applicability_result: ApplicabilityResult
    risk_assessment: RiskAssessment | None = None
    control_profile: ControlProfile | None = None
    evidence_requirements: EvidenceRequirements | None = None
    scenario: ScenarioOutput | None = None
    validation_result: ScenarioValidationResult
    audit_trace: dict[str, Any] = Field(default_factory=dict)


class BatchGenerateScenarioResponse(BaseModel):
    results: list[GenerateScenarioResponse]
