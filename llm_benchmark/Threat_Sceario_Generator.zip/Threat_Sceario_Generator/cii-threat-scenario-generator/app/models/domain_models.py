from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class NormalizedInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    threat_category: str
    threat_type: str
    threat_actor: list[str]
    threat_sector: str
    threat_name: str
    control_name: list[str]
    asset: str
    service: str
    canonical: dict[str, Any]


class ValidationOutcome(BaseModel):
    status: Literal["Passed", "PassedWithWarnings", "Failed"]
    warnings: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


class ContextProfile(BaseModel):
    sector: str
    subsector: str | None = None
    entity: str | None = None
    asset: str
    asset_id: str | None = None
    service: str
    service_function: str
    environment_type: str
    criticality: str
    functions: list[str] = Field(default_factory=list)
    data_handled: list[str] = Field(default_factory=list)
    dependent_systems: list[str] = Field(default_factory=list)
    availability_requirement: str
    integrity_requirement: str
    confidentiality_requirement: str
    privilege_context: list[str] = Field(default_factory=list)
    interfaces: list[str] = Field(default_factory=list)
    technology_flags: dict[str, bool] = Field(default_factory=dict)
    service_criticality: str = "Medium"
    context_confidence: float = Field(ge=0.0, le=1.0)
    context_warnings: list[str] = Field(default_factory=list)


class IdentifiedThreat(BaseModel):
    threat_category: str
    threat_type: str
    threat_actor: list[str]
    threat_sector: str
    threat_name: str
    security_objective: str
    match_confidence: float = Field(ge=0.0, le=1.0)
    match_status: Literal["ExactMatch", "PartialMatch", "CustomThreat"]


class ApplicabilityResult(BaseModel):
    status: Literal["Pass", "Rejected", "Conditional"]
    applicability_score: float = Field(ge=0.0, le=1.0)
    checks: dict[str, bool]
    rejection_reason: str | None = None
    reason: str


class RiskAssessment(BaseModel):
    likelihood_score: int = Field(ge=1, le=5)
    impact_score: int = Field(ge=1, le=5)
    priority_score: int = Field(ge=1, le=25)
    priority_rating: str
    inherent_risk_score: int
    inherent_risk_rating: str
    residual_concern: str | None = None
    ranking_reason: str


class ControlProfile(BaseModel):
    mapped_controls: list[dict[str, Any]]
    control_coverage_score: float = Field(ge=0.0, le=1.0)
    control_effectiveness_status: str
    control_warnings: list[str] = Field(default_factory=list)


class EvidenceRequirements(BaseModel):
    evidence_status: str
    required_artifacts: list[str]
    control_gap_summary: str
    evidence_confidence_score: float = Field(ge=0.0, le=1.0)


class ScenarioValidationResult(BaseModel):
    validation_status: Literal["Passed", "Failed", "PassedWithWarnings", "NotGenerated"]
    validation_errors: list[str] = Field(default_factory=list)
    validation_warnings: list[str] = Field(default_factory=list)
    human_review_required: bool
