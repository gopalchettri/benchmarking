from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class GenerateScenarioRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    threat_category: str = Field(..., min_length=1, max_length=200)
    threat_type: str = Field(..., min_length=1, max_length=300)
    threat_actor: str | list[str]
    threat_sector: str = Field(..., min_length=1, max_length=200)
    threat_name: str = Field(..., min_length=1, max_length=500)
    control_name: str | list[str]
    asset: str = Field(..., min_length=1, max_length=300)
    service: str = Field(..., min_length=1, max_length=300)

    @field_validator("*", mode="before")
    @classmethod
    def reject_empty_values(cls, value: Any) -> Any:
        if isinstance(value, str) and not value.strip():
            raise ValueError("empty strings are not allowed")
        if isinstance(value, list):
            if not value:
                raise ValueError("empty lists are not allowed")
            cleaned = []
            for item in value:
                if not isinstance(item, str) or not item.strip():
                    raise ValueError("list values must be non-empty strings")
                cleaned.append(item.strip())
            return cleaned
        return value

    @field_validator("threat_actor")
    @classmethod
    def validate_threat_actor_size(cls, value: str | list[str]) -> str | list[str]:
        if isinstance(value, str) and len(value) > 1000:
            raise ValueError("threat_actor is too large")
        if isinstance(value, list) and len(value) > 20:
            raise ValueError("too many threat actors")
        return value

    @field_validator("control_name")
    @classmethod
    def validate_control_name_size(cls, value: str | list[str]) -> str | list[str]:
        if isinstance(value, str) and len(value) > 2000:
            raise ValueError("control_name is too large")
        if isinstance(value, list) and len(value) > 50:
            raise ValueError("too many controls")
        return value


class BatchGenerateScenarioRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[GenerateScenarioRequest] = Field(..., min_length=1, max_length=50)
