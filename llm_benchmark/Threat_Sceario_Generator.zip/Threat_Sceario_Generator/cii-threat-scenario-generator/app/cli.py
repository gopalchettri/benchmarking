import argparse
import json

from app.config import get_settings
from app.models.request_models import GenerateScenarioRequest
from app.services.scenario_service import ScenarioService

SAMPLE_REQUEST = {
    "threat_category": "Denial of Service",
    "threat_type": "DDoS Attack on Nodes",
    "threat_actor": "Malicious insiders, Hackers",
    "threat_sector": "Industry",
    "threat_name": "Disruption of MES service nodes affecting production scheduling",
    "control_name": (
        "High Availability Architecture, Network Segmentation, Spare Capacity, Tested Failover, "
        "Manual Operating Procedures"
    ),
    "asset": "Manufacturing Execution Platform",
    "service": "Manufacturing Execution and Production Scheduling",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    generate = subparsers.add_parser("generate")
    generate.add_argument("--sample", action="store_true")
    generate.add_argument("--input-file")
    args = parser.parse_args()

    if args.command == "generate":
        if args.sample:
            payload = SAMPLE_REQUEST
        elif args.input_file:
            with open(args.input_file, encoding="utf-8") as handle:
                payload = json.load(handle)
        else:
            raise SystemExit("Use --sample or --input-file")
        response = ScenarioService(get_settings()).generate_scenario(
            GenerateScenarioRequest.model_validate(payload)
        )
        print(json.dumps(response.model_dump(mode="json"), indent=2))


if __name__ == "__main__":
    main()
