from fastapi import APIRouter, Depends, HTTPException

from app.config import Settings, get_settings
from app.models.request_models import BatchGenerateScenarioRequest, GenerateScenarioRequest
from app.models.response_models import BatchGenerateScenarioResponse, GenerateScenarioResponse
from app.services import data_loader
from app.services.audit_logger import AuditLogger
from app.services.scenario_service import ScenarioService

router = APIRouter()


def get_service(settings: Settings = Depends(get_settings)) -> ScenarioService:
    return ScenarioService(settings)


@router.get("/health")
def health(settings: Settings = Depends(get_settings)) -> dict[str, str]:
    return {
        "status": "ok",
        "service": "cii-threat-scenario-generator",
        "llm_provider": settings.llm_provider,
    }


@router.post("/generate-scenario", response_model=GenerateScenarioResponse)
def generate_scenario(
    request: GenerateScenarioRequest, service: ScenarioService = Depends(get_service)
) -> GenerateScenarioResponse:
    return service.generate_scenario(request)


@router.post("/generate-scenario/batch", response_model=BatchGenerateScenarioResponse)
def generate_scenario_batch(
    request: BatchGenerateScenarioRequest, service: ScenarioService = Depends(get_service)
) -> BatchGenerateScenarioResponse:
    return BatchGenerateScenarioResponse(
        results=[service.generate_scenario(item) for item in request.items]
    )


@router.get("/metadata/threat-categories")
def threat_categories() -> dict[str, list[str]]:
    return {
        "items": sorted({item["threat_category"] for item in data_loader.load_threat_library()})
    }


@router.get("/metadata/threat-types")
def threat_types() -> dict[str, list[str]]:
    return {"items": sorted({item["threat_type"] for item in data_loader.load_threat_library()})}


@router.get("/metadata/assets")
def assets() -> dict[str, list[str]]:
    return {"items": sorted({item["asset"] for item in data_loader.load_asset_metadata()})}


@router.get("/metadata/services")
def services() -> dict[str, list[str]]:
    return {"items": sorted({item["service"] for item in data_loader.load_service_metadata()})}


@router.get("/scenarios/{scenario_id}", response_model=GenerateScenarioResponse)
def get_scenario(
    scenario_id: str, settings: Settings = Depends(get_settings)
) -> GenerateScenarioResponse:
    record = AuditLogger(settings.scenario_audit_log_path).find(scenario_id)
    if not record:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return GenerateScenarioResponse.model_validate(record)
