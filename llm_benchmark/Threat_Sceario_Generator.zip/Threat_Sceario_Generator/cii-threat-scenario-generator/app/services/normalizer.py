from app.models.domain_models import NormalizedInput
from app.models.request_models import GenerateScenarioRequest


def canonical(value: str) -> str:
    return " ".join(value.strip().lower().split())


def split_csv_or_list(value: str | list[str]) -> list[str]:
    raw_items = value if isinstance(value, list) else value.split(",")
    return [item.strip() for item in raw_items if item and item.strip()]


def _singularize_actor(actor: str) -> str:
    mapping = {
        "malicious insiders": "Malicious insider",
        "hackers": "Hacker",
        "fraudsters": "Fraudster",
    }
    return mapping.get(canonical(actor), actor.strip())


def normalize_request(request: GenerateScenarioRequest) -> NormalizedInput:
    actors = [_singularize_actor(item) for item in split_csv_or_list(request.threat_actor)]
    controls = split_csv_or_list(request.control_name)
    return NormalizedInput(
        threat_category=request.threat_category.strip(),
        threat_type=request.threat_type.strip(),
        threat_actor=actors,
        threat_sector=request.threat_sector.strip(),
        threat_name=request.threat_name.strip(),
        control_name=controls,
        asset=request.asset.strip(),
        service=request.service.strip(),
        canonical={
            "threat_category": canonical(request.threat_category),
            "threat_type": canonical(request.threat_type),
            "threat_actor": [canonical(item) for item in actors],
            "threat_sector": canonical(request.threat_sector),
            "threat_name": canonical(request.threat_name),
            "control_name": [canonical(item) for item in controls],
            "asset": canonical(request.asset),
            "service": canonical(request.service),
        },
    )
