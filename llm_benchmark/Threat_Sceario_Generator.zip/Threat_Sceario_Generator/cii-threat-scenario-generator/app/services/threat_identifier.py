from app.models.domain_models import ContextProfile, IdentifiedThreat, NormalizedInput
from app.services import data_loader
from app.services.normalizer import canonical

REQUIRED_MATCH_CONFIDENCE_KEYS = {"exact", "partial", "custom"}


def identify(normalized: NormalizedInput, context: ContextProfile) -> IdentifiedThreat:
    del context
    threats = data_loader.load_threat_library()
    rules = data_loader.load_applicability_rules()
    scoring_rules = data_loader.load_scoring_rules()
    match_confidence = scoring_rules.get("threat_match_confidence", {})
    missing_confidence_rules = REQUIRED_MATCH_CONFIDENCE_KEYS - set(match_confidence)
    if missing_confidence_rules:
        missing = ", ".join(sorted(missing_confidence_rules))
        raise RuntimeError(f"Missing threat match confidence rules: {missing}")
    objective = rules["category_objectives"].get(normalized.threat_category, "Unknown")
    exact = next(
        (
            item
            for item in threats
            if canonical(item["threat_category"]) == normalized.canonical["threat_category"]
            and canonical(item["threat_type"]) == normalized.canonical["threat_type"]
        ),
        None,
    )
    partial = exact or next(
        (
            item
            for item in threats
            if canonical(item["threat_category"]) == normalized.canonical["threat_category"]
        ),
        None,
    )
    source = exact or partial
    if source:
        status = "ExactMatch" if exact else "PartialMatch"
        confidence = match_confidence["exact"] if exact else match_confidence["partial"]
        return IdentifiedThreat(
            threat_category=normalized.threat_category,
            threat_type=normalized.threat_type,
            threat_actor=normalized.threat_actor,
            threat_sector=normalized.threat_sector,
            threat_name=normalized.threat_name,
            security_objective=objective,
            match_confidence=confidence,
            match_status=status,
        )
    return IdentifiedThreat(
        threat_category=normalized.threat_category,
        threat_type=normalized.threat_type,
        threat_actor=normalized.threat_actor,
        threat_sector=normalized.threat_sector,
        threat_name=normalized.threat_name,
        security_objective=objective,
        match_confidence=match_confidence["custom"],
        match_status="CustomThreat",
    )
