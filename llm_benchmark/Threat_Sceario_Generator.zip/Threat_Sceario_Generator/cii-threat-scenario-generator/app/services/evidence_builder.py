from app.models.domain_models import ControlProfile, EvidenceRequirements
from app.services import data_loader

REQUIRED_EVIDENCE_CONFIDENCE_KEYS = {"pending_validation"}


def build(controls: ControlProfile) -> EvidenceRequirements:
    confidence_rules = data_loader.load_scoring_rules().get("evidence_confidence_scores", {})
    missing_confidence_rules = REQUIRED_EVIDENCE_CONFIDENCE_KEYS - set(confidence_rules)
    if missing_confidence_rules:
        missing = ", ".join(sorted(missing_confidence_rules))
        raise RuntimeError(f"Missing evidence confidence score rules: {missing}")
    required: list[str] = []
    for control in controls.mapped_controls:
        for artifact in control.get("required_evidence", []):
            if artifact not in required:
                required.append(artifact)
    return EvidenceRequirements(
        evidence_status="Pending Validation",
        required_artifacts=required,
        control_gap_summary=(
            "Controls are identified, but implementation evidence must be validated before "
            "residual risk can be reduced."
        ),
        evidence_confidence_score=confidence_rules["pending_validation"],
    )
