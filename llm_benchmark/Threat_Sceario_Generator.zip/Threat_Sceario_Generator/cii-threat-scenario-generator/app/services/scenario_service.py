import hashlib
import json
import uuid

from fastapi import HTTPException

from app.config import Settings
from app.models.domain_models import ScenarioValidationResult
from app.models.request_models import GenerateScenarioRequest
from app.models.response_models import GenerateScenarioResponse
from app.services import (
    applicability_engine,
    context_builder,
    control_identifier,
    evidence_builder,
    llm_input_builder,
    normalizer,
    ranking_engine,
    scenario_validator,
    threat_identifier,
    validator,
)
from app.services.audit_logger import AuditLogger
from app.services.llm_client import LLMClientError, build_llm_client
from app.services.normalizer import canonical


def _sector_code(sector: str) -> str:
    if sector.lower().startswith("industry"):
        return "IND"
    return "".join(part[0].upper() for part in sector.split() if part)[:4] or "GEN"


def _category_code(category: str) -> str:
    rules = ranking_engine.load_scoring_rules()
    return rules.get("category_codes", {}).get(canonical(category), "GEN")


def _scenario_id(sector: str, asset_id: str | None, category: str, request_hash: str) -> str:
    sector_code = _sector_code(sector)
    category_code = _category_code(category)
    return f"GEN-{sector_code}-{asset_id or 'ASSET'}-{category_code}-{request_hash[:6].upper()}"


def _stable_hash(payload: dict) -> str:
    canonical_payload = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical_payload.encode("utf-8")).hexdigest()


class ScenarioService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.audit_logger = AuditLogger(settings.scenario_audit_log_path)

    def generate_scenario(self, request: GenerateScenarioRequest) -> GenerateScenarioResponse:
        request_id = str(uuid.uuid4())
        request_dump = request.model_dump(mode="json")
        request_hash = _stable_hash(request_dump)
        normalized = normalizer.normalize_request(request)
        validation = validator.validate(normalized)
        if validation.status == "Failed":
            raise HTTPException(status_code=422, detail={"errors": validation.errors})

        context = context_builder.build_context(normalized)
        threat = threat_identifier.identify(normalized, context)
        applicability = applicability_engine.evaluate(normalized, context, threat)
        generated_id = _scenario_id(
            context.sector, context.asset_id, threat.threat_category, request_hash
        )

        if applicability.status == "Rejected":
            response = GenerateScenarioResponse(
                generated_scenario_id=generated_id,
                request_id=request_id,
                status="Rejected",
                rejection_reason=applicability.rejection_reason,
                input_parameters=request_dump,
                normalized_input=normalized,
                context_profile=context,
                identified_threat=threat,
                applicability_result=applicability,
                risk_assessment=None,
                control_profile=None,
                evidence_requirements=None,
                scenario=None,
                validation_result=ScenarioValidationResult(
                    validation_status="NotGenerated",
                    human_review_required=False,
                ),
                audit_trace={"request_id": request_id, "llm_called": False},
            )
            self.audit_logger.append(request_dump, response)
            return response

        risk = ranking_engine.rank(normalized, context, threat, applicability)
        controls = control_identifier.identify(normalized, context, threat)
        evidence = evidence_builder.build(controls)
        risk.residual_concern = (
            "Residual risk remains elevated until identified controls are supported by validated "
            "implementation evidence."
        )
        pack = llm_input_builder.build(
            normalized, context, threat, applicability, risk, controls, evidence
        )
        try:
            scenario = build_llm_client(self.settings).generate_scenario(pack)
        except RuntimeError as exc:
            status = 503 if "requires" in str(exc) else 500
            raise HTTPException(status_code=status, detail=str(exc)) from exc
        except LLMClientError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

        validation_result = scenario_validator.validate(
            scenario, normalized, context, applicability, risk, controls, evidence
        )
        response = GenerateScenarioResponse(
            generated_scenario_id=generated_id,
            request_id=request_id,
            input_parameters=request_dump,
            normalized_input=normalized,
            context_profile=context,
            identified_threat=threat,
            applicability_result=applicability,
            risk_assessment=risk,
            control_profile=controls,
            evidence_requirements=evidence,
            scenario=scenario,
            validation_result=validation_result,
            audit_trace={
                "request_id": request_id,
                "llm_called": True,
                "validation_input_status": validation.status,
                "validation_warnings": validation.warnings,
            },
        )
        self.audit_logger.append(request_dump, response)
        return response
