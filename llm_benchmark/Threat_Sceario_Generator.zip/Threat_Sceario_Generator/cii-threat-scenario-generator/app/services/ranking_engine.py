from app.models.domain_models import (
    ApplicabilityResult,
    ContextProfile,
    IdentifiedThreat,
    NormalizedInput,
    RiskAssessment,
)
from app.services import data_loader
from app.services.normalizer import canonical


def load_scoring_rules() -> dict:
    return data_loader.load_scoring_rules()


def _rating(score: int, matrix: dict) -> str:
    if score <= matrix["low_max"]:
        return "Low"
    if score <= matrix["medium_max"]:
        return "Medium"
    if score <= matrix["high_max"]:
        return "High"
    return "Critical"


def rank(
    normalized: NormalizedInput,
    context: ContextProfile,
    threat: IdentifiedThreat,
    applicability: ApplicabilityResult,
) -> RiskAssessment:
    rules = load_scoring_rules()
    criticality_score = rules["criticality_scores"].get(context.criticality, 3)
    service_score = rules["criticality_scores"].get(context.service_criticality, 3)
    availability_score = rules["availability_scores"].get(context.availability_requirement, 3)
    exposure_level = 2
    if context.technology_flags.get("has_remote_access") or any(
        "remote" in canonical(item) for item in context.interfaces
    ):
        exposure_level = 4
    elif context.interfaces:
        exposure_level = 3
    capable_actors = {"hacker", "malicious insider", "advanced threat actor"}
    threat_actor_capability = (
        4 if any(canonical(actor) in capable_actors for actor in threat.threat_actor) else 3
    )
    applicability_component = max(1, round(applicability.applicability_score * 5))
    likelihood = round((threat_actor_capability + exposure_level + applicability_component) / 3)
    impact = max(criticality_score, service_score, availability_score)
    score = likelihood * impact
    rating = _rating(score, rules["risk_matrix"])
    return RiskAssessment(
        likelihood_score=likelihood,
        impact_score=impact,
        priority_score=score,
        priority_rating=rating,
        inherent_risk_score=score,
        inherent_risk_rating=rating,
        ranking_reason=(
            f"Likelihood reflects actor capability, exposure, and applicability; impact reflects "
            f"{context.criticality} asset criticality and "
            f"{context.availability_requirement} availability."
        ),
    )
