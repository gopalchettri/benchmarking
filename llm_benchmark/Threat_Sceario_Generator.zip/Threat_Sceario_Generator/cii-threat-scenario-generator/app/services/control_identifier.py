from app.models.domain_models import (
    ContextProfile,
    ControlProfile,
    IdentifiedThreat,
    NormalizedInput,
)
from app.services import data_loader
from app.services.normalizer import canonical

REQUIRED_CONTROL_COVERAGE_KEYS = {
    "three_or_more_resolved",
    "one_or_two_resolved",
    "unresolved_only",
    "none",
}


def identify(
    normalized: NormalizedInput, context: ContextProfile, threat: IdentifiedThreat
) -> ControlProfile:
    del context
    mappings = data_loader.load_threat_control_mappings()
    mapped_names: list[str] = []
    for mapping in mappings:
        if canonical(mapping["threat_category"]) == canonical(threat.threat_category) and canonical(
            mapping["threat_type"]
        ) == canonical(threat.threat_type):
            mapped_names = mapping["mapped_control_names"]
            break
    combined: list[str] = []
    for name in [*normalized.control_name, *mapped_names]:
        if canonical(name) not in {canonical(existing) for existing in combined}:
            combined.append(name)

    controls = data_loader.load_control_library()
    resolved = []
    warnings = []
    for name in combined:
        control = next(
            (item for item in controls if canonical(item["control_name"]) == canonical(name)), None
        )
        in_input = canonical(name) in normalized.canonical["control_name"]
        in_mapping = canonical(name) in {canonical(item) for item in mapped_names}
        source = (
            "input_and_mapping" if in_input and in_mapping else "input" if in_input else "mapping"
        )
        if control:
            resolved.append(
                {
                    "control_name": control["control_name"],
                    "control_description": control["control_description"],
                    "required_evidence": control.get("required_evidence", []),
                    "source": source,
                    "match_status": "Resolved",
                }
            )
        else:
            warnings.append(f"Control was not found in library: {name}")
            resolved.append(
                {
                    "control_name": name,
                    "control_description": "User-supplied control not resolved in control library.",
                    "required_evidence": [],
                    "source": source,
                    "match_status": "Unresolved",
                }
            )
    resolved_count = sum(1 for item in resolved if item["match_status"] == "Resolved")
    coverage_rules = data_loader.load_scoring_rules().get("control_coverage_scores", {})
    missing_coverage_rules = REQUIRED_CONTROL_COVERAGE_KEYS - set(coverage_rules)
    if missing_coverage_rules:
        missing = ", ".join(sorted(missing_coverage_rules))
        raise RuntimeError(f"Missing control coverage score rules: {missing}")
    if resolved_count >= 3:
        coverage = coverage_rules["three_or_more_resolved"]
    elif resolved_count >= 1:
        coverage = coverage_rules["one_or_two_resolved"]
    elif resolved:
        coverage = coverage_rules["unresolved_only"]
    else:
        coverage = coverage_rules["none"]
    return ControlProfile(
        mapped_controls=resolved,
        control_coverage_score=coverage,
        control_effectiveness_status="Requires evidence validation",
        control_warnings=warnings,
    )
