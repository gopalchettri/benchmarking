import hashlib
import json
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.models.response_models import GenerateScenarioResponse

_WRITE_LOCK = threading.Lock()


class AuditLogger:
    def __init__(self, log_path: str):
        self.log_path = Path(log_path)

    def append(self, request: dict[str, Any], response: GenerateScenarioResponse) -> None:
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        request_json = json.dumps(request, sort_keys=True, separators=(",", ":"), default=str)
        record = {
            "timestamp_utc": datetime.now(UTC).isoformat(),
            "generated_scenario_id": response.generated_scenario_id,
            "input_hash": hashlib.sha256(request_json.encode("utf-8")).hexdigest(),
            "request": request,
            "response": response.model_dump(mode="json"),
            "validation_status": response.validation_result.validation_status,
        }
        with _WRITE_LOCK:
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, separators=(",", ":")) + "\n")

    def find(self, scenario_id: str) -> dict[str, Any] | None:
        if not self.log_path.exists():
            return None
        with self.log_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                record = json.loads(line)
                if record.get("generated_scenario_id") == scenario_id:
                    return record["response"]
        return None
