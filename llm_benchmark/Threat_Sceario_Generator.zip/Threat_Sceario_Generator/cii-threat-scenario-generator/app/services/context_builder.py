from app.models.domain_models import ContextProfile, NormalizedInput
from app.services import data_loader
from app.services.normalizer import canonical

REQUIRED_CONFIDENCE_PENALTY_KEYS = {"missing_asset", "missing_service", "missing_taxonomy"}


def _find_by(items: list[dict], key: str, value: str) -> dict | None:
    wanted = canonical(value)
    return next((item for item in items if canonical(str(item.get(key, ""))) == wanted), None)


def build_context(normalized: NormalizedInput) -> ContextProfile:
    asset = _find_by(data_loader.load_asset_metadata(), "asset", normalized.asset)
    service = _find_by(data_loader.load_service_metadata(), "service", normalized.service)
    taxonomy = next(
        (
            item
            for item in data_loader.load_business_taxonomy()
            if canonical(item["asset"]) == canonical(normalized.asset)
            and canonical(item["service"]) == canonical(normalized.service)
        ),
        None,
    )
    warnings: list[str] = []
    penalties = data_loader.load_scoring_rules().get("context_confidence_penalties", {})
    missing_penalties = REQUIRED_CONFIDENCE_PENALTY_KEYS - set(penalties)
    if missing_penalties:
        missing = ", ".join(sorted(missing_penalties))
        raise RuntimeError(f"Missing context confidence penalty rules: {missing}")
    confidence = 1.0
    if not asset:
        confidence -= penalties["missing_asset"]
        warnings.append("Asset metadata was not found; fallback asset context used.")
    if not service:
        confidence -= penalties["missing_service"]
        warnings.append("Service metadata was not found; fallback service context used.")
    if not taxonomy:
        confidence -= penalties["missing_taxonomy"]
        warnings.append("Business taxonomy mapping was not found.")

    return ContextProfile(
        sector=(asset or service or {}).get("sector", normalized.threat_sector),
        subsector=(taxonomy or {}).get("subsector"),
        entity=(taxonomy or {}).get("entity"),
        asset=normalized.asset,
        asset_id=(asset or {}).get("asset_id"),
        service=normalized.service,
        service_function=(service or {}).get(
            "service_function", f"Supports the {normalized.service} service."
        ),
        environment_type=(asset or {}).get("environment_type", "Unknown environment"),
        criticality=(asset or {}).get(
            "criticality", (service or {}).get("service_criticality", "Medium")
        ),
        functions=(asset or {}).get("functions", []),
        data_handled=(asset or {}).get("data_handled", []),
        dependent_systems=(asset or {}).get("dependent_systems", []),
        availability_requirement=(asset or service or {}).get(
            "availability_requirement", "Unknown"
        ),
        integrity_requirement=(asset or {}).get("integrity_requirement", "Unknown"),
        confidentiality_requirement=(asset or {}).get("confidentiality_requirement", "Unknown"),
        privilege_context=(asset or {}).get("privilege_context", []),
        interfaces=(asset or {}).get("interfaces", []),
        technology_flags=(asset or {}).get("technology_flags", {}),
        service_criticality=(service or {}).get("service_criticality", "Medium"),
        context_confidence=max(confidence, 0.0),
        context_warnings=warnings,
    )
