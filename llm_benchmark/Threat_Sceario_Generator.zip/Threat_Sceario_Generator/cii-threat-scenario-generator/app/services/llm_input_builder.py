from app.models.domain_models import (
    ApplicabilityResult,
    ContextProfile,
    ControlProfile,
    EvidenceRequirements,
    IdentifiedThreat,
    NormalizedInput,
    RiskAssessment,
)


def build(
    normalized: NormalizedInput,
    context: ContextProfile,
    threat: IdentifiedThreat,
    applicability: ApplicabilityResult,
    risk: RiskAssessment,
    controls: ControlProfile,
    evidence: EvidenceRequirements,
) -> dict:
    return {
        "scenario_generation_mode": "CII defensive threat scenario",
        "input_parameters": normalized.model_dump(exclude={"canonical"}),
        "context_profile": context.model_dump(),
        "identified_threat": threat.model_dump(),
        "applicability_result": applicability.model_dump(),
        "risk_assessment": risk.model_dump(),
        "control_profile": controls.model_dump(),
        "evidence_requirements": evidence.model_dump(),
        "generation_constraints": {
            "do_not_invent_assets": True,
            "do_not_invent_controls": True,
            "do_not_include_exploit_steps": True,
            "use_only_supplied_context": True,
            "state_assumptions": True,
            "include_business_impact": True,
            "include_control_gaps": True,
            "output_defensive_risk_scenario_only": True,
        },
    }
