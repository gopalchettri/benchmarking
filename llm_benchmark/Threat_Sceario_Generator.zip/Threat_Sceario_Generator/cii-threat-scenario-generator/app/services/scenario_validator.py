from app.models.domain_models import (
    ApplicabilityResult,
    ContextProfile,
    ControlProfile,
    EvidenceRequirements,
    NormalizedInput,
    RiskAssessment,
    ScenarioValidationResult,
)
from app.models.llm_models import ScenarioOutput
from app.services.normalizer import canonical

UNSAFE_TERMS = [
    "payload",
    "exploit code",
    "step-by-step exploit",
    "bypass authentication by",
    "run this command",
    "malware code",
    "credential theft instructions",
]


def validate(
    scenario: ScenarioOutput,
    normalized: NormalizedInput,
    context: ContextProfile,
    applicability: ApplicabilityResult,
    risk: RiskAssessment,
    controls: ControlProfile,
    evidence: EvidenceRequirements,
) -> ScenarioValidationResult:
    errors: list[str] = []
    warnings: list[str] = []
    if scenario.target_asset != normalized.asset:
        errors.append("Scenario invented or changed the target asset.")
    if scenario.supported_service != normalized.service:
        errors.append("Scenario invented or changed the supported service.")
    if scenario.threat_category != normalized.threat_category:
        errors.append("Scenario changed the threat category.")
    if scenario.threat_type != normalized.threat_type:
        errors.append("Scenario changed the threat type.")
    if scenario.threat_name != normalized.threat_name:
        errors.append("Scenario changed the threat name.")
    allowed_actors = {canonical(item) for item in normalized.threat_actor}
    if any(canonical(actor) not in allowed_actors for actor in scenario.threat_actor):
        errors.append("Scenario contains threat actors not supplied or resolved by the engine.")
    allowed_controls = {canonical(item["control_name"]) for item in controls.mapped_controls}
    if any(
        canonical(control.control_name) not in allowed_controls
        for control in scenario.mapped_controls
    ):
        errors.append("Scenario contains invented controls.")
    unsafe_scan_payload = scenario.model_dump(exclude={"excluded_details"})
    serialized = str(unsafe_scan_payload).lower()
    for term in UNSAFE_TERMS:
        if term in serialized:
            errors.append(f"Scenario contains unsafe content term: {term}")
    if not scenario.required_evidence:
        warnings.append("Scenario does not include required evidence.")
    human_review = (
        risk.priority_rating in {"High", "Critical"}
        or applicability.status == "Conditional"
        or evidence.evidence_status == "Pending Validation"
        or context.criticality == "High"
    )
    if errors:
        return ScenarioValidationResult(
            validation_status="Failed",
            validation_errors=errors,
            validation_warnings=warnings,
            human_review_required=True,
        )
    return ScenarioValidationResult(
        validation_status="PassedWithWarnings" if warnings else "Passed",
        validation_warnings=warnings,
        human_review_required=human_review,
    )
