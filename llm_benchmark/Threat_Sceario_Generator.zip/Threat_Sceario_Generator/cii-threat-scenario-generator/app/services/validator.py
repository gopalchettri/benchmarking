from app.models.domain_models import NormalizedInput, ValidationOutcome
from app.services import data_loader
from app.services.normalizer import canonical


def validate(normalized: NormalizedInput) -> ValidationOutcome:
    warnings: list[str] = []
    errors: list[str] = []
    threats = data_loader.load_threat_library()
    rules = data_loader.load_applicability_rules()
    assets = data_loader.load_asset_metadata()
    services = data_loader.load_service_metadata()

    categories = {canonical(item["threat_category"]) for item in threats}
    categories.update(canonical(item) for item in rules["category_objectives"])
    threat_types = {canonical(item["threat_type"]) for item in threats}
    known_assets = {canonical(item["asset"]) for item in assets}
    known_services = {canonical(item["service"]) for item in services}

    if normalized.canonical["threat_category"] not in categories:
        errors.append("Unknown threat category.")
    if normalized.canonical["threat_type"] not in threat_types:
        warnings.append("Unknown threat type; scenario will use custom-threat matching.")
    if normalized.canonical["asset"] not in known_assets:
        warnings.append("Unknown asset; fallback context will be used.")
    if normalized.canonical["service"] not in known_services:
        warnings.append("Unknown service; fallback service context will be used.")

    if errors:
        return ValidationOutcome(status="Failed", warnings=warnings, errors=errors)
    return ValidationOutcome(
        status="PassedWithWarnings" if warnings else "Passed", warnings=warnings
    )
