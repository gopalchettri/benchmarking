import json
from abc import ABC, abstractmethod
from typing import Any

from app.config import Settings
from app.models.llm_models import ControlOutput, RiskSummary, ScenarioOutput
from app.prompts.scenario_prompt import SYSTEM_PROMPT, build_user_prompt


class LLMClientError(RuntimeError):
    pass


class BaseLLMClient(ABC):
    @abstractmethod
    def generate_scenario(self, scenario_input_pack: dict[str, Any]) -> ScenarioOutput:
        raise NotImplementedError


def _generation_options(settings: Settings) -> dict[str, Any]:
    return {"temperature": settings.llm_temperature}


class MockLLMClient(BaseLLMClient):
    def generate_scenario(self, scenario_input_pack: dict[str, Any]) -> ScenarioOutput:
        context = scenario_input_pack["context_profile"]
        threat = scenario_input_pack["identified_threat"]
        risk = scenario_input_pack["risk_assessment"]
        controls = scenario_input_pack["control_profile"]
        evidence = scenario_input_pack["evidence_requirements"]

        title = (
            "Denial-of-Service Disruption of the Manufacturing Execution Platform "
            "Supporting Production Scheduling"
            if threat["threat_category"] == "Denial of Service"
            and context["asset"] == "Manufacturing Execution Platform"
            else f"{threat['threat_category']} Scenario Affecting {context['asset']}"
        )
        functions = context.get("functions") or [context["service"]]
        function_text = ", ".join(item[0].lower() + item[1:] for item in functions[:4])
        control_outputs = [
            ControlOutput(
                control_name=item["control_name"],
                control_purpose=item.get("control_description", "Supports risk reduction."),
                required_evidence=item.get("required_evidence", []),
            )
            for item in controls["mapped_controls"]
        ]
        residual = (
            "Residual risk remains elevated until failover, segmentation, capacity, and manual "
            "operating evidence is verified."
        )
        return ScenarioOutput(
            scenario_title=title,
            scenario_statement=(
                f"A {', '.join(threat['threat_actor']).lower()} disrupts the availability of the "
                f"{context['asset']}, which supports {context['service']} in the "
                f"{context['sector']} sector. The disruption affects service nodes, "
                f"integration paths, or supporting network services used to {function_text}."
            ),
            threat_actor=threat["threat_actor"],
            threat_category=threat["threat_category"],
            threat_type=threat["threat_type"],
            threat_name=threat["threat_name"],
            target_sector=context["sector"],
            target_asset=context["asset"],
            supported_service=context["service"],
            service_function=context["service_function"],
            high_level_attack_path=(
                "The threat actor attempts to degrade service availability by overwhelming service "
                "nodes, disrupting integration paths, or causing resource exhaustion in supporting "
                "network or application components. This is a high-level defensive risk scenario "
                "and does not include exploit instructions."
            ),
            business_impact=[
                "Production orders may not be scheduled or updated on time.",
                "Production schedule continuity may be affected.",
                "Quality checkpoint monitoring may be delayed.",
            ],
            operational_impact=[
                "Work-in-progress visibility may be reduced.",
                "Line instructions may be delayed.",
                "Manual operating procedures may be required during outage.",
            ],
            cii_impact=[
                f"A critical {context['sector'].lower()} service may experience "
                "availability degradation.",
                f"Operational continuity of {context['service']} may be affected.",
            ],
            mapped_controls=control_outputs,
            required_evidence=evidence["required_artifacts"],
            control_gap_summary=evidence["control_gap_summary"],
            risk_summary=RiskSummary(
                applicability_score=scenario_input_pack["applicability_result"][
                    "applicability_score"
                ],
                likelihood_score=risk["likelihood_score"],
                impact_score=risk["impact_score"],
                priority_score=risk["priority_score"],
                priority_rating=risk["priority_rating"],
                residual_concern=residual,
            ),
            assumptions=[
                "The scenario is generated from the supplied asset, service, threat, "
                "and control context.",
                "No implementation evidence has been uploaded in the MVP.",
            ],
            excluded_details=[
                "Exploit instructions are intentionally excluded.",
                "Payloads, commands, and bypass procedures are intentionally excluded.",
            ],
        )


class OpenAILLMClient(BaseLLMClient):
    def __init__(self, settings: Settings):
        self.settings = settings

    def generate_scenario(self, scenario_input_pack: dict[str, Any]) -> ScenarioOutput:
        self.settings.validate_openai_ready()
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise LLMClientError("OpenAI SDK is not installed.") from exc

        client = OpenAI(api_key=self.settings.openai_api_key)
        schema = ScenarioOutput.model_json_schema()
        try:
            if hasattr(client.responses, "parse"):
                parsed = client.responses.parse(
                    model=self.settings.openai_model,
                    input=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": build_user_prompt(scenario_input_pack)},
                    ],
                    text_format=ScenarioOutput,
                    **_generation_options(self.settings),
                )
                return parsed.output_parsed

            response = client.responses.create(
                model=self.settings.openai_model,
                input=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": build_user_prompt(scenario_input_pack)},
                ],
                text={
                    "format": {
                        "type": "json_schema",
                        "name": "ScenarioOutput",
                        "schema": schema,
                        "strict": True,
                    }
                },
                **_generation_options(self.settings),
            )
            content = getattr(response, "output_text", None)
            if not content:
                content = response.output[0].content[0].text
            return ScenarioOutput.model_validate(json.loads(content))
        except Exception as exc:
            raise LLMClientError("OpenAI scenario generation failed.") from exc


class AzureOpenAILLMClient(BaseLLMClient):
    def __init__(self, settings: Settings):
        self.settings = settings

    def generate_scenario(self, scenario_input_pack: dict[str, Any]) -> ScenarioOutput:
        self.settings.validate_azure_openai_ready()
        try:
            from openai import AzureOpenAI
        except ImportError as exc:
            raise LLMClientError("OpenAI SDK is not installed.") from exc

        client = AzureOpenAI(
            api_key=self.settings.azure_openai_api_key,
            azure_endpoint=self.settings.azure_openai_endpoint,
            api_version=self.settings.azure_openai_api_version,
        )
        schema = ScenarioOutput.model_json_schema()
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": build_user_prompt(scenario_input_pack)},
        ]
        try:
            if hasattr(client.beta.chat.completions, "parse"):
                parsed = client.beta.chat.completions.parse(
                    model=self.settings.azure_openai_deployment_name,
                    messages=messages,
                    response_format=ScenarioOutput,
                    **_generation_options(self.settings),
                )
                return parsed.choices[0].message.parsed

            response = client.chat.completions.create(
                model=self.settings.azure_openai_deployment_name,
                messages=messages,
                response_format={
                    "type": "json_schema",
                    "json_schema": {
                        "name": "ScenarioOutput",
                        "schema": schema,
                        "strict": True,
                    },
                },
                **_generation_options(self.settings),
            )
            content = response.choices[0].message.content
            return ScenarioOutput.model_validate(json.loads(content))
        except Exception as exc:
            raise LLMClientError("Azure OpenAI scenario generation failed.") from exc


def build_llm_client(settings: Settings) -> BaseLLMClient:
    if settings.llm_provider == "azure_openai":
        return AzureOpenAILLMClient(settings)
    if settings.llm_provider == "openai":
        return OpenAILLMClient(settings)
    return MockLLMClient()
