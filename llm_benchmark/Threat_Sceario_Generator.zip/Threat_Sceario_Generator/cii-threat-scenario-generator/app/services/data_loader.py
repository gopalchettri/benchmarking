import json
from functools import lru_cache
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parents[2]
SEED_DIR = BASE_DIR / "data" / "seed"


def _load_json(name: str) -> Any:
    with (SEED_DIR / name).open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


@lru_cache
def load_business_taxonomy() -> list[dict[str, Any]]:
    return _load_json("business_taxonomy.json")


@lru_cache
def load_asset_metadata() -> list[dict[str, Any]]:
    return _load_json("asset_metadata.json")


@lru_cache
def load_service_metadata() -> list[dict[str, Any]]:
    return _load_json("service_metadata.json")


@lru_cache
def load_threat_library() -> list[dict[str, Any]]:
    return _load_json("threat_library.json")


@lru_cache
def load_control_library() -> list[dict[str, Any]]:
    return _load_json("control_library.json")


@lru_cache
def load_threat_control_mappings() -> list[dict[str, Any]]:
    return _load_json("threat_control_mappings.json")


@lru_cache
def load_applicability_rules() -> dict[str, Any]:
    return _load_json("applicability_rules.json")


@lru_cache
def load_scoring_rules() -> dict[str, Any]:
    return _load_json("scoring_rules.json")
