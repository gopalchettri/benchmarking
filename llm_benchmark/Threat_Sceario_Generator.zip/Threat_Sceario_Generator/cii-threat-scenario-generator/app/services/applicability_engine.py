from app.models.domain_models import (
    ApplicabilityResult,
    ContextProfile,
    IdentifiedThreat,
    NormalizedInput,
)
from app.services import data_loader
from app.services.normalizer import canonical

REQUIRED_WEIGHT_KEYS = {
    "sector_match",
    "asset_context_match",
    "service_impact_match",
    "category_objective_match",
    "threat_type_match",
    "actor_plausibility",
    "technology_gate_passed",
}


def _gate_for(threat_type: str) -> dict | None:
    return next(
        (
            gate
            for gate in data_loader.load_applicability_rules()["technology_gates"]
            if canonical(gate["threat_type"]) == canonical(threat_type)
        ),
        None,
    )


def _type_relevance_rule_for(threat_type: str) -> dict | None:
    return next(
        (
            rule
            for rule in data_loader.load_applicability_rules().get(
                "threat_type_relevance_rules", []
            )
            if canonical(rule["threat_type"]) == canonical(threat_type)
        ),
        None,
    )


def _matches_type_relevance_rule(rule: dict, context: ContextProfile) -> bool:
    flags = context.technology_flags
    if any(flags.get(flag, False) for flag in rule.get("any_flags", [])):
        return True
    if any(bool(getattr(context, field, None)) for field in rule.get("any_context_fields", [])):
        return True
    for field, allowed_values in rule.get("any_context_values", {}).items():
        context_value = getattr(context, field, None)
        if context_value and canonical(str(context_value)) in {
            canonical(str(value)) for value in allowed_values
        }:
            return True
    return False


def evaluate(
    normalized: NormalizedInput, context: ContextProfile, threat: IdentifiedThreat
) -> ApplicabilityResult:
    flags = context.technology_flags
    gate = _gate_for(threat.threat_type)
    gate_passed = True
    rejection_reason = None
    if gate and not flags.get(gate["required_flag"], False):
        gate_passed = False
        rejection_reason = gate["reject_reason"]

    sector_match = (
        canonical(normalized.threat_sector)
        in {
            canonical(context.sector),
            canonical(threat.threat_sector),
            "all sectors",
        }
        or canonical(threat.threat_sector) == "all sectors"
    )
    asset_context_match = bool(context.asset and context.context_confidence >= 0.5)
    service_impact_match = bool(context.service and context.service_function)
    objective = data_loader.load_applicability_rules()["category_objectives"].get(
        threat.threat_category
    )
    category_objective_match = bool(
        objective and canonical(objective) == canonical(threat.security_objective)
    )
    threat_type_match = threat.match_status in {"ExactMatch", "PartialMatch"}
    actor_plausibility = bool(threat.threat_actor)

    type_relevance_rule = _type_relevance_rule_for(threat.threat_type)
    if type_relevance_rule:
        threat_type_match = _matches_type_relevance_rule(type_relevance_rule, context)

    checks = {
        "sector_match": sector_match,
        "asset_context_match": asset_context_match,
        "service_impact_match": service_impact_match,
        "category_objective_match": category_objective_match,
        "threat_type_match": threat_type_match,
        "actor_plausibility": actor_plausibility,
        "technology_gate_passed": gate_passed,
    }
    weights = data_loader.load_applicability_rules().get("applicability_weights", {})
    missing_weights = REQUIRED_WEIGHT_KEYS - set(weights)
    if missing_weights:
        missing = ", ".join(sorted(missing_weights))
        raise RuntimeError(f"Missing applicability weight rules: {missing}")
    score = round(sum(weights[key] for key, passed in checks.items() if passed), 2)
    if not gate_passed:
        return ApplicabilityResult(
            status="Rejected",
            applicability_score=score,
            checks=checks,
            rejection_reason=rejection_reason,
            reason=rejection_reason or "Technology gate failed.",
        )
    status = "Pass" if score >= 0.75 else "Conditional"
    return ApplicabilityResult(
        status=status,
        applicability_score=score,
        checks=checks,
        reason="Threat is applicable to the selected asset and service context."
        if status == "Pass"
        else "Threat may be applicable, but context confidence or matching is incomplete.",
    )
