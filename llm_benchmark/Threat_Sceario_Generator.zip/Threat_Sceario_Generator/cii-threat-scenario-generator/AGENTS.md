# AGENTS.md

Guidance for future Codex work in this repository:

- Follow the documented architecture flow in `README.md`.
- Keep deterministic engines separate from LLM generation.
- The deterministic engine decides relevance, applicability, ranking, controls, and evidence.
- The LLM only converts approved context into readable defensive scenario language.
- Never hardcode API keys or print `OPENAI_API_KEY`.
- Keep scenario validation and unsafe-content checks active.
- Do not add exploit instructions, procedural attack steps, payloads, bypass techniques, or code.
- Run `pytest -q` before finishing implementation changes.
- Run `ruff check .` before finishing implementation changes.
- Update `README.md` when adding or changing endpoints, environment variables, or run commands.
