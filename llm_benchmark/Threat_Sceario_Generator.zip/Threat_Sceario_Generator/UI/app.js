const API_BASE_URL = "http://127.0.0.1:8000";

const sampleRequest = {
  threat_category: "Denial of Service",
  threat_type: "DDoS Attack on Nodes",
  threat_actor: "Malicious insiders, Hackers",
  threat_sector: "Industry",
  threat_name: "Disruption of MES service nodes affecting production scheduling",
  control_name:
    "High Availability Architecture, Network Segmentation, Spare Capacity, Tested Failover, Manual Operating Procedures",
  asset: "Manufacturing Execution Platform",
  service: "Manufacturing Execution and Production Scheduling",
};

const rejectedRequest = {
  threat_category: "Tampering",
  threat_type: "51% Attack",
  threat_actor: "Hackers",
  threat_sector: "Industry",
  threat_name: "Blockchain consensus manipulation",
  control_name: "Network Segmentation",
  asset: "Manufacturing Execution Platform",
  service: "Manufacturing Execution and Production Scheduling",
};

const scenarioSamples = [
  {
    id: "mes_ddos",
    label: "MES DoS - Production Scheduling",
    payload: sampleRequest,
  },
  {
    id: "mes_tampering",
    label: "MES Tampering - Production Orders",
    payload: {
      threat_category: "Tampering",
      threat_type: "Unauthorized Modification",
      threat_actor: "Malicious insiders, Hackers",
      threat_sector: "Industry",
      threat_name: "Unauthorized modification of production orders or engineering changes",
      control_name:
        "Network Segmentation, Privileged Access Management, Manual Operating Procedures",
      asset: "Manufacturing Execution Platform",
      service: "Manufacturing Execution and Production Scheduling",
    },
  },
  {
    id: "scada_eop",
    label: "SCADA EoP - Engineering Functions",
    payload: {
      threat_category: "Elevation of Privilege",
      threat_type: "Access Control Vulnerabilities",
      threat_actor: "Hackers, Malicious insiders",
      threat_sector: "Industry",
      threat_name: "Unauthorized elevation of access to administrative or engineering functions",
      control_name: "Privileged Access Management, Network Segmentation",
      asset: "Industrial Control Platform",
      service: "Plant Process Automation and SCADA",
    },
  },
  {
    id: "scada_spoofing",
    label: "SCADA Spoofing - Trusted Node",
    payload: {
      threat_category: "Spoofing",
      threat_type: "Node Impersonation",
      threat_actor: "Hackers, Malicious entity",
      threat_sector: "Industry",
      threat_name: "Impersonation of trusted service node or device identity",
      control_name: "Network Segmentation, Privileged Access Management",
      asset: "Industrial Control Platform",
      service: "Plant Process Automation and SCADA",
    },
  },
  {
    id: "dewa_distribution_dos",
    label: "DEWA DoS - Distribution SCADA",
    payload: {
      threat_category: "Denial of Service",
      threat_type: "DDoS Attack on Nodes",
      threat_actor: "Hackers, Malicious insiders",
      threat_sector: "Energy",
      threat_name:
        "Disruption of electricity distribution SCADA service nodes affecting network monitoring and control",
      control_name:
        "High Availability Architecture, Network Segmentation, Spare Capacity, Tested Failover, Manual Operating Procedures",
      asset: "Electricity Distribution SCADA Platform",
      service: "Electricity Distribution Network Monitoring and Control",
    },
  },
  {
    id: "dewa_tampering_metering",
    label: "DEWA Tampering - Smart Meter Data",
    payload: {
      threat_category: "Tampering",
      threat_type: "Unauthorized Modification",
      threat_actor: "Hackers, Malicious insiders",
      threat_sector: "Energy",
      threat_name:
        "Unauthorized modification of smart meter readings or customer consumption data",
      control_name:
        "Network Segmentation, Privileged Access Management, Manual Operating Procedures",
      asset: "Smart Metering and Customer Consumption Data Platform",
      service: "Electricity and Water Smart Metering",
    },
  },
  {
    id: "mes_blockchain_reject",
    label: "Reject - Blockchain 51% on MES",
    payload: rejectedRequest,
  },
  {
    id: "mes_biometric_reject",
    label: "Reject - Biometric Data on MES",
    payload: {
      threat_category: "Information Disclosure",
      threat_type: "Biometric Data Vulnerabilities",
      threat_actor: "Hackers, Fraudsters",
      threat_sector: "Industry",
      threat_name: "Exposure of biometric data",
      control_name: "Network Segmentation, Privileged Access Management",
      asset: "Manufacturing Execution Platform",
      service: "Manufacturing Execution and Production Scheduling",
    },
  },
];

const fields = [
  "threat_category",
  "threat_type",
  "threat_actor",
  "threat_sector",
  "threat_name",
  "control_name",
  "asset",
  "service",
];

const seedDatasets = [
  {
    id: "business_taxonomy",
    label: "Business Taxonomy",
    file: "data/seed/business_taxonomy.json",
    description: "Maps sector, subsector, entity, service, and asset.",
    columns: ["sector", "subsector", "entity", "service", "asset"],
  },
  {
    id: "asset_metadata",
    label: "Asset Metadata",
    file: "data/seed/asset_metadata.json",
    description: "Asset master data, criticality, dependencies, interfaces, and technology flags.",
    columns: [
      "asset_id",
      "asset",
      "sector",
      "service",
      "environment_type",
      "criticality",
      "availability_requirement",
      "integrity_requirement",
      "confidentiality_requirement",
      "functions",
      "data_handled",
      "dependent_systems",
      "privilege_context",
      "interfaces",
      "has_service_nodes",
      "has_remote_access",
      "has_privileged_access",
      "uses_blockchain",
      "uses_biometric_data",
      "uses_gps_or_location_dependency",
    ],
  },
  {
    id: "service_metadata",
    label: "Service Metadata",
    file: "data/seed/service_metadata.json",
    description: "Service functions, service criticality, impact drivers, and availability.",
    columns: [
      "service",
      "sector",
      "service_function",
      "service_criticality",
      "availability_requirement",
    ],
  },
  {
    id: "threat_library",
    label: "Threat Library",
    file: "data/seed/threat_library.json",
    description: "Threat categories, types, names, and sector relevance.",
    columns: [
      "threat_category",
      "threat_type",
      "threat_name",
      "threat_sector",
    ],
  },
  {
    id: "control_library",
    label: "Control Library",
    file: "data/seed/control_library.json",
    description: "Control domains, descriptions, verification steps, and required evidence.",
    columns: [
      "control_name",
      "control_description",
      "required_evidence",
    ],
  },
  {
    id: "threat_control_mappings",
    label: "Threat Control Mappings",
    file: "data/seed/threat_control_mappings.json",
    description: "Which controls are mapped to each threat category and threat type.",
    columns: ["threat_category", "threat_type", "mapped_control_names"],
  },
  {
    id: "applicability_rules",
    label: "Applicability Rules",
    file: "data/seed/applicability_rules.json",
    description: "Technology gates, category objectives, and applicability scoring weights.",
    columns: [
      "rule_group",
      "threat_type",
      "required_flag",
      "reject_reason",
      "threat_category",
      "security_objective",
    ],
  },
  {
    id: "scoring_rules",
    label: "Scoring Rules",
    file: "data/seed/scoring_rules.json",
    description: "Risk, score, confidence, and identifier rules used by deterministic engines.",
    columns: ["rule_group", "rule_name", "rule_value"],
  },
];

let seedCache = {};

$(function () {
  loadForm(sampleRequest);
  checkHealth();
  setupTabs();
  setupSampleScenarios();
  setupSeedDataView();

  $("#refreshHealth").on("click", checkHealth);
  $("#loadSample").on("click", function () {
    loadSelectedSample();
    clearError();
  });
  $("#loadRejected").on("click", function () {
    loadForm(rejectedRequest);
    clearError();
  });
  $("#clearForm").on("click", function () {
    fields.forEach((field) => $("#" + field).val(""));
    clearError();
  });
  $("#scenarioForm").on("submit", submitScenario);
  $("#reloadSeedData").on("click", function () {
    seedCache = {};
    loadSelectedSeedDataset();
  });
  $("#seedDataset").on("change", loadSelectedSeedDataset);
  $("#seedSearch").on("input", filterSeedTable);
});

function setupTabs() {
  $(".tab-button").on("click", function () {
    const viewId = $(this).data("view");
    $(".tab-button").removeClass("active");
    $(this).addClass("active");
    $(".view-panel").removeClass("active");
    $("#" + viewId).addClass("active");
    if (viewId === "masterDataView" && !$("#seedDataset").val()) {
      setupSeedDataView();
    }
  });
}

function setupSampleScenarios() {
  const $select = $("#sampleScenario");
  if ($select.children().length === 0) {
    scenarioSamples.forEach((sample) => {
      $select.append(`<option value="${sample.id}">${escapeHtml(sample.label)}</option>`);
    });
  }
  $select.val("mes_ddos");
  $select.on("change", function () {
    loadSelectedSample();
    clearError();
  });
}

function loadSelectedSample() {
  const sampleId = $("#sampleScenario").val();
  const sample = scenarioSamples.find((item) => item.id === sampleId) || scenarioSamples[0];
  loadForm(sample.payload);
}

function setupSeedDataView() {
  const $select = $("#seedDataset");
  if ($select.children().length === 0) {
    seedDatasets.forEach((dataset) => {
      $select.append(`<option value="${dataset.id}">${escapeHtml(dataset.label)}</option>`);
    });
  }
  loadSelectedSeedDataset();
}

function loadForm(values) {
  fields.forEach((field) => $("#" + field).val(values[field] || ""));
}

function readForm() {
  const payload = {};
  fields.forEach((field) => {
    payload[field] = String($("#" + field).val()).trim();
  });
  return payload;
}

function checkHealth() {
  setHealth("checking", "Checking API", "Connecting to FastAPI");
  $.ajax({
    url: API_BASE_URL + "/health",
    method: "GET",
    timeout: 5000,
  })
    .done(function (data) {
      setHealth("ok", "API connected", data.llm_provider);
    })
    .fail(function () {
      setHealth("down", "API unavailable", "Start FastAPI on port 8000");
    });
}

function setHealth(status, title, subtitle) {
  const $health = $("#apiHealth");
  $health.removeClass("health-ok health-down");
  $health.addClass(status === "ok" ? "health-ok" : "health-down");
  $health.find("strong").text(title);
  $health.find("small").text(subtitle);
}

function submitScenario(event) {
  event.preventDefault();
  clearError();

  const payload = readForm();
  const missing = fields.filter((field) => !payload[field]);
  if (missing.length) {
    showError("All fields are required.");
    return;
  }

  setLoading(true);
  renderLoading();

  $.ajax({
    url: API_BASE_URL + "/generate-scenario",
    method: "POST",
    data: JSON.stringify(payload),
    contentType: "application/json",
    timeout: 120000,
  })
    .done(function (response) {
      renderResult(response);
    })
    .fail(function (xhr) {
      const message = xhr.responseJSON?.detail || "Scenario generation failed.";
      showError(typeof message === "string" ? message : JSON.stringify(message));
      renderEmpty();
    })
    .always(function () {
      setLoading(false);
    });
}

function setLoading(isLoading) {
  $("#generateButton").prop("disabled", isLoading).text(isLoading ? "Generating..." : "Generate Scenario");
}

function showError(message) {
  $("#formError").removeClass("hidden").text(message);
}

function clearError() {
  $("#formError").addClass("hidden").text("");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderLoading() {
  $("#outputPanel")
    .removeClass("empty-state")
    .html(
      '<div class="empty-state"><h2>Generating scenario</h2><p>The backend is validating applicability, ranking risk, mapping controls, and calling Azure OpenAI.</p></div>',
    );
}

function renderEmpty() {
  $("#outputPanel")
    .addClass("empty-state")
    .html("<h2>Scenario Output</h2><p>Generated scenario results will appear here.</p>");
}

function renderResult(result) {
  if (result.status === "Rejected") {
    renderRejected(result);
    return;
  }

  if (!result.scenario) {
    $("#outputPanel")
      .addClass("empty-state")
      .html("<h2>No scenario returned</h2><p>The backend did not return a scenario body.</p>");
    return;
  }

  const scenario = result.scenario;
  const risk = scenario.risk_summary;
  $("#outputPanel")
    .removeClass("empty-state")
    .html(`
      <div class="status-bar status-generated">
        <strong>Status</strong><span>Machine Generated</span>
        ${result.validation_result.human_review_required ? "<span>· Human review required</span>" : ""}
      </div>
      <div class="scenario-header">
        <h2>${escapeHtml(scenario.scenario_title)}</h2>
        <div class="rating">${escapeHtml(risk.priority_rating)}</div>
      </div>

      <div class="section-group group-llm">
        <div class="group-header">
          <span class="source-badge source-llm">AI Generated</span>
          <div class="group-header-line"></div>
        </div>
        <p class="scenario-text">${escapeHtml(scenario.scenario_statement)}</p>
        ${renderSection("High-Level Attack Path", `<p class="attack-path-text">${escapeHtml(scenario.high_level_attack_path)}</p>`)}
        <div class="output-grid">
          ${renderSection("Business Impact", renderList(scenario.business_impact))}
          ${renderSection("Operational Impact", renderList(scenario.operational_impact))}
          ${renderSection("CII Impact", renderList(scenario.cii_impact))}
        </div>
      </div>

      <div class="section-group group-internal">
        <div class="group-header">
          <span class="source-badge source-internal">System Data</span>
          <div class="group-header-line"></div>
        </div>
        ${renderKeyValues([
          ["Scenario ID", result.generated_scenario_id],
          ["Asset", scenario.target_asset],
          ["Service", scenario.supported_service],
          ["Threat", scenario.threat_type],
          ["Likelihood", risk.likelihood_score],
          ["Impact", risk.impact_score],
          ["Priority", risk.priority_score],
          ["Applicability", risk.applicability_score],
        ])}
        ${renderSection("Control Gap", `<p class="control-gap-text">${escapeHtml(scenario.control_gap_summary)}</p><p class="muted">${escapeHtml(risk.residual_concern)}</p>`)}
        ${renderSection("Mapped Controls", renderControls(scenario.mapped_controls))}
        ${renderSection("Required Evidence", renderTags(scenario.required_evidence))}
      </div>
    `);
}

function renderRejected(result) {
  $("#outputPanel")
    .removeClass("empty-state")
    .html(`
      <div class="status-bar status-rejected"><strong>Threat Rejected</strong></div>
      <h2>Applicability Check Failed</h2>
      <p class="scenario-text">${escapeHtml(result.rejection_reason)}</p>
      ${renderKeyValues([
        ["Scenario ID", result.generated_scenario_id],
        ["Applicability Score", result.applicability_result.applicability_score],
        ["Reason", result.applicability_result.reason],
      ])}
    `);
}

function renderKeyValues(items) {
  return `<dl class="kv-grid">${items
    .map(
      ([key, value]) => `
        <div>
          <dt>${escapeHtml(key)}</dt>
          <dd>${escapeHtml(value)}</dd>
        </div>
      `,
    )
    .join("")}</dl>`;
}

function renderSection(title, body) {
  return `<section class="output-section"><h3>${escapeHtml(title)}</h3>${body}</section>`;
}

function renderList(items) {
  return `<ul class="clean-list">${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`;
}

function renderControls(controls) {
  return `<div class="control-list">${controls
    .map(
      (control) => `
        <article class="control-item">
          <h4>${escapeHtml(control.control_name)}</h4>
          <p>${escapeHtml(control.control_purpose)}</p>
          <small>${escapeHtml(control.required_evidence.join(", "))}</small>
        </article>
      `,
    )
    .join("")}</div>`;
}

function renderTags(items) {
  return `<div class="tag-list">${items.map((item) => `<span>${escapeHtml(item)}</span>`).join("")}</div>`;
}

function loadSelectedSeedDataset() {
  const datasetId = $("#seedDataset").val();
  const dataset = seedDatasets.find((item) => item.id === datasetId) || seedDatasets[0];
  if (!dataset) {
    return;
  }

  $("#seedSearch").val("");
  $("#seedSummary").html(
    `<div class="loading-row">Loading ${escapeHtml(dataset.label)}...</div>`,
  );
  $("#seedTableWrap").empty();

  if (seedCache[dataset.id]) {
    renderSeedDataset(dataset, seedCache[dataset.id]);
    return;
  }

  $.getJSON(dataset.file)
    .done(function (data) {
      seedCache[dataset.id] = data;
      renderSeedDataset(dataset, data);
    })
    .fail(function () {
      $("#seedSummary").html(
        `<div class="error-banner">Unable to load ${escapeHtml(dataset.file)}. Start the UI with <strong>python -m http.server 5500</strong>.</div>`,
      );
    });
}

function renderSeedDataset(dataset, data) {
  const rows = normalizeSeedRows(dataset.id, data);
  const columns = dataset.columns || collectColumns(rows);

  $("#seedSummary").html(`
    <div class="summary-card">
      <strong>${escapeHtml(dataset.label)}</strong>
      <span>${escapeHtml(dataset.description)}</span>
    </div>
    <div class="summary-card">
      <strong>${rows.length}</strong>
      <span>Rows</span>
    </div>
    <div class="summary-card">
      <strong>${columns.length}</strong>
      <span>Scenario-relevant columns</span>
    </div>
    <div class="summary-card">
      <strong>${escapeHtml(dataset.file)}</strong>
      <span>Source JSON</span>
    </div>
  `);

  if (!rows.length) {
    $("#seedTableWrap").html("<div class='empty-table'>No rows found.</div>");
    return;
  }

  const thead = columns.map((column) => `<th>${escapeHtml(toTitle(column))}</th>`).join("");
  const tbody = rows
    .map((row) => {
      const flatRow = flattenRow(row);
      return `
        <tr>
          ${columns.map((column) => `<td>${formatCell(flatRow[column])}</td>`).join("")}
        </tr>
      `;
    })
    .join("");

  $("#seedTableWrap").html(`
    <table class="seed-table">
      <thead><tr>${thead}</tr></thead>
      <tbody>${tbody}</tbody>
    </table>
  `);
}

function normalizeSeedRows(datasetId, data) {
  if (Array.isArray(data)) {
    return data;
  }

  if (datasetId === "applicability_rules") {
    const gates = (data.technology_gates || []).map((gate) => ({
      rule_group: "Technology Gate",
      threat_type: gate.threat_type,
      required_flag: gate.required_flag,
      reject_reason: gate.reject_reason,
    }));
    const objectives = Object.entries(data.category_objectives || {}).map(
      ([threatCategory, securityObjective]) => ({
        rule_group: "Category Objective",
        threat_category: threatCategory,
        security_objective: securityObjective,
      }),
    );
    const weights = Object.entries(data.applicability_weights || {}).map(([name, value]) => ({
      rule_group: "Applicability Weight",
      rule_name: name,
      rule_value: value,
    }));
    const relevanceRules = (data.threat_type_relevance_rules || []).map((rule) => ({
      rule_group: "Threat Type Relevance",
      threat_type: rule.threat_type,
      required_flag: (rule.any_flags || []).join(", "),
      rule_name: (rule.any_context_fields || []).join(", "),
      rule_value: JSON.stringify(rule.any_context_values || {}),
    }));
    return [...gates, ...objectives, ...weights, ...relevanceRules];
  }

  if (datasetId === "scoring_rules") {
    return [
      ...Object.entries(data.risk_matrix || {}).map(([name, value]) => ({
        rule_group: "Risk Matrix",
        rule_name: name,
        rule_value: value,
      })),
      ...Object.entries(data.criticality_scores || {}).map(([name, value]) => ({
        rule_group: "Criticality Score",
        rule_name: name,
        rule_value: value,
      })),
      ...Object.entries(data.availability_scores || {}).map(([name, value]) => ({
        rule_group: "Availability Score",
        rule_name: name,
        rule_value: value,
      })),
      ...Object.entries(data.category_codes || {}).map(([name, value]) => ({
        rule_group: "Category Code",
        rule_name: name,
        rule_value: value,
      })),
      ...Object.entries(data.context_confidence_penalties || {}).map(([name, value]) => ({
        rule_group: "Context Confidence Penalty",
        rule_name: name,
        rule_value: value,
      })),
      ...Object.entries(data.control_coverage_scores || {}).map(([name, value]) => ({
        rule_group: "Control Coverage Score",
        rule_name: name,
        rule_value: value,
      })),
      ...Object.entries(data.threat_match_confidence || {}).map(([name, value]) => ({
        rule_group: "Threat Match Confidence",
        rule_name: name,
        rule_value: value,
      })),
      ...Object.entries(data.evidence_confidence_scores || {}).map(([name, value]) => ({
        rule_group: "Evidence Confidence Score",
        rule_name: name,
        rule_value: value,
      })),
    ];
  }

  return Object.entries(data).map(([key, value]) => ({
    key,
    value,
  }));
}

function collectColumns(rows) {
  const columns = [];
  rows.forEach((row) => {
    Object.keys(flattenRow(row)).forEach((key) => {
      if (!columns.includes(key)) {
        columns.push(key);
      }
    });
  });
  return columns;
}

function flattenRow(row) {
  const flat = {};
  Object.entries(row).forEach(([key, value]) => {
    if (key === "technology_flags" && value && typeof value === "object" && !Array.isArray(value)) {
      Object.entries(value).forEach(([flagKey, flagValue]) => {
        flat[flagKey] = flagValue;
      });
    } else {
      flat[key] = value;
    }
  });
  return flat;
}

function formatCell(value) {
  if (value === undefined || value === null || value === "") {
    return "<span class='muted'>-</span>";
  }
  if (typeof value === "boolean") {
    return value ? "<span class='bool-yes'>Yes</span>" : "<span class='bool-no'>No</span>";
  }
  if (Array.isArray(value)) {
    return `<div class="cell-list">${value.map((item) => `<span>${escapeHtml(item)}</span>`).join("")}</div>`;
  }
  if (typeof value === "object") {
    return `<pre class="cell-json">${escapeHtml(JSON.stringify(value, null, 2))}</pre>`;
  }
  return escapeHtml(value);
}

function toTitle(value) {
  return String(value).replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

function filterSeedTable() {
  const term = String($("#seedSearch").val()).toLowerCase().trim();
  $(".seed-table tbody tr").each(function () {
    const rowText = $(this).text().toLowerCase();
    $(this).toggle(!term || rowText.includes(term));
  });
}
