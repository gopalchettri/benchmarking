# CII Threat Scenario UI

Plain HTML, CSS, and jQuery UI for the FastAPI CII Threat Scenario Generator.

The UI has two views:

- `Scenario Generator`: submits the eight scenario parameters to the backend API.
- `Master Data Tables`: displays only scenario-relevant seed tables and columns in searchable table format for stakeholder review.

## Run

Start the backend first:

```powershell
cd C:\Users\User\Documents\GC_Research\Threat_Sceario_Generator\cii-threat-scenario-generator
uvicorn app.main:app --reload
```

Then start the UI:

```powershell
cd C:\Users\User\Documents\GC_Research\Threat_Sceario_Generator\UI
python -m http.server 5500
```

Open:

```text
http://127.0.0.1:5500
```

Open `Master Data Tables` to inspect:

- Business Taxonomy
- Asset Metadata
- Service Metadata
- Threat Library
- Control Library
- Threat Control Mappings
- Applicability Rules
- Scoring Rules
