"""
Configuration Module

Reads settings from .env file with search-order resolution:
  1. CLI --env-file argument
  2. DOTENV_PATH environment variable
  3. ./control_extraction/.env  (local)
  4. ../  .env  (parent directory)

Uses pydantic-settings for validation and type coercion.
"""

import os
import warnings
from pathlib import Path
from typing import List, Literal, Optional
from urllib.parse import quote_plus

from pydantic import model_validator
from pydantic_settings import BaseSettings

# ── Auto-Scaling Ratios ─────────────────────────────────────────────────────
# When a token ceiling is left at 0 (the default), it is auto-derived from
# LLM_MODEL_CONTEXT_TOKENS using these ratios.  The ratios reproduce the
# original 128K defaults exactly:  128000 * 0.128 = 16384, etc.
_AUTO_SUBCONTROL_RATIO = 0.128     # sub-control output ceiling
_AUTO_MAX_OUTPUT_RATIO = 0.125     # fallback output ceiling
_AUTO_TOC_RATIO = 0.032            # ToC output ceiling
_AUTO_DISCOVERY_RATIO = 0.016      # discovery output ceiling
_MIN_CONTENT_BUDGET = 5000         # minimum usable content tokens


class Settings(BaseSettings):
    """Application settings — all configurable via .env or environment variables."""

    # --- App Metadata & Routing ---
    APP_NAME_GATEWAY: str = "API Gateway / Orchestrator"
    APP_NAME_DOC_PROCESSING: str = "Document Processing Service"
    APP_NAME_AI_EXTRACTION: str = "AI Extraction Service"
    APP_NAME_STORAGE: str = "Storage & Aggregation Service"
    APP_VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    AZURE_STORAGE_CONNECTION_STRING: Optional[str] = None
    AZURE_BLOB_CONTAINER_NAME: str = "uaeccpm"


    # --- Blob / Document Storage PDF, PDF Extraction Markdown---
    USE_AZURE_STORAGE: bool = True
    BLOB_STORAGE_DIR: str = "./blob_data"

    # --- Document Processing ---
    PARSE_TYPE: Literal["docling", "pymupdf4llm", "kreuzberg"] = "pymupdf4llm"
    PDF_MIN_CHARS_PER_PAGE: int = 100      # Pages with fewer chars are flagged as thin in logs
    PDF_MAX_PAGES: int = 2000              # Reject PDFs exceeding this page count (0 = no limit)
    PDF_CONVERSION_TIMEOUT_SECONDS: int = 300  # Max seconds for pymupdf4llm conversion

    
    # --- CORS ---
    CORS_ALLOWED_ORIGINS: List[str] = []

    LOG_LEVEL: str = "INFO"
    ENVIRONMENT: Literal["development", "production"] = "development"

    
    # --- Microservice URLs ---
    DOC_SERVICE_URL: str = "http://localhost:8001"
    AI_SERVICE_URL: str = "http://localhost:8002"
    STORAGE_SERVICE_URL: str = "http://localhost:8003"

    # --- LLM Provider ---
    LLM_PROVIDER: Literal["azure", "ollama"] = "azure"
    LLM_MODEL_CONTEXT_TOKENS: int = 128000
    LLM_REASONING_EFFORT: Literal["low", "medium", "high"] = "low"
    # Fallback output limit when callers don't specify max_tokens.
    # 0 = auto-derive from LLM_MODEL_CONTEXT_TOKENS (12.5%).
    LLM_MAX_OUTPUT_TOKENS: int = 0
    LLM_REQUEST_TIMEOUT_SECONDS: int = 900
    LLM_ENABLE_WARMUP: bool = True

    # Azure OpenAI
    AZURE_OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_ENDPOINT: Optional[str] = None
    AZURE_OPENAI_DEPLOYMENT_NAME: Optional[str] = None
    AZURE_OPENAI_API_VERSION: Optional[str] = None

    # Ollama
    OLLAMA_BASE_URL: Optional[str] = None
    OLLAMA_API_KEY: Optional[str] = "ollama"
    OLLAMA_MODEL_NAME: Optional[str] = None
    OLLAMA_CONNECTION_POOL_SIZE: int = 3
    OLLAMA_KEEPALIVE_TIMEOUT: int = 600
    OLLAMA_NUM_BATCH: int = 512
    OLLAMA_REPEAT_PENALTY: float = 1.0
    OLLAMA_TOP_K: int = 1
    OLLAMA_TOP_P: float = 1.0
    TCP_KEEPALIVE_IDLE: int = 30
    TCP_KEEPALIVE_INTERVAL: int = 10
    TCP_KEEPALIVE_COUNT: int = 3

    # --- Rate Limiting ---
    LLM_RATE_LIMIT_RPM: int = 8
    LLM_RATE_LIMIT_BURST: int = 5
    LLM_RATE_LIMIT_MIN_INTERVAL: float = 0.5

    # --- Token Tracking ---
    TOKEN_TRACKER_HISTORY_SIZE: int = 1000
    TOKEN_TRACKER_LOG_FREQUENCY: int = 5

    # --- Page Window Overlap ---
    # Number of extra PDF pages included before and after each control's raw page
    # range when building the text window sent to the LLM.
    #
    # Why it is needed:
    #   The TOC lists a printed page number for each control (e.g. "3.2.1 ... 17").
    #   The PDF page index (what pg_17.txt maps to) may differ by ±1 because some
    #   PDFs have a cover page or blank page that shifts the numbering. Without
    #   overlap, a control whose content starts on PDF page 18 but whose TOC entry
    #   says page 17 would receive an empty or truncated window and be missed.
    #
    # Concrete example (WINDOW_OVERLAP=1):
    #   TOC says control 3.2.1 starts on page 17, next control starts on page 19.
    #   Raw window  = pages 17–18  (TOC range)
    #   Final window = pages 16–19  (raw ± 1 overlap, clamped to document bounds)
    #
    # Phase 5 retry (missing controls after first pass):
    #   The retry expands the ALREADY-overlapped window by WINDOW_OVERLAP again.
    #   With the default of 1: initial window is raw ± 1, retry window is raw ± 2.
    #   This gives the LLM a second chance with a wider view when a control was
    #   not found in the initial extraction.
    #
    # Tuning guide:
    #   1  — correct for most frameworks (default)
    #   2  — use when controls are consistently missed on the first pass,
    #         or when the framework PDF has multi-page front matter that shifts
    #         printed page numbers by more than 1 relative to PDF page indices
    #   0  — rejected at startup (removes off-by-one buffer; makes retry a no-op)
    WINDOW_OVERLAP: int = 1

    # --- Control Discovery (fallback when TOC has no entries) ---
    # Window size (in pages) for scanning content body to discover control IDs.
    # Each window is sent as one LLM call. Overlap is 1 page between windows.
    DISCOVERY_WINDOW_SIZE: int = 4
    # Max output tokens for each discovery LLM call.
    # 0 = auto-derive from LLM_MODEL_CONTEXT_TOKENS (1.6%).
    DISCOVERY_MAX_TOKENS: int = 0

    # --- Prompt Source ---
    # "module" = use per-framework .py prompt modules (current production default).
    # "txt"    = use per-framework .txt rule files injected into base template.
    # Switch to "txt" once all frameworks are validated in production.
    PROMPT_SOURCE: Literal["module", "txt"] = "module"

    # --- Post-Extraction Validation ---
    # Maximum recursion depth for post-extraction corrections
    # (merge_lowercase_continuations, renest_interleaved_children, etc.).
    # Real compliance frameworks nest at most 4–5 levels deep. The default
    # of 10 is generous headroom that prevents RecursionError on malformed
    # LLM output while never triggering on valid framework content.
    POST_EXTRACTION_MAX_DEPTH: int = 10

    # --- Sub-Control Extraction ---
    # 0 = auto-derive from LLM_MODEL_CONTEXT_TOKENS (12.8%).
    SUBCONTROL_MAX_TOKENS: int = 0
    SUBCONTROL_MAX_RETRIES: int = 2
    SUBCONTROL_RETRY_WAIT: float = 5.0
    SUBCONTROL_RETRY_BACKOFF: float = 2.0
    SUBCONTROL_MIN_CONTENT_CHARS: int = 50

    # --- Chunking (sub-control extraction only) ---
    # Budget: content = context × CHUNK_CONTEXT_RATIO − CHUNK_PROMPT_OVERHEAD_TOKENS − SUBCONTROL_MAX_TOKENS
    CHUNK_CONTEXT_RATIO: float = 0.75
    # Fixed token overhead for system + user prompt templates.
    # Heaviest prompt (DESC ISR) is ~2,382 tokens. 2,500 adds headroom.
    CHUNK_PROMPT_OVERHEAD_TOKENS: int = 2600

    # --- ToC Extraction (single-shot, no chunking) ---
    # 0 = auto-derive from LLM_MODEL_CONTEXT_TOKENS (3.2%).
    TOC_MAX_TOKENS: int = 0
    TOC_MAX_PDF_PAGES: int = 15

    # --- Output inside the storage folder ---
    # This is the folder where the final extracted controls 
    # are saved in .json format
    OUTPUT_DIR: str = "./output"

    # --- Cost Tracking ---
    LLM_COST_PER_1K_INPUT: float = 0.0
    LLM_COST_PER_1K_OUTPUT: float = 0.0



    # --- Rate Limiting ---
    GLOBAL_RATE_LIMIT_MAX_REQUESTS: int = 50
    GLOBAL_RATE_LIMIT_WINDOW_SECONDS: int = 60

    # --- Trusted Proxies ---
    TRUSTED_PROXY_CIDRS: List[str] = []




    # --- Database Backend ---
    DB_BACKEND: Literal["postgresql", "mongodb", "mysql", "mssql"] = "mysql"
    MONGODB_URL: Optional[str] = None
    MONGODB_DB_NAME: str = "ccpm"

    # --- Redis ---
    REDIS_URL: str = "redis://localhost:6379/0"

    # --- PostgreSQL (individual fields — assembled into DATABASE_URL below) ---
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "pass"
    POSTGRES_DB: str = "ccpm"
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    # Assembled at startup by the validator; can also be set directly to override.
    DATABASE_URL: str = ""


    # --- MySQL (individual fields — assembled into DATABASE_URL when DB_BACKEND=mysql) ---
    MYSQL_USER: str = "root"
    MYSQL_PASSWORD: str = ""
    MYSQL_DB: str = "uaeccpm"
    MYSQL_HOST: str = "localhost"
    MYSQL_PORT: int = 3306

  
    # --- Structural Safeguards ---
    MAX_FILE_UPLOAD_BYTES: int = 209715200  # 200MB
    SAGA_RETRY_ATTEMPTS: int = 3
    SAGA_RETRY_MIN_WAIT: int = 2
    SAGA_RETRY_MAX_WAIT: int = 10

    # --- DLQ ---
    DLQ_MAX_DELIVERY_ATTEMPTS: int = 3

    # --- Framework Auto-Detection ---
    AUTODETECT_CONFIDENCE_THRESHOLD: float = 0.85

    # -------------------------------------------------------------------------


    # --- Log Truncation ---
    LOG_TRUNCATE_SYSTEM_PROMPT: int = 0
    LOG_TRUNCATE_USER_PROMPT: int = 0
    LOG_TRUNCATE_LLM_OUTPUT: int = 0
    LOG_TRUNCATE_JSON_ERROR: int = 500
    LOG_ROTATION_SIZE: str = "10 MB"
    LOG_RETENTION_DAYS: str = "30 days"

    
    @model_validator(mode="after")
    def assemble_database_url(self):
        """Build DATABASE_URL from individual DB settings if not set directly.

        Assembles the correct connection string based on DB_BACKEND:
        - postgresql: postgresql://user:pass@host:port/db
        - mysql:      mysql+asyncmy://user:pass@host:port/db?charset=utf8mb4
        - mssql:      mssql+pymssql://user:pass@host:port/db  (requires manual DATABASE_URL)
        - mongodb:    uses MONGODB_URL instead (DATABASE_URL unused)
        """
        if not self.DATABASE_URL:
            if self.DB_BACKEND == "mysql":
                self.DATABASE_URL = (
                    f"mysql+asyncmy://{quote_plus(self.MYSQL_USER)}:{quote_plus(self.MYSQL_PASSWORD)}"
                    f"@{self.MYSQL_HOST}:{self.MYSQL_PORT}/{self.MYSQL_DB}"
                    f"?charset=utf8mb4"
                )
            elif self.DB_BACKEND in ("postgresql", "mssql"):
                self.DATABASE_URL = (
                    f"postgresql://{quote_plus(self.POSTGRES_USER)}:{quote_plus(self.POSTGRES_PASSWORD)}"
                    f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
                )
        return self

    @model_validator(mode="after")
    def validate_bounds(self):
        """Cross-field validation for numeric settings."""
        # ── Auto-derive token ceilings from context window ──────────────
        ctx = self.LLM_MODEL_CONTEXT_TOKENS
        if self.SUBCONTROL_MAX_TOKENS == 0:
            self.SUBCONTROL_MAX_TOKENS = int(ctx * _AUTO_SUBCONTROL_RATIO)
        if self.LLM_MAX_OUTPUT_TOKENS == 0:
            self.LLM_MAX_OUTPUT_TOKENS = int(ctx * _AUTO_MAX_OUTPUT_RATIO)
        if self.TOC_MAX_TOKENS == 0:
            self.TOC_MAX_TOKENS = int(ctx * _AUTO_TOC_RATIO)
        if self.DISCOVERY_MAX_TOKENS == 0:
            self.DISCOVERY_MAX_TOKENS = int(ctx * _AUTO_DISCOVERY_RATIO)

        if self.LLM_MAX_OUTPUT_TOKENS > self.LLM_MODEL_CONTEXT_TOKENS:
            raise ValueError("LLM_MAX_OUTPUT_TOKENS cannot exceed LLM_MODEL_CONTEXT_TOKENS")
        if self.SUBCONTROL_MAX_TOKENS >= self.LLM_MODEL_CONTEXT_TOKENS:
            raise ValueError(
                f"SUBCONTROL_MAX_TOKENS ({self.SUBCONTROL_MAX_TOKENS:,}) must be less than "
                f"LLM_MODEL_CONTEXT_TOKENS ({self.LLM_MODEL_CONTEXT_TOKENS:,})"
            )
        reserved = self.SUBCONTROL_MAX_TOKENS + self.CHUNK_PROMPT_OVERHEAD_TOKENS
        if reserved >= self.LLM_MODEL_CONTEXT_TOKENS:
            raise ValueError(
                f"SUBCONTROL_MAX_TOKENS ({self.SUBCONTROL_MAX_TOKENS:,}) + "
                f"CHUNK_PROMPT_OVERHEAD_TOKENS ({self.CHUNK_PROMPT_OVERHEAD_TOKENS:,}) = "
                f"{reserved:,} — leaves no room for content in "
                f"LLM_MODEL_CONTEXT_TOKENS ({self.LLM_MODEL_CONTEXT_TOKENS:,}). "
                f"Reduce SUBCONTROL_MAX_TOKENS."
            )
        if self.POST_EXTRACTION_MAX_DEPTH < 1 or self.POST_EXTRACTION_MAX_DEPTH > 50:
            raise ValueError(
                "POST_EXTRACTION_MAX_DEPTH must be between 1 and 50. "
                "Real compliance frameworks nest at most 4–5 levels deep. "
                "Values above 50 risk hitting Python's recursion limit on "
                "malformed LLM output."
            )
        if self.LLM_RATE_LIMIT_RPM <= 0:
            raise ValueError("LLM_RATE_LIMIT_RPM must be positive")
        if self.WINDOW_OVERLAP < 1:
            raise ValueError(
                "WINDOW_OVERLAP must be >= 1. "
                "Setting it to 0 removes the off-by-one buffer and makes the "
                "Phase 5 retry a no-op (same window as initial extraction)."
            )
        if self.DISCOVERY_WINDOW_SIZE < 2:
            raise ValueError(
                "DISCOVERY_WINDOW_SIZE must be >= 2. "
                "Smaller windows produce too little context for the LLM."
            )
        # ── Content budget sanity check ─────────────────────────────────
        content_budget = (
            int(ctx * self.CHUNK_CONTEXT_RATIO)
            - self.CHUNK_PROMPT_OVERHEAD_TOKENS
            - self.SUBCONTROL_MAX_TOKENS
        )
        if content_budget < _MIN_CONTENT_BUDGET:
            raise ValueError(
                f"Content budget too small ({content_budget:,} tokens). "
                f"Reduce SUBCONTROL_MAX_TOKENS or increase LLM_MODEL_CONTEXT_TOKENS."
            )
        return self

    model_config = {"env_file_encoding": "utf-8", "extra": "ignore"}


# --- .env Resolution Logic ---
# Search order: CLI --env-file → DOTENV_PATH env var → local .env → shared project .env
_SEARCH_PATHS = [
    Path(__file__).resolve().parent / ".env",
    Path(__file__).resolve().parent.parent / ".env",
]


def resolve_env_file(cli_env_path: Optional[str] = None) -> Optional[str]:
    """Find the .env file. Returns path or None."""
    # 1. CLI arg (highest priority)
    if cli_env_path:
        p = Path(cli_env_path)
        if p.exists():
            return str(p)
        warnings.warn(f"--env-file '{cli_env_path}' not found. Searching defaults...")

    # 2. DOTENV_PATH env var
    env_path = os.environ.get("DOTENV_PATH")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return str(p)

    # 3. Search known locations
    for p in _SEARCH_PATHS:
        if p.exists():
            return str(p)

    return None


_settings_instance: Optional[Settings] = None


def get_settings(env_file_path: Optional[str] = None) -> Settings:
    """
    Get the singleton Settings instance.

    On first call, creates the instance using the provided env_file_path.
    Subsequent calls return the same instance regardless of arguments,
    ensuring all modules share identical configuration.
    """
    global _settings_instance
    if _settings_instance is not None:
        return _settings_instance

    resolved = resolve_env_file(env_file_path)
    if resolved:
        _settings_instance = Settings(_env_file=resolved)
    else:
        warnings.warn("No .env file found. Using environment variables and defaults.")
        _settings_instance = Settings()
    return _settings_instance


def validate_config(settings: Settings) -> List[str]:
    """Validate critical config at startup. Returns list of errors (empty = OK)."""
    errors = []
    if settings.LLM_PROVIDER == "azure":
        for var in ["AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT_NAME"]:
            if not getattr(settings, var):
                errors.append(f"{var} not set (required for azure provider)")
    elif settings.LLM_PROVIDER == "ollama":
        for var in ["OLLAMA_BASE_URL", "OLLAMA_MODEL_NAME"]:
            if not getattr(settings, var):
                errors.append(f"{var} not set (required for ollama provider)")
    else:
        errors.append(f"Unknown LLM_PROVIDER: {settings.LLM_PROVIDER} (expected: azure, ollama)")

    # Validate CORS in production
    if settings.ENVIRONMENT == "production" and not settings.CORS_ALLOWED_ORIGINS:
        errors.append(
            "CORS_ALLOWED_ORIGINS must not be empty in production. "
            "Set explicit origins (e.g. ['https://app.example.com'])."
        )
    if "*" in settings.CORS_ALLOWED_ORIGINS and settings.ENVIRONMENT == "production":
        errors.append(
            "CORS_ALLOWED_ORIGINS='*' is not allowed in production. "
            "Set explicit origins."
        )

    # Cross-validate DB_BACKEND vs DATABASE_URL scheme
    if settings.DB_BACKEND in ("postgresql", "mysql", "mssql") and settings.DATABASE_URL:
        expected_schemes = {
            "postgresql": ["postgresql://", "postgresql+"],
            "mysql": ["mysql://", "mysql+"],
            "mssql": ["mssql://", "mssql+", "postgresql://"],  # mssql allows pg fallback
        }
        url = settings.DATABASE_URL.lower()
        schemes = expected_schemes[settings.DB_BACKEND]
        if not any(url.startswith(s) for s in schemes):
            errors.append(
                f"DB_BACKEND={settings.DB_BACKEND} but DATABASE_URL starts with "
                f"'{settings.DATABASE_URL.split('://')[0]}://' — scheme mismatch. "
                f"Expected one of: {schemes}"
            )
    return errors
