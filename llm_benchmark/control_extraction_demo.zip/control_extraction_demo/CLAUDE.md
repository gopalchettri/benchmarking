# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

ControlForge — a multi-service compliance automation platform that extracts security controls from framework PDFs (ISO 27001, NIST CSF, PCI-DSS, UAE IAS, NCA ECC, SAMA CSF, SWIFT CSCF, DESC ISR) using LLM-based extraction. Event-driven architecture using Redis Streams for inter-service communication. Deployed on AKS/Managed OpenShift.

Tech stack: Python 3.11+/FastAPI, MySQL (SQLAlchemy 2.0 async + asyncmy), Redis (task queue + job state), Azure Blob Storage, Azure OpenAI, OpenTelemetry.

## Commands

### Local Development
```powershell
# Full stack (opens separate terminal windows per service)
.\run_local.ps1

# Stop everything
.\stop_local.ps1

# Reset Redis state
.\reset_redis.ps1
```

### Individual Services (from project root)
```bash
# Set PYTHONPATH first
export PYTHONPATH="$PWD:$PWD/shared_core:$PWD/services/<service_name>"

# Run a service
cd services/<service_name>
python -m uvicorn main:app --host 127.0.0.1 --port <port> --reload

# Run its Redis Stream worker
python worker.py
```

Service ports: API Gateway=8000, Doc Processing=8001, AI Extraction=8002, Storage=8003

### Docker
```bash
docker-compose up
```

### Testing
```bash
# All tests
pytest

# Unit tests only
pytest -m unit

# Integration tests (require Redis + DB)
pytest -m integration

# Single test file
pytest tests/test_config.py

# Single test
pytest tests/test_config.py::test_function_name
```

### Setup
```bash
py -3.12 -m venv venv
pip install -r requirements.txt
pip check  # verify no conflicts
```
Requires Python 3.11+.

## Architecture

### Service Pipeline (event-driven via Redis Streams)

```
Upload → API Gateway (8000) → doc_processing:stream → Doc Processing (8001)
         ↓ job state in Redis                         ↓ PDF → markdown, framework detection
                                                      → ai_extraction:stream → AI Extraction (8002)
                                                        ↓ LLM extraction with framework-specific prompts
                                                        → storage:stream → Storage (8003)
                                                          ↓ DB persistence, audit logging
```

Each service has a FastAPI `main.py` (HTTP endpoints + health check) and a `worker.py` (Redis Stream consumer).

### Key Directories

- `services/api_gateway/` — Entry point, file upload, CORS, rate limiting, job orchestration
- `services/doc_processing/` — PDF extraction with 3-tier fallback: Docling → pymupdf4llm → PyMuPDF
- `services/ai_extraction/` — LLM extraction, framework-specific prompts in `prompts/` subdir, token budgeting, chunking
- `services/storage/` — SQLAlchemy persistence (MySQL or PostgreSQL), audit logging, search endpoints
- `shared_core/` — Cross-service utilities: `redis_client.py` (job state), `stream_client.py` (task queue), `health.py`, `telemetry.py`, `middlewares/`, `interfaces/` (Azure/Local blob storage)
- `seed/` — Framework profile definitions, seeded at Storage startup
- `validation/` — Pre-flight checks (`check_deps.py` for Redis/DB connectivity)

### Configuration

All settings in `config.py` using pydantic-settings (`Settings` class). Values come from `.env` file with search order: CLI `--env-file` → `DOTENV_PATH` env var → `./control_extraction/.env` → parent `.env`. Singleton via `get_settings()`.

Token ceilings auto-derive from `LLM_MODEL_CONTEXT_TOKENS` when set to 0 (default).

### LLM Providers

Two providers: Azure OpenAI (primary) and Ollama (fallback). Configured via `LLM_PROVIDER` setting. Rate limiting at 8 RPM with burst=5. Async clients throughout.

### Framework Prompt System

Per-framework prompt modules in `services/ai_extraction/prompts/` (e.g., `iso_27001.py`, `nist_csf.py`, `generic.py`). Controlled by `PROMPT_SOURCE` setting: `"module"` (default) uses Python modules, `"txt"` uses template files.

### Database

`DB_BACKEND` setting selects MySQL (default), PostgreSQL, or MongoDB. `DATABASE_URL` auto-assembled from individual `MYSQL_*` or `POSTGRES_*` fields. Startup DDL is idempotent. Async driver (`asyncmy` for MySQL) at runtime, sync driver for startup migrations.

### PYTHONPATH

Services import from `shared_core/`, `utils/`, and `config.py` at project root. PYTHONPATH must include the project root and `shared_core/` directory. The `conftest.py` adds all service directories to `sys.path` for test imports.

## Testing Conventions

- Async tests: `asyncio_mode = auto` in pytest.ini — no need for `@pytest.mark.asyncio`
- Markers: `@pytest.mark.unit` and `@pytest.mark.integration`
- Fixtures in `tests/conftest.py`: `sample_profile_dict`, `sample_extraction_dict`

## Code Review

Custom review commands available via `.claude/commands/`:
- `/review <files>` — Full audit across all priorities
- `/review-security`, `/review-schema`, `/review-gateway`, `/review-extraction`, `/review-docprocessing`, `/review-storage`, `/review-shared`, `/review-config`, `/review-deploy`, `/review-prompts`, `/review-diff` — Scoped reviews

The code-reviewer agent (`.claude/agents/code-reviewer.md`) defines the full review rubric with 15 priority categories.

## Key Conventions

- **SQLAlchemy 2.0 style**: `mapped_column()`, `Mapped[]` types, `select()` (not legacy `session.query()`)
- **Async everywhere**: async FastAPI endpoints, async SQLAlchemy sessions (`asyncmy` driver), async Redis, async HTTP clients
- **MySQL charset**: Must use `utf8mb4` end-to-end (GCC frameworks contain Arabic text)
- **Control hierarchy**: Stored via `parent_id` FK in MySQL — single database, no dual-DB consistency
- **shared_core/ is imported by all services** — changes here affect the entire platform
- **Pydantic v2**: Uses `model_validator`, `field_validator` (not v1 `@validator`)
