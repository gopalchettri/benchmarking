"""
doc_processing task handlers
=============================
Plain async functions — no Celery, no RQ.
Dispatched via Redis Streams (shared_core.stream_client).

Worker reads tasks from the "doc_processing:stream" Redis Stream,
calls the matching handler, and ACKs on success.
"""
import asyncio
import hashlib
import io
import os
import shutil
import sys
import tempfile
import threading
from datetime import datetime, timezone
from config import get_settings
from shared_core.constants import STATE_AI_EXTRACTION
from shared_core.redis_client import update_job_state
from shared_core.stream_client import publish_task

# Add project root to sys.path for imports
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, 'shared_core'))

# Import settings and constants
settings = get_settings()

# ── Stream name consumed by this service ─────────────────────────────────────
DOC_STREAM = "doc_processing:stream"
DOC_GROUP  = "doc_workers"

# C-3: Singleton storage instance — avoids creating a new BlobServiceClient per call
# H-1: Thread-safe initialization via lock (matches config.py pattern)
_storage_instance = None
_storage_lock = threading.Lock()


def _get_storage():
    """Factory to get the configured FileStoragePort implementation (cached singleton)."""
    global _storage_instance
    if _storage_instance is not None:
        return _storage_instance
    with _storage_lock:
        if _storage_instance is not None:
            return _storage_instance
        from shared_core.interfaces.storage_port import LocalBlobStorage, AzureBlobStorage
        if settings.USE_AZURE_STORAGE and settings.AZURE_STORAGE_CONNECTION_STRING:
            _storage_instance = AzureBlobStorage(
                settings.AZURE_STORAGE_CONNECTION_STRING,
                settings.AZURE_BLOB_CONTAINER_NAME,
            )
        else:
            _storage_instance = LocalBlobStorage(settings.BLOB_STORAGE_DIR)
        return _storage_instance


def _sha256_file(path: str) -> str:
    """Compute SHA-256 of a file using chunked reads (avoids loading full file into memory)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


async def process_pdf(
    *,
    job_id: str,
    pdf_path: str,
    toc_start_page: int,
    toc_end_page: int,
    content_start_page: int,
    content_end_page: int,
    framework: str,
    framework_profile_id: str = "",
    **_extra,            # absorb unknown fields gracefully
) -> None:
    """
    Heavy OCR extraction handler.
    Resolved from the Redis Stream by the worker loop.
    """
    from utils.logging_config import start_job_logging, stop_job_logging, get_job_logger
    start_job_logging(job_id, "doc_processing")
    job_log = get_job_logger(job_id)
    job_log.info(f"Starting document processing for pdf: {pdf_path}, TOC pages: {toc_start_page}-{toc_end_page}, Content pages: {content_start_page}-{content_end_page}")

    from shared_core.audit_client import log_audit

    tmp_dir = None

    try:
        await log_audit(action="job.doc_processing.started", entity_type="job", entity_id=job_id)

        # Update persistent job record
        from shared_core.job_client import update_job_record
        await update_job_record(job_id, status="processing", started_at=datetime.now(timezone.utc).isoformat(), framework=framework)
        use_azure = settings.USE_AZURE_STORAGE and settings.AZURE_STORAGE_CONNECTION_STRING
        storage = _get_storage()
        if use_azure:
            # Azure mode needs local scratch space for downloads and parser output.
            tmp_dir = tempfile.mkdtemp(prefix=f"doc_{job_id}_")

        # --- Idempotency: check sentinel BEFORE downloading PDF ---
        sentinel_blob = f"{framework}/{job_id}/_complete"
        parsed_filename = f"{framework}/{job_id}/{job_id}_{framework}_parsed.md"
        extractor = None

        if await asyncio.to_thread(storage.file_exists, sentinel_blob):
            job_log.info(f"Sentinel {sentinel_blob} found in storage — skipping PDF conversion")
            saved_blob_path = parsed_filename

            # Read cached hash from sentinel to avoid re-downloading full PDF.
            sentinel_data = await asyncio.to_thread(storage.read_file, sentinel_blob)
            cached_hash = sentinel_data.decode("utf-8", errors="ignore").strip() if sentinel_data else ""
            if cached_hash and len(cached_hash) == 64:
                source_pdf_hash = cached_hash
                job_log.info(f"PDF SHA-256 (from sentinel): {source_pdf_hash}")
            else:
                # Fallback: sentinel was written without hash (legacy), compute it
                if use_azure:
                    pdf_bytes = await asyncio.to_thread(storage.read_file, pdf_path)
                    source_pdf_hash = hashlib.sha256(pdf_bytes).hexdigest()
                else:
                    if tmp_dir is None:
                        tmp_dir = tempfile.mkdtemp(prefix=f"doc_{job_id}_")
                    local_path = await asyncio.to_thread(storage.download_file, pdf_path, tmp_dir)
                    source_pdf_hash = await asyncio.to_thread(_sha256_file, local_path)
                job_log.info(f"PDF SHA-256 (computed, legacy sentinel): {source_pdf_hash}")
        else:
            # Download PDF for conversion
            if tmp_dir is None:
                tmp_dir = tempfile.mkdtemp(prefix=f"doc_{job_id}_")
            local_path = await asyncio.to_thread(storage.download_file, pdf_path, tmp_dir)
            source_pdf_hash = await asyncio.to_thread(_sha256_file, local_path)
            job_log.info(f"PDF SHA-256: {source_pdf_hash}")

            from pdf_extractor import PDFExtractor
            extractor = PDFExtractor(settings)
            # In Azure mode, write intermediate per-page files to the temp directory
            work_dir = tmp_dir if use_azure else None
            # L-1: Run sync PDF conversion in thread with timeout to prevent hangs
            await asyncio.wait_for(
                asyncio.to_thread(
                    extractor.convert_pdf, local_path,
                    framework_name=framework, job_id=job_id, work_dir=work_dir,
                ),
                timeout=settings.PDF_CONVERSION_TIMEOUT_SECONDS,
            )

            # Save the full parsed markdown to blob storage.
            # ai_extraction will fetch it by reference — large content is NOT
            # transmitted through Redis.
            # M-1: Stream per-page files to a temp file instead of assembling
            # the entire document in memory.
            saved_blob_path = ""
            total_pages = extractor.get_total_pages()
            if total_pages > 0:
                combined_markdown_path = extractor.get_combined_markdown_path()
                if combined_markdown_path is None:
                    raise ValueError("Combined markdown path missing after PDF conversion")
                with open(combined_markdown_path, "rb") as f:
                    saved_blob_path = await asyncio.to_thread(
                        storage.save_file, f, parsed_filename,
                    )
                job_log.info(f"Saved parsed markdown to storage: {saved_blob_path}")

                # Persist parsed blob path in job record
                from shared_core.job_client import update_job_record
                await update_job_record(job_id, parsed_blob_path=saved_blob_path)

                # Upload _complete sentinel to blob storage (for idempotency check)
                if use_azure:
                    await asyncio.to_thread(
                        storage.save_file,
                        io.BytesIO(source_pdf_hash.encode("utf-8")),
                        sentinel_blob,
                    )
                    job_log.info("Uploaded sentinel to Azure")

        # --- Framework auto-detection if no profile provided ---
        # Page slices are extracted only when needed for detection — skipped
        # entirely when framework_profile_id is already known or conversion was cached.
        detected_profile_id = framework_profile_id
        if not framework_profile_id and extractor:
            try:
                from framework_detector import detect_framework, fetch_profiles_for_detection

                toc_content = ""
                if toc_start_page > 0 and toc_end_page > 0:
                    toc_content = extractor.extract_pages(toc_start_page, toc_end_page)
                control_content = extractor.extract_pages(content_start_page, content_end_page)

                profiles = await fetch_profiles_for_detection(
                    settings.STORAGE_SERVICE_URL, settings.API_V1_STR
                )
                detection_text = (toc_content + "\n" + control_content)
                result = detect_framework(
                    text=detection_text,
                    profiles=profiles,
                    confidence_threshold=settings.AUTODETECT_CONFIDENCE_THRESHOLD,
                )
                if result.detected:
                    detected_profile_id = result.selected_profile_id
                    job_log.info(
                        f"Auto-detected framework: {result.selected_profile_name} "
                        f"(confidence={result.confidence:.2f}, "
                        f"profile_id={detected_profile_id})"
                    )
                else:
                    job_log.warning(
                        f"Framework auto-detection inconclusive. "
                        f"Top candidates: "
                        f"{[(c.profile_name, f'{c.confidence:.2f}') for c in result.candidates[:3]]}"
                    )
            except Exception as e:
                job_log.warning(f"Framework auto-detection failed (non-fatal): {e}")

        await update_job_state(job_id, STATE_AI_EXTRACTION)

        # Forward to AI Extraction via Redis Stream.
        # Pass a blob reference + page ranges — not the raw content strings.
        await publish_task(
            stream="ai_extraction:stream",
            task_name="extract_controls",
            payload={
                "framework": framework,
                "parsed_blob_path": saved_blob_path,
                "toc_pages": f"{toc_start_page}-{toc_end_page}",
                "content_pages": f"{content_start_page}-{content_end_page}",
                "framework_profile_id": detected_profile_id or framework_profile_id,
                "source_pdf_hash": source_pdf_hash,
            },
            job_id=job_id,
        )
        job_log.info(f"[doc_processing] process_pdf done  job_id={job_id}")
        await log_audit(action="job.doc_processing.completed", entity_type="job", entity_id=job_id)

    except Exception as exc:
        # Sanitize error before storing in Redis — Azure SDK exceptions can
        # embed endpoint URLs and partial auth headers in str(exc).
        import re as _re
        safe_error = _re.sub(r'https?://\S+', '[URL]', f"{type(exc).__name__}: {str(exc)[:300]}")
        await update_job_state(job_id, f"Doc Processing Error: {safe_error}")
        from shared_core.job_client import update_job_record
        await update_job_record(job_id, status="failed", error_message=safe_error)
        job_log.error(f"[doc_processing] process_pdf failed  job_id={job_id}: {safe_error}")
        await log_audit(action="job.doc_processing.failed", entity_type="job", entity_id=job_id, details={"error": safe_error})
        raise
    finally:
        # Clean up per-job temp directory
        if tmp_dir:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        stop_job_logging(job_id)


# ── Handler registry ─────────────────────────────────────────────────────────
HANDLERS = {
    "process_pdf": process_pdf,
}
