"""
PDF Extractor
=============
Converts PDF to markdown with per-page mapping using a parser selected via
`PARSE_TYPE` in `.env`.

Supported parsers:
- `docling`
- `pymupdf4llm`
- `kreuzberg`

Storage layout (under work_dir or BLOB_STORAGE_DIR from config):
  {base}/
    {framework_name}/
      {job_id}/
        pg_1.txt       <- per-page markdown files
        pg_2.txt
        ...
        combined.md    <- combined markdown with page markers
        _complete      <- sentinel written last; absence means a prior run crashed mid-write
"""

from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

import fitz

from utils.logging_config import logger

if TYPE_CHECKING:
    from config import Settings


class PDFExtractor:
    """PDF to markdown converter with permanent per-page disk persistence."""

    def __init__(self, config: "Settings"):
        self._config = config
        self._total_pages: int = 0
        self._job_dir: Optional[Path] = None
        self._combined_markdown_path: Optional[Path] = None

    @staticmethod
    def _page_number_and_content(page) -> tuple[int, str]:
        """Normalize Kreuzberg page entries across dict/object return shapes."""
        if isinstance(page, dict):
            return int(page["page_number"]), page.get("content", "")
        return int(page.page_number), getattr(page, "content", "")

    def _resolve_job_dir(self, framework_name: str, job_id: str, work_dir: Optional[str]) -> Path:
        if not framework_name or not job_id:
            raise ValueError("framework_name and job_id must be non-empty strings")
        base_dir = Path(work_dir if work_dir else self._config.BLOB_STORAGE_DIR).resolve()
        job_dir = (base_dir / framework_name / job_id).resolve()
        if not job_dir.is_relative_to(base_dir):
            raise ValueError(
                f"framework_name or job_id escapes base directory: "
                f"{framework_name!r}, {job_id!r}"
            )
        return job_dir

    def _write_outputs(self, job_dir: Path, page_count: int, page_map: dict[int, str]) -> None:
        missing_pages = [pg for pg in range(1, page_count + 1) if pg not in page_map]
        if missing_pages:
            raise ValueError(
                f"{self._config.PARSE_TYPE} did not return all pages. Missing pages: "
                f"{missing_pages[:20]}{'...' if len(missing_pages) > 20 else ''}"
            )

        min_chars = self._config.PDF_MIN_CHARS_PER_PAGE
        total_chars = 0
        thin: List[int] = []
        for pg in range(1, page_count + 1):
            stripped = page_map[pg].strip()
            total_chars += len(stripped)
            if len(stripped) < min_chars:
                thin.append(pg)

        logger.info(
            f"PDF converted via {self._config.PARSE_TYPE}: {page_count} pages, {total_chars:,} chars"
        )
        if thin:
            logger.warning(f"Pages with thin content (<{min_chars} chars): {thin}")

        if job_dir.exists():
            shutil.rmtree(job_dir)
        job_dir.mkdir(parents=True, exist_ok=True)

        combined_markdown_path = job_dir / "combined.md"
        with combined_markdown_path.open("w", encoding="utf-8") as combined:
            for pg in range(1, page_count + 1):
                text = page_map[pg]
                (job_dir / f"pg_{pg}.txt").write_text(text, encoding="utf-8")
                if text.strip():
                    combined.write(f"{text}\n\n<!-- page={pg}/{page_count} -->\n\n")

        (job_dir / "_complete").touch()
        self._total_pages = page_count
        self._job_dir = job_dir
        self._combined_markdown_path = combined_markdown_path
        logger.info(f"Saved to: {job_dir} ({page_count} page files)")

    def _convert_with_kreuzberg(self, pdf_path: str, page_count: int) -> dict[int, str]:
        from kreuzberg import ExtractionConfig, PageConfig, extract_file_sync

        logger.info("Converting PDF via kreuzberg (markdown + per-page extraction)...")
        config = ExtractionConfig(
            output_format="markdown",
            pages=PageConfig(extract_pages=True),
        )
        result = extract_file_sync(pdf_path, config=config)
        return {
            page_number: content
            for page_number, content in (
                self._page_number_and_content(page) for page in (result.pages or [])
            )
        }

    def _convert_with_pymupdf4llm(self, pdf_path: str, page_count: int) -> dict[int, str]:
        import pymupdf4llm

        logger.info("Converting PDF via pymupdf4llm (structured markdown)...")
        chunks = pymupdf4llm.to_markdown(pdf_path, page_chunks=True)
        return {
            pg: chunk.get("text", "")
            for pg, chunk in enumerate(chunks, start=1)
        }

    def _convert_with_docling(self, pdf_path: str, page_count: int) -> dict[int, str]:
        from docling.datamodel.accelerator_options import AcceleratorDevice, AcceleratorOptions
        from docling.datamodel.base_models import InputFormat
        from docling.datamodel.pipeline_options import PdfPipelineOptions
        from docling.document_converter import DocumentConverter, PdfFormatOption

        logger.info("Converting PDF via docling (page-by-page markdown)...")
        os.environ.setdefault("OMP_NUM_THREADS", "1")

        pipeline_options = PdfPipelineOptions()
        pipeline_options.do_ocr = False
        pipeline_options.do_table_structure = False
        pipeline_options.accelerator_options = AcceleratorOptions(
            num_threads=1,
            device=AcceleratorDevice.CPU,
        )

        converter = DocumentConverter(
            format_options={
                InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
            }
        )

        page_map: dict[int, str] = {}
        for pg in range(1, page_count + 1):
            logger.debug(f"Docling converting page {pg}/{page_count}")
            result = converter.convert(
                pdf_path,
                page_range=(pg, pg),
                max_num_pages=1,
            )
            page_map[pg] = result.document.export_to_markdown().strip()
        return page_map

    def convert_pdf(
        self,
        pdf_path: str,
        framework_name: str,
        job_id: str,
        work_dir: Optional[str] = None,
    ) -> None:
        logger.info(f"Loading PDF: {pdf_path}")

        if self._total_pages > 0:
            raise RuntimeError("convert_pdf() already called. Create a new PDFExtractor instance.")

        pdf = Path(pdf_path)
        if not pdf.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        with fitz.open(pdf_path) as doc:
            if doc.is_encrypted:
                logger.error(f"Rejected encrypted PDF: {pdf_path}")
                raise ValueError("PDF is password-protected. Provide an unencrypted PDF.")
            page_count = len(doc)

        if page_count == 0:
            raise ValueError(f"PDF has 0 pages: {pdf_path}")

        max_pages = getattr(self._config, "PDF_MAX_PAGES", 0)
        if max_pages and page_count > max_pages:
            raise ValueError(
                f"PDF has {page_count} pages (maximum allowed: {max_pages})"
            )

        job_dir = self._resolve_job_dir(framework_name, job_id, work_dir)
        if (job_dir / "_complete").exists():
            logger.info(f"Job directory already exists, skipping conversion: {job_dir}")
            self._total_pages = page_count
            self._job_dir = job_dir
            self._combined_markdown_path = job_dir / "combined.md"
            return

        parse_type = self._config.PARSE_TYPE
        if parse_type == "kreuzberg":
            page_map = self._convert_with_kreuzberg(pdf_path, page_count)
        elif parse_type == "pymupdf4llm":
            page_map = self._convert_with_pymupdf4llm(pdf_path, page_count)
        elif parse_type == "docling":
            page_map = self._convert_with_docling(pdf_path, page_count)
        else:
            raise ValueError(f"Unsupported PARSE_TYPE: {parse_type}")

        self._write_outputs(job_dir, page_count, page_map)

    def extract_pages(self, start_page: int, end_page: int) -> str:
        if self._total_pages == 0:
            raise ValueError("No PDF conversion cached. Call convert_pdf() first.")

        total = self._total_pages
        if start_page < 1 or end_page > total or start_page > end_page:
            raise ValueError(f"Invalid page range {start_page}-{end_page} (PDF has {total} pages)")

        logger.debug(f"Extracting pages {start_page}–{end_page} of {total}")

        parts = []
        for pg in range(start_page, end_page + 1):
            page_file = self._job_dir / f"pg_{pg}.txt"
            try:
                text = page_file.read_text(encoding="utf-8").strip()
            except OSError as e:
                raise ValueError(f"Disk cache missing page {pg}: {e}") from e

            if text:
                parts.append(f"{text}\n\n<!-- page={pg}/{total} -->")

        content = "\n\n".join(parts)
        if len(content.strip()) < self._config.SUBCONTROL_MIN_CONTENT_CHARS:
            logger.warning(f"Pages {start_page}-{end_page}: only {len(content)} chars (below minimum)")

        return content

    def get_total_pages(self) -> int:
        return self._total_pages

    def get_job_dir(self) -> Optional[Path]:
        return self._job_dir

    def get_combined_markdown_path(self) -> Optional[Path]:
        return self._combined_markdown_path

    def __enter__(self) -> "PDFExtractor":
        return self

    def __exit__(self, *_) -> None:
        pass
