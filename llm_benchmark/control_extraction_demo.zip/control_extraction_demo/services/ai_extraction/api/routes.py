from typing import Optional

from fastapi import APIRouter, HTTPException, Path as FastAPIPath, Query
from pydantic import BaseModel, Field

from shared_core.job_client import create_job_record
from shared_core.stream_client import publish_task
from shared_core.redis_client import fetch_job_state
from shared_core.job_client import fetch_job_record
from config import get_settings

settings = get_settings()

router = APIRouter(prefix=settings.API_V1_STR, tags=["AI Extraction"])


# Aligned with extract_toc handler signature in handlers.py
class TOCRequest(BaseModel):
    orchestration_job_id: str = Field(default="", max_length=255)
    framework: str = Field(..., max_length=255)
    content: str = Field(..., max_length=5_000_000)
    toc_pages: str = Field(default="", max_length=50)
    framework_profile_id: str = Field(default="", max_length=255)


class ControlRequest(BaseModel):
    orchestration_job_id: str = Field(..., max_length=255)
    framework: str = Field(..., max_length=255)
    toc_content: str = Field(default="", max_length=5_000_000)
    control_content: str = Field(default="", max_length=5_000_000)
    toc_pages: str = Field(default="", max_length=50)
    content_pages: str = Field(default="", max_length=50)
    framework_profile_id: str = Field(default="", max_length=255)


@router.post(
    "/extract_toc",
    status_code=202,
    summary="Extract Table of Contents",
    description="Dispatch a TOC extraction task to the AI extraction Redis Stream.",
)
async def extract_toc_api(request: TOCRequest):
    """Dispatch a task to the ai_extraction Redis Stream."""
    requested_job_id = request.orchestration_job_id or None
    job_id = await publish_task(
        stream="ai_extraction:stream",
        task_name="extract_toc",
        payload={
            "framework":            request.framework,
            "content":              request.content,
            "toc_pages":            request.toc_pages,
            "framework_profile_id": request.framework_profile_id,
        },
        job_id=requested_job_id,
    )
    await create_job_record(
        job_id=job_id,
        framework=request.framework,
        framework_profile_id=request.framework_profile_id or None,
    )
    return {"job_id": job_id, "status": "queued"}


@router.post(
    "/extract_controls",
    status_code=202,
    summary="Extract controls and sub-controls",
    description="Dispatch a control extraction task to the AI extraction Redis Stream.",
)
async def extract_controls_api(request: ControlRequest):
    """Dispatch a task to the ai_extraction Redis Stream."""
    requested_job_id = request.orchestration_job_id or None
    job_id = await publish_task(
        stream="ai_extraction:stream",
        task_name="extract_controls",
        payload={
            "framework":            request.framework,
            "toc_content":          request.toc_content,
            "control_content":      request.control_content,
            "toc_pages":            request.toc_pages,
            "content_pages":        request.content_pages,
            "framework_profile_id": request.framework_profile_id,
        },
        job_id=requested_job_id,
    )
    await create_job_record(
        job_id=job_id,
        framework=request.framework,
        framework_profile_id=request.framework_profile_id or None,
    )
    return {"job_id": job_id, "status": "queued"}


@router.post(
    "/stream_controls",
    status_code=501,
    summary="Stream control extraction (not implemented)",
    description="SSE token streaming endpoint — reserved for future implementation.",
)
async def stream_controls_api(_request: ControlRequest):
    """SSE token streaming — not yet implemented."""
    raise HTTPException(
        status_code=501,
        detail="Real-time streaming is not yet implemented. Use /extract_controls for async extraction.",
    )


@router.get(
    "/jobs/{job_id}",
    summary="Get job status",
    description="Retrieve the current processing status of an extraction job.",
)
async def get_job_status(job_id: str = FastAPIPath(..., max_length=255, pattern=r'^[\w\-]+$')):
    state = await fetch_job_state(job_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    return {"job_id": job_id, "status": state}


@router.post(
    "/jobs/{job_id}/retry",
    status_code=202,
    summary="Retry a failed extraction job",
    description="Re-queue a failed job for retry. Fetches stored job data and "
                "re-publishes to the extraction stream with the full payload.",
)
async def retry_job(
    job_id: str = FastAPIPath(..., max_length=255, pattern=r'^[\w\-]+$'),
    toc_pages: Optional[str] = Query(None, max_length=50, description="TOC page range, e.g. '1-5'"),
    content_pages: Optional[str] = Query(None, max_length=50, description="Content page range, e.g. '6-50'"),
):
    """Re-queue a failed job for retry.

    Only jobs in 'ai_extraction_failed' state can be retried.
    The handler's idempotency guard prevents duplicate work if the job
    was already completed between the check and the retry.
    """
    state = await fetch_job_state(job_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    if state != "ai_extraction_failed":
        raise HTTPException(
            status_code=409,
            detail=f"Job {job_id} is in state '{state}' — only failed jobs can be retried",
        )

    # Fetch the stored job record to rebuild a complete payload.
    try:
        job_record = await fetch_job_record(job_id)
    except Exception:
        raise HTTPException(status_code=502, detail="Failed to retrieve job record from storage service")
    if job_record is None:
        raise HTTPException(status_code=404, detail=f"Job record {job_id} not found in storage")

    payload = {
        "retry": True,
        "framework": job_record.get("framework", ""),
        "parsed_blob_path": job_record.get("parsed_blob_path") or job_record.get("blob_path", ""),
        "framework_profile_id": job_record.get("framework_profile_id", ""),
        "source_pdf_hash": job_record.get("source_pdf_hash") or job_record.get("file_hash", ""),
    }
    if toc_pages:
        payload["toc_pages"] = toc_pages
    if content_pages:
        payload["content_pages"] = content_pages

    # Re-publish to the stream. The worker picks it up and the handler's
    # idempotency guard (A-01) prevents double-execution.
    await publish_task(
        stream="ai_extraction:stream",
        task_name="extract_controls",
        payload=payload,
        job_id=job_id,
    )
    return {"job_id": job_id, "status": "retry_queued"}
