from docling.document_converter import DocumentConverter
from pathlib import Path

source = r"C:\Users\User\Documents\GC_Research\control_extraction\frameworks\SAMA.pdf"

converter = DocumentConverter()
result = converter.convert(source)

md_content = result.document.export_to_markdown()

# Save to file
output_path = Path(r"C:\Users\User\Documents\GC_Research\control_extraction\frameworks\SAMA.md")
output_path.write_text(md_content, encoding="utf-8")

print(f"Saved {len(md_content)} chars to {output_path}")