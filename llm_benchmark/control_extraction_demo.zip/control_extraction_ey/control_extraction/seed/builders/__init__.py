"""
Framework profile builders.

Each framework has its own module. Add a new framework by:
  1. Adding its UUID seed to _helpers._UUID_SEEDS
  2. Writing its builder module (e.g., nist_csf.py)
  3. Importing and calling it in build_profiles() below
"""
from typing import Any

from .iso_27001 import _build_iso_27001
from .desc_isr  import _build_desc_isr
from .sama_csf  import _build_sama_csf
from .uae_ias   import _build_uae_ias
from .nca_ecc_2 import _build_nca_ecc_2

def build_profiles() -> list[dict[str, Any]]:
    """Return all active framework profile definitions."""
    return [
        _build_iso_27001(),   # ISO/IEC 27001:2022
        _build_desc_isr(),    # DESC ISR v3.1
        _build_sama_csf(),    # SAMA CSF v1.0
        # _build_nist_csf(),  — TODO
        # _build_pci_dss(),   — TODO
        # _build_swift_cscf() — TODO
        # _build_ecc(),       — TODO
        _build_nca_ecc_2(),     # NCA ECC v2
        _build_uae_ias(),     # UAE IAS v2.1
    ]
