"""
Job Repository
===============
Database-agnostic port + implementations for extraction job tracking.

Ports:
- JobRepositoryPort: Job CRUD + status updates

Implementations:
- PostgresJobRepository: PostgreSQL via SQLAlchemy (async)
- MySQLJobRepository: MySQL via SQLAlchemy (async, inherits Postgres)
- MongoJobRepository: MongoDB via PyMongo (sync)
"""

import abc
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import select, func

from .core_repo import _session_scope
from utils.logging_config import logger


# ── Abstract Port ──


class JobRepositoryPort(abc.ABC):
    """Database-agnostic port for extraction job persistence."""

    @abc.abstractmethod
    async def create_job(self, job_data: dict) -> dict:
        """Create a new job record. Returns job dict."""

    @abc.abstractmethod
    async def get_job(self, job_id: str) -> Optional[dict]:
        """Get job by ID."""

    @abc.abstractmethod
    async def update_job(self, job_id: str, updates: dict) -> Optional[dict]:
        """Update job fields (status, counts, timestamps). Returns updated job or None."""

    @abc.abstractmethod
    async def list_jobs(
        self,
        framework: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Tuple[List[dict], int]:
        """List jobs with optional filters. Returns (results, total_count)."""

    @abc.abstractmethod
    async def delete_job(self, job_id: str) -> bool:
        """Delete a job record. Returns True if found and deleted."""


# ── Helpers ──


def _safe_iso(val):
    """Convert a datetime-like value to ISO string safely."""
    if val is None:
        return None
    return val.isoformat() if hasattr(val, 'isoformat') else str(val)


# Allowlist of fields that may be updated via update_job.
# Prevents mass-assignment of identity/timestamp columns.
_JOB_UPDATABLE_FIELDS = {
    "status", "controls_extracted", "total_nodes", "error_message",
    "started_at", "completed_at", "parsed_blob_path",
    "raw_result_blob_path", "canonical_result_blob_path",
}


def _blob_download_url(blob_path: Optional[str]) -> Optional[str]:
    """Build a relative download URL for a blob path, or None if not set."""
    if not blob_path:
        return None
    return f"/api/v1/documents/{blob_path}"


def _job_to_dict(record) -> dict:
    result = {
        "id": record.id,
        "framework": record.framework,
        "framework_version": record.framework_version,
        "framework_profile_id": record.framework_profile_id,
        "user_id": record.user_id,
        "status": record.status,
        "file_name": record.file_name,
        "file_hash": record.file_hash,
        "blob_path": record.blob_path,
        "parsed_blob_path": record.parsed_blob_path,
        "raw_result_blob_path": record.raw_result_blob_path,
        "canonical_result_blob_path": record.canonical_result_blob_path,
        "controls_extracted": record.controls_extracted,
        "total_nodes": record.total_nodes,
        "error_message": record.error_message,
        "created_at": _safe_iso(record.created_at),
        "started_at": _safe_iso(record.started_at),
        "completed_at": _safe_iso(record.completed_at),
    }
    result["download_urls"] = {
        "source_pdf": _blob_download_url(record.blob_path),
        "parsed_markdown": _blob_download_url(record.parsed_blob_path),
        "raw_result_json": _blob_download_url(record.raw_result_blob_path),
        "canonical_result_json": _blob_download_url(record.canonical_result_blob_path),
    }
    return result


_MAX_HIERARCHY_DEPTH = 20


def count_nodes(sub_controls: list, _depth: int = 0) -> int:
    """Recursively count all nodes in a sub_controls tree (max depth: 20)."""
    if not sub_controls or _depth >= _MAX_HIERARCHY_DEPTH:
        return 0
    total = 0
    for sc in sub_controls:
        total += 1
        total += count_nodes(sc.get("sub_controls") or [], _depth + 1)
    return total


# ── PostgreSQL Implementation ──


class PostgresJobRepository(JobRepositoryPort):

    def __init__(self, session_maker):
        self.SessionLocal = session_maker

    async def create_job(self, job_data: dict) -> dict:
        from models import ExtractionJobModel
        async with _session_scope(self.SessionLocal, commit=True) as session:
            record = ExtractionJobModel(**job_data)
            session.add(record)
            await session.flush()
            return _job_to_dict(record)

    async def get_job(self, job_id: str) -> Optional[dict]:
        from models import ExtractionJobModel
        async with _session_scope(self.SessionLocal) as session:
            stmt = select(ExtractionJobModel).where(ExtractionJobModel.id == job_id)
            result = await session.execute(stmt)
            record = result.scalars().first()
            return _job_to_dict(record) if record else None

    async def update_job(self, job_id: str, updates: dict) -> Optional[dict]:
        from models import ExtractionJobModel
        async with _session_scope(self.SessionLocal, commit=True) as session:
            stmt = select(ExtractionJobModel).where(ExtractionJobModel.id == job_id)
            result = await session.execute(stmt)
            record = result.scalars().first()
            if not record:
                return None
            for key, value in updates.items():
                if key in _JOB_UPDATABLE_FIELDS and hasattr(record, key):
                    setattr(record, key, value)
            await session.flush()
            return _job_to_dict(record)

    async def list_jobs(
        self,
        framework: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Tuple[List[dict], int]:
        from models import ExtractionJobModel
        async with _session_scope(self.SessionLocal) as session:
            base = select(ExtractionJobModel)
            if framework:
                base = base.where(ExtractionJobModel.framework == framework)
            if status:
                base = base.where(ExtractionJobModel.status == status)

            # Count query
            count_stmt = select(func.count()).select_from(base.subquery())
            total = (await session.execute(count_stmt)).scalar()

            # Data query
            data_stmt = (
                base.order_by(ExtractionJobModel.created_at.desc())
                .offset(offset)
                .limit(limit)
            )
            result = await session.execute(data_stmt)
            records = result.scalars().all()
            return [_job_to_dict(r) for r in records], total

    async def delete_job(self, job_id: str) -> bool:
        from models import ExtractionJobModel
        async with _session_scope(self.SessionLocal, commit=True) as session:
            stmt = select(ExtractionJobModel).where(ExtractionJobModel.id == job_id)
            result = await session.execute(stmt)
            record = result.scalars().first()
            if record:
                await session.delete(record)
                return True
            return False


# ── MySQL Implementation ──


class MySQLJobRepository(PostgresJobRepository):
    """MySQL job repo — identical to PostgreSQL via SQLAlchemy ORM."""
    pass


# ── MongoDB Implementation ──


class MongoJobRepository(JobRepositoryPort):

    def __init__(self, mongo_url: str, db_name: str = "control_extraction"):
        from pymongo import MongoClient
        self._client = MongoClient(mongo_url)
        self._db = self._client[db_name]
        self._jobs = self._db["jobs"]
        self._jobs.create_index("status")
        self._jobs.create_index("framework")

    async def create_job(self, job_data: dict) -> dict:
        import asyncio
        # H-5: Copy to avoid mutating caller's dict
        job_data = dict(job_data)
        job_data["_id"] = job_data.pop("id", str(uuid.uuid4()))
        job_data.setdefault("status", "accepted")
        job_data.setdefault("controls_extracted", 0)
        job_data.setdefault("total_nodes", 0)
        job_data["created_at"] = datetime.now(timezone.utc)
        await asyncio.to_thread(self._jobs.insert_one, job_data)
        return await self.get_job(job_data["_id"])

    async def get_job(self, job_id: str) -> Optional[dict]:
        import asyncio
        doc = await asyncio.to_thread(self._jobs.find_one, {"_id": job_id})
        return self._to_dict(doc) if doc else None

    async def update_job(self, job_id: str, updates: dict) -> Optional[dict]:
        import asyncio
        result = await asyncio.to_thread(self._jobs.update_one, {"_id": job_id}, {"$set": updates})
        if result.matched_count == 0:
            return None
        return await self.get_job(job_id)

    async def list_jobs(
        self,
        framework: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Tuple[List[dict], int]:
        import asyncio
        filters: Dict[str, Any] = {}
        if framework:
            filters["framework"] = framework
        if status:
            filters["status"] = status

        def _sync_list():
            total = self._jobs.count_documents(filters)
            cursor = (
                self._jobs.find(filters)
                .sort("created_at", -1)
                .skip(offset)
                .limit(limit)
            )
            return [self._to_dict(doc) for doc in cursor], total

        return await asyncio.to_thread(_sync_list)

    async def delete_job(self, job_id: str) -> bool:
        import asyncio
        result = await asyncio.to_thread(self._jobs.delete_one, {"_id": job_id})
        return result.deleted_count > 0

    @staticmethod
    def _to_dict(doc: dict) -> dict:
        doc = dict(doc)  # copy to avoid mutating the original
        doc_id = doc.pop("_id", None)
        doc["id"] = doc_id
        for ts in ("created_at", "started_at", "completed_at"):
            if ts in doc:
                doc[ts] = _safe_iso(doc[ts])
        return doc
