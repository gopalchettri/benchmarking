"""
Repositories
=============
Database-agnostic ports + SQLAlchemy implementations for controls and profiles.

Ports:
- ControlRepositoryPort: Abstract interface for control persistence
- ProfileRepositoryPort: Abstract interface for profile persistence

Implementations:
- PostgresControlRepository / PostgresProfileRepository: PostgreSQL via SQLAlchemy (async)
- MySQLControlRepository / MySQLProfileRepository: MySQL via SQLAlchemy (async)
"""

import abc
import re
import uuid
from contextlib import asynccontextmanager
from typing import Dict, List, Optional

from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.dialects.mysql import insert as mysql_insert

from utils.logging_config import logger


def _get_models():
    """Lazy import of storage models to avoid module-name collisions in tests."""
    from models import FrameworkProfileModel, CanonicalControlModel
    return FrameworkProfileModel, CanonicalControlModel


@asynccontextmanager
async def _session_scope(session_maker, *, commit: bool = False):
    """Async context manager for database session lifecycle.

    Args:
        session_maker: SQLAlchemy async_sessionmaker callable.
        commit: If True, auto-commit on success and rollback on failure.
                If False (default for read-only queries), just close.
    """
    async with session_maker() as session:
        try:
            yield session
            if commit:
                await session.commit()
        except Exception:
            try:
                await session.rollback()
            except Exception:
                pass  # Don't mask the original exception
            raise


# ── Pydantic model for incoming extraction payloads ──

class SubControlPayload(BaseModel):
    id: str = ""
    title: str = ""
    description: str = ""
    sub_controls: Optional[list] = None


class ExtractionPayload(BaseModel):
    control_id: str
    title: str = ""
    description: str = ""
    guidance: str = ""
    sections: Optional[Dict] = None
    sub_controls: Optional[list] = None
    domain: str = ""
    domain_name: Optional[str] = None        # Set by tasks.py from profile domain_mapping
    node_type: Optional[str] = None          # "sub_subdomain" for SAMA 3.2.1.1-4, None for regular controls
    verbatim_verified: Optional[bool] = None
    extraction_confidence: Optional[float] = None
    source_pages: Optional[str] = None
    extraction_status: str = "machine_draft"
    llm_model: Optional[str] = None
    source_pdf_hash: Optional[str] = None


# ── Abstract Ports ──

class ControlRepositoryPort(abc.ABC):
    """Database-agnostic port for control persistence."""

    @abc.abstractmethod
    async def save_controls(
        self,
        job_id: str,
        framework: str,
        framework_version: str,
        framework_profile_id: str,
        extractions: List[ExtractionPayload],
    ) -> int:
        """Persist extracted controls. Returns count of saved controls."""

    @abc.abstractmethod
    async def get_controls(self, job_id: str, limit: int = 5000, offset: int = 0) -> List[dict]:
        """Get controls by job ID."""

    @abc.abstractmethod
    async def get_control_by_id(self, control_id: str) -> Optional[dict]:
        """Get a single control by ID."""

    @abc.abstractmethod
    async def search_controls(
        self,
        framework: Optional[str] = None,
        query: Optional[str] = None,
        limit: int = 500,
        offset: int = 0,
    ) -> List[dict]:
        """Search controls with optional text filter."""


class ProfileRepositoryPort(abc.ABC):
    """Database-agnostic port for framework profile persistence."""

    @abc.abstractmethod
    async def save_profile(self, profile_data: dict) -> dict:
        """Create or update a framework profile."""

    @abc.abstractmethod
    async def get_profile(self, profile_id: str) -> Optional[dict]:
        """Get a profile by ID."""

    @abc.abstractmethod
    async def get_profile_by_name(self, name: str) -> Optional[dict]:
        """Get a profile by machine name."""

    @abc.abstractmethod
    async def list_profiles(self) -> List[dict]:
        """List all profiles."""

    @abc.abstractmethod
    async def delete_profile(self, profile_id: str) -> bool:
        """Delete a profile. Returns True if deleted."""


# ── Helpers ──

def _natural_sort_key(control_id: str) -> list:
    """Sort key for dotted numeric IDs: '3.3.2' < '3.3.10' (not lexicographic)."""
    parts = re.split(r'[.\-]', control_id)
    return [int(p) if p.isdigit() else p.lower() for p in parts]


def _normalize_control_id(framework: str, version: str, raw_id: str) -> str:
    """Build a normalized control identifier: 'FRAMEWORK-VERSION:RAW_ID'."""
    fw = framework.replace(" ", "-")
    return f"{fw}-{version}:{raw_id}" if version else f"{fw}:{raw_id}"


def _build_control_insert_values(
    job_id: str,
    framework: str,
    framework_version: str,
    framework_profile_id: str,
    payload: dict,
) -> dict:
    """Build the column-value dict for a single control INSERT/upsert."""
    control_id = payload["control_id"]
    normalized = _normalize_control_id(framework, framework_version or "", control_id)

    sections = dict(payload.get("sections") or {})
    if payload.get("guidance"):
        sections.setdefault("Guidance", payload["guidance"])
    if payload.get("description"):
        sections.setdefault("Description", payload["description"])

    # Carry node_type in metadata_json (avoids DB schema migration).
    # Downstream consumers (tree builders, GRC tools, APIs) read this
    # to distinguish sub-subdomains from regular controls.
    metadata = {}
    node_type = payload.get("node_type")
    if node_type:
        metadata["node_type"] = node_type

    return dict(
        id=str(uuid.uuid4()),
        control_id_raw=control_id,
        control_id_normalized=normalized,
        title=payload.get("title", ""),
        description=payload.get("description"),
        sections=sections if sections else None,
        sub_controls=payload.get("sub_controls") or None,
        domain_name=payload.get("domain_name"),
        source_framework=framework,
        framework_version=framework_version,
        framework_profile_id=framework_profile_id or None,
        job_id=job_id,
        extraction_confidence=payload.get("extraction_confidence"),
        verbatim_verified=payload.get("verbatim_verified"),
        source_pages=payload.get("source_pages"),
        metadata_json=metadata if metadata else None,
        extraction_status=payload.get("extraction_status", "machine_draft"),
        llm_model=payload.get("llm_model"),
        source_pdf_hash=payload.get("source_pdf_hash"),
    )


# Columns updated when a duplicate (job_id, control_id_raw) is found.
# Identity columns (id, job_id, control_id_raw, source_framework, etc.) are intentionally excluded.
_UPSERT_UPDATE_COLS = (
    "title", "description", "sections", "sub_controls",
    "domain_name",
    "extraction_confidence", "verbatim_verified", "source_pages",
    "metadata_json",
    "llm_model",        # update if same job re-submitted (duplicate Redis message)
    "source_pdf_hash",  # same reason
    # extraction_status, verified_by, verified_at intentionally excluded:
    # re-extraction must never overwrite a human's verification decision.
)


# Section key priority for canonical output. Keys listed here appear first
# (in this order); any unlisted keys follow in their original order.
# Needed because PostgreSQL JSONB reorders dict keys alphabetically on storage.
_SECTION_PRIORITY = ["Principle", "Objective", "Description", "Guidance"]


def _reorder_sections(sections):
    """Restore preferred section key ordering after JSONB alphabetical reorder."""
    if not sections or not isinstance(sections, dict):
        return sections
    result = {}
    for key in _SECTION_PRIORITY:
        if key in sections:
            result[key] = sections[key]
    for key, value in sections.items():
        if key not in result:
            result[key] = value
    return result


def _model_to_dict(record) -> dict:
    return {
        "id": record.id,
        "control_id_raw": record.control_id_raw,
        "control_id_normalized": record.control_id_normalized,
        "parent_id": record.parent_id,
        "hierarchy_level": record.hierarchy_level,
        "hierarchy_path": record.hierarchy_path,
        "title": record.title,
        "description": record.description,
        "sections": _reorder_sections(record.sections),
        "sub_controls": record.sub_controls,
        "domain_name": record.domain_name,
        "source_framework": record.source_framework,
        "framework_version": record.framework_version,
        "framework_profile_id": record.framework_profile_id,
        "job_id": record.job_id,
        "extraction_confidence": record.extraction_confidence,
        "verbatim_verified": record.verbatim_verified,
        "extraction_status": record.extraction_status,
        "verified_by": record.verified_by,
        "verified_at": record.verified_at.isoformat() if record.verified_at else None,
        "metadata_json": record.metadata_json,
        "source_pages": record.source_pages,
        "llm_model": record.llm_model,
        "source_pdf_hash": record.source_pdf_hash,
        "created_at": record.created_at.isoformat() if record.created_at else None,
        "updated_at": record.updated_at.isoformat() if record.updated_at else None,
    }


def _profile_to_dict(record) -> dict:
    return {
        "id": record.id,
        "name": record.name,
        "display_name": record.display_name,
        "version": record.version,
        "prompt_module": record.prompt_module,
        "control_layout": record.control_layout,
        "domain_mapping": record.domain_mapping,
        "content_hash": record.content_hash,
        "seed_version": record.seed_version,
        "seeded_at": record.seeded_at.isoformat() if record.seeded_at else None,
        "created_at": record.created_at.isoformat() if record.created_at else None,
        "updated_at": record.updated_at.isoformat() if record.updated_at else None,
    }


# ── PostgreSQL Implementations ──

class PostgresControlRepository(ControlRepositoryPort):
    """PostgreSQL implementation for control persistence."""

    def __init__(self, session_maker):
        self.SessionLocal = session_maker

    async def save_controls(
        self,
        job_id: str,
        framework: str,
        framework_version: str,
        framework_profile_id: str,
        extractions: List[ExtractionPayload],
    ) -> int:
        _, CCM = _get_models()
        async with _session_scope(self.SessionLocal, commit=True) as session:
            for ex in extractions:
                values = _build_control_insert_values(
                    job_id, framework, framework_version,
                    framework_profile_id, ex.model_dump(),
                )
                stmt = pg_insert(CCM).values(**values)
                stmt = stmt.on_conflict_do_update(
                    constraint="uq_job_control",
                    set_={col: getattr(stmt.excluded, col) for col in _UPSERT_UPDATE_COLS},
                )
                await session.execute(stmt)
            return len(extractions)

    async def get_controls(self, job_id: str, limit: int = 5000, offset: int = 0) -> List[dict]:
        _, CCM = _get_models()
        async with _session_scope(self.SessionLocal) as session:
            stmt = (
                select(CCM)
                .where(CCM.job_id == job_id)
                .order_by(CCM.control_id_raw)
                .offset(offset)
                .limit(limit)
            )
            result = await session.execute(stmt)
            records = result.scalars().all()
            results = [_model_to_dict(r) for r in records]
            # Secondary natural sort ensures correct numeric ordering (3.3.2 < 3.3.10)
            results.sort(key=lambda r: _natural_sort_key(r.get("control_id_raw", "")))
            return results

    async def get_control_by_id(self, control_id: str) -> Optional[dict]:
        _, CCM = _get_models()
        async with _session_scope(self.SessionLocal) as session:
            stmt = select(CCM).where(CCM.id == control_id)
            result = await session.execute(stmt)
            record = result.scalars().first()
            return _model_to_dict(record) if record else None

    async def search_controls(
        self,
        framework: Optional[str] = None,
        query: Optional[str] = None,
        limit: int = 500,
        offset: int = 0,
    ) -> List[dict]:
        _, CCM = _get_models()
        async with _session_scope(self.SessionLocal) as session:
            stmt = select(CCM)
            if framework:
                stmt = stmt.where(CCM.source_framework == framework)
            if query:
                # H-1: Escape ILIKE wildcards to prevent injection
                escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
                like_pattern = f"%{escaped}%"
                stmt = stmt.where(
                    CCM.title.ilike(like_pattern)
                    | CCM.control_id_raw.ilike(like_pattern)
                )
            stmt = stmt.order_by(CCM.control_id_raw).offset(offset).limit(limit)
            result = await session.execute(stmt)
            return [_model_to_dict(r) for r in result.scalars().all()]


# Allowlist of fields that may be updated via save_profile.
# Prevents mass-assignment of identity/audit columns.
_PROFILE_UPDATABLE_FIELDS = {
    "display_name", "version", "prompt_module", "control_layout",
    "domain_mapping", "content_hash", "seed_version", "seeded_at",
}


class PostgresProfileRepository(ProfileRepositoryPort):
    """PostgreSQL implementation for framework profiles."""

    def __init__(self, session_maker):
        self.SessionLocal = session_maker

    async def save_profile(self, profile_data: dict) -> dict:
        FPM, _ = _get_models()
        async with _session_scope(self.SessionLocal, commit=True) as session:
            profile_id = profile_data.get("id") or str(uuid.uuid4())

            # M-9: Row-level lock to prevent concurrent update races
            stmt = (
                select(FPM)
                .where(FPM.id == profile_id)
                .with_for_update()
            )
            result = await session.execute(stmt)
            existing = result.scalars().first()

            if existing:
                for key, value in profile_data.items():
                    if key in _PROFILE_UPDATABLE_FIELDS and hasattr(existing, key):
                        setattr(existing, key, value)
            else:
                profile_data["id"] = profile_id
                record = FPM(**profile_data)
                session.add(record)
                existing = record

            await session.flush()
            await session.refresh(existing)
            return _profile_to_dict(existing)

    async def get_profile(self, profile_id: str) -> Optional[dict]:
        FPM, _ = _get_models()
        async with _session_scope(self.SessionLocal) as session:
            stmt = select(FPM).where(FPM.id == profile_id)
            result = await session.execute(stmt)
            record = result.scalars().first()
            return _profile_to_dict(record) if record else None

    async def get_profile_by_name(self, name: str) -> Optional[dict]:
        FPM, _ = _get_models()
        async with _session_scope(self.SessionLocal) as session:
            stmt = select(FPM).where(FPM.name == name)
            result = await session.execute(stmt)
            record = result.scalars().first()
            return _profile_to_dict(record) if record else None

    async def list_profiles(self) -> List[dict]:
        FPM, _ = _get_models()
        async with _session_scope(self.SessionLocal) as session:
            stmt = select(FPM)
            result = await session.execute(stmt)
            return [_profile_to_dict(r) for r in result.scalars().all()]

    async def delete_profile(self, profile_id: str) -> bool:
        FPM, _ = _get_models()
        async with _session_scope(self.SessionLocal, commit=True) as session:
            stmt = select(FPM).where(FPM.id == profile_id)
            result = await session.execute(stmt)
            record = result.scalars().first()
            if record:
                await session.delete(record)
                return True
            return False


# ── MySQL Implementations ──

class MySQLControlRepository(PostgresControlRepository):
    """MySQL implementation for control persistence."""

    async def save_controls(
        self,
        job_id: str,
        framework: str,
        framework_version: str,
        framework_profile_id: str,
        extractions: List[ExtractionPayload],
    ) -> int:
        _, CCM = _get_models()
        async with _session_scope(self.SessionLocal, commit=True) as session:
            for ex in extractions:
                values = _build_control_insert_values(
                    job_id, framework, framework_version,
                    framework_profile_id, ex.model_dump(),
                )
                stmt = mysql_insert(CCM).values(**values)
                stmt = stmt.on_duplicate_key_update(
                    {col: getattr(stmt.inserted, col) for col in _UPSERT_UPDATE_COLS}
                )
                await session.execute(stmt)
            return len(extractions)

    async def search_controls(
        self,
        framework: Optional[str] = None,
        query: Optional[str] = None,
        limit: int = 500,
        offset: int = 0,
    ) -> List[dict]:
        _, CCM = _get_models()
        async with _session_scope(self.SessionLocal) as session:
            stmt = select(CCM)
            if framework:
                stmt = stmt.where(CCM.source_framework == framework)
            if query:
                # MySQL LIKE is case-insensitive with utf8mb4_general_ci by default
                escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
                like_pattern = f"%{escaped}%"
                stmt = stmt.where(
                    CCM.title.like(like_pattern)
                    | CCM.control_id_raw.like(like_pattern)
                )
            stmt = stmt.order_by(CCM.control_id_raw).offset(offset).limit(limit)
            result = await session.execute(stmt)
            return [_model_to_dict(r) for r in result.scalars().all()]


class MySQLProfileRepository(PostgresProfileRepository):
    """MySQL implementation for framework profiles."""
    pass
