"""
Configuration Module for Storage & Aggregation Service

Reads settings from .env file with search-order resolution:
  1. CLI --env-file argument
  2. DOTENV_PATH environment variable
  3. services/storage/.env  (same directory as this module)
  4. services/.env  (parent directory)

Uses pydantic-settings for validation and type coercion.
"""

import os
import threading
import warnings
from pathlib import Path
from typing import List, Literal, Optional
from urllib.parse import quote_plus

from pydantic import model_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Storage service settings — all configurable via .env or environment variables."""

    # --- App Metadata & Routing ---
    APP_NAME_STORAGE: str = "Storage & Aggregation Service"
    APP_VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    LOG_LEVEL: str = "INFO"
    ENVIRONMENT: Literal["development", "production"] = "development"

    # --- CORS ---
    # Default ["*"] for dev; set to specific origins in production.
    # When ["*"], allow_credentials is automatically disabled (browser requirement).
    CORS_ALLOWED_ORIGINS: List[str] = ["*"]

    # --- Database Backend ---
    DB_BACKEND: Literal["postgresql", "mongodb", "mysql"] = "mysql"

    # --- Redis ---
    REDIS_URL: str = "redis://localhost:6379/0"

    # --- Self-reference (used by shared_core.job_client when the worker
    #     updates job records via HTTP — it calls back to this service) ---
    STORAGE_SERVICE_URL: str = "http://localhost:8003"

    # --- MySQL (assembled into DATABASE_URL when DB_BACKEND=mysql) ---
    MYSQL_USER: str = "root"
    MYSQL_PASSWORD: str = ""
    MYSQL_DB: str = "uaeccpm"
    MYSQL_HOST: str = "localhost"
    MYSQL_PORT: int = 3306
    DATABASE_URL: str = ""

    # --- Rate Limiting ---
    GLOBAL_RATE_LIMIT_MAX_REQUESTS: int = 50
    GLOBAL_RATE_LIMIT_WINDOW_SECONDS: int = 60

    # --- Trusted Proxies (used by RateLimitingMiddleware) ---
    TRUSTED_PROXY_CIDRS: List[str] = []

    # --- Output ---
    OUTPUT_DIR: str = "./output"

    # --- Blob / Document Storage ---
    BLOB_BACKEND: Literal["local", "azure"] = "azure"
    # BLOB_STORAGE_DIR: str = str(Path(__file__).resolve().parent.parent.parent / "blob_data")
    AZURE_STORAGE_CONNECTION_STRING: Optional[str] = None
    AZURE_BLOB_CONTAINER_NAME: str = "uaeccpm"
    BLOB_MAX_BYTES: int = 100 * 1024 * 1024  # 100 MB

    # --- DLQ ---
    DLQ_MAX_DELIVERY_ATTEMPTS: int = 3

    # --- Logging ---
    LOG_ROTATION_SIZE: str = "10 MB"
    LOG_RETENTION_DAYS: str = "30 days"

    @model_validator(mode="after")
    def assemble_database_url(self):
        """Build DATABASE_URL from individual DB settings if not set directly.

        Assembles the correct connection string based on DB_BACKEND:
        - mysql: mysql+asyncmy://user:pass@host:port/db?charset=utf8mb4
        """
        if not self.DATABASE_URL:
            if self.DB_BACKEND == "mysql":
                self.DATABASE_URL = (
                    f"mysql+asyncmy://{quote_plus(self.MYSQL_USER)}:{quote_plus(self.MYSQL_PASSWORD)}"
                    f"@{self.MYSQL_HOST}:{self.MYSQL_PORT}/{self.MYSQL_DB}"
                    f"?charset=utf8mb4"
                )
        return self

    @model_validator(mode="after")
    def validate_production(self):
        """Production environment validations."""
        if self.ENVIRONMENT == "production":
            # H-6: Reject empty/default DB passwords in production
            if self.DB_BACKEND == "mysql" and not self.MYSQL_PASSWORD:
                raise ValueError("MYSQL_PASSWORD must be set in production.")
            if self.BLOB_BACKEND == "azure" and not self.AZURE_STORAGE_CONNECTION_STRING:
                raise ValueError("AZURE_STORAGE_CONNECTION_STRING must be set when BLOB_BACKEND='azure'.")
        return self

    model_config = {"env_file_encoding": "utf-8", "extra": "ignore"}


# --- .env Resolution Logic ---
_SEARCH_PATHS = [
    Path(__file__).resolve().parent / ".env",
    Path(__file__).resolve().parent.parent / ".env",
]


def resolve_env_file(cli_env_path: Optional[str] = None) -> Optional[str]:
    """Find the .env file. Returns path or None."""
    if cli_env_path:
        p = Path(cli_env_path)
        if p.exists():
            return str(p)
        warnings.warn(f"--env-file '{cli_env_path}' not found. Searching defaults...")

    env_path = os.environ.get("DOTENV_PATH")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return str(p)

    for p in _SEARCH_PATHS:
        if p.exists():
            return str(p)

    return None


_settings_instance: Optional[Settings] = None
_settings_lock = threading.Lock()


def get_settings(env_file_path: Optional[str] = None) -> Settings:
    """Get the singleton Settings instance (thread-safe)."""
    global _settings_instance
    if _settings_instance is not None:
        return _settings_instance

    with _settings_lock:
        if _settings_instance is not None:
            return _settings_instance
        resolved = resolve_env_file(env_file_path)
        if resolved:
            _settings_instance = Settings(_env_file=resolved)
        else:
            warnings.warn("No .env file found. Using environment variables and defaults.")
            _settings_instance = Settings()
        return _settings_instance
