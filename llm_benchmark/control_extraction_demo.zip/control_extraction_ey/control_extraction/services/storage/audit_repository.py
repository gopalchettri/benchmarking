"""
Audit Repository
=================
Database-agnostic port + implementations for audit log persistence.

Implementations:
- PostgresAuditRepository: PostgreSQL via SQLAlchemy (async)
- MySQLAuditRepository: MySQL via SQLAlchemy (async)
- MongoAuditRepository: MongoDB via PyMongo (sync)
"""

import abc
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import select

from repositories.core_repo import _session_scope


class AuditRepositoryPort(abc.ABC):
    """Database-agnostic port for audit log persistence."""

    @abc.abstractmethod
    async def save_audit_event(self, event: Dict[str, Any]) -> str:
        """Persist a single audit event. Returns the event ID."""

    @abc.abstractmethod
    async def query_audit_logs(
        self,
        action: Optional[str] = None,
        entity_type: Optional[str] = None,
        entity_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[dict]:
        """Query audit logs with optional filters."""


class PostgresAuditRepository(AuditRepositoryPort):
    """PostgreSQL implementation for audit log persistence."""

    def __init__(self, session_maker):
        self.SessionLocal = session_maker

    async def save_audit_event(self, event: Dict[str, Any]) -> str:
        from models import AuditLogModel

        async with _session_scope(self.SessionLocal, commit=True) as session:
            details = event.get("details")
            if isinstance(details, str):
                try:
                    details = json.loads(details)
                except json.JSONDecodeError:
                    details = {"raw": details}

            created_at = event.get("created_at")
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at)
            elif not created_at:
                created_at = datetime.now(timezone.utc)

            record = AuditLogModel(
                action=event["action"],
                entity_type=event["entity_type"],
                entity_id=event["entity_id"],
                details=details,
                user_id=event.get("user_id") or None,
                created_at=created_at,
            )
            session.add(record)
            await session.flush()
            await session.refresh(record)
            return str(record.id)

    async def query_audit_logs(
        self,
        action: Optional[str] = None,
        entity_type: Optional[str] = None,
        entity_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[dict]:
        from models import AuditLogModel

        async with _session_scope(self.SessionLocal) as session:
            stmt = select(AuditLogModel)
            if action:
                stmt = stmt.where(AuditLogModel.action == action)
            if entity_type:
                stmt = stmt.where(AuditLogModel.entity_type == entity_type)
            if entity_id:
                stmt = stmt.where(AuditLogModel.entity_id == entity_id)
            stmt = stmt.order_by(AuditLogModel.created_at.desc())
            stmt = stmt.offset(offset).limit(limit)
            result = await session.execute(stmt)
            return [self._to_dict(r) for r in result.scalars().all()]

    @staticmethod
    def _to_dict(record) -> dict:
        return {
            "id": str(record.id),
            "action": record.action,
            "entity_type": record.entity_type,
            "entity_id": record.entity_id,
            "details": record.details,
            "user_id": record.user_id,
            "created_at": record.created_at.isoformat() if record.created_at else None,
        }


class MySQLAuditRepository(PostgresAuditRepository):
    """MySQL implementation for audit log persistence.

    Functionally identical to PostgreSQL — both use SQLAlchemy ORM with
    the same AuditLogModel. BigInteger auto-increment PK works the same
    (AUTO_INCREMENT on MySQL, SERIAL/IDENTITY on PostgreSQL).

    Separate class for explicit backend selection and future MySQL-specific tuning.
    """
    pass


class MongoAuditRepository(AuditRepositoryPort):
    """MongoDB implementation for audit log persistence."""

    def __init__(self, mongo_url: str, db_name: str = "control_extraction"):
        from pymongo import MongoClient
        self._client = MongoClient(mongo_url)
        self._db = self._client[db_name]
        self._audit_logs = self._db["audit_logs"]
        # Indexes for efficient querying
        self._audit_logs.create_index("action")
        self._audit_logs.create_index("created_at")

    async def save_audit_event(self, event: Dict[str, Any]) -> str:
        import asyncio

        details = event.get("details")
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except json.JSONDecodeError:
                details = {"raw": details}

        created_at = event.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        elif not created_at:
            created_at = datetime.now(timezone.utc)

        event_id = event.get("id", str(uuid.uuid4()))
        doc = {
            "action": event["action"],
            "entity_type": event["entity_type"],
            "entity_id": event["entity_id"],
            "details": details,
            "user_id": event.get("user_id") or None,
            "created_at": created_at,
        }
        # M-7: Use upsert to gracefully handle duplicate event IDs
        await asyncio.to_thread(
            self._audit_logs.update_one,
            {"_id": event_id},
            {"$setOnInsert": doc},
            upsert=True,
        )
        return event_id

    async def query_audit_logs(
        self,
        action: Optional[str] = None,
        entity_type: Optional[str] = None,
        entity_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[dict]:
        import asyncio

        filters: Dict[str, Any] = {}
        if action:
            filters["action"] = action
        if entity_type:
            filters["entity_type"] = entity_type
        if entity_id:
            filters["entity_id"] = entity_id

        def _sync_query():
            cursor = (
                self._audit_logs
                .find(filters)
                .sort("created_at", -1)
                .skip(offset)
                .limit(limit)
            )
            results = []
            for doc in cursor:
                doc_id = doc.pop("_id")
                doc["id"] = doc_id
                if "created_at" in doc and doc["created_at"]:
                    doc["created_at"] = doc["created_at"].isoformat()
                results.append(doc)
            return results

        return await asyncio.to_thread(_sync_query)
