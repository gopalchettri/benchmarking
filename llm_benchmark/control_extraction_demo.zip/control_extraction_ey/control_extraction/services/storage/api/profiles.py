"""
Profile CRUD Endpoints
======================
Create, list, get, update, delete framework profiles.
"""

import logging
import re
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, field_validator

from config import get_settings
from repositories import ProfileRepositoryPort
from shared_core.audit_client import log_audit
from api.dependencies import get_profile_repository, _require_uuid_path, _VALID_CONTROL_LAYOUTS

settings = get_settings()
router = APIRouter(prefix=settings.API_V1_STR, tags=["Profiles"])

_DOMAIN_MAPPING_MAX_ENTRIES = 200


# M-9: Shared validators — extracted to avoid duplication across Create/Update models.
def _check_prompt_module(v: Optional[str]) -> Optional[str]:
    if v is not None and not re.match(r"^prompts\.[a-z0-9_]+$", v):
        raise ValueError("prompt_module must match 'prompts.<module_name>' (lowercase, alphanumeric + underscores)")
    return v


def _check_control_layout(v: Optional[str]) -> Optional[str]:
    if v is not None and v not in _VALID_CONTROL_LAYOUTS:
        raise ValueError(f"control_layout must be one of {_VALID_CONTROL_LAYOUTS}")
    return v


def _check_domain_mapping(v: Optional[dict]) -> Optional[dict]:
    """M-10: Validate domain_mapping is Dict[str, str] with reasonable size."""
    if v is None:
        return v
    if len(v) > _DOMAIN_MAPPING_MAX_ENTRIES:
        raise ValueError(f"domain_mapping must have at most {_DOMAIN_MAPPING_MAX_ENTRIES} entries")
    for key, val in v.items():
        if not isinstance(key, str) or not isinstance(val, str):
            raise ValueError("domain_mapping must be Dict[str, str]")
    return v


class ProfileCreateRequest(BaseModel):
    """Validated request body for creating a framework profile."""
    name: str
    display_name: str
    version: str
    prompt_module: str
    control_layout: Optional[str] = None
    domain_mapping: Optional[dict] = None

    @field_validator("prompt_module")
    @classmethod
    def validate_prompt_module(cls, v: str) -> str:
        return _check_prompt_module(v)

    @field_validator("control_layout")
    @classmethod
    def validate_control_layout(cls, v: Optional[str]) -> Optional[str]:
        return _check_control_layout(v)

    @field_validator("domain_mapping")
    @classmethod
    def validate_domain_mapping(cls, v: Optional[dict]) -> Optional[dict]:
        return _check_domain_mapping(v)


class ProfileUpdateRequest(BaseModel):
    """Validated request body for updating a framework profile."""
    display_name: Optional[str] = None
    version: Optional[str] = None
    prompt_module: Optional[str] = None
    control_layout: Optional[str] = None
    domain_mapping: Optional[dict] = None

    @field_validator("prompt_module")
    @classmethod
    def validate_prompt_module(cls, v: Optional[str]) -> Optional[str]:
        return _check_prompt_module(v)

    @field_validator("control_layout")
    @classmethod
    def validate_control_layout(cls, v: Optional[str]) -> Optional[str]:
        return _check_control_layout(v)

    @field_validator("domain_mapping")
    @classmethod
    def validate_domain_mapping(cls, v: Optional[dict]) -> Optional[dict]:
        return _check_domain_mapping(v)


@router.post("/admin/framework-profiles", status_code=201)
async def create_profile(
    profile_data: ProfileCreateRequest,
    request: Request,
    repo: ProfileRepositoryPort = Depends(get_profile_repository),
):
    """Create a new framework profile."""
    from sqlalchemy.exc import IntegrityError

    data = profile_data.model_dump(exclude_none=True)
    try:
        result = await repo.save_profile(data)
    except IntegrityError:
        raise HTTPException(status_code=409, detail=f"Profile with name '{data.get('name')}' already exists")

    user_id = getattr(request.state, "user_id", None)
    await log_audit(action="profile.created", entity_type="profile", entity_id=result.get("id", ""), user_id=user_id)

    return result


@router.get("/admin/framework-profiles")
async def list_profiles(
    repo: ProfileRepositoryPort = Depends(get_profile_repository),
):
    """List all framework profiles."""
    return await repo.list_profiles()


@router.get("/admin/framework-profiles/{profile_id}")
async def get_profile(
    profile_id: str,
    repo: ProfileRepositoryPort = Depends(get_profile_repository),
):
    """Get a framework profile by ID."""
    _require_uuid_path(profile_id, "profile_id")
    try:
        profile = await repo.get_profile(profile_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found")
        return profile
    except HTTPException:
        raise
    except Exception as e:
        logging.getLogger(__name__).exception(f"Failed to get profile {profile_id}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/admin/framework-profiles/{profile_id}")
async def update_profile(
    profile_id: str,
    profile_data: ProfileUpdateRequest,
    request: Request,
    repo: ProfileRepositoryPort = Depends(get_profile_repository),
):
    """Update an existing framework profile."""
    _require_uuid_path(profile_id, "profile_id")
    existing = await repo.get_profile(profile_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Profile not found")

    data = profile_data.model_dump(exclude_none=True)
    data["id"] = profile_id
    result = await repo.save_profile(data)

    user_id = getattr(request.state, "user_id", None)
    await log_audit(action="profile.updated", entity_type="profile", entity_id=profile_id, user_id=user_id)

    return result


@router.delete("/admin/framework-profiles/{profile_id}")
async def delete_profile(
    profile_id: str,
    request: Request,
    repo: ProfileRepositoryPort = Depends(get_profile_repository),
):
    """Delete a framework profile."""
    _require_uuid_path(profile_id, "profile_id")
    deleted = await repo.delete_profile(profile_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Profile not found")

    user_id = getattr(request.state, "user_id", None)
    await log_audit(action="profile.deleted", entity_type="profile", entity_id=profile_id, user_id=user_id)

    return {"deleted": True}
