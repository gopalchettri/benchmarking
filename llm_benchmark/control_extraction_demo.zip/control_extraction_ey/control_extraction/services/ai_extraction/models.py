"""
Data Models

Framework-agnostic Pydantic models with nested sub-control support.
Uses recursive SubControl.children for arbitrary nesting depth.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from pydantic import BaseModel, computed_field, field_validator, model_validator


_MAX_SUBCONTROL_DEPTH = 20  # Same limit as _MAX_NESTING_DEPTH in controls.py


class SubControl(BaseModel):
    """A single sub-control/sub-requirement, with optional nested children."""
    number: str          # "1", "a", "i", "1.1"
    id: str              # "M2.1.1.1", "AC-2.a"
    text: str            # verbatim sub-control text
    node_type: str = ""                  # semantic type: "sub_family", "control", "requirement"
    sections: Dict[str, str] = {}        # descriptive prose (Description, Guidance, etc.)
    metadata: Dict[str, str] = {}        # structured attributes (Priority, Applicability)
    children: list[SubControl] = []

    @field_validator("number", "id")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("SubControl number/id cannot be empty")
        return v.strip()

    @field_validator("text")
    @classmethod
    def text_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Sub-control text cannot be empty")
        return v.strip()

    @model_validator(mode="after")
    def check_nesting_depth(self) -> SubControl:
        """Prevent stack overflow from malformed LLM output with excessive nesting."""
        def _check(node: SubControl, depth: int = 0) -> None:
            if depth > _MAX_SUBCONTROL_DEPTH:
                raise ValueError(
                    f"SubControl nesting exceeds max depth ({_MAX_SUBCONTROL_DEPTH})"
                )
            for child in node.children:
                _check(child, depth + 1)
        _check(self)
        return self


# Resolve forward reference for recursive model
SubControl.model_rebuild()


class ControlExtraction(BaseModel):
    """Extraction result for a single control."""
    control_id: str
    title: str
    sections: Dict[str, str] = {}
    sub_controls: List[SubControl]
    source_pages: Optional[str] = None

    @computed_field
    @property
    def total_sub_controls(self) -> int:
        """Auto-calculated total sub-controls including nested children."""
        return count_all_sub_controls(self.sub_controls)


class ExtractionsWrapper(BaseModel):
    """AST/Grammar enforced wrapper for LLM generation of multiple controls."""
    extractions: List[ControlExtraction]


class TOCEntry(BaseModel):
    """Single entry in the Table of Contents."""
    control_id: str
    title: str
    page: Optional[int] = None


class FrameworkTOC(BaseModel):
    """Table of Contents extracted from a framework PDF."""
    framework_name: str
    total_controls: int
    controls: List[TOCEntry]


def count_all_sub_controls(sub_controls: List[SubControl]) -> int:
    """Count all sub-controls including nested children (iterative, no recursion limit)."""
    count = 0
    stack = list(sub_controls)
    while stack:
        sc = stack.pop()
        count += 1
        stack.extend(sc.children)
    return count


def collect_sub_control_ids(sub_controls: List[SubControl]) -> set:
    """Collect all sub_control IDs (iterative — no recursion limit).

    H-2: Matches the iterative pattern of count_all_sub_controls() to avoid
    depth-guard truncation that could cause dedup mismatches.
    """
    ids = set()
    stack = list(sub_controls)
    while stack:
        sc = stack.pop()
        ids.add(sc.id)
        stack.extend(sc.children)
    return ids


@dataclass
class PageGroup:
    """One or more consecutive TOC entries sharing the same start page.

    All controls in the group are extracted with a single LLM call using
    the window [window_start, window_end] (inclusive, 1-indexed PDF pages).
    """
    control_ids: List[str]
    window_start: int
    window_end: int
