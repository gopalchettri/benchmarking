"""
Sub-Control Extractor
=====================
Extracts sub-controls from framework PDF content using LLM.

PRIMARY PATH — TOC page-window groups (PageGroup):
  Requires toc_entries with page numbers + control_start_page/control_end_page.
  One LLM call per PageGroup (controls sharing the same TOC start page).
  ±1 page overlap absorbs TOC off-by-one errors and cross-page content bleed.

Token tracking is done INSIDE providers.py — do NOT call record_call() here.
IDs are computed deterministically from parent_id + number (not from LLM output).
"""

import asyncio
import functools
import re
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from pydantic import ValidationError

from llm.providers import ILLMProvider, estimate_tokens
from llm.rate_limiter import TokenBucketRateLimiter
from models import (
    ControlExtraction, ExtractionsWrapper, SubControl, TOCEntry,
    PageGroup,
)
from post_extraction_validator import (
    merge_lowercase_continuations,
    renest_interleaved_children,
    detect_letter_sequence_gaps,
)
from prompts import load_framework_prompts
from prompts.base import build_subcontrol_prompts, _SAFE_CONTROL_ID
from utils.logging_config import logger
from extraction.post_process import dedup_extractions, locate_controls_in_text
from extraction.id_pattern import derive_id_pattern
from core.document import split_by_page_markers

if TYPE_CHECKING:
    from config import Settings

# Matches printed page footers (e.g. "Page 3 of 45") to strip from window text.
_PAGE_STRIP_RE = re.compile(r'\n*Page \d+ of \d+\n*')

# Max sub-control nesting depth (parsing guard, NOT rebuild iterations).
# Prevents stack overflow from malformed LLM output with excessive nesting.
_MAX_NESTING_DEPTH = 20

@functools.lru_cache(maxsize=64)
def _safe_compile_pattern(pattern: str) -> re.Pattern:
    """Compile and cache a regex pattern from a framework profile.

    lru_cache ensures each pattern is compiled only once per process lifetime.
    Raises ValueError on invalid pattern syntax.
    """
    try:
        return re.compile(pattern)
    except re.error as e:
        raise ValueError(f"Invalid regex pattern '{pattern}': {e}") from e





@dataclass
class ExtractionResult:
    """Result of sub-control extraction, preserving errors for auditability."""
    extractions: List[ControlExtraction]
    errors: List[str] = field(default_factory=list)
    missing_control_ids: List[str] = field(default_factory=list)


# ── Module-level helpers ─────────────────────────────────────────────────────


def _natural_sort_key(value: str) -> list:
    """Sort key for dotted/hyphenated IDs: 'M1.2' < 'M1.10' (not lexicographic)."""
    parts = re.split(r'[.\-]', value)
    return [int(p) if p.isdigit() else p.lower() for p in parts]


def _merge_sub_control_lists(
    first: List[SubControl],
    second: List[SubControl],
) -> List[SubControl]:
    """Recursively merge two sub_control lists by number.

    When both lists contain the same number, their children and sections
    are merged recursively (not replaced wholesale).  This prevents
    silently dropping children that appear in only one half of a split.
    """
    seen: Dict[str, SubControl] = {}
    for sc in first:
        seen[sc.number] = sc

    for sc in second:
        prev = seen.get(sc.number)
        if prev is None:
            seen[sc.number] = sc
        else:
            # Recursively merge children
            prev.children = _merge_sub_control_lists(prev.children, sc.children)
            # Merge sections (keep existing, add missing)
            for key, val in sc.sections.items():
                if key not in prev.sections:
                    prev.sections[key] = val

    return sorted(seen.values(), key=lambda s: _natural_sort_key(s.number))


def _merge_chunked_extractions(
    first: List[ControlExtraction],
    second: List[ControlExtraction],
) -> List[ControlExtraction]:
    """Merge extractions from two split windows of the same control group.

    When a page group is too large for the context window, it is split into
    sub-windows.  Both halves target the same control_ids, so the results
    may overlap.  This helper merges them by control_id:
      - If only one half has a control, keep it as-is.
      - If both halves extracted the same control_id, recursively merge
        their sections and sub_controls (by number, at every nesting level).
        Sub-controls are sorted by natural order after merging.
    """
    if not first:
        return second
    if not second:
        return first

    by_id: Dict[str, ControlExtraction] = {}
    for ext in first:
        by_id[ext.control_id] = ext

    for ext in second:
        if ext.control_id not in by_id:
            by_id[ext.control_id] = ext
        else:
            existing = by_id[ext.control_id]
            # Merge top-level sections (keep existing values, add missing ones)
            for key, val in ext.sections.items():
                if key not in existing.sections:
                    existing.sections[key] = val
            # Recursively merge sub_controls (children at every level)
            existing.sub_controls = _merge_sub_control_lists(
                existing.sub_controls, ext.sub_controls,
            )

    return list(by_id.values())







def _validate_page_inputs(
    toc_entries: List[TOCEntry],
    control_start_page: int,
    control_end_page: int,
) -> List[str]:
    """Phase 0 sanity checks. Returns warnings (never aborts extraction)."""
    warnings = []
    for e in toc_entries:
        if e.page is not None:
            if e.page < control_start_page or e.page > control_end_page:
                warnings.append(
                    f"Control {e.control_id} TOC page {e.page} outside "
                    f"control range [{control_start_page}, {control_end_page}]"
                )
    pages_with_numbers = [e.page for e in toc_entries if e.page is not None]
    if pages_with_numbers and control_end_page < max(pages_with_numbers):
        warnings.append(
            f"control_end_page={control_end_page} < max TOC page {max(pages_with_numbers)} "
            f"— last control window will be truncated"
        )
    return warnings


def _inject_extra_toc_ids(
    toc_entries: List[TOCEntry],
    extra_ids: Dict[str, List[str]],
) -> List[TOCEntry]:
    """Inject child IDs declared by the prompt module but missing from the TOC.

    When a framework's TOC doesn't list certain sub-sections (e.g., SAMA-CSF
    3.2.1.1–3.2.1.4), the prompt module declares them in EXTRA_TOC_IDS.
    Missing children are added with the parent's page number so they appear
    in the correct page group and extraction constraint.
    """
    existing_ids = {e.control_id for e in toc_entries}
    parent_pages = {e.control_id: e.page for e in toc_entries if e.page is not None}
    injected = 0

    for parent_id, child_ids in extra_ids.items():
        parent_page = parent_pages.get(parent_id)
        if parent_page is None:
            continue
        for child_id in child_ids:
            if child_id not in existing_ids:
                toc_entries.append(TOCEntry(
                    control_id=child_id,
                    title="",
                    page=parent_page,
                ))
                existing_ids.add(child_id)
                injected += 1

    if injected:
        logger.info(
            f"Injected {injected} extra TOC ID(s) from prompt module EXTRA_TOC_IDS"
        )

    return toc_entries


def _build_page_groups(
    toc_entries: List[TOCEntry],
    control_start_page: int,
    control_end_page: int,
    window_overlap: int = 1,
) -> Tuple[List[PageGroup], List[str]]:
    """Build one PageGroup per set of controls sharing the same TOC start page.

    Returns:
        (groups, without_pages) where without_pages are control_ids that had
        no page number in the TOC and could not be assigned to a group.
    """
    if control_start_page > control_end_page:
        raise ValueError(
            f"control_start_page ({control_start_page}) > control_end_page ({control_end_page})"
        )

    with_pages = sorted(
        [(e.control_id, e.page) for e in toc_entries if e.page is not None],
        key=lambda x: x[1],
    )
    without_pages = [e.control_id for e in toc_entries if e.page is None]

    if not with_pages:
        return [], without_pages

    groups: List[PageGroup] = []
    i = 0
    while i < len(with_pages):
        page = with_pages[i][1]
        same_page: List[str] = []
        while i < len(with_pages) and with_pages[i][1] == page:
            same_page.append(with_pages[i][0])
            i += 1
        # Raw end = next group's start - 1, or control_end_page for last group
        raw_end = with_pages[i][1] - 1 if i < len(with_pages) else control_end_page
        window_start = max(page - window_overlap, control_start_page)
        window_end = min(raw_end + window_overlap, control_end_page)
        groups.append(PageGroup(
            control_ids=same_page,
            window_start=window_start,
            window_end=window_end,
        ))

    return groups, without_pages




# ── Main extractor class ─────────────────────────────────────────────────────

# ASCII-only: cybersecurity framework control IDs (NIST, ISO, SAMA, PCI, etc.)
# use only ASCII alphanumerics and separators. International chars not expected.
# Used to detect whether a matched prefix is a true word boundary or a shorter parent ID.
_ID_CONTINUATION_CHARS = frozenset(
    "._-abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
)


class SubControlExtractor:
    """Extracts sub-controls from framework content via LLM."""

    def __init__(
        self,
        provider: "ILLMProvider",
        config: "Settings",
        rate_limiter: TokenBucketRateLimiter,
    ):
        self.provider = provider
        self.config = config
        self.rate_limiter = rate_limiter
        self._deployment_name = provider.model_name

    async def extract(
        self,
        framework_name: str,
        content: str,
        framework_profile: Optional[Dict[str, Any]] = None,
        toc_entries: Optional[List[TOCEntry]] = None,
        control_start_page: Optional[int] = None,
        control_end_page: Optional[int] = None,
    ) -> ExtractionResult:
        """Extract sub-controls from content via TOC page-window groups.

        Args:
            framework_name:       Framework identifier string
            content:              Markdown content with <!-- page=X/Y --> markers
            framework_profile:    Profile dict with prompt_module, etc.
            toc_entries:          Full TOCEntry list (with .page attributes)
            control_start_page:   First PDF page index of the control section
            control_end_page:     Last PDF page index of the control section
        """
        # Inject extra TOC IDs from the prompt module (e.g., SAMA-CSF 3.2.1.x)
        # before pattern derivation so the auto-derived pattern covers all
        # expected ID depths (e.g., both 3-part and 4-part).
        if toc_entries and framework_profile and framework_profile.get("prompt_module"):
            prompt_mod = load_framework_prompts(framework_profile["prompt_module"])
            extra = getattr(prompt_mod, 'EXTRA_TOC_IDS', None)
            if extra:
                toc_entries = _inject_extra_toc_ids(toc_entries, extra)

        # Auto-derive ID pattern from TOC entries instead of reading from profile.
        # The pattern is computed from the data itself — no hand-written regex needed.
        _profile_pattern: Optional[re.Pattern] = None
        if toc_entries:
            try:
                _derived = derive_id_pattern([e.control_id for e in toc_entries])
                if _derived:
                    _profile_pattern = _safe_compile_pattern(_derived)
                    logger.info(f"Auto-derived control ID pattern: {_derived}")
            except (ValueError, re.error, TypeError, IndexError) as e:
                logger.warning(f"Pattern derivation failed, no ID validation: {e}")

        # ── PRIMARY PATH ────────────────────────────────────────────────────
        toc_has_pages = bool(toc_entries and any(e.page is not None for e in toc_entries))
        if not (
            toc_has_pages
            and control_start_page is not None
            and control_end_page is not None
        ):
            raise ValueError(
                "PageGroup extraction requires toc_entries with page numbers "
                "and control_start_page/control_end_page. "
                f"toc_has_pages={toc_has_pages}, "
                f"control_start_page={control_start_page}, "
                f"control_end_page={control_end_page}"
            )

        logger.info(
            f"PageGroup primary path: {len(toc_entries)} TOC entries, "
            f"pages {control_start_page}–{control_end_page}"
        )
        return await self._extract_by_page_groups(
            framework_name=framework_name,
            content=content,
            toc_entries=toc_entries,
            control_start_page=control_start_page,
            control_end_page=control_end_page,
            framework_profile=framework_profile,
            _profile_pattern=_profile_pattern,
        )

    # ── PAGE-GROUP PATH ──────────────────────────────────────────────────────

    async def _extract_by_page_groups(
        self,
        framework_name: str,
        content: str,
        toc_entries: List[TOCEntry],
        control_start_page: int,
        control_end_page: int,
        framework_profile: Optional[Dict],
        _profile_pattern: Optional[re.Pattern],
    ) -> ExtractionResult:
        # Phase 0: Validate inputs
        validation_warnings = _validate_page_inputs(
            toc_entries, control_start_page, control_end_page
        )
        for w in validation_warnings:
            logger.warning(f"[PageGroup validation] {w}")

        # Phase 1: Split content by page markers
        page_texts = split_by_page_markers(content)
        if not page_texts:
            raise ValueError(
                "No <!-- page=X/Y --> markers found in content. "
                "Ensure pdf_extractor.py wrote page markers before calling extract()."
            )
        logger.info(
            f"Split content into {len(page_texts)} pages "
            f"({min(page_texts)}–{max(page_texts)})"
        )

        # Phase 2: Build page groups
        groups, without_pages = _build_page_groups(
            toc_entries, control_start_page, control_end_page,
            window_overlap=self.config.WINDOW_OVERLAP,
        )

        if without_pages:
            logger.warning(
                f"No TOC page numbers for: {without_pages} — these controls may be missed"
            )

        all_expected_ids = [e.control_id for e in toc_entries]
        logger.info(
            f"Built {len(groups)} page groups for {len(all_expected_ids)} expected controls"
        )

        # Phase 3: Parallel group extraction
        # A single asyncio.gather with a semaphore is the correct concurrency pattern.
        # The semaphore bounds concurrent LLM calls; creating all coroutines upfront is
        # cheap (~1 KB each) and does not cause OOM even for 500+ groups.
        concurrency = self.config.LLM_RATE_LIMIT_BURST
        semaphore = asyncio.Semaphore(concurrency)
        errors: List[str] = list(validation_warnings)

        async def _process_group(
            i: int, group: PageGroup, _profile_pattern: Optional[re.Pattern]
        ) -> Tuple[int, List[ControlExtraction], Optional[str]]:
            async with semaphore:
                try:
                    results = await self._extract_group(
                        framework_name, group, page_texts, framework_profile, _profile_pattern
                    )
                    for r in results:
                        r.source_pages = f"{group.window_start}-{group.window_end}"
                    logger.info(
                        f"Group {i}/{len(groups)} {group.control_ids}: "
                        f"{len(results)} extraction(s)"
                    )
                    return (i, results, None)
                except Exception as e:
                    msg = f"Group {i} {group.control_ids} failed: {e}"
                    logger.error(msg, exc_info=True)
                    return (i, [], msg)

        # O-03: Job-level timeout prevents a hung LLM call from blocking the
        # entire worker indefinitely. Individual calls have their own timeout
        # (LLM_REQUEST_TIMEOUT_SECONDS), but gather itself had no upper bound.
        gather_timeout = self.config.LLM_REQUEST_TIMEOUT_SECONDS * 2
        try:
            group_results = await asyncio.wait_for(
                asyncio.gather(
                    *[_process_group(i, g, _profile_pattern) for i, g in enumerate(groups, 1)]
                ),
                timeout=gather_timeout,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(
                f"Parallel extraction timed out after {gather_timeout}s "
                f"({len(groups)} groups). Check LLM provider health."
            )

        all_extractions: List[ControlExtraction] = []
        for _idx, results, error in sorted(group_results, key=lambda x: x[0]):
            if error:
                errors.append(error)
            else:
                all_extractions.extend(results)

        # Phase 4: merge continuations + re-nest interleaved + clean sections
        if all_extractions:
            merge_lowercase_continuations(all_extractions)
            renest_interleaved_children(all_extractions)
            detect_letter_sequence_gaps(all_extractions)
            all_extractions = self._clean_sections(all_extractions)

        # Phase 5: Retry missing controls
        extracted_ids = {ext.control_id for ext in all_extractions}
        
        missing_ids_list = []

        for expected_id in all_expected_ids:
            if expected_id in extracted_ids:
                continue

            expected_prefix = expected_id + "."
            satisfied = any(
                ext_id.startswith(expected_prefix) for ext_id in extracted_ids
            )

            if not satisfied:
                missing_ids_list.append(expected_id)

        missing_ids = sorted(set(missing_ids_list))

        if missing_ids:
            logger.error(
                f"Missing {len(missing_ids)} control(s) after initial extraction: "
                f"{missing_ids}. Retrying with expanded window..."
            )
            group_for_id = {cid: g for g in groups for cid in g.control_ids}
            no_group_ids = [cid for cid in missing_ids if cid not in group_for_id]
            retryable_ids = [cid for cid in missing_ids if cid in group_for_id]

            # Phase 5.5: Text-search recovery for controls with no page group.
            # Zero LLM calls — just searches raw page text for the control ID string.
            if no_group_ids:
                recovered = locate_controls_in_text(
                    no_group_ids, page_texts,
                    control_start_page, control_end_page,
                    self.config.WINDOW_OVERLAP,
                )
                recovered_ids = set()
                for cid, pg in recovered:
                    group_for_id[cid] = pg
                    recovered_ids.add(cid)
                still_no_group = [cid for cid in no_group_ids if cid not in recovered_ids]
                retryable_ids.extend(list(recovered_ids))
                for cid in still_no_group:
                    logger.warning(f"No group found for {cid} — cannot retry")
                if recovered_ids:
                    logger.info(
                        f"Phase 5.5 recovered {len(recovered_ids)} control(s) "
                        f"via text search: {sorted(recovered_ids)}"
                    )
            else:
                still_no_group = []

            async def _retry_one(
                cid: str,
            ) -> Tuple[str, List[ControlExtraction], Optional[Exception]]:
                group = group_for_id[cid]
                try:
                    async with semaphore:
                        retry_group = PageGroup(
                            control_ids=[cid],
                            window_start=max(
                                group.window_start - self.config.WINDOW_OVERLAP,
                                control_start_page,
                            ),
                            window_end=min(
                                group.window_end + self.config.WINDOW_OVERLAP,
                                control_end_page,
                            ),
                        )
                        logger.info(
                            f"Retry {cid}: window [{retry_group.window_start}–"
                            f"{retry_group.window_end}]"
                        )
                        retry_results = await self._extract_group(
                            framework_name, retry_group, page_texts, framework_profile, _profile_pattern
                        )
                        for r in retry_results:
                            r.source_pages = f"{retry_group.window_start}-{retry_group.window_end}"
                    return cid, retry_results, None
                except Exception as e:
                    return cid, [], e

            retry_outcomes = await asyncio.gather(
                *(_retry_one(cid) for cid in retryable_ids)
            )
            still_missing: List[str] = list(still_no_group)
            for cid, retry_results, exc in retry_outcomes:
                if exc is not None:
                    still_missing.append(cid)
                    errors.append(f"Control {cid} retry failed: {exc}")
                    logger.error(f"Retry failed for {cid}: {exc}")
                elif retry_results:
                    all_extractions.extend(retry_results)
                    logger.info(f"Retry recovered: {cid}")
                else:
                    still_missing.append(cid)
                    logger.error(f"Retry returned 0 extractions for {cid}")

            missing_ids = still_missing
            if missing_ids:
                logger.error(
                    f"UNRECOVERABLE: {len(missing_ids)} control(s) missing "
                    f"after retry: {missing_ids}"
                )
                errors.extend(f"Control {cid} missing after retry" for cid in missing_ids)

        all_extractions = dedup_extractions(all_extractions, _profile_pattern)

        return ExtractionResult(
            extractions=all_extractions,
            errors=errors,
            missing_control_ids=missing_ids,
        )

    _MAX_GROUP_RECURSION_DEPTH = 10

    async def _extract_group(
        self,
        framework_name: str,
        group: PageGroup,
        page_texts: Dict[int, str],
        framework_profile: Optional[Dict],
        _profile_pattern: Optional[re.Pattern] = None,
        _depth: int = 0,
    ) -> List[ControlExtraction]:
        """One LLM call extracting all controls in a PageGroup."""
        if _depth >= self._MAX_GROUP_RECURSION_DEPTH:
            logger.warning(
                f"Max recursion depth ({self._MAX_GROUP_RECURSION_DEPTH}) reached "
                f"for group {group.control_ids} — returning partial results"
            )
            return []
        # --- Phase 1: Assemble window text ---
        all_pages = list(range(group.window_start, group.window_end + 1))
        missing_pages = []
        empty_pages = []
        window_parts = []
        for pg in all_pages:
            if pg not in page_texts:
                missing_pages.append(pg)
            elif not page_texts[pg]:
                empty_pages.append(pg)
            else:
                window_parts.append(page_texts[pg])
        if not window_parts:
            logger.warning(
                f"Empty window for {group.control_ids} "
                f"(pages {group.window_start}–{group.window_end}): "
                f"{len(missing_pages)} missing from PDF, {len(empty_pages)} empty"
            )
            return []

        window_text = "\n\n".join(window_parts)
        window_text = _PAGE_STRIP_RE.sub('\n', window_text)
        window_text = re.sub(r' {2,}', ' ', window_text)

        # Context window pre-check — split oversized windows instead of skipping.
        # Uses CHUNK_CONTEXT_RATIO as safety margin (default 0.75 = 25% headroom).
        est_tokens = estimate_tokens(window_text, model_name=self._deployment_name)
        content_budget = int(
            self.config.LLM_MODEL_CONTEXT_TOKENS * self.config.CHUNK_CONTEXT_RATIO
        ) - self.config.CHUNK_PROMPT_OVERHEAD_TOKENS - self.config.SUBCONTROL_MAX_TOKENS
        if est_tokens > content_budget:
            actual_pages = [pg for pg in all_pages if pg in page_texts and page_texts[pg]]
            if len(actual_pages) <= 1:
                logger.warning(
                    f"Single page {group.control_ids} exceeds budget "
                    f"({est_tokens:,} > {content_budget:,} tokens), extracting anyway"
                )
            else:
                # Split so first half gets pages[:mid_idx], second gets pages[mid_idx:].
                # Using mid_idx (not mid_idx+1) guarantees the first half is strictly
                # smaller than the original, preventing infinite recursion.
                mid_idx = len(actual_pages) // 2
                split_page = actual_pages[mid_idx - 1]  # last page of first half
                logger.info(
                    f"Content for {group.control_ids} exceeds budget "
                    f"({est_tokens:,} > {content_budget:,} tokens), "
                    f"splitting after page {split_page} "
                    f"({mid_idx}/{len(actual_pages)} pages in first half)"
                )
                first = PageGroup(
                    control_ids=group.control_ids,
                    window_start=group.window_start,
                    window_end=split_page,
                )
                second = PageGroup(
                    control_ids=group.control_ids,
                    window_start=split_page + 1,
                    window_end=group.window_end,
                )
                r1 = await self._extract_group(
                    framework_name, first, page_texts, framework_profile, _profile_pattern,
                    _depth=_depth + 1,
                )
                r2 = await self._extract_group(
                    framework_name, second, page_texts, framework_profile, _profile_pattern,
                    _depth=_depth + 1,
                )
                return _merge_chunked_extractions(r1, r2)

        # --- Phase 2: Build prompts ---
        if framework_profile and framework_profile.get("prompt_module"):
            prompt_mod = load_framework_prompts(framework_profile["prompt_module"])
            system_prompt, user_prompt = prompt_mod.get_subcontrol_prompts(window_text)
            # Framework-specific prompts don't receive target_control_ids,
            # so we append the constraint here (with sanitization).
            safe_ids = [cid for cid in group.control_ids if _SAFE_CONTROL_ID.match(cid)]
            if len(safe_ids) != len(group.control_ids):
                logger.warning(
                    "Dropped %d control ID(s) with unsafe characters from prompt constraint",
                    len(group.control_ids) - len(safe_ids),
                )
            if safe_ids:
                user_prompt += (
                    f"\n\nExtract ONLY these controls: {', '.join(safe_ids)}. "
                    "Ignore any other control sections you may see."
                )
        else:
            # PE-03 fix: build_subcontrol_prompts already appends "Extract ONLY"
            # when target_control_ids is provided — don't duplicate it.
            system_prompt, user_prompt = build_subcontrol_prompts(
                framework_name, window_text, target_control_ids=group.control_ids,
            )

        # --- Phase 3: LLM call + parse ---
        raw = await self._call_with_retry(
            system_prompt, user_prompt,
            self.config.SUBCONTROL_MAX_TOKENS,
            response_model=ExtractionsWrapper,
        )
        return self._parse_response(
            raw,
            known_control_ids=group.control_ids,
            profile_pattern=_profile_pattern,
        )

    # ── SHARED HELPERS ───────────────────────────────────────────────────────


    async def _call_with_retry(
        self,
        system: str,
        user: str,
        max_tokens: int,
        response_model: Optional[type] = None,
    ) -> Dict:
        """Single LLM call with rate limiting. Retries handled by provider layer."""
        await self.rate_limiter.acquire()

        est_in = estimate_tokens(system + user, model_name=self._deployment_name)
        logger.info(f"LLM call: est_input={est_in:,}, max_output={max_tokens:,}")

        start_time = time.monotonic()
        llm_response = await self.provider.generate_json_with_metrics(
            system, user, max_tokens, response_model
        )
        duration = time.monotonic() - start_time
        speed = llm_response.completion_tokens / duration if duration > 0 else 0
        logger.info(
            f"LLM response: {llm_response.prompt_tokens:,} in, "
            f"{llm_response.completion_tokens:,} out, {duration:.1f}s "
            f"({speed:.1f} tok/s)"
        )
        return llm_response.content

    def _parse_response(
        self,
        response: Dict,
        known_control_ids: Optional[List[str]] = None,
        profile_pattern: Optional[re.Pattern] = None,
    ) -> List[ControlExtraction]:
        """Parse LLM response dict into ControlExtraction objects."""
        extractions_raw = response.get("extractions", [])
        if not isinstance(extractions_raw, list):
            logger.warning(
                f"Expected 'extractions' list, got {type(extractions_raw).__name__}. "
                f"Response keys: {list(response.keys()) if isinstance(response, dict) else 'N/A'}. "
                f"Wrapping entire response as single extraction."
            )
            extractions_raw = [response]

        sorted_known = (
            sorted(known_control_ids, key=len, reverse=True)
            if known_control_ids else []
        )

        results: List[ControlExtraction] = []
        for i, raw in enumerate(extractions_raw):
            try:
                control_id = raw.get("control_id", "").strip()
                if not control_id:
                    logger.warning(f"Extraction {i}: empty control_id, skipping")
                    continue

                if profile_pattern and profile_pattern.match(control_id):
                    # Valid ID per the auto-derived pattern — accept natively.
                    # Handles frameworks where TOC format differs from body IDs.
                    pass
                elif not sorted_known and not profile_pattern:
                    # M-7: No known IDs and no pattern — accept all control_ids.
                    # This prevents silently dropping every extraction when both
                    # are empty (latent bug if a caller passes an empty group).
                    pass
                else:
                    matched_id = None
                    is_child_id = False
                    for kid in sorted_known:
                        if control_id == kid:
                            matched_id = kid
                            break
                        if control_id.startswith(kid):
                            remainder = control_id[len(kid):]
                            if not remainder or remainder[0] not in _ID_CONTINUATION_CHARS:
                                matched_id = kid
                                break
                            # Accept child IDs: "1.1" is a valid child of
                            # known TOC entry "1".  Keeps control_id as-is
                            # (no remapping to parent).
                            if remainder[0] == ".":
                                is_child_id = True
                                break

                    if matched_id:
                        control_id = matched_id
                    elif not is_child_id:
                        logger.warning(
                            f"Extraction {i}: invalid control_id '{control_id}', skipping"
                        )
                        continue

                extraction = ControlExtraction(
                    control_id=control_id,
                    title=raw.get("title", "").strip(),
                    sections=raw.get("sections", {}),
                    sub_controls=self._parse_sub_controls(
                        raw.get("sub_controls", []), parent_id=control_id
                    ),
                )
                results.append(extraction)
            except (ValidationError, AttributeError, TypeError, KeyError) as e:
                logger.warning(f"Skipping malformed extraction {i}: {type(e).__name__}: {e}")
                continue

        return results

    def _parse_sub_controls(
        self, raw_list: list, parent_id: str = "", _depth: int = 0
    ) -> List[SubControl]:
        """Recursively parse sub-controls, computing IDs from parent_id + number.

        IDs are computed deterministically: id = f"{parent_id}.{number}".
        Any id field returned by the LLM is ignored.
        """
        if _depth > _MAX_NESTING_DEPTH:
            logger.warning(
                f"_parse_sub_controls: max recursion depth exceeded at parent_id='{parent_id}'"
            )
            return []
        result: List[SubControl] = []
        for raw in raw_list:
            try:
                number = str(raw.get("number", "")).strip()
                if not number:
                    logger.warning(
                        f"Sub-control missing number under parent '{parent_id}', skipping entry"
                    )
                    raise ValueError(f"Sub-control missing number under parent '{parent_id}'")
                # If the LLM returned the full hierarchical number from the
                # document (e.g., "1.1.1" under parent "1.1"), use it directly
                # instead of re-appending the parent prefix.
                if parent_id and number.startswith(parent_id + "."):
                    sc_id = number
                else:
                    sc_id = f"{parent_id}.{number}" if parent_id else number
                children = self._parse_sub_controls(
                    raw.get("children", []), parent_id=sc_id, _depth=_depth + 1
                )
                sc = SubControl(
                    number=number,
                    id=sc_id,
                    text=str(raw.get("text", "")).strip(),
                    node_type=raw.get("node_type", ""),
                    sections=raw.get("sections", {}),
                    metadata=raw.get("metadata", {}),
                    children=children,
                )
                result.append(sc)
            except Exception as e:
                # H-6: Skip malformed sub-control children instead of raising.
                # A single bad sub-control should not abort the entire control.
                # Covers ValidationError (Pydantic) and any other parsing failure.
                logger.warning(
                    f"Skipping malformed sub-control (parent='{parent_id}'): "
                    f"{type(e).__name__}: {e}"
                )
                continue
        if not result and raw_list:
            logger.warning(
                f"All {len(raw_list)} sub-controls failed parsing. "
                f"First raw item: {raw_list[0]}"
            )
        return result

    @staticmethod
    def _build_ngrams(words: List[str], n: int) -> set:
        """Build a set of n-grams (tuples of n consecutive words).

        Uses a sliding-window comprehension (O(N) memory) rather than
        zip(*slices) which materialises N full list copies simultaneously.
        """
        if len(words) < n:
            return {tuple(words)} if words else set()
        return {tuple(words[i:i + n]) for i in range(len(words) - n + 1)}

    # M-1: Section dedup thresholds now read from config (with same defaults).

    def _clean_sections(
        self,
        extractions: List[ControlExtraction],
    ) -> List[ControlExtraction]:
        """Remove sections whose content overlaps with sub_controls text."""
        fwd_threshold = self.config.SECTION_FWD_OVERLAP_THRESHOLD
        rev_threshold = self.config.SECTION_REV_OVERLAP_THRESHOLD
        min_words = self.config.SECTION_MIN_WORDS_FOR_OVERLAP
        ngram_size = self.config.SECTION_NGRAM_SIZE

        for extraction in extractions:
            if not extraction.sections or not extraction.sub_controls:
                continue

            sc_text = " ".join(
                sc.text for sc in self._flatten_sub_controls(extraction.sub_controls)
            )
            sc_words = sc_text.lower().split()
            sc_ngrams = self._build_ngrams(sc_words, ngram_size)
            if not sc_ngrams:
                continue

            cleaned = {}
            for key, value in extraction.sections.items():
                sec_words = value.lower().split()
                if len(sec_words) < min_words:
                    cleaned[key] = value
                    continue
                sec_ngrams = self._build_ngrams(sec_words, ngram_size)
                if not sec_ngrams:
                    cleaned[key] = value
                    continue
                common = len(sec_ngrams & sc_ngrams)
                fwd = common / len(sec_ngrams)
                rev = common / len(sc_ngrams) if sc_ngrams else 0
                if (fwd > fwd_threshold
                        or rev > rev_threshold):
                    logger.info(
                        f"Removed section '{key}' from {extraction.control_id} "
                        f"(fwd={fwd:.0%}, rev={rev:.0%})"
                    )
                else:
                    cleaned[key] = value
            extraction.sections = cleaned

        return extractions

    @staticmethod
    def _flatten_sub_controls(sub_controls: List[SubControl]) -> List[SubControl]:
        """Flatten nested sub-controls into a single list (iterative, document order)."""
        flat: List[SubControl] = []
        # Reverse so pop() yields first-to-last (preserves document order)
        stack = list(reversed(sub_controls))
        while stack:
            sc = stack.pop()
            flat.append(sc)
            # Prepend children in reverse so they're popped in order
            stack.extend(reversed(sc.children))
        return flat
