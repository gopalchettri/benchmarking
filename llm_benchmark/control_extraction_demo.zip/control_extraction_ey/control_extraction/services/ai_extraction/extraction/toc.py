"""
Table of Contents Extractor

Extracts a structured list of controls from the ToC pages of a
cybersecurity framework PDF using LLM.

Uses generate_json_with_metrics() from the provider — token tracking
is handled inside the provider. Do NOT call token_tracker separately.
"""

import re
import time
from typing import TYPE_CHECKING

from pydantic import ValidationError
from llm.providers import ILLMProvider, estimate_tokens
from llm.rate_limiter import TokenBucketRateLimiter
from models import FrameworkTOC
from prompts import load_framework_prompts
from prompts.base import build_toc_prompts
from extraction.id_pattern import derive_id_pattern
from utils.logging_config import logger

if TYPE_CHECKING:
    from config import Settings

# Multi-format regex for detecting a line that is ONLY a control ID.
# Covers: letter-prefixed (M2.1.1, A.5.1), compound-prefix (PR.AC-1),
# simple letter-dash (AC-2), keyword-based (Requirement 1),
# numeric-dotted/hyphenated (3.1.1, 1-2-1, 8.4.4), bare numbers (1, 2, 3).
_ID_ONLY_LINE = re.compile(
    r'^\s*('
    r'[A-Za-z]{1,3}[\d.\-]+\d'                    # letter-prefixed: M2.1.1, A.5.1
    r'|[A-Za-z]{2,3}[.\-][A-Za-z]{2,3}[.\-]\d+'   # compound: PR.AC-1, ID.AM-1
    r'|[A-Za-z]+\-\d+'                             # simple: AC-2, SI-4
    r'|Requirement\s+\d+'                          # keyword: Requirement 1
    r'|\d+[.\-]\d+(?:[.\-]\d+)*'                   # numeric: 3.1.1, 1-2-1, 8.4.4
    r'|[1-9]\d{0,2}'                                 # bare: 1-999
    r')\s*$'
)
# Regex for a title line with dot-leaders and a trailing page number
_TITLE_WITH_PAGE = re.compile(r'^(\s*.+?)\s*\.{2,}[\s.]*(\d+)\s*$')

# fitz sometimes inserts blank lines between the ID-only line and the title line.
# Allow skipping up to this many blank lines when joining split ToC entries.
_MAX_BLANK_LINES_BETWEEN_ID_AND_TITLE = 2


def _preprocess_toc_text(raw: str) -> str:
    """Join split-line ToC entries from fitz raw text extraction.

    Fitz often places the control ID alone on one line and the
    title+dots+page on the next. This joins them into single lines.

    Before:  "3.1.1\nCyber Security Governance ........... 13"
    After:   "3.1.1 Cyber Security Governance ........... 13"
    """
    lines = raw.splitlines()
    result = []
    i = 0
    while i < len(lines):
        line = lines[i]
        id_match = _ID_ONLY_LINE.match(line)
        if id_match:
            # L-6: Skip up to 2 blank lines between the ID-only line and the
            # title line. fitz sometimes inserts whitespace-only lines between them.
            j = i + 1
            while j < len(lines) and j <= i + _MAX_BLANK_LINES_BETWEEN_ID_AND_TITLE and not lines[j].strip():
                j += 1
            if j < len(lines) and _TITLE_WITH_PAGE.match(lines[j]):
                result.append(id_match.group(1).rstrip() + " " + lines[j].lstrip())
                i = j + 1
                continue
        result.append(line)
        i += 1
    return "\n".join(result)


def _backfill_page_numbers(toc: FrameworkTOC, source_text: str) -> FrameworkTOC:
    """Recover null page numbers from source text via regex.

    For each TOCEntry with page=None, searches the source text for the
    control_id followed by dots and a trailing integer.
    """
    null_entries = [(i, e) for i, e in enumerate(toc.controls) if e.page is None]
    if not null_entries:
        return toc

    lines = source_text.splitlines()

    for idx, entry in null_entries:
        cid = re.escape(entry.control_id)
        for line_no, line in enumerate(lines):
            if not re.search(r'(?<![.\-\w])' + cid + r'(?![.\-\w])', line):
                continue
            # L-7: Search this line and the 2 following (3 lines total) for a trailing
            # page number. Prefer dot-leader matches over bare numbers to avoid
            # cross-reference false positives (e.g. section "2023" vs page "23").
            candidates = lines[line_no: line_no + 3]
            page_num = None
            # Pass 1: dot-leader patterns (high confidence)
            for candidate in candidates:
                m = re.search(r'\.{2,}[\s.]*(\d+)\s*$', candidate)
                if m:
                    page_num = int(m.group(1))
                    break
            # Pass 2: bare page number (lower confidence, constrained to 1-9999).
            # Rejects 0, 5+ digit numbers to avoid year-like false positives
            # (e.g. "2023" in body text). Framework PDFs rarely exceed 1000 pages.
            if page_num is None:
                for candidate in candidates:
                    m2 = re.fullmatch(r'\s*([1-9]\d{0,3})\s*', candidate)
                    if m2:
                        page_num = int(m2.group(1))
                        break
            if page_num is not None:
                toc.controls[idx] = entry.model_copy(update={"page": page_num})
            # M-1: Break after the first line match for this control_id.
            # Only the first occurrence in the TOC is relevant; subsequent
            # matches may be cross-references or body text, producing wrong page numbers.
            break

    recovered = sum(1 for i, _ in null_entries if toc.controls[i].page is not None)
    logger.debug(f"Page backfill: recovered {recovered}/{len(null_entries)} null page numbers")

    return toc


async def extract_toc_from_text(
    provider: ILLMProvider,
    framework_name: str,
    content: str,
    pages: str,
    rate_limiter: TokenBucketRateLimiter,
    config: "Settings",
    framework_profile: dict | None = None,
) -> FrameworkTOC:
    """
    Extract Table of Contents from text content.

    Args:
        provider: LLM provider instance
        framework_name: Name of the framework
        content: The text content of the TOC
        pages: Page range string (e.g. "1-10") for logging
        rate_limiter: Rate limiter for LLM calls
        config: Application settings
        framework_profile: Optional profile dict with prompt_module, etc.

    Returns:
        FrameworkTOC with list of controls

    Raises:
        ValueError: If content is empty or LLM response is invalid
        Exception: On LLM call failure
    """
    logger.info(f"Extracting ToC from pages {pages}")

    if not content.strip():
        raise ValueError(f"No content found for TOC extraction in pages {pages}")

    content = _preprocess_toc_text(content)

    if not content.strip():
        raise ValueError(
            f"ToC content is empty after preprocessing for pages {pages} — "
            "check that the PDF page range includes the table of contents."
        )

    est_tokens = estimate_tokens(content, model_name=provider.model_name)
    # ToC uses a single-shot call (no chunking). Validate that content fits within
    # the context window after reserving output tokens. The provider will also
    # enforce this, but checking here gives a clearer error message.
    available_for_input = config.LLM_MODEL_CONTEXT_TOKENS - config.TOC_MAX_TOKENS
    if est_tokens > available_for_input:
        raise ValueError(
            f"ToC content ({est_tokens:,} tokens) exceeds available context "
            f"({available_for_input:,} tokens = {config.LLM_MODEL_CONTEXT_TOKENS:,} "
            f"- {config.TOC_MAX_TOKENS:,} output). Consider increasing TOC_MAX_PDF_PAGES limit."
        )
    logger.info(f"ToC content: {len(content):,} chars (est. {est_tokens:,} tokens, limit: {available_for_input:,})")

    if framework_profile and framework_profile.get("prompt_module"):
        prompt_mod = load_framework_prompts(framework_profile["prompt_module"])
        system_prompt, user_prompt = prompt_mod.get_toc_prompts(content)
    else:
        system_prompt, user_prompt = build_toc_prompts(framework_name, content)

    try:
        await rate_limiter.acquire()
        logger.info(f"ToC LLM call: est. {est_tokens:,} tokens, max_output={config.TOC_MAX_TOKENS}")

        start_time = time.monotonic()
        llm_response = await provider.generate_json_with_metrics(
            system_prompt, user_prompt, config.TOC_MAX_TOKENS
        )
        duration = time.monotonic() - start_time

        logger.info(
            f"ToC LLM response: {llm_response.prompt_tokens:,} in, "
            f"{llm_response.completion_tokens:,} out, {duration:.1f}s"
        )

    except Exception as e:
        logger.exception("ToC extraction error")
        raise

    # Parse response
    try:
        raw = llm_response.content
        controls_list = raw.get("controls") or []
        toc = FrameworkTOC(
            framework_name=framework_name,
            # Always derive from the actual parsed list — the LLM may hallucinate
            # total_controls (e.g. say 93 while only returning 45 entries).
            total_controls=len(controls_list),
            controls=controls_list,
        )
        toc = _backfill_page_numbers(toc, content)

        # Auto-derive ID pattern from the extracted IDs and filter outliers.
        try:
            toc_ids = [e.control_id for e in toc.controls]
            derived_pattern = derive_id_pattern(toc_ids)
            if derived_pattern:
                id_pattern = re.compile(derived_pattern)
                logger.info(f"Auto-derived TOC ID pattern: {derived_pattern}")
                valid_entries = []
                invalid_count = 0
                for entry in toc.controls:
                    if id_pattern.match(entry.control_id):
                        valid_entries.append(entry)
                    else:
                        invalid_count += 1
                        logger.debug(f"ToC ID '{entry.control_id}' doesn't match derived pattern, skipping")
                if invalid_count:
                    logger.warning(f"ToC validation: {invalid_count} outlier entries removed (derived pattern: {derived_pattern})")
                toc.controls = valid_entries
                toc.total_controls = len(valid_entries)
        except (ValueError, re.error, TypeError, IndexError) as e:
            logger.warning(f"Pattern derivation failed, accepting all TOC entries: {e}")

        logger.info(f"ToC found {toc.total_controls} controls")
        for entry in toc.controls:
            page_str = f"Page {entry.page}" if entry.page else "Page --"
            logger.debug(f"  [{page_str}] {entry.control_id} {entry.title}")
        return toc
    except (KeyError, TypeError, AttributeError, ValidationError) as e:
        logger.error(f"ToC validation error: {e}")
        raise ValueError(f"Failed to parse ToC from LLM response: {e}") from e


