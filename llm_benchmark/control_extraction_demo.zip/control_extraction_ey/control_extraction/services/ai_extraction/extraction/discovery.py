"""
Discovery mode — fallback when TOC extraction returns zero entries.
Scans content body pages in small overlapping windows to find control IDs.
"""

import re
import asyncio
from typing import TYPE_CHECKING
from utils.logging_config import logger
from core.document import split_by_page_markers, PAGE_MARKER_RE
from llm.providers import estimate_tokens
from prompts.base import build_discovery_prompts
from extraction.id_pattern import derive_id_pattern, detect_normalization_prefix
from models import FrameworkTOC, TOCEntry

if TYPE_CHECKING:
    from config import Settings
    from llm.rate_limiter import TokenBucketRateLimiter
    from llm.interfaces import ILLMProvider


# ── Discovery-mode constants ─────────────────────────────────────────────────
# Safety ceiling: prevents runaway LLM calls on extremely large documents.
# At DISCOVERY_WINDOW_SIZE=4, covers up to 200 content pages (50 * 4).
_DISC_MAX_LLM_CALLS = 50


# ═══════════════════════════════════════════════════════════════════════════════
# Discovery mode — fallback when TOC extraction returns zero entries.
# Scans content body pages in small overlapping windows to find control IDs.
# ═══════════════════════════════════════════════════════════════════════════════

def _try_normalize_id(raw_id: str, pattern: re.Pattern, id_prefixes: list[str] = None) -> str:
    """Attempt to normalize a control ID to match the expected pattern.

    Some frameworks print control IDs differently in the body than in references.
    For example, ISO 27001 Table A.1 prints "5.1" but the canonical form is "A.5.1".

    Strategy:
      1. If the raw ID already matches the pattern → return as-is.
      2. Try adding common prefixes configured in the framework profile and check again.
      3. If nothing works → return the raw ID unchanged (caller will filter it out).

    This avoids framework-specific normalization config. The pattern itself
    is enough to guide the normalization attempts.

    Args:
        raw_id:      Control ID as returned by the LLM (e.g., "5.1")
        pattern:     Compiled regex from the framework profile (e.g., r"^A\\.\\d+\\.\\d+$")
        id_prefixes: Optional list of prefixes to attempt to prepend (e.g. `["A."]`)

    Returns:
        Normalized ID if a match was found, otherwise the original raw_id.
    """
    if pattern.match(raw_id):
        return raw_id

    if id_prefixes:
        for prefix in id_prefixes:
            candidate = prefix + raw_id
            if pattern.match(candidate):
                return candidate

    return raw_id


def _build_discovery_windows(
    page_texts: dict[int, str],
    start_page: int,
    end_page: int,
    window_size: int,
    overlap: int,
) -> list[tuple[int, int]]:
    """Build a list of (window_start, window_end) tuples for discovery scanning.

    Creates overlapping windows of `window_size` pages, stepping by
    (window_size - overlap) pages each time. This ensures every control
    is seen by at least one window, even if it falls on a page boundary.

    Example with window_size=4, overlap=1, pages 17-24:
      Window 1: pages 17-20
      Window 2: pages 20-23
      Window 3: pages 23-24  (last window may be smaller)

    Args:
        page_texts:  Dict of {page_number: text} from PDF splitting.
        start_page:  First page to scan (from content_pages or clamped).
        end_page:    Last page to scan (from content_pages or clamped).
        window_size: Number of pages per window.
        overlap:     Number of overlapping pages between consecutive windows.

    Returns:
        List of (start, end) tuples. Each tuple defines one discovery window.
    """
    # Clamp to actual available pages to avoid scanning empty ranges
    actual_start = max(start_page, min(page_texts.keys()))
    actual_end = min(end_page, max(page_texts.keys()))

    if actual_start > actual_end:
        return []

    step = max(1, window_size - overlap)
    windows = []
    current = actual_start

    while current <= actual_end:
        w_end = min(current + window_size - 1, actual_end)
        windows.append((current, w_end))
        current += step

    return windows


def _build_window_text(
    page_texts: dict[int, str],
    window_start: int,
    window_end: int,
) -> str:
    """Build LLM-ready text for a discovery window with [PAGE N] headers.

    Replaces the raw <!-- page=X/Y --> markers with simple [PAGE N] headers.
    This removes ambiguity for the LLM: controls below a [PAGE N] header
    are on page N. No need for the LLM to parse HTML comment syntax.

    Example output:
        [PAGE 17]
        Table A.1 — Information security controls
        5.1  Policies for information security  Control ...

        [PAGE 18]
        5.12  Classification of information ...

    Args:
        page_texts:   Dict of {page_number: text} from PDF splitting.
        window_start: First page in this window.
        window_end:   Last page in this window.

    Returns:
        Combined text with [PAGE N] headers, or empty string if no text found.
    """
    parts = []
    for pg in range(window_start, window_end + 1):
        if pg not in page_texts or not page_texts[pg]:
            continue
        # Strip existing page markers — we replace them with [PAGE N] headers
        clean_text = PAGE_MARKER_RE.sub('', page_texts[pg]).strip()
        if clean_text:
            parts.append(f"[PAGE {pg}]\n{clean_text}")

    return "\n\n".join(parts)


def _clean_discovery_entry(
    raw_entry: dict,
    window_start: int,
    window_end: int,
    id_pattern: re.Pattern | None,
    id_prefixes: list[str] = None,
) -> dict | None:
    """Validate and clean a single discovery entry from the LLM.

    Applies four filters in order:
      1. Strip whitespace and markdown formatting from control_id.
      2. Reject entries with empty control_id.
      3. Reject entries whose page number falls outside this window's range
         (catches LLM page hallucination).
      4. Normalize the ID and check against the auto-derived ID pattern
         (catches false positives like "Figure 3.2").

    Args:
        raw_entry:    Single entry dict from LLM response {"control_id", "title", "page"}.
        window_start: First page of the window that produced this entry.
        window_end:   Last page of the window that produced this entry.
        id_pattern:   Compiled regex for valid control IDs (from framework profile).
                      None = skip pattern check (not recommended for production).

    Returns:
        Cleaned entry dict if valid, None if rejected.
    """
    # --- Step 1: Clean the control_id ---
    raw_id = str(raw_entry.get("control_id", "")).strip()
    # Python str.strip(chars) removes ALL characters in the set from BOTH edges,
    # handling any nesting depth: ***A.5.1*** → A.5.1, `**id**` → id
    raw_id = raw_id.strip('*_`')
    raw_id = re.sub(r'\s+', '', raw_id)           # strip internal spaces: A. 5.1 → A.5.1

    if not raw_id:
        return None

    # --- Step 2: Validate page is within this window's range ---
    page = raw_entry.get("page")
    if page is None:
        return None
    try:
        page = int(page)
    except (ValueError, TypeError):
        return None

    if page < window_start or page > window_end:
        # LLM hallucinated a page number outside the window it was shown.
        # This is the strongest anti-hallucination check in discovery.
        return None

    # --- Step 3: Normalize ID and check against pattern ---
    if id_pattern:
        normalized_id = _try_normalize_id(raw_id, id_pattern, id_prefixes)
        if not id_pattern.match(normalized_id):
            return None
        # L-5: Log when normalization changes the ID (aids debugging mismatches)
        if normalized_id != raw_id:
            logger.debug(f"[Discovery] ID normalized: '{raw_id}' → '{normalized_id}'")
        raw_id = normalized_id

    # --- Step 4: Clean title (optional field, for logging/debugging) ---
    title = str(raw_entry.get("title", "")).strip()

    return {"control_id": raw_id, "title": title, "page": page}


async def discover_controls_from_body(
    provider: "ILLMProvider",
    framework_name: str,
    content: str,
    start_page: int,
    end_page: int,
    rate_limiter: "TokenBucketRateLimiter",
    config: "Settings",
    framework_profile: dict | None = None,
) -> "FrameworkTOC":
    """Discover control IDs and page locations by scanning body pages.

    This is the fallback for frameworks whose Table of Contents does not
    list individual controls (e.g., ISO 27001 where TOC just says "Annex A").

    HOW IT WORKS (simple version):
      1. Split the content into individual pages using <!-- page=X/Y --> markers.
      2. Build small overlapping windows of pages (same size Phase 2 uses).
      3. Send each window to the LLM: "what control IDs are on these pages?"
      4. Filter each result: page must be in window range, ID must match pattern.
      5. Merge all results, remove duplicates (keep first occurrence).
      6. Return a FrameworkTOC — same type the TOC extractor returns.

    The rest of the pipeline (extraction.controls) receives the same
    data type whether it came from the TOC or from discovery. It cannot
    tell the difference and does not need to.

    Args:
        provider:           LLM provider instance (Azure or Ollama).
        framework_name:     Human-readable framework name.
        content:            Full markdown content with <!-- page=X/Y --> markers.
        start_page:         First page to scan (from content_pages job param).
        end_page:           Last page to scan (from content_pages job param).
        rate_limiter:       Shared rate limiter (same instance Phase 2 will use).
        config:             Application settings.
        framework_profile:  Framework profile dict.

    Returns:
        FrameworkTOC with discovered controls and page numbers.

    Raises:
        ValueError: If content has no page markers or page range is invalid.
        RuntimeError: If more than half the discovery windows fail.
    """
    # ── Import here to avoid circular dependency at module level ──────

    logger.info(
        f"[Discovery] Starting control discovery for {framework_name}, "
        f"pages {start_page}-{end_page}"
    )

    # ── Step 1: Split content into pages ─────────────────────────────
    page_texts = split_by_page_markers(content)
    if not page_texts:
        raise ValueError(
            "[Discovery] No <!-- page=X/Y --> markers found in content. "
            "Cannot run discovery without page boundaries."
        )

    # ── Step 2: Build windows ────────────────────────────────────────
    overlap = max(1, config.WINDOW_OVERLAP)
    windows = _build_discovery_windows(
        page_texts, start_page, end_page,
        window_size=config.DISCOVERY_WINDOW_SIZE,
        overlap=overlap,
    )
    if not windows:
        raise ValueError(
            f"[Discovery] No scannable pages in range {start_page}-{end_page}. "
            f"Available pages: {min(page_texts.keys())}-{max(page_texts.keys())}"
        )

    # M-5: Circuit breaker limit now configurable via DISCOVERY_MAX_LLM_CALLS
    max_calls = getattr(config, "DISCOVERY_MAX_LLM_CALLS", _DISC_MAX_LLM_CALLS)
    if len(windows) > max_calls:
        raise ValueError(
            f"[Discovery] Page range {start_page}-{end_page} requires "
            f"{len(windows)} LLM calls (limit: {max_calls}). "
            f"Reduce content_pages range or increase DISCOVERY_WINDOW_SIZE."
        )

    logger.info(
        f"[Discovery] Built {len(windows)} windows "
        f"(size={config.DISCOVERY_WINDOW_SIZE}, overlap={overlap})"
    )

    # ── Step 3: Initialize pattern state ─────────────────────────────
    # Pattern is no longer read from profile — it's auto-derived after
    # the window scan (Step 4b) using derive_id_pattern.
    # id_pattern starts as None: _clean_discovery_entry intentionally
    # skips per-entry pattern validation during the scan phase.
    # Filtering is deferred to Step 4b where the derived pattern is
    # applied in bulk — this avoids the chicken-and-egg problem of
    # needing a pattern before the IDs are known.
    pattern_str = ""
    # NOTE: id_pattern is intentionally None during the scan phase (Step 4).
    # The _scan_window closure captures this variable by reference. Since
    # asyncio.gather completes ALL windows before Step 4b assigns a derived
    # pattern, there is no race condition — all windows see None consistently.
    id_pattern: re.Pattern | None = None

    # ── Step 4: Scan each window with LLM ────────────────────────────
    all_entries: list[dict] = []
    failed_windows = 0
    semaphore = asyncio.Semaphore(config.LLM_RATE_LIMIT_BURST)

    async def _scan_window(
        idx: int, w_start: int, w_end: int
    ) -> tuple[int, list[dict], str | None]:
        """Scan one window and return (index, entries, error_or_none)."""
        async with semaphore:
            try:
                # Build the page text with [PAGE N] headers
                window_text = _build_window_text(page_texts, w_start, w_end)
                if not window_text:
                    logger.warning(
                        f"[Discovery] Window {idx}/{len(windows)} "
                        f"(pages {w_start}-{w_end}): empty text, skipping"
                    )
                    return (idx, [], None)

                # H-04: Context window pre-check — skip windows that are too
                # large to fit in the context window, avoiding wasted LLM calls.
                est_tokens = estimate_tokens(
                    window_text, model_name=provider.model_name
                )
                available = config.LLM_MODEL_CONTEXT_TOKENS - config.DISCOVERY_MAX_TOKENS
                if est_tokens > available:
                    logger.warning(
                        f"[Discovery] Window {idx} (pages {w_start}-{w_end}) "
                        f"exceeds context ({est_tokens:,} > {available:,} tokens), skipping"
                    )
                    return (idx, [], None)

                # Discovery prompt is intentionally permissive — no pattern or
                # prefix hints. Validation is deferred to Step 4b post-scan.
                system_prompt, user_prompt = build_discovery_prompts(
                    framework_name, window_text,
                )

                # Call LLM with rate limiting
                await rate_limiter.acquire()
                logger.info(
                    f"[Discovery] Window {idx}/{len(windows)} "
                    f"(pages {w_start}-{w_end})"
                )
                llm_response = await provider.generate_json_with_metrics(
                    system_prompt, user_prompt, config.DISCOVERY_MAX_TOKENS
                )

                # Parse response
                raw = llm_response.content
                raw_controls = raw.get("controls", [])
                if not isinstance(raw_controls, list):
                    logger.warning(
                        f"[Discovery] Window {idx}: 'controls' is not a list"
                    )
                    return (idx, [], None)

                # Validate and clean each entry (page-range check only;
                # pattern filtering is deferred to Step 4b post-scan)
                clean = []
                for entry in raw_controls:
                    cleaned = _clean_discovery_entry(
                        entry, w_start, w_end, id_pattern,
                    )
                    if cleaned:
                        clean.append(cleaned)

                logger.info(
                    f"[Discovery] Window {idx}: "
                    f"{len(raw_controls)} raw → {len(clean)} valid entries"
                )
                return (idx, clean, None)

            except Exception as e:
                error_msg = f"[Discovery] Window {idx} (pages {w_start}-{w_end}) failed: {e}"
                logger.warning(error_msg)
                return (idx, [], error_msg)

    # Run all windows (parallel with semaphore for rate limiting)
    window_results = await asyncio.gather(
        *[_scan_window(i, ws, we) for i, (ws, we) in enumerate(windows, 1)]
    )

    # Collect results and count failures
    failed_errors: list[str] = []
    for _idx, entries, error in sorted(window_results, key=lambda x: x[0]):
        if error:
            failed_windows += 1
            failed_errors.append(error)
        all_entries.extend(entries)

    # Circuit breaker: fail if too many windows failed
    if failed_windows > len(windows) // 2:
        # L-8: Include which windows failed and why, for debuggability
        error_summary = "; ".join(failed_errors[:5])
        if len(failed_errors) > 5:
            error_summary += f" ... and {len(failed_errors) - 5} more"
        raise RuntimeError(
            f"[Discovery] {failed_windows}/{len(windows)} windows failed. "
            f"Errors: {error_summary}"
        )

    if failed_windows > 0:
        # M-6: Log failure rate prominently so ops can spot degraded discovery runs.
        failure_pct = failed_windows / len(windows) * 100
        logger.warning(
            f"[Discovery] {failed_windows}/{len(windows)} windows failed "
            f"({failure_pct:.0f}% failure rate). "
            f"Proceeding with partial results. "
            f"First error: {failed_errors[0][:200] if failed_errors else 'unknown'}"
        )

    # ── Step 4b: Auto-derive pattern + normalize via domain_mapping ──
    if all_entries:
        try:
            # Deduplicate IDs before derivation — overlapping windows produce
            # duplicates that inflate statistics without changing the result.
            raw_ids = list(dict.fromkeys(
                e["control_id"] for e in all_entries if e.get("control_id")
            ))

            # Pass 1: Derive from raw IDs as returned by LLM
            raw_pattern = derive_id_pattern(raw_ids)

            # Pass 2: Auto-detect prefix from domain_mapping keys.
            # If domain keys share a prefix (e.g., "A.") that raw IDs lack,
            # normalize IDs and re-derive. Zero manual config needed.
            domain_mapping = (framework_profile or {}).get("domain_mapping", {})
            norm_prefix = detect_normalization_prefix(domain_mapping, raw_ids)

            prefixed_pattern = ""
            if norm_prefix:
                normalized_ids = [
                    rid if rid.startswith(norm_prefix) else norm_prefix + rid
                    for rid in raw_ids
                ]
                prefixed_pattern = derive_id_pattern(normalized_ids)

            # Decide: prefer prefixed pattern if it validates, else raw pattern
            if prefixed_pattern:
                pattern_str = prefixed_pattern
                # Apply prefix normalization to all entry IDs
                for entry in all_entries:
                    cid = entry["control_id"]
                    if not cid.startswith(norm_prefix):
                        entry["control_id"] = norm_prefix + cid
                logger.info(
                    f"[Discovery] Applied prefix normalization ({norm_prefix!r}) "
                    f"from domain_mapping and derived pattern: {pattern_str}"
                )
            elif raw_pattern:
                pattern_str = raw_pattern
                logger.info(f"[Discovery] Auto-derived pattern from raw IDs: {pattern_str}")

            # Filter entries against the derived pattern
            if pattern_str:
                try:
                    id_pattern = re.compile(pattern_str)
                    before_count = len(all_entries)
                    all_entries = [
                        e for e in all_entries
                        if id_pattern.match(e.get("control_id", ""))
                    ]
                    removed = before_count - len(all_entries)
                    if removed:
                        logger.info(
                            f"[Discovery] Filtered {removed} entries not matching "
                            f"derived pattern {pattern_str}"
                        )
                except re.error as e:
                    logger.warning(f"[Discovery] Derived pattern invalid: {e}")
        except (ValueError, re.error, TypeError, IndexError) as e:
            logger.warning(f"[Discovery] Pattern auto-derivation failed, accepting all entries: {e}")

    # ── Step 5: Deduplicate (keep first occurrence = lowest page) ────
    # Sort by page number so first occurrence = earliest page = most accurate
    all_entries.sort(key=lambda e: e["page"])

    seen_ids: set[str] = set()
    deduped: list[dict] = []
    for entry in all_entries:
        cid = entry["control_id"]
        if cid not in seen_ids:
            seen_ids.add(cid)
            deduped.append(entry)

    logger.info(
        f"[Discovery] {len(all_entries)} total entries → "
        f"{len(deduped)} unique controls after dedup"
    )

    # ── Step 6: Build FrameworkTOC (same type as TOC extractor) ──────
    toc_entries = [
        TOCEntry(
            control_id=e["control_id"],
            title=e.get("title", ""),
            page=e["page"],
        )
        for e in deduped
    ]

    toc = FrameworkTOC(
        framework_name=framework_name,
        total_controls=len(toc_entries),
        controls=toc_entries,
    )

    logger.info(
        f"[Discovery] Complete: {toc.total_controls} controls discovered "
        f"across pages {start_page}-{end_page}"
    )
    return toc
