"""
Post-processing and deduplication utilities for AI Extraction.
"""
from typing import List, Dict, Tuple, Optional
import re
from models import ControlExtraction, PageGroup, count_all_sub_controls, collect_sub_control_ids
from utils.logging_config import logger

def locate_controls_in_text(
    control_ids: List[str],
    page_texts: Dict[int, str],
    control_start_page: int,
    control_end_page: int,
    window_overlap: int,
) -> List[Tuple[str, PageGroup]]:
    """Phase 5.5: locate missing controls via text search (zero LLM calls).

    For each control_id, searches all page_texts for the literal control ID
    string. When found, builds a PageGroup from the pages where it appears.

    Returns:
        List of (control_id, PageGroup) for controls that were found.
    """
    results: List[Tuple[str, PageGroup]] = []
    for cid in control_ids:
        # H-3: Use lookaround regex instead of \b to avoid false positives.
        # \b treats "." as a word boundary, so "5.1" would match inside "5.10".
        # Negative lookaround ensures the ID isn't part of a longer ID.
        cid_pattern = re.compile(r'(?<![.\-\w])' + re.escape(cid) + r'(?![.\-\w])')
        found_pages: List[int] = []
        for page_num, text in page_texts.items():
            if cid_pattern.search(text):
                found_pages.append(page_num)
        if not found_pages:
            continue
        found_pages.sort()
        w_start = max(min(found_pages) - window_overlap, control_start_page)
        w_end = min(max(found_pages) + window_overlap, control_end_page)
        pg = PageGroup(
            control_ids=[cid],
            window_start=w_start,
            window_end=w_end,
        )
        logger.info(
            f"Phase 5.5: text search located {cid} on page(s) {found_pages} "
            f"→ window [{w_start}–{w_end}]"
        )
        results.append((cid, pg))
    return results

def _matches_or_child_of(control_id: str, pattern: re.Pattern) -> bool:
    """Check if control_id matches the pattern or is a dot-separated child.

    Example: pattern=r"^\d+$", control_id="1.1" → parent "1" matches → True.
    Used so that child IDs (e.g., "1.1" under TOC entry "1") are not
    discarded as phantoms or removed by structural dedup.
    """
    if pattern.match(control_id):
        return True
    parts = control_id.split(".")
    for i in range(1, len(parts)):
        if pattern.match(".".join(parts[:i])):
            return True
    return False


def dedup_extractions(
    all_extractions: List[ControlExtraction],
    _profile_pattern: Optional[re.Pattern],
) -> List[ControlExtraction]:
    """Phantom filter → structural dedup → same-ID dedup (keep richer)."""
    if not all_extractions:
        return all_extractions

    # Phantom filter: remove extractions whose control_id doesn't match the profile pattern
    # (or isn't a child of a pattern-matching parent)
    if _profile_pattern:
        kept, phantom_ids = [], []
        for ext in all_extractions:
            if _matches_or_child_of(ext.control_id, _profile_pattern):
                kept.append(ext)
            else:
                phantom_ids.append(ext.control_id)
        all_extractions = kept
        if phantom_ids:
            logger.warning(f"Removed {len(phantom_ids)} phantom extraction(s): {phantom_ids}")

    # Structural dedup: remove top-level extractions whose ID already
    # appears as a sub_control ID inside another extraction
    sub_id_to_parents: Dict[str, set] = {}
    for ext in all_extractions:
        for sc_id in collect_sub_control_ids(ext.sub_controls):
            sub_id_to_parents.setdefault(sc_id, set()).add(ext.control_id)

    structural_exempt: set = set()
    if _profile_pattern:
        for ext in all_extractions:
            if _matches_or_child_of(ext.control_id, _profile_pattern):
                structural_exempt.add(ext.control_id)

    before = len(all_extractions)
    all_extractions = [
        ext for ext in all_extractions
        if ext.control_id in structural_exempt
        or ext.control_id not in sub_id_to_parents
        or sub_id_to_parents[ext.control_id] == {ext.control_id}
    ]
    removed = before - len(all_extractions)
    if removed:
        logger.info(f"Removed {removed} duplicate child extraction(s)")

    # Same-ID dedup: keep the extraction with more sub_controls
    seen_ids: Dict[str, int] = {}
    deduped: List[ControlExtraction] = []
    for ext in all_extractions:
        if ext.control_id in seen_ids:
            existing_idx = seen_ids[ext.control_id]
            existing = deduped[existing_idx]
            if (count_all_sub_controls(ext.sub_controls)
                    > count_all_sub_controls(existing.sub_controls)):
                deduped[existing_idx] = ext
                logger.info(
                    f"Replaced duplicate '{ext.control_id}' with richer extraction"
                )
            else:
                logger.warning(f"Dropped duplicate '{ext.control_id}'")
        else:
            seen_ids[ext.control_id] = len(deduped)
            deduped.append(ext)
    if len(deduped) < len(all_extractions):
        logger.info(
            f"Resolved {len(all_extractions) - len(deduped)} same-id duplicate(s)"
        )
    return deduped
