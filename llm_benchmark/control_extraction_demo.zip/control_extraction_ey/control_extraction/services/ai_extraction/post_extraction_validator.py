"""
Post-Extraction Validator
=========================
Deterministic corrections for LLM extraction errors that prompt
engineering cannot guarantee at 100%.

merge_lowercase_continuations():
  Merges sub-controls that start with a lowercase letter into the
  preceding sub-control's text. Fixes PDF hard-line-break artifacts
  where a sentence is split across lines and the LLM treats each
  fragment as a separate numbered item.

renest_interleaved_children():
  Detects when items of one numbering type (e.g., letters) appear
  interleaved among items of another type (e.g., digits) and re-nests
  them as children of the preceding item. Uses sequence-continuity
  detection (not ratio thresholds) for zero false positives.

detect_letter_sequence_gaps():
  Warning-only validator that detects gaps in letter sequences
  (e.g., a → c means b is missing). Logs for operator review.

Framework-agnostic. Runs after LLM extraction, before dedup.
"""

from typing import List, Tuple

from config import get_settings
from models import ControlExtraction, SubControl, count_all_sub_controls
from utils.logging_config import logger


def _max_rebuild_depth() -> int:
    """Return the configured maximum recursion depth for post-extraction corrections.

    Read lazily from Settings (not at import time) so that the .env file
    and any service-specific overrides are guaranteed to be loaded first.

    Real compliance frameworks nest at most 4–5 levels deep; the default
    of 10 is generous headroom that prevents RecursionError on malformed
    LLM output while never triggering on valid framework content.

    Configurable via POST_EXTRACTION_MAX_DEPTH in .env / config.py.
    """
    return get_settings().POST_EXTRACTION_MAX_DEPTH


def merge_lowercase_continuations(
    extractions: List[ControlExtraction],
) -> int:
    """Merge sub-controls that start with lowercase into the previous control.

    Compliance frameworks write every numbered item in sentence case.
    A sub-control starting with a lowercase letter is a continuation of
    the previous item that the LLM incorrectly split at a PDF line break.

    Example (3.3.14):
      #3: "To support this process a security event monitoring standard
           should be defined, approved and implemented."
      #4: "the standard should address for all information assets..."

    Detection:  sub_control.text starts with a lowercase letter.
    Correction: Append text to previous sub_control, remove the
                lowercase entry, renumber remaining items.

    Returns the number of merges performed.
    """
    max_depth = _max_rebuild_depth()
    total_merged = 0

    for extraction in extractions:
        if len(extraction.sub_controls) < 2:
            continue

        merged_indices: List[int] = []

        for i in range(1, len(extraction.sub_controls)):
            sc = extraction.sub_controls[i]
            text = sc.text.strip()

            if not text or not text[0].islower():
                continue

            # Skip items with single-letter numbers (a, b, c…) — these are
            # intentional lettered sub-items, not PDF line-break continuations.
            if len(sc.number) == 1 and sc.number.isalpha():
                continue

            # Only merge if the PREVIOUS sub-control does not end with sentence-
            # terminal punctuation. A clean sentence boundary means the next item
            # is a new statement, not a continuation broken by a PDF line wrap.
            prev = extraction.sub_controls[i - 1]
            if prev.text.rstrip().endswith(('.', ':', ';', '!', '?', ')', '"', "'")):
                continue

            prev.text = prev.text.rstrip() + "\n" + text
            merged_indices.append(i)
            logger.debug(
                f"Merged lowercase continuation in {extraction.control_id}: "
                f"#{sc.number} (\"{text[:50]}...\") into #{prev.number}"
            )

        if merged_indices:
            for idx in reversed(merged_indices):
                extraction.sub_controls.pop(idx)

            # Only renumber when ALL existing numbers are pure integers.
            # Mixed-format controls (letters, Roman numerals) keep their original
            # numbers; we only update the computed id field.
            all_numeric = all(sc.number.isdigit() for sc in extraction.sub_controls)
            for i, sc in enumerate(extraction.sub_controls, 1):
                if all_numeric:
                    sc.number = str(i)
                if sc.number.startswith(extraction.control_id + "."):
                    sc.id = sc.number
                else:
                    sc.id = f"{extraction.control_id}.{sc.number}"
                if sc.children:
                    _rebuild_child_ids(sc.id, sc.children, max_depth=max_depth)

            total_merged += len(merged_indices)

    # Recurse into children at all levels (B-05 fix)
    for extraction in extractions:
        for sc in extraction.sub_controls:
            if sc.children:
                total_merged += _merge_children_lowercase(
                    sc.children, max_depth=max_depth,
                )

    if total_merged:
        logger.info(
            f"Merged {total_merged} lowercase continuation(s) into previous sub-controls"
        )

    return total_merged


def _merge_children_lowercase(
    children: List[SubControl], *, max_depth: int, _depth: int = 0,
) -> int:
    """Recursively merge lowercase continuations in children lists.

    Same logic as the top-level merge but applied to nested children.
    Returns the number of merges performed at all levels.
    """
    if _depth > max_depth or len(children) < 2:
        return 0

    merged = 0
    merged_indices: List[int] = []

    for i in range(1, len(children)):
        sc = children[i]
        text = sc.text.strip()
        if not text or not text[0].islower():
            continue
        # Skip single-letter-numbered items (intentional lettered sub-items).
        if len(sc.number) == 1 and sc.number.isalpha():
            continue
        prev = children[i - 1]
        if prev.text.rstrip().endswith(('.', ':', ';', '!', '?', ')', '"', "'")):
            continue
        prev.text = prev.text.rstrip() + "\n" + text
        merged_indices.append(i)

    if merged_indices:
        for idx in reversed(merged_indices):
            children.pop(idx)
        merged += len(merged_indices)

        # Renumber remaining children and rebuild IDs — same logic as the
        # top-level merge in merge_lowercase_continuations().  Without this,
        # nested children retain stale .id values after items are removed,
        # which causes wrong dedup decisions and incorrect IDs in storage.
        all_numeric = all(sc.number.isdigit() for sc in children)
        for i, sc in enumerate(children, 1):
            if all_numeric:
                sc.number = str(i)
            # Rebuild .id from the parent context.  Children don't carry
            # their parent_id, but their existing .id encodes it as
            # everything before the last "." + number segment.  We
            # reconstruct from the current .id prefix.
            parts = sc.id.rsplit(".", 1)
            parent_prefix = parts[0] if len(parts) > 1 else sc.id
            sc.id = f"{parent_prefix}.{sc.number}"
            if sc.children:
                _rebuild_child_ids(
                    sc.id, sc.children, max_depth=max_depth, _depth=_depth,
                )

    # Recurse into each child's children
    for child in children:
        if child.children:
            merged += _merge_children_lowercase(
                child.children, max_depth=max_depth, _depth=_depth + 1,
            )

    return merged


def _rebuild_child_ids(
    parent_id: str, children: List[SubControl],
    *, max_depth: int, _depth: int = 0,
) -> None:
    """Recursively rebuild IDs for all descendants after renumbering."""
    if _depth > max_depth:
        logger.warning(
            f"_rebuild_child_ids: max depth {max_depth} exceeded at {parent_id}"
        )
        return
    for child in children:
        if child.number.startswith(parent_id + "."):
            child.id = child.number
        else:
            child.id = f"{parent_id}.{child.number}"
        if child.children:
            _rebuild_child_ids(
                child.id, child.children, max_depth=max_depth, _depth=_depth + 1,
            )


# ── Numbering-type classification ────────────────────────────────────────────

def _classify_number(number: str) -> str:
    """Classify a sub-control number as 'num', 'alpha', or 'other'.

    - 'num':   pure digits (e.g., "1", "12")
    - 'alpha': single lowercase or uppercase letter (e.g., "a", "B")
    - 'other': everything else (hierarchical "1.1.1", roman "ii", mixed "4a")
    """
    if number.isdigit():
        return "num"
    if len(number) == 1 and number.isalpha():
        return "alpha"
    return "other"


def _is_next_in_sequence(last_number: str, first_number: str, ntype: str) -> bool:
    """Check if first_number is the expected successor of last_number.

    For 'num': int(last) + 1 == int(first).
    For 'alpha': chr(ord(last) + 1) == first (case-sensitive).
    """
    try:
        if ntype == "num":
            return int(last_number) + 1 == int(first_number)
        if ntype == "alpha":
            return chr(ord(last_number.lower()) + 1) == first_number.lower()
    except (ValueError, TypeError):
        pass
    return False


# ── Re-nesting interleaved children ──────────────────────────────────────────

def renest_interleaved_children(
    extractions: List[ControlExtraction],
) -> int:
    """Re-nest sub-controls that the LLM placed at the wrong level.

    Uses sequence-continuity detection: if a numbering sequence of one type
    (e.g., digits 1, 2, 3, 4) continues across a break of another type
    (e.g., letters a, b), the break items are misplaced children and get
    moved under the preceding item.

    Example: [1, 2, 3, a, b, 4] → 3+1=4 (continuous) → [1, 2, 3(a,b), 4]

    Framework-agnostic. Works on any numbering pattern.
    Returns the total number of items re-nested.
    """
    max_depth = _max_rebuild_depth()
    total_renested = 0

    for extraction in extractions:
        if not extraction.sub_controls:
            continue
        before_count = count_all_sub_controls(extraction.sub_controls)
        renested = _renest_list(
            extraction.sub_controls, extraction.control_id,
            max_depth=max_depth,
        )
        after_count = count_all_sub_controls(extraction.sub_controls)
        if before_count != after_count:
            logger.error(
                f"Data loss in renest_interleaved_children for "
                f"{extraction.control_id}: {before_count} → {after_count}"
            )
        total_renested += renested

    if total_renested:
        logger.info(
            f"Re-nested {total_renested} interleaved sub-control(s)"
        )
    return total_renested


def _build_runs(items: List[SubControl]) -> List[Tuple[str, List[int]]]:
    """Build contiguous runs of same-type items.

    Returns a list of (type, [indices]) tuples where type is 'num',
    'alpha', or 'other' and indices are positions in the items list.
    """
    runs: List[Tuple[str, List[int]]] = []
    for i, sc in enumerate(items):
        ntype = _classify_number(sc.number)
        if runs and runs[-1][0] == ntype:
            runs[-1][1].append(i)
        else:
            runs.append((ntype, [i]))
    return runs


def _renest_list(
    items: List[SubControl], parent_id: str,
    *, max_depth: int, _depth: int = 0,
) -> int:
    """Re-nest interleaved items in a single sub-controls list.

    Uses a stabilization loop: finds one minority run to move per pass,
    then re-derives runs from the modified list. Repeats until stable.

    Returns the number of items moved.
    """
    if _depth > max_depth:
        return 0

    # For lists with <2 items, only recurse into children.
    if len(items) < 2:
        moved = 0
        for sc in items:
            if sc.children:
                moved += _renest_list(
                    sc.children, sc.id, max_depth=max_depth, _depth=_depth + 1,
                )
        return moved

    moved = 0
    changed = True
    # Safety cap: each pass moves ≥1 item out of the list, so the
    # theoretical maximum is len(items).  ×2 adds headroom and
    # prevents an infinite loop on pathological LLM output.
    max_passes = len(items) * 2
    pass_count = 0

    while changed and pass_count < max_passes:
        pass_count += 1
        changed = False
        runs = _build_runs(items)

        if len(runs) < 2:
            break

        # Find the first eligible minority run and move it.
        for r in range(1, len(runs)):
            run_type, run_indices = runs[r]

            # Never move "other"-typed items — can't verify continuity.
            if run_type == "other":
                continue

            prev_type, prev_indices = runs[r - 1]
            if prev_type == "other" or prev_type == run_type:
                continue

            should_move = False

            # Case A: Flanked — runs on both sides are the same type
            # and form a continuous sequence across the break.
            if r + 1 < len(runs):
                next_type, next_indices = runs[r + 1]
                if next_type == prev_type:
                    last_before = items[prev_indices[-1]].number
                    first_after = items[next_indices[0]].number
                    if _is_next_in_sequence(
                        last_before, first_after, prev_type
                    ):
                        should_move = True

            # Case B: Trailing run — no following run to check continuity.
            # Only move if: preceding run has ≥2 items (established sequence)
            # AND this type hasn't appeared in any earlier run (it's genuinely
            # a minority, not a continuation of a dominant type).
            if (
                not should_move
                and r == len(runs) - 1
                and len(prev_indices) >= 2
            ):
                type_seen_before = any(
                    t == run_type for t, _ in runs[:r]
                )
                if not type_seen_before:
                    should_move = True

            if should_move:
                anchor = items[prev_indices[-1]]
                items_to_move = [items[i] for i in run_indices]

                for i in reversed(run_indices):
                    items.pop(i)

                for sc in items_to_move:
                    sc.id = f"{anchor.id}.{sc.number}"
                    if sc.children:
                        _rebuild_child_ids(
                            sc.id, sc.children, max_depth=max_depth,
                        )
                    anchor.children.append(sc)
                    moved += 1
                    logger.debug(
                        f"Re-nested #{sc.number} (\"{sc.text[:60]}...\") "
                        f"as child of #{anchor.number} (id={anchor.id})"
                    )

                changed = True
                break  # Re-derive runs from the modified list

    # Recurse into all children at every depth.
    for sc in items:
        if sc.children:
            moved += _renest_list(
                sc.children, sc.id, max_depth=max_depth, _depth=_depth + 1,
            )

    return moved


# ── Letter-sequence gap detection ────────────────────────────────────────────

def detect_letter_sequence_gaps(
    extractions: List[ControlExtraction],
) -> List[Tuple[str, str]]:
    """Detect gaps in letter sequences within sub-controls.

    Scans sub_controls at every nesting level for letter-numbered items
    (a, b, c, ...) and reports any missing letters in the sequence.

    Warning-only — does not modify any data.
    Returns a list of (parent_id, missing_letter) tuples.
    """
    max_depth = _max_rebuild_depth()
    all_gaps: List[Tuple[str, str]] = []

    for extraction in extractions:
        gaps = _detect_gaps_in_list(
            extraction.sub_controls, extraction.control_id,
            max_depth=max_depth,
        )
        all_gaps.extend(gaps)

    for parent_id, missing in all_gaps:
        logger.warning(
            f"Letter sequence gap: '{missing}' missing under {parent_id}"
        )

    return all_gaps


def _detect_gaps_in_list(
    items: List[SubControl], parent_id: str,
    *, max_depth: int, _depth: int = 0,
) -> List[Tuple[str, str]]:
    """Detect letter-sequence gaps in a single list and recurse into children."""
    if _depth > max_depth:
        return []

    gaps: List[Tuple[str, str]] = []

    # Collect single-letter items and check for gaps.
    letters = [
        sc.number.lower()
        for sc in items
        if len(sc.number) == 1 and sc.number.isalpha()
    ]
    if len(letters) >= 2:
        sorted_letters = sorted(set(letters))
        for i in range(1, len(sorted_letters)):
            expected_ord = ord(sorted_letters[i - 1]) + 1
            actual_ord = ord(sorted_letters[i])
            while expected_ord < actual_ord:
                missing = chr(expected_ord)
                gaps.append((parent_id, missing))
                expected_ord += 1

    # Recurse into children.
    for sc in items:
        if sc.children:
            gaps.extend(_detect_gaps_in_list(
                sc.children, sc.id, max_depth=max_depth, _depth=_depth + 1,
            ))

    return gaps
