import asyncio
import re
import uuid as _uuid
import httpx

from config import get_settings
from utils.logging_config import logger
from core.exceptions import TransientServiceError

config = get_settings()
STORAGE_SERVICE_URL = config.STORAGE_SERVICE_URL
API_V1_STR = config.API_V1_STR

# H-7: Required keys that downstream code assumes exist in a profile response.
_REQUIRED_PROFILE_KEYS = {"id", "name"}

# L-6: Reusable httpx client for profile fetches (avoids per-call creation)
# M-2: Timeout now configurable via PROFILE_FETCH_TIMEOUT_SECONDS
_profile_http_client: httpx.AsyncClient | None = None
_profile_client_lock = asyncio.Lock()


async def _get_profile_client() -> httpx.AsyncClient:
    global _profile_http_client
    if _profile_http_client is not None and not _profile_http_client.is_closed:
        return _profile_http_client
    async with _profile_client_lock:
        # Re-check after acquiring lock
        if _profile_http_client is not None and not _profile_http_client.is_closed:
            return _profile_http_client
        timeout = getattr(config, 'PROFILE_FETCH_TIMEOUT_SECONDS', 10)
        _profile_http_client = httpx.AsyncClient(timeout=float(timeout))
    return _profile_http_client


async def close_profile_client() -> None:
    """H-5: Explicitly close the profile HTTP client to prevent connection leaks.

    Called from FastAPI lifespan shutdown and worker cleanup paths.
    """
    global _profile_http_client
    if _profile_http_client is not None and not _profile_http_client.is_closed:
        await _profile_http_client.aclose()
        _profile_http_client = None
        logger.info("Closed profile HTTP client")


def _validate_profile_response(data: dict) -> bool:
    """Check that the profile response contains the minimum required keys."""
    return isinstance(data, dict) and _REQUIRED_PROFILE_KEYS.issubset(data.keys())


async def fetch_profile_via_http(framework_profile_id: str) -> dict | None:
    """Fetch a framework profile from the storage service via HTTP.

    L-5: Uses async HTTP to avoid blocking the event loop.
    """
    # Validate UUID format before embedding in URL — prevents path traversal
    # from a corrupted or malicious Redis stream payload.
    try:
        _uuid.UUID(framework_profile_id)
    except (ValueError, AttributeError):
        # Redact invalid value — it may contain adversarial content from a
        # corrupted Redis stream message. Log only a safe fragment.
        safe_fragment = str(framework_profile_id)[:8] if framework_profile_id else "<empty>"
        logger.warning(
            f"Invalid framework_profile_id format (prefix='{safe_fragment}...') "
            "— skipping profile fetch"
        )
        return None

    try:
        url = f"{STORAGE_SERVICE_URL}{API_V1_STR}/admin/framework-profiles/{framework_profile_id}"
        client = await _get_profile_client()
        resp = await client.get(url)

        if resp.status_code == 200:
            data = resp.json()
            # H-7: Validate response schema before passing downstream
            if not _validate_profile_response(data):
                logger.error(
                    f"Profile response for {framework_profile_id} missing required keys "
                    f"{_REQUIRED_PROFILE_KEYS - set(data.keys()) if isinstance(data, dict) else _REQUIRED_PROFILE_KEYS}. "
                    "Treating as absent."
                )
                return None
            return data

        if resp.status_code == 404:
            logger.warning(
                f"Profile fetch returned HTTP 404 for {framework_profile_id} — "
                "framework-specific prompts and domain mapping will be skipped."
            )
            return None

        # 5xx Server Error or 429 Too Many Requests -> DO NOT fallback to generic prompts.
        # This forces the job to fail and be retried by the Redis queue.
        if resp.status_code >= 500 or resp.status_code == 429:
            raise TransientServiceError(
                f"Storage service unavailable (HTTP {resp.status_code}). "
                "Rejecting job for retry to prevent hallucinated extraction."
            )

        logger.error(
            f"Profile fetch returned HTTP {resp.status_code} for {framework_profile_id}. "
            "Proceeding without profile."
        )
    except httpx.RequestError as e:
        safe_e = re.sub(r'https?://\S+', '[URL]', f"{type(e).__name__}: {str(e)[:200]}")
        raise TransientServiceError(
            f"Storage service connection failed: {safe_e}. "
            "Rejecting job for retry to prevent hallucinated extraction."
        ) from e
    except TransientServiceError:
        raise
    except Exception as e:
        safe_e = re.sub(r'https?://\S+', '[URL]', f"{type(e).__name__}: {str(e)[:200]}")
        raise TransientServiceError(
            f"Unexpected error fetching profile {framework_profile_id}: {safe_e}. "
            "Rejecting job for retry to prevent fallback degradation."
        ) from e
