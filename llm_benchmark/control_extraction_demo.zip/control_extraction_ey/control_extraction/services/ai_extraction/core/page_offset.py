"""
Page Offset Detection
=====================
Auto-detects the offset between printed page numbers (what users read from
the document's TOC) and physical PDF page indices (the <!-- page=N/T -->
markers in the parsed markdown).

    physical_page_index = printed_page_number + offset

Works on the page_texts dict that split_by_page_markers() already produces.
No PDF file access needed. No fitz dependency.

Apply offset to:
  YES  content_pages       (user reads printed pages from document TOC)
  YES  TOC-extracted pages (LLM reads printed pages from document text)
  NO   toc_pages           (user scrolls in viewer → already physical)
"""

import re
from collections import Counter

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

# Characters to strip from candidate lines before number extraction.
# Covers markdown bold/italic (*) and common invisible Unicode chars.
_STRIP_RE = re.compile(r'[\*\ufeff\u200b]')


def detect_page_offset(page_texts: dict[int, str], min_samples: int = 5) -> int:
    """Detect offset between printed page numbers and physical page indices.

    Args:
        page_texts: {physical_page_index: page_text_content} from
                    split_by_page_markers(). Keys are physical PDF indices
                    (from <!-- page=N --> markers). Values contain the page
                    text where printed page numbers appear in headers/footers.
        min_samples: minimum number of matching pages required for a reliable
                     offset. Below this threshold, returns 0 (assume no offset).

    Returns:
        Offset as int. 0 means printed == physical (or detection failed).
        Positive means physical > printed (front matter pages exist).
    """
    if not page_texts:
        return 0

    offsets: list[int] = []

    for physical_idx in sorted(page_texts.keys()):
        text = page_texts[physical_idx]
        lines = text.strip().split("\n")
        if not lines:
            continue

        # Footer lines first — page numbers are almost always in footers.
        # Checking footer before header prevents chapter numbers in headers
        # from stealing the match (break fires on first hit).
        candidates = lines[-3:] + lines[:3]
        for line in candidates:
            # Strip markdown bold/italic and invisible Unicode chars
            clean = _STRIP_RE.sub('', line.strip()).strip()
            if not clean:
                continue

            printed = _try_extract_page_number(clean)
            if printed is not None:
                offset = physical_idx - printed
                # Guard: reject negative offsets and unreasonably large ones
                if 0 <= offset <= 50:
                    offsets.append(offset)
                break

    if len(offsets) < min_samples:
        logger.debug(
            f"[PageOffset] Only {len(offsets)} samples (need {min_samples}), "
            "assuming offset=0"
        )
        return 0

    consensus = Counter(offsets).most_common(1)[0][0]
    agreement = offsets.count(consensus)
    total = len(offsets)

    # Reject when fewer than half the samples agree — likely noise
    if agreement / total < 0.5:
        logger.warning(
            f"[PageOffset] Agreement too low ({agreement}/{total}), "
            "assuming offset=0"
        )
        return 0

    if agreement / total < 0.8:
        logger.warning(
            f"[PageOffset] Low consensus: {agreement}/{total} pages agree "
            f"on offset={consensus}. Detection may be unreliable."
        )

    if consensus != 0:
        logger.info(
            f"[PageOffset] Detected offset={consensus} "
            f"({agreement}/{total} pages agree)"
        )

    return consensus


def _try_extract_page_number(clean: str) -> int | None:
    """Try to extract a printed page number from a cleaned line.

    Two strategies, checked in order:
      1. Standalone number — entire line is digits (e.g. "3")
      2. Trailing number  — digits at end of line (e.g. "Document Classification: Open 1")

    Returns the printed page number, or None if no match.
    """
    # Strategy 1: Entire line is a standalone number
    if clean.isdigit():
        n = int(clean)
        if 0 <= n <= 9999:
            return n

    # Strategy 2: Trailing number at end of line
    # Handles footer formats like "Document Classification: Open 1"
    m = re.search(r'\b(\d{1,4})\s*$', clean)
    if m:
        n = int(m.group(1))
        if 0 <= n <= 9999:
            return n

    return None


def apply_offset_to_page_range(page_range: str, offset: int) -> str:
    """Convert a printed page range to physical page indices.

    "11-18" with offset=6 → "17-24"
    "9-178" with offset=4 → "13-182"
    "16-109" with offset=0 → "16-109" (unchanged)
    "3" with offset=4 → "7"

    Returns the original string if offset is 0 or input is empty/non-numeric.
    """
    if not offset or not page_range:
        return page_range

    # Normalize en-dash / em-dash to ASCII hyphen
    normalized = page_range.replace('\u2013', '-').replace('\u2014', '-')

    # Validate: must be "N" or "N-M" (with optional spaces around dash)
    if not re.fullmatch(r'\d+(?:\s*-\s*\d+)?', normalized.strip()):
        return page_range

    parts = normalized.split("-")
    converted = [int(p.strip()) + offset for p in parts]

    # Validate: no negative pages after conversion
    if any(p < 1 for p in converted):
        logger.warning(
            f"[PageOffset] Offset {offset} produces negative page in "
            f"'{page_range}' → {converted}. Returning original."
        )
        return page_range

    result = "-".join(str(p) for p in converted)
    logger.info(f"[PageOffset] Pages: \"{page_range}\" → \"{result}\" (offset={offset})")
    return result


def apply_offset_to_toc_entries(toc_entries: list, offset: int) -> int:
    """Apply offset to LLM-extracted TOC page numbers. Modifies in-place.

    Returns count of entries adjusted.
    """
    if not offset or not toc_entries:
        return 0

    adjusted = 0
    for entry in toc_entries:
        if hasattr(entry, "page") and entry.page is not None:
            entry.page += offset
            adjusted += 1

    if adjusted:
        logger.info(
            f"[PageOffset] Adjusted {adjusted} TOC entries by +{offset}"
        )
    return adjusted
