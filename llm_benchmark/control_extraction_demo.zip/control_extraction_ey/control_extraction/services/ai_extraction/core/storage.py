import asyncio
import os
import threading
from config import get_settings
from shared_core.stream_client import publish_task
from core.document import split_by_page_markers, parse_page_range
from core.page_offset import detect_page_offset, apply_offset_to_page_range
from shared_core.interfaces.storage_port import AzureBlobStorage, LocalBlobStorage

config = get_settings()

# C-3: Singleton storage instance — avoids creating a new BlobServiceClient per call
# H-1: Thread-safe initialization via lock (matches config.py pattern)
_storage_instance = None
_storage_lock = threading.Lock()

def _get_storage():
    """Factory to get the configured FileStoragePort implementation (cached singleton)."""
    global _storage_instance
    if _storage_instance is not None:
        return _storage_instance
    with _storage_lock:
        if _storage_instance is not None:
            return _storage_instance
        if config.USE_AZURE_STORAGE and config.AZURE_STORAGE_CONNECTION_STRING:
            _storage_instance = AzureBlobStorage(
                config.AZURE_STORAGE_CONNECTION_STRING,
                config.AZURE_BLOB_CONTAINER_NAME
            )
        else:
            blob_dir = getattr(config, 'BLOB_STORAGE_DIR', None)
            if not blob_dir:
                raise RuntimeError(
                    "No storage backend configured: set AZURE_STORAGE_CONNECTION_STRING "
                    "or BLOB_STORAGE_DIR in your .env file"
                )
            _storage_instance = LocalBlobStorage(blob_dir)
        return _storage_instance

async def load_content_from_blob(
    blob_path: str,
    toc_pages: str,
    content_pages: str,
    job_log,
) -> tuple[str, str, int, str]:
    """Download the full parsed markdown directly into memory and slice it.

    Returns:
        (toc_text, control_text, page_offset, adjusted_content_pages)
    """

    try:
        storage = _get_storage()
        # M-9: StoragePort.read_file() is synchronous (Azure SDK uses blocking I/O).
        # Wrap in asyncio.to_thread() to avoid blocking the event loop.
        # H-1: Timeout prevents a hung blob read from blocking the entire job.
        # NOTE: On timeout, the background thread continues to completion (Python
        # limitation — threads are not interruptible). Downloaded bytes are discarded
        # when the future is garbage-collected, but I/O bandwidth is consumed.
        file_bytes = await asyncio.wait_for(
            asyncio.to_thread(storage.read_file, blob_path),
            timeout=config.BLOB_READ_TIMEOUT_SECONDS,
        )
        # Guard: reject blobs that exceed the configured size ceiling.
        # Prevents OOM from corrupt or malicious blobs.
        if len(file_bytes) > config.BLOB_MAX_BYTES:
            raise ValueError(
                f"Blob size {len(file_bytes):,} bytes exceeds "
                f"BLOB_MAX_BYTES={config.BLOB_MAX_BYTES:,}. "
                "Increase the limit or investigate the blob."
            )
        full_markdown = file_bytes.decode('utf-8', errors='replace')
        if '\ufffd' in full_markdown:
            import logging
            logging.getLogger(__name__).warning(
                "Non-UTF-8 bytes detected in blob %s — replaced with U+FFFD",
                os.path.basename(blob_path) if blob_path else "<empty>",
            )
    except Exception as e:
        # L-4: Include a redacted blob path hint (filename only) in the ERROR log
        # so it's actionable without DEBUG enabled, while keeping the full path at DEBUG.
        blob_name = os.path.basename(blob_path) if blob_path else "<empty>"
        job_log.debug(f"Failed to fetch blob '{blob_path}': {e}")
        job_log.error(f"Failed to fetch blob '{blob_name}': {type(e).__name__}: {str(e)[:200]}")
        raise

    blob_name = os.path.basename(blob_path) if blob_path else "<empty>"
    job_log.info(f"Downloaded parsed blob {blob_name} ({len(full_markdown):,} chars)")
    job_log.debug(f"Full blob path: {blob_path}")

    pages = split_by_page_markers(full_markdown)
    total = max(pages) if pages else 0

    if total == 0:
        job_log.warning("Parsed blob contains no page markers — returning empty slices")
        return "", "", 0, content_pages

    # Detect page offset (physical vs printed page numbers)
    page_offset = detect_page_offset(pages)
    if page_offset:
        content_pages = apply_offset_to_page_range(content_pages, page_offset)
        job_log.info(f"Page offset {page_offset} applied → content_pages={content_pages}")
    # Note: toc_pages is NOT adjusted (user scrolled in viewer → already physical)

    def _slice(pages_str: str, overlap: int = 0) -> str:
        # M-4: `total` refers to the original PDF's highest page number,
        # not the count of pages in this slice. The re-emitted markers
        # (<!-- page=X/total -->) preserve the original PDF pagination
        # so downstream page-window logic maps back to TOC page numbers.
        r = parse_page_range(pages_str)
        if not r:
            return ""
        start = max(1, r[0] - overlap)
        end = min(total, r[1] + overlap)
        parts = [
            f"{pages[pg]}\n\n<!-- page={pg}/{total} -->"
            for pg in range(start, end + 1)
            if pg in pages
        ]
        return "\n\n".join(parts)

    return (
        _slice(toc_pages, overlap=config.WINDOW_OVERLAP),
        _slice(content_pages),
        page_offset,
        content_pages,
    )


async def enrich_and_store_payload(
    job_id: str,
    framework: str,
    payload: list[dict],
    profile: dict | None,
    llm_model: str,
    source_pdf_hash: str,
) -> None:
    """Enriches extracted controls with domain mappings, then publishes to storage."""

    if profile and profile.get("domain_mapping"):
        domain_mapping = profile["domain_mapping"]
        sorted_prefixes = sorted(domain_mapping.items(), key=lambda x: -len(x[0]))
        for ex in payload:
            cid = ex.get("control_id", "")
            for prefix, dname in sorted_prefixes:
                if cid.startswith(prefix) and (len(cid) == len(prefix) or cid[len(prefix)] == "."):
                    ex["domain_name"] = dname
                    break

    framework_version = profile.get("version", "") if profile else ""
    await publish_task(
        stream="storage:stream",
        task_name="store_controls",
        payload={
            "job_id": job_id,
            "framework": framework,
            "framework_version": framework_version,
            "framework_profile_id": profile.get("id", "") if profile else "",
            "extractions": payload,
            "llm_model": llm_model,
            "source_pdf_hash": source_pdf_hash or None,
        },
        job_id=job_id,
    )
