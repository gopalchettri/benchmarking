"""
Blueprint resolution and caching logic.
"""
import json as _json
from redis.exceptions import ConnectionError as RedisConnectionError
from models import TOCEntry
from core.document import parse_page_range
from core.exceptions import TransientServiceError
from shared_core.redis_client import get_async_redis_client
from utils.logging_config import logger
from config import get_settings
from extraction.discovery import discover_controls_from_body

config = get_settings()

# ── Blueprint Cache Helpers ──────────────────────────────────────────────────
# TTL is read from config (BLUEPRINT_CACHE_TTL_DAYS) rather than a module-level
# constant, so operators can tune cache lifetime without a code deploy.


async def _try_get_cached_blueprint(cache_key: str) -> list[TOCEntry] | None:
    """Try to load a cached TOC/discovery blueprint from Redis.

    Returns list of TOCEntry on cache hit, None on miss.
    M-5: Raises TransientServiceError on Redis connection failures
    so callers fail fast instead of silently running full discovery.
    """
    try:
        client = get_async_redis_client()
        raw = await client.get(f"blueprint:{cache_key}")
        if raw is None:
            return None
        entries_data = _json.loads(raw)
        entries = [
            TOCEntry(
                control_id=e["control_id"],
                title=e.get("title", ""),
                page=e.get("page"),
            )
            for e in entries_data
        ]
        logger.info(f"Blueprint cache HIT: {cache_key} ({len(entries)} entries)")
        return entries
    except (RedisConnectionError, OSError) as e:
        raise TransientServiceError(f"Redis unavailable during blueprint cache read: {e}") from e
    except (_json.JSONDecodeError, KeyError, TypeError, ValueError) as e:
        logger.warning(f"Blueprint cache read failed ({cache_key}): {e}")
        return None


async def _try_cache_blueprint(
    cache_key: str,
    entries: list[TOCEntry],
    ttl_days: int | None = None,
) -> None:
    """Cache a TOC/discovery blueprint in Redis.

    M-5: Raises TransientServiceError on Redis connection failures.
    Non-connection errors are logged and swallowed.
    """
    if ttl_days is None:
        ttl_days = config.BLUEPRINT_CACHE_TTL_DAYS
    try:
        client = get_async_redis_client()
        payload = _json.dumps(
            [
                {"control_id": e.control_id, "title": e.title, "page": e.page}
                for e in entries
            ]
        )
        await client.set(f"blueprint:{cache_key}", payload, ex=ttl_days * 86400)
        logger.info(f"Blueprint cached: {cache_key} ({len(entries)} entries, TTL={ttl_days}d)")
    except (RedisConnectionError, OSError) as e:
        raise TransientServiceError(f"Redis unavailable during blueprint cache write: {e}") from e
    except (_json.JSONDecodeError, KeyError, TypeError, ValueError) as e:
        logger.warning(f"Blueprint cache write failed ({cache_key}): {e}")


async def resolve_blueprint(
    provider,
    extractor,
    framework: str,
    control_content: str,
    content_pages: str,
    toc_entries: list[TOCEntry] | None,
    profile: dict | None,
    source_pdf_hash: str,
    job_log,
    control_layout: str = "toc_body",
) -> tuple[int, int, list[TOCEntry] | None]:
    """Resolves the control blueprint (TOC vs Cache vs Discovery) and returns bounds + entries."""
    page_range = parse_page_range(content_pages)
    if not page_range:
        raise ValueError(
            f"Cannot parse content_pages='{content_pages}'. "
            "Provide a valid page range such as '13-38'."
        )
    control_start_page: int = page_range[0]
    control_end_page: int   = page_range[1]

    usable_entries = [e for e in (toc_entries or []) if e.page is not None]

    cache_key = None
    framework_version = profile.get("version", "") if profile else ""
    if source_pdf_hash:
        cache_key = f"{framework}:{framework_version}:{source_pdf_hash}:{control_start_page}-{control_end_page}"

    if len(usable_entries) > 0:
        if cache_key:
            # H-2: Cache usable_entries (with pages) not toc_entries — entries
            # without page numbers are useless for page-window grouping.
            await _try_cache_blueprint(cache_key, usable_entries)
    else:
        if control_layout == "annex":
            job_log.info("[ANNEX layout] No TOC entries expected — running cache lookup, then discovery.")
        else:
            job_log.warning("TOC extraction returned 0 usable entries. Attempting cache lookup, then discovery fallback.")
        
        if cache_key:
            cached = await _try_get_cached_blueprint(cache_key)
            if cached:
                toc_entries = cached
                job_log.info(f"Loaded cached blueprint: {len(toc_entries)} entries (key={cache_key})")

        usable_after_cache = [e for e in (toc_entries or []) if e.page is not None]
        if len(usable_after_cache) == 0:
            if not profile or not profile.get("prompt_module"):
                raise ValueError("Discovery mode requires a framework profile with prompt_module.")
                
            job_log.info(f"Running discovery scan on pages {control_start_page}-{control_end_page}...")

            disc_toc = await discover_controls_from_body(
                provider=provider,
                framework_name=framework,
                content=control_content,
                start_page=control_start_page,
                end_page=control_end_page,
                rate_limiter=extractor.rate_limiter,
                config=config,
                framework_profile=profile,
            )
            toc_entries = disc_toc.controls
            if not toc_entries:
                raise ValueError("Discovery scan also found 0 controls.")
                
            job_log.info(f"Discovery found {len(toc_entries)} controls")
            if cache_key:
                await _try_cache_blueprint(cache_key, toc_entries)

    return control_start_page, control_end_page, toc_entries

