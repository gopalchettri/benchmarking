"""
ai_extraction task handlers
=============================
Plain async functions — no Celery, no RQ.
Dispatched via Redis Streams (shared_core.stream_client).

Supports framework profile-driven extraction: when framework_profile is
passed in the payload, framework-specific prompts and ID validation are used.
"""
import asyncio
import os
import re
import sys
from typing import Optional

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
if BASE not in sys.path:
    sys.path.insert(0, BASE)
if os.path.join(BASE, 'shared_core') not in sys.path:
    sys.path.insert(0, os.path.join(BASE, 'shared_core'))
if os.path.dirname(__file__) not in sys.path:
    sys.path.insert(0, os.path.dirname(__file__))

from config import get_settings
from models import TOCEntry
from shared_core.audit_client import log_audit
from shared_core.constants import STATE_COMPLETED, STATE_AI_EXTRACTION_FAILED
from shared_core.redis_client import get_async_redis_client, update_job_state, fetch_job_state
from shared_core.stream_client import publish_task
from utils.logging_config import logger, start_job_logging, stop_job_logging, get_job_logger

from core.page_offset import apply_offset_to_toc_entries
from core.profile import fetch_profile_via_http
from core.storage import load_content_from_blob, enrich_and_store_payload
from extraction.controls import SubControlExtractor
from extraction.toc import extract_toc_from_text
from jobs.blueprint import resolve_blueprint
from llm.providers import ILLMProvider, get_llm_provider
from llm.rate_limiter import TokenBucketRateLimiter, RateLimitConfig
from shared_core.job_client import update_job_record

config = get_settings()

STORAGE_SERVICE_URL = config.STORAGE_SERVICE_URL
API_V1_STR          = config.API_V1_STR


def _sanitize_error(exc: Exception, max_len: int = 200) -> str:
    """Produce a safe error string that won't leak internal structure.

    Strips URLs, connection strings, API keys, and truncates to max_len.
    """
    raw = str(exc)[:max_len]
    # Strip URLs (http/https endpoints)
    safe = re.sub(r'https?://\S+', '[URL]', raw)
    # Strip Azure connection strings
    safe = re.sub(r'DefaultEndpointsProtocol=[^;]+(?:;[^;]+)*', '[CONNECTION_STRING]', safe)
    # Strip anything that looks like an API key (32+ hex or base64 chars)
    safe = re.sub(r'[A-Za-z0-9+/=]{32,}', '[REDACTED]', safe)
    # Strip file system paths
    safe = re.sub(r'(?:/[\w.-]+){3,}', '[PATH]', safe)
    return safe


# ── Alerting callback (A-03) ──────────────────────────────────────────────────
async def _fire_alert(job_id: str, framework: str, error: str) -> None:
    """Fire an alert on extraction failure if ALERT_WEBHOOK_URL is configured.

    Generic webhook-based alerting — works with Slack, PagerDuty, Teams,
    or any HTTP endpoint that accepts JSON POST. Silently no-ops if not configured.
    """
    webhook_url = getattr(config, 'ALERT_WEBHOOK_URL', None)
    if not webhook_url:
        return
    try:
        import httpx
        payload = {
            "text": f"[AI Extraction FAILED] job={job_id} framework={framework}: {error}",
            "job_id": job_id,
            "framework": framework,
            "error": error,
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            await client.post(webhook_url, json=payload)
    except Exception as alert_err:
        logger.warning(f"Alert webhook failed (non-critical): {alert_err}")


# ── Stream name consumed by this service ─────────────────────────────────────
AI_STREAM = "ai_extraction:stream"
AI_GROUP  = "ai_workers"

# ── Singleton provider & rate limiter ────────────────────────────────────────
_provider: Optional[ILLMProvider] = None
_provider_lock = asyncio.Lock()
_rate_limiter: Optional[TokenBucketRateLimiter] = None
_rate_limiter_lock = asyncio.Lock()


async def _get_shared_provider() -> ILLMProvider:
    """Return a singleton LLM provider (async double-checked locking)."""
    global _provider
    if _provider is not None:
        return _provider
    async with _provider_lock:
        if _provider is not None:
            return _provider
        _provider = get_llm_provider(config)
        if config.LLM_ENABLE_WARMUP:
            await _provider.warmup_model()
        return _provider


async def _get_shared_rate_limiter() -> TokenBucketRateLimiter:
    """Return a singleton rate limiter (async double-checked locking)."""
    global _rate_limiter
    if _rate_limiter is not None:
        return _rate_limiter
    async with _rate_limiter_lock:
        if _rate_limiter is not None:
            return _rate_limiter
        _rate_limiter = TokenBucketRateLimiter(RateLimitConfig(
            requests_per_minute=config.LLM_RATE_LIMIT_RPM,
            burst_size=config.LLM_RATE_LIMIT_BURST,
            min_interval_seconds=config.LLM_RATE_LIMIT_MIN_INTERVAL,
        ))
        return _rate_limiter


async def cleanup_shared_resources() -> None:
    """Close shared provider on shutdown. Called from worker/main lifespan."""
    global _provider
    if _provider is not None:
        await _provider.close()
        _provider = None




def _log_extraction_counts(profile: dict | None, results: list, job_log) -> None:
    """Log extracted sub-control counts."""
    if not profile:
        return
    total_sub_controls = sum(r.total_sub_controls for r in results)
    job_log.info(f"[AI Extraction] Total sub-controls extracted: {total_sub_controls}")

async def extract_controls(
    *,
    job_id: str,
    framework: str,
    toc_content: str = "",
    control_content: str = "",
    parsed_blob_path: str = "",
    toc_pages: str = "",
    content_pages: str = "",
    framework_profile_id: str = "",
    framework_profile: dict | None = None,
    source_pdf_hash: str = "",
    **_extra,
) -> None:
    """LLM sub-control extraction handler.

    Accepts content either as a blob reference (parsed_blob_path + page ranges)
    or as inline strings (toc_content / control_content) for backward compatibility.

    When framework_profile is provided (or framework_profile_id is set),
    uses framework-specific prompts and profile-driven validation.
    """
    start_job_logging(job_id, "ai_extraction")
    job_log = get_job_logger(job_id)
    if _extra:
        job_log.debug(f"Ignored unexpected payload keys: {list(_extra.keys())}")

    # A-01: Idempotency guard — skip if this job is already completed.
    # Prevents duplicate extraction on Redis Stream re-delivery after crash.
    existing_state = await fetch_job_state(job_id)
    if existing_state == STATE_COMPLETED:
        job_log.info(f"[ai_extraction] Job {job_id} already completed — skipping (idempotency guard)")
        stop_job_logging(job_id)
        return

    try:
        # Validate blob path against path traversal attacks.
        # Normalizes the path first to catch encoded/obfuscated traversal
        # (e.g., URL-encoded %2e%2e, null bytes, Windows backslashes).
        if parsed_blob_path:
            import posixpath
            # Strip null bytes and normalize separators
            clean = parsed_blob_path.replace('\x00', '').replace('\\', '/')
            normalized = posixpath.normpath(clean)
            if (
                normalized.startswith('/')
                or normalized.startswith('..')
                or '/..' in normalized
                or normalized != clean.strip('/')
            ):
                raise ValueError(
                    f"Invalid blob path (path traversal detected): "
                    f"{parsed_blob_path[:80]}"
                )

        # Resolve content from blob storage when a reference is provided.
        # Inline strings (old messages / direct calls) fall through unchanged.
        page_offset = 0
        if parsed_blob_path and not (toc_content or control_content):
            toc_content, control_content, page_offset, content_pages = await load_content_from_blob(
                parsed_blob_path, toc_pages, content_pages, job_log,
            )
            if not toc_content:
                job_log.warning(
                    f"Blob slice for toc_pages='{toc_pages}' returned empty — "
                    "TOC extraction will be skipped; page-window grouping requires a TOC."
                )
            if not control_content:
                raise ValueError(
                    f"Blob slice for content_pages='{content_pages}' returned empty — "
                    "verify the page range covers the full control body."
                )
        elif parsed_blob_path and (toc_content or control_content):
            job_log.warning(
                "parsed_blob_path provided alongside inline content — "
                "using inline content; blob path ignored."
            )

        job_log.info(
            f"Starting AI extraction for framework: {framework}. "
            f"TOC chars: {len(toc_content)}, Content chars: {len(control_content)}"
        )
        await log_audit(action="job.ai_extraction.started", entity_type="job", entity_id=job_id)

        await update_job_record(job_id, status="extracting")

        # Resolve framework profile
        profile = framework_profile
        if not profile and framework_profile_id:
            job_log.info(f"Fetching framework profile: {framework_profile_id}")
            profile = await fetch_profile_via_http(framework_profile_id)
            if profile:
                job_log.info(f"Loaded profile: {profile.get('display_name', profile.get('name', 'unknown'))}")
            else:
                job_log.warning(f"Profile {framework_profile_id} not found, using generic prompts")

        # logic for identifying to use toc or annex or matrix vs discovery routing
        # Resolve document layout — drives TOC vs discovery routing.
        # Uses `or` (not default param) because DB column is nullable:
        # {"control_layout": None}.get("control_layout", "toc_body") returns None, not "toc_body"
        layout = (profile or {}).get("control_layout") or "toc_body"

        if layout == "matrix":
            raise NotImplementedError(
                f"control_layout='matrix' is not yet supported for framework '{framework}'"
            )

        provider = await _get_shared_provider()
        llm_model = getattr(provider, "deployment", None) or getattr(provider, "model", None)
        rate_limiter = await _get_shared_rate_limiter()
        extractor = SubControlExtractor(provider, config, rate_limiter)
        toc_entries = None

        if toc_content and layout != "annex":
            job_log.info("Extracting TOC (sequential — page windows require TOC first)...")
            try:
                toc = await extract_toc_from_text(
                    provider, framework, toc_content, toc_pages or "batch",
                    extractor.rate_limiter, config, framework_profile=profile,
                )
                if toc and toc.controls:
                    toc_entries = toc.controls
                    job_log.info(f"TOC extracted: {len(toc_entries)} entries")
                    # Apply page offset to LLM-extracted TOC page numbers
                    # (TOC text contains printed page numbers; pipeline needs physical)
                    if page_offset:
                        apply_offset_to_toc_entries(toc_entries, page_offset)
            except Exception as toc_err:
                raise RuntimeError(f"TOC extraction failed: {_sanitize_error(toc_err)}") from toc_err
        elif layout == "annex":
            job_log.info("[ANNEX layout] Skipping TOC extraction — controls are in Annex, not TOC")

        control_start_page, control_end_page, toc_entries = await resolve_blueprint(
            provider=provider,
            extractor=extractor,
            framework=framework,
            control_content=control_content,
            content_pages=content_pages,
            toc_entries=toc_entries,
            profile=profile,
            source_pdf_hash=source_pdf_hash,
            job_log=job_log,
            control_layout=layout,
        )

        extraction_result = await extractor.extract(
            framework, control_content,
            framework_profile=profile,
            toc_entries=toc_entries,
            control_start_page=control_start_page,
            control_end_page=control_end_page,
        )

        results = extraction_result.extractions
        if extraction_result.errors:
            for err_msg in extraction_result.errors:
                job_log.warning(f"[AI Extraction] Chunk error: {err_msg}")
        if extraction_result.missing_control_ids:
            job_log.error(
                f"[AI Extraction] {len(extraction_result.missing_control_ids)} "
                f"control(s) unrecoverable after retry: "
                f"{extraction_result.missing_control_ids}"
            )

        _log_extraction_counts(profile, results, job_log)

        payload = [r.model_dump() for r in results]

        await enrich_and_store_payload(
            job_id=job_id,
            framework=framework,
            payload=payload,
            profile=profile,
            llm_model=llm_model,
            source_pdf_hash=source_pdf_hash,
        )

        # M-14: Removed STATE_MERGE (immediately overwritten, never observable)
        await update_job_state(job_id, STATE_COMPLETED)
        job_log.info(f"[ai_extraction] extract_controls done  job_id={job_id}")
        await log_audit(
            action="job.ai_extraction.completed",
            entity_type="job",
            entity_id=job_id,
            details={"controls_extracted": len(results)},
        )

    except Exception as exc:
        await update_job_state(job_id, STATE_AI_EXTRACTION_FAILED)
        safe_error = _sanitize_error(exc, max_len=300)
        await update_job_record(job_id, status="failed", error_message=safe_error)
        await log_audit(action="job.ai_extraction.failed", entity_type="job", entity_id=job_id, details={"error": safe_error})
        job_log.error(f"[ai_extraction] extract_controls failed  job_id={job_id}: {safe_error}")
        # A-03: Fire alerting callback if configured. Enables Slack/PagerDuty/webhook
        # integration without hardcoding any specific provider.
        await _fire_alert(job_id, framework, safe_error)
        raise
    finally:
        stop_job_logging(job_id)


async def extract_toc(
    *,
    job_id: str,
    framework: str,
    content: str,
    toc_pages: str = "",
    framework_profile_id: str = "",
    framework_profile: dict | None = None,
    **_extra,
) -> dict | None:
    """LLM TOC extraction handler."""
    start_job_logging(job_id, "toc_extraction")
    job_log = get_job_logger(job_id)
    if _extra:
        job_log.debug(f"Ignored unexpected payload keys: {list(_extra.keys())}")
    job_log.info(f"Starting TOC extraction for framework: {framework}")

    try:
        # C-1: Resolve profile from ID if not provided inline
        profile = framework_profile
        if not profile and framework_profile_id:
            job_log.info(f"Fetching framework profile: {framework_profile_id}")
            profile = await fetch_profile_via_http(framework_profile_id)
            if profile:
                job_log.info(f"Loaded profile: {profile.get('display_name', profile.get('name', 'unknown'))}")
            else:
                job_log.warning(f"Profile {framework_profile_id} not found, using generic prompts")

        provider = await _get_shared_provider()
        limiter = await _get_shared_rate_limiter()
        toc = await extract_toc_from_text(
            provider, framework, content, toc_pages or config.TOC_DEFAULT_PAGES, limiter, config,
            framework_profile=profile,
        )
        result = toc.model_dump() if toc else None
        entry_count = len((result or {}).get("controls", []))
        job_log.info(f"[ai_extraction] extract_toc done  job_id={job_id}  entries={entry_count}")
        return result
    except Exception as exc:
        safe_exc = _sanitize_error(exc, max_len=300)
        await update_job_state(job_id, STATE_AI_EXTRACTION_FAILED)
        await update_job_record(job_id, status="failed", error_message=safe_exc)
        job_log.error(f"[ai_extraction] extract_toc failed  job_id={job_id}: {safe_exc}")
        raise
    finally:
        stop_job_logging(job_id)


# ── Handler registry ─────────────────────────────────────────────────────────
HANDLERS = {
    "extract_controls": extract_controls,
    "extract_toc":      extract_toc,
}