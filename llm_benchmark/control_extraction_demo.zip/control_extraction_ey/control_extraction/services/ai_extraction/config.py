"""
Configuration Module for AI Extraction Service

Reads settings from .env file with search-order resolution:
  1. CLI --env-file argument
  2. DOTENV_PATH environment variable
  3. services/ai_extraction/.env  (same directory as this module)
  4. services/.env  (parent directory)

Uses pydantic-settings for validation and type coercion.
"""

import os
import threading
import warnings
from pathlib import Path
from typing import List, Literal, Optional

from pydantic import model_validator
from pydantic_settings import BaseSettings

# ── Auto-Scaling Ratios ─────────────────────────────────────────────────────
# When a token ceiling is left at 0 (the default), it is auto-derived from
# LLM_MODEL_CONTEXT_TOKENS using these ratios.  The ratios reproduce the
# original 128K defaults exactly:  128000 * 0.128 = 16384, etc.
_AUTO_SUBCONTROL_RATIO = 0.128     # sub-control output ceiling
_AUTO_MAX_OUTPUT_RATIO = 0.125     # fallback output ceiling
_AUTO_TOC_RATIO = 0.032            # ToC output ceiling
_AUTO_DISCOVERY_RATIO = 0.016      # discovery output ceiling
_MIN_CONTENT_BUDGET = 5000         # minimum usable content tokens


class Settings(BaseSettings):
    """Application settings — all configurable via .env or environment variables."""

    # --- App Metadata & Routing ---
    APP_NAME_AI_EXTRACTION: str = "AI Extraction Service"
    APP_VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"

    # --- Blob / Document Storage ---
    USE_AZURE_STORAGE: bool = True
    # BLOB_STORAGE_DIR: str = str(Path(__file__).resolve().parent.parent.parent / "blob_data")
    AZURE_STORAGE_CONNECTION_STRING: Optional[str] = None
    AZURE_BLOB_CONTAINER_NAME: str = "uaeccpm"
    # Hard ceiling on downloaded blob size. Prevents OOM if a corrupt or
    # malicious blob is stored. 100 MB is well above the largest real framework PDF.
    BLOB_MAX_BYTES: int = 100 * 1024 * 1024   # 100 MB
    BLOB_READ_TIMEOUT_SECONDS: int = 120     # generous for large PDFs over slow links
    # TTL for the Redis blueprint cache (TOC / discovery results).
    # 30 days is appropriate for static, versioned framework documents.
    # Reduce for frequently-updated frameworks.
    BLUEPRINT_CACHE_TTL_DAYS: int = 30

    LOG_LEVEL: str = "INFO"
    ENVIRONMENT: Literal["development", "production"] = "development"

    # --- Redis & Services ---
    REDIS_URL: str = "redis://localhost:6379/0"
    STORAGE_SERVICE_URL: str = "http://localhost:8003"

    # --- LLM Provider ---
    LLM_PROVIDER: Literal["azure", "ollama"] = "azure"
    LLM_MODEL_CONTEXT_TOKENS: int = 128000
    LLM_REASONING_EFFORT: Literal["low", "medium", "high"] = "low"
    LLM_MAX_OUTPUT_TOKENS: int = 0
    LLM_REQUEST_TIMEOUT_SECONDS: int = 900
    LLM_ENABLE_WARMUP: bool = True
    # Temperature for LLM calls. Default 0 for deterministic output.
    # Set to 1.0 for models that don't support 0 (e.g. gpt-5-mini).
    LLM_TEMPERATURE: float = 0.0

    # Azure OpenAI
    AZURE_OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_ENDPOINT: Optional[str] = None
    AZURE_OPENAI_DEPLOYMENT_NAME: Optional[str] = None
    AZURE_OPENAI_API_VERSION: Optional[str] = None

    # Ollama
    OLLAMA_BASE_URL: Optional[str] = None
    OLLAMA_API_KEY: Optional[str] = "ollama"  # Ollama requires a non-empty key but ignores the value
    OLLAMA_MODEL_NAME: Optional[str] = None
    OLLAMA_CONNECTION_POOL_SIZE: int = 3
    OLLAMA_KEEPALIVE_TIMEOUT: int = 600
    OLLAMA_NUM_BATCH: int = 512
    OLLAMA_REPEAT_PENALTY: float = 1.0
    OLLAMA_TOP_K: int = 1
    OLLAMA_TOP_P: float = 1.0

    # TCP Keep-Alive
    TCP_KEEPALIVE_IDLE: int = 30
    TCP_KEEPALIVE_INTERVAL: int = 10
    TCP_KEEPALIVE_COUNT: int = 3

    # --- Rate Limiting ---
    LLM_RATE_LIMIT_RPM: int = 8
    LLM_RATE_LIMIT_BURST: int = 5
    LLM_RATE_LIMIT_MIN_INTERVAL: float = 0.5
    GLOBAL_RATE_LIMIT_MAX_REQUESTS: int = 50
    GLOBAL_RATE_LIMIT_WINDOW_SECONDS: int = 60

    # --- Trusted Proxies (used by RateLimitingMiddleware) ---
    TRUSTED_PROXY_CIDRS: List[str] = []

    # --- Token Tracking ---
    TOKEN_TRACKER_HISTORY_SIZE: int = 1000
    TOKEN_TRACKER_LOG_FREQUENCY: int = 5
    LLM_COST_PER_1K_INPUT: float = 0.0
    LLM_COST_PER_1K_OUTPUT: float = 0.0

    # --- Extraction Window Overlap ---
    WINDOW_OVERLAP: int = 1

    # --- Control Discovery ---
    DISCOVERY_WINDOW_SIZE: int = 4
    DISCOVERY_MAX_TOKENS: int = 0

    # --- Post-Extraction Validation ---
    # Maximum recursion depth for post-extraction corrections
    # (merge_lowercase_continuations, renest_interleaved_children, etc.).
    # Real compliance frameworks nest at most 4–5 levels deep. The default
    # of 10 is generous headroom that prevents RecursionError on malformed
    # LLM output while never triggering on valid framework content.
    POST_EXTRACTION_MAX_DEPTH: int = 10

    # --- Sub-Control Extraction ---
    SUBCONTROL_MAX_TOKENS: int = 0

    # --- Chunking Budget ---
    CHUNK_CONTEXT_RATIO: float = 0.75
    CHUNK_PROMPT_OVERHEAD_TOKENS: int = 2600

    # --- ToC Extraction ---
    TOC_MAX_TOKENS: int = 0
    TOC_MAX_PDF_PAGES: int = 15
    TOC_DEFAULT_PAGES: str = "1-10"

    # --- Section Dedup Thresholds (M-1) ---
    # Tuned empirically on SAMA, ISO 27001, and PCI-DSS.
    SECTION_FWD_OVERLAP_THRESHOLD: float = 0.5   # >=50% forward n-gram overlap -> duplicate
    SECTION_REV_OVERLAP_THRESHOLD: float = 0.3   # >=30% reverse overlap catches partial repeats
    SECTION_MIN_WORDS_FOR_OVERLAP: int = 30      # skip overlap check for short sections
    SECTION_NGRAM_SIZE: int = 4                  # 4-gram balances precision vs recall

    # --- Profile Fetch (M-2) ---
    PROFILE_FETCH_TIMEOUT_SECONDS: int = 10

    # --- Dead Letter Queue (used by shared_core.stream_client) ---
    DLQ_MAX_DELIVERY_ATTEMPTS: int = 3

    # --- Alerting (A-03) ---
    # Set to a Slack/PagerDuty/Teams webhook URL to receive failure alerts.
    # Leave empty to disable alerting.
    ALERT_WEBHOOK_URL: Optional[str] = None

    # --- Log Truncation ---
    LOG_TRUNCATE_SYSTEM_PROMPT: int = 0
    LOG_TRUNCATE_USER_PROMPT: int = 0
    LOG_TRUNCATE_LLM_OUTPUT: int = 0
    LOG_TRUNCATE_JSON_ERROR: int = 500
    LOG_ROTATION_SIZE: str = "10 MB"
    LOG_RETENTION_DAYS: str = "30 days"

    @model_validator(mode="after")
    def validate_bounds(self):
        """Cross-field validation for numeric settings."""
        # ── Auto-derive token ceilings from context window ──────────────
        ctx = self.LLM_MODEL_CONTEXT_TOKENS
        if self.SUBCONTROL_MAX_TOKENS == 0:
            self.SUBCONTROL_MAX_TOKENS = int(ctx * _AUTO_SUBCONTROL_RATIO)
        if self.LLM_MAX_OUTPUT_TOKENS == 0:
            self.LLM_MAX_OUTPUT_TOKENS = int(ctx * _AUTO_MAX_OUTPUT_RATIO)
        if self.TOC_MAX_TOKENS == 0:
            self.TOC_MAX_TOKENS = int(ctx * _AUTO_TOC_RATIO)
        if self.DISCOVERY_MAX_TOKENS == 0:
            self.DISCOVERY_MAX_TOKENS = int(ctx * _AUTO_DISCOVERY_RATIO)

        if self.LLM_MAX_OUTPUT_TOKENS > self.LLM_MODEL_CONTEXT_TOKENS:
            raise ValueError("LLM_MAX_OUTPUT_TOKENS cannot exceed LLM_MODEL_CONTEXT_TOKENS")
        if self.SUBCONTROL_MAX_TOKENS >= self.LLM_MODEL_CONTEXT_TOKENS:
            raise ValueError(
                f"SUBCONTROL_MAX_TOKENS ({self.SUBCONTROL_MAX_TOKENS:,}) must be less than "
                f"LLM_MODEL_CONTEXT_TOKENS ({self.LLM_MODEL_CONTEXT_TOKENS:,})"
            )
        reserved = self.SUBCONTROL_MAX_TOKENS + self.CHUNK_PROMPT_OVERHEAD_TOKENS
        if reserved >= self.LLM_MODEL_CONTEXT_TOKENS:
            raise ValueError(
                f"SUBCONTROL_MAX_TOKENS ({self.SUBCONTROL_MAX_TOKENS:,}) + "
                f"CHUNK_PROMPT_OVERHEAD_TOKENS ({self.CHUNK_PROMPT_OVERHEAD_TOKENS:,}) = "
                f"{reserved:,} — leaves no room for content in "
                f"LLM_MODEL_CONTEXT_TOKENS ({self.LLM_MODEL_CONTEXT_TOKENS:,}). "
                f"Reduce SUBCONTROL_MAX_TOKENS."
            )
        if self.POST_EXTRACTION_MAX_DEPTH < 1 or self.POST_EXTRACTION_MAX_DEPTH > 50:
            raise ValueError(
                "POST_EXTRACTION_MAX_DEPTH must be between 1 and 50. "
                "Real compliance frameworks nest at most 4–5 levels deep. "
                "Values above 50 risk hitting Python's recursion limit on "
                "malformed LLM output."
            )
        if self.LLM_RATE_LIMIT_RPM <= 0:
            raise ValueError("LLM_RATE_LIMIT_RPM must be positive")
        if self.WINDOW_OVERLAP < 1 or self.WINDOW_OVERLAP > 5:
            raise ValueError(
                "WINDOW_OVERLAP must be between 1 and 5. "
                "Values > 5 expand every page group by ±5 pages, dramatically "
                "increasing LLM token consumption. Setting it to 0 removes the "
                "off-by-one buffer and makes Phase 5 retry a no-op."
            )
        if self.DISCOVERY_WINDOW_SIZE < 2:
            raise ValueError(
                "DISCOVERY_WINDOW_SIZE must be >= 2. "
                "Smaller windows produce too little context for the LLM."
            )
        # ── Content budget sanity check ─────────────────────────────────
        content_budget = (
            int(ctx * self.CHUNK_CONTEXT_RATIO)
            - self.CHUNK_PROMPT_OVERHEAD_TOKENS
            - self.SUBCONTROL_MAX_TOKENS
        )
        if content_budget < _MIN_CONTENT_BUDGET:
            raise ValueError(
                f"Content budget too small ({content_budget:,} tokens). "
                f"Reduce SUBCONTROL_MAX_TOKENS or increase LLM_MODEL_CONTEXT_TOKENS."
            )
        if self.ENVIRONMENT == "production":
            no_truncation = [
                name for name in ("LOG_TRUNCATE_SYSTEM_PROMPT", "LOG_TRUNCATE_USER_PROMPT", "LOG_TRUNCATE_LLM_OUTPUT")
                if getattr(self, name) == 0
            ]
            if no_truncation:
                warnings.warn(
                    f"Production log truncation disabled for: {', '.join(no_truncation)}. "
                    "Full prompts/outputs will be logged, which may include sensitive content. "
                    "Set these to a positive value (e.g., 500) to truncate.",
                    stacklevel=2,
                )
        return self

    model_config = {"env_file_encoding": "utf-8", "extra": "ignore"}


# --- .env Resolution Logic ---
_SEARCH_PATHS = [
    Path(__file__).resolve().parent / ".env",
    Path(__file__).resolve().parent.parent / ".env",
]

def resolve_env_file(cli_env_path: Optional[str] = None) -> Optional[str]:
    """Find the .env file. Returns path or None."""
    if cli_env_path:
        p = Path(cli_env_path)
        if p.exists():
            return str(p)
        warnings.warn(f"--env-file '{cli_env_path}' not found. Searching defaults...")

    env_path = os.environ.get("DOTENV_PATH")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return str(p)

    for p in _SEARCH_PATHS:
        if p.exists():
            return str(p)

    return None


_settings_instance: Optional[Settings] = None
_settings_lock = threading.Lock()

def get_settings(env_file_path: Optional[str] = None) -> Settings:
    """
    Get the singleton Settings instance (thread-safe).
    """
    global _settings_instance
    # Fast path: already initialized (no lock needed)
    if _settings_instance is not None:
        return _settings_instance

    # Thread-safe initialization — prevents duplicate Settings creation
    # when multiple threads/coroutines race on first access.
    with _settings_lock:
        if _settings_instance is not None:
            return _settings_instance
        resolved = resolve_env_file(env_file_path)
        if resolved:
            _settings_instance = Settings(_env_file=resolved)
        else:
            warnings.warn("No .env file found. Using environment variables and defaults.")
            _settings_instance = Settings()

        # Validate critical provider config at startup — fail fast
        config_errors = validate_config(_settings_instance)
        if config_errors:
            import logging
            _logger = logging.getLogger(__name__)
            for err in config_errors:
                _logger.error(f"[Config] {err}")
            raise RuntimeError(f"Configuration validation failed: {'; '.join(config_errors)}")

        return _settings_instance


def validate_config(settings: Settings) -> List[str]:
    """Validate critical config at startup. Returns list of errors."""
    errors = []
    if settings.LLM_PROVIDER == "azure":
        for var in ["AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT_NAME"]:
            if not getattr(settings, var):
                errors.append(f"{var} not set (required for azure provider)")
    elif settings.LLM_PROVIDER == "ollama":
        for var in ["OLLAMA_BASE_URL", "OLLAMA_MODEL_NAME"]:
            if not getattr(settings, var):
                errors.append(f"{var} not set (required for ollama provider)")
    else:
        errors.append(f"Unknown LLM_PROVIDER: {settings.LLM_PROVIDER}")

    return errors
