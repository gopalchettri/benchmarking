"""
SWIFT Customer Security Controls Framework (CSCF) v2025 — Framework-Specific Prompts
=====================================================================================
~32 controls organized into 3 objectives, using dotted numeric IDs.
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "SWIFT CSCF v2025"

TOC_RULES = """\
- Controls use dotted numeric IDs: X.Y (e.g., 1.1, 2.3, 7.1)
- Three objectives: Secure Your Environment, Know and Limit Access, Detect and Respond
- Expected: ~32 controls total
- Skip objective headers — extract only leaf controls
- Advisory controls are still controls — include them with a note
"""

SUBCONTROL_RULES = """\
- Control IDs: X.Y (single dot, numeric, e.g., 1.1, 2.3, 7.1). No sub-control ID in output.
- 'Control Statement' → sections{"Control Statement": "..."} (the core requirement, verbatim)
- 'Control Context' → sections{"Control Context": "..."} (background / rationale)
- 'Implementation Guidance' contains numbered items → each item becomes a sub_control
- Classification (Mandatory / Advisory) → sections{"Classification": "Mandatory"} or sections{"Classification": "Advisory"}
- Architecture type(s) if present (A1, A2, A3, A4, B) → sections{"Architecture": "A1, A2, ..."}
- NO ID FIELD: Do NOT include an "id" field in sub_control objects. Output only "number", "text", "children".

EXAMPLE (1.1):
INPUT:

1.1 SWIFT Environment Protection
Mandatory | A1, A2, A3, A4, B

Control Statement
Ensure the protection of the SWIFT local infrastructure from potentially compromised elements of the general IT environment and external environment.

Control Context
SWIFT recognises that local infrastructure may be hosted in environments that are not fully under the control of SWIFT users. The risk of external attacks and compromise is real and the SWIFT environment must be segregated from the general IT environment.

Implementation Guidance
1. Segregate the SWIFT environment from external systems using network controls such as firewalls and DMZs.
2. Restrict inbound and outbound connectivity to the minimum required for business operations.
3. Apply technical controls to prevent unauthorized access to the SWIFT environment.

EXPECTED OUTPUT:
{"extractions": [{"control_id": "1.1", "title": "SWIFT Environment Protection", "sections": {"Classification": "Mandatory", "Architecture": "A1, A2, A3, A4, B", "Control Statement": "Ensure the protection of the SWIFT local infrastructure from potentially compromised elements of the general IT environment and external environment.", "Control Context": "SWIFT recognises that local infrastructure may be hosted in environments that are not fully under the control of SWIFT users. The risk of external attacks and compromise is real and the SWIFT environment must be segregated from the general IT environment."}, "sub_controls": [{"number": "1", "text": "Segregate the SWIFT environment from external systems using network controls such as firewalls and DMZs."}, {"number": "2", "text": "Restrict inbound and outbound connectivity to the minimum required for business operations."}, {"number": "3", "text": "Apply technical controls to prevent unauthorized access to the SWIFT environment."}]}]}\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
