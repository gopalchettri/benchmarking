"""
PCI-DSS v4.0.1 — Framework-Specific Prompts
=============================================
12 Requirements with ~260 sub-requirements using dotted numbering.
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "PCI-DSS v4.0.1"

TOC_RULES = """\
- Requirements are numbered: Requirement 1 through Requirement 12
- Sub-requirements use dotted numbering: 1.1, 1.1.1, 1.1.2, etc.
- Extract leaf-level requirements (e.g., 1.1.1, 1.2.3, NOT 1.1 if it has children)
- "Requirement X" headers are parent groupings — skip unless they are leaf-level
- Expected: ~260 sub-requirements total
- Skip: Overview, Scope, Applicability Notes, Testing Procedures, Guidance columns
- Control IDs may appear as "Requirement X.Y.Z" or just "X.Y.Z"
"""

SUBCONTROL_RULES = """\
- Control IDs: dotted numeric (1.1.1, 6.2.3.1, 12.3.4). Title = the requirement title line WITHOUT the ID prefix.
- "Defined Approach Requirements" (PDF heading) contains the actual control text. \
Use the SINGULAR key "Defined Approach Requirement" in output:
    • If it is a SINGLE statement (possibly with inline bullets) → sections{"Defined Approach Requirement": "..."}
    • If it contains MULTIPLE distinct numbered or lettered sub-items → each item becomes a sub_control
- "Customized Approach Objective" → sections{"Customized Approach Objective": "..."}
- "Defined Approach Testing Procedures" (items like 1.1.1.a, 1.1.1.b) → sections{"Testing Procedures": "..."}
  CRITICAL: Testing Procedure items (X.Y.Z.a, X.Y.Z.b) are HOW to audit, NOT what to implement.
  They MUST go to sections{"Testing Procedures": "..."} and NEVER become sub_controls.
- "Guidance" / "Purpose" / "Good Practice" → sections{"Guidance": "..."}
- "Applicability Notes" → sections{"Applicability Notes": "..."}
- NO ID FIELD: Do NOT include an "id" field in sub_control objects. Output only "number", "text", "children".

EXAMPLE (1.1.1):
INPUT:

1.1.1 Processes and mechanisms for installing and maintaining network security controls are defined and understood.

Defined Approach Requirements
All security policies and operational procedures that are identified in Requirement 1 are:
• Documented.
• Kept up to date.
• In use.
• Known to all affected parties.

Customized Approach Objective
Expectations, controls, and oversight for meeting activities within Requirement 1 are defined and adhered to by affected personnel. All supporting activities are repeatable, consistently applied, and conform to management's intent.

Defined Approach Testing Procedures
1.1.1.a Examine documentation and interview personnel to verify that security policies and operational procedures identified in Requirement 1 are managed in accordance with all elements specified in this requirement.

Guidance
Purpose: Security policies and procedures are important for the effective implementation and sustainability of security controls.

EXPECTED OUTPUT:
{"extractions": [{"control_id": "1.1.1", "title": "Processes and mechanisms for installing and maintaining network security controls are defined and understood", "sections": {"Defined Approach Requirement": "All security policies and operational procedures that are identified in Requirement 1 are:\n• Documented.\n• Kept up to date.\n• In use.\n• Known to all affected parties.", "Customized Approach Objective": "Expectations, controls, and oversight for meeting activities within Requirement 1 are defined and adhered to by affected personnel. All supporting activities are repeatable, consistently applied, and conform to management's intent.", "Testing Procedures": "1.1.1.a Examine documentation and interview personnel to verify that security policies and operational procedures identified in Requirement 1 are managed in accordance with all elements specified in this requirement.", "Guidance": "Purpose: Security policies and procedures are important for the effective implementation and sustainability of security controls."}, "sub_controls": []}]}\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
