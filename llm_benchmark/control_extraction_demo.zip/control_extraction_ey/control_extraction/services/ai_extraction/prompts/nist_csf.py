"""
NIST Cybersecurity Framework (CSF) v2.0 — Framework-Specific Prompts
====================================================================
6 Functions → 22 Categories → 106 Subcategories.
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "NIST CSF 2.0"

TOC_RULES = """\
- Structure: Functions (GV, ID, PR, DE, RS, RC) → Categories → Subcategories
- Subcategory IDs follow: {FUNCTION}.{CATEGORY}-{NUMBER} (e.g., PR.AC-01, DE.CM-09)
- Functions are NOT controls — skip them (GV, ID, PR, DE, RS, RC headers)
- Categories are NOT controls — skip them (e.g., PR.AC, DE.CM headers)
- Extract ONLY Subcategories (leaf-level), e.g., PR.AC-01, PR.AC-02
- Expected: ~106 subcategories total
- The 6 Functions: Govern (GV), Identify (ID), Protect (PR), Detect (DE), Respond (RS), Recover (RC)
"""

SUBCONTROL_RULES = """\
- Functions (GV, ID, PR, DE, RS, RC) and Categories (e.g., PR.AA, DE.CM) are groupings, NOT controls.
- Subcategories ARE the controls. ID pattern: {FUNCTION}.{CATEGORY}-{NN} (e.g., PR.AA-01, DE.CM-09).
- CRITICAL: Most subcategories are a SINGLE outcome statement with NO sub_controls.
  The subcategory text itself IS the control — put it in the title field. sub_controls = [].
- Implementation Examples → sections{"Implementation Examples": "..."} verbatim (NOT sub_controls)
- Informative References → sections{"Informative References": "..."} verbatim (NOT sub_controls)
- NO ID FIELD: Do NOT include an "id" field in sub_control objects. Output only "number", "text", "children".

EXAMPLE (PR.AA-01):
INPUT:

PR.AA-01: Identities and credentials for authorized users, services, and hardware are managed by the organization.

Implementation Examples
Ex 1: Maintain a current list of all users and non-person entities (NPE) with access to organizational systems
Ex 2: Establish, maintain, and manage identity records and authentication credentials for authorized users
Ex 3: Define and enforce access permissions and entitlements for each authorized user, service, or hardware component

Informative References
CSF v1.1 PR.AC-1
CIS Controls v8 5.1, 6.1
NIST SP 800-53 Rev. 5 AC-2, IA-2, IA-4, IA-5, IA-8

EXPECTED OUTPUT:
{"extractions": [{"control_id": "PR.AA-01", "title": "Identities and credentials for authorized users, services, and hardware are managed by the organization.", "sections": {"Implementation Examples": "Ex 1: Maintain a current list of all users and non-person entities (NPE) with access to organizational systems\nEx 2: Establish, maintain, and manage identity records and authentication credentials for authorized users\nEx 3: Define and enforce access permissions and entitlements for each authorized user, service, or hardware component", "Informative References": "CSF v1.1 PR.AC-1\nCIS Controls v8 5.1, 6.1\nNIST SP 800-53 Rev. 5 AC-2, IA-2, IA-4, IA-5, IA-8"}, "sub_controls": []}]}

WRONG (do NOT do this — Implementation Examples are NOT sub-controls):
{"control_id":"PR.AA-01","sub_controls":[{"number":"1","text":"Maintain a current list of all users..."},{"number":"2","text":"Establish, maintain, and manage identity records..."}]}
WHY WRONG: Implementation Examples are guidance, NOT requirements. They go in sections{"Implementation Examples": "..."}, NOT in sub_controls. sub_controls = [] for most NIST CSF subcategories.\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
