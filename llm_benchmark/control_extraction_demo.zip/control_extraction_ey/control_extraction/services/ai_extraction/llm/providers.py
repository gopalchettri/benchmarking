"""
LLM Provider Abstraction Layer

This module implements the ILLMProvider interface with support for:
- Azure OpenAI
- Ollama (local)

All providers enforce temperature=0 for deterministic output.
"""

import asyncio
import functools
import httpx
import json
import re
import socket
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple, Type
from pydantic import BaseModel

from instructor import Mode, AsyncInstructor, from_openai
from instructor.exceptions import InstructorRetryException
from core.exceptions import (
    ContextOverflowError,
    UnparseableJSONError,
    EmptyResponseError,
    LLMConnectionError,
    ProviderConfigurationError
)

if TYPE_CHECKING:
    from config import Settings

from utils.logging_config import logger

# tiktoken: accurate token counting for OpenAI/Azure models.
# Optional — falls back to char-based estimation if unavailable.
try:
    import tiktoken
    _TIKTOKEN_AVAILABLE = True
except ImportError:
    tiktoken = None  # type: ignore[assignment]
    _TIKTOKEN_AVAILABLE = False

# Approximate characters per token — empirical average across GPT-4 and Qwen models.
# Source: OpenAI docs state ~4 chars/token for English prose; 3.7 is slightly
# conservative to account for mixed prose/structured content. Used only for rough
# overflow estimation in error messages, not for rate limiting or budget allocation.
_APPROX_CHARS_PER_TOKEN = 3.7
# L-2: Named constants for char-based token estimation (fallback path)
_CHARS_PER_TOKEN_JSON = 3.5     # JSON/structured content has more punctuation tokens
_CHARS_PER_TOKEN_PROSE = 4.0    # English prose averages ~4 chars/token
_QWEN_EFFICIENCY_FACTOR = 0.95  # Qwen tokenizer is slightly more efficient
_JSON_PUNCTUATION_THRESHOLD = 0.02  # >2% JSON punctuation → classify as JSON-heavy


# C-1: Bounded LRU cache (maxsize=8) replaces the previous unbounded dict.
# Prevents slow memory leaks in long-running workers when deployment names rotate.
@functools.lru_cache(maxsize=8)
def _get_tiktoken_encoding(model_name: str):
    """Get tiktoken encoding for a model, with bounded LRU caching.

    Returns encoding object or None if model is unsupported.
    """
    if not _TIKTOKEN_AVAILABLE or not model_name:
        return None
    try:
        enc = tiktoken.encoding_for_model(model_name)
        logger.info(f"[tiktoken] Loaded encoding for model '{model_name}': {enc.name}")
        return enc
    except KeyError:
        # Model not in tiktoken's registry — try o200k_base (GPT-4o/5 family)
        try:
            enc = tiktoken.get_encoding("o200k_base")
            logger.info(f"[tiktoken] Model '{model_name}' not in registry, using o200k_base")
            return enc
        except Exception:
            pass
    logger.info(f"[tiktoken] No encoding available for '{model_name}', using char estimation")
    return None


def _truncate_for_log(text: str, limit: int) -> str:
    """
    Truncate text for logging based on limit.

    Args:
        text: Text to potentially truncate
        limit: Max chars (0 or negative = no truncation)

    Returns:
        Original text if limit <= 0, otherwise truncated with '...'
    """
    if limit <= 0:
        return text
    if len(text) <= limit:
        return text
    return text[:limit] + "..."


# P-04: Bounded hash-based cache for estimate_tokens.
# Key = (text_hash, len, model_name) — len reduces collision risk.
# Cleared when full (simple eviction). Saves ~10ms per repeated tiktoken call.
_TOKEN_ESTIMATE_CACHE: dict[tuple[int, int, str], int] = {}
_TOKEN_CACHE_MAX = 128


def estimate_tokens(text: str, model_type: str = "default", model_name: str = "") -> int:
    """
    Count or estimate token count for text.

    Strategy:
      1. If tiktoken is available AND model_name maps to a known encoding,
         use exact tokenization (accurate for OpenAI/Azure models).
      2. Otherwise, fall back to char-based estimation with content-type
         and model-family adjustments.

    P-04: Results are cached by (hash, len, model_name) to avoid re-encoding
    identical text across multiple pipeline stages.

    Args:
        text: Text to count/estimate tokens for
        model_type: Model family hint ("qwen", "llama", "gpt", "default")
        model_name: Specific model/deployment name for tiktoken lookup

    Returns:
        Token count (exact if tiktoken available, estimated otherwise)
    """
    if not text:
        return 0

    cache_key = (hash(text), len(text), model_name)
    cached = _TOKEN_ESTIMATE_CACHE.get(cache_key)
    if cached is not None:
        return cached

    # --- Path 1: Exact count via tiktoken ---
    if model_name:
        encoding = _get_tiktoken_encoding(model_name)
        if encoding is not None:
            result = len(encoding.encode(text))
            _cache_token_result(cache_key, result)
            return result

    # --- Path 2: Char-based estimation (fallback) ---
    char_count = len(text)

    # Detect content type for better estimation
    json_indicators = text.count('{') + text.count('[') + text.count('"')
    is_json_heavy = json_indicators > char_count * _JSON_PUNCTUATION_THRESHOLD

    chars_per_token = _CHARS_PER_TOKEN_JSON if is_json_heavy else _CHARS_PER_TOKEN_PROSE

    # Model-specific adjustments (minor)
    if model_type.lower() in ("qwen", "qwen2", "qwen3"):
        chars_per_token *= _QWEN_EFFICIENCY_FACTOR

    result = max(1, int(char_count / chars_per_token))
    _cache_token_result(cache_key, result)
    return result


def _cache_token_result(key: tuple, value: int) -> None:
    """Store a token estimate in the bounded cache."""
    if len(_TOKEN_ESTIMATE_CACHE) >= _TOKEN_CACHE_MAX:
        _TOKEN_ESTIMATE_CACHE.clear()
    _TOKEN_ESTIMATE_CACHE[key] = value


def log_token_calculation(
    provider_name: str,
    system_prompt_chars: int,
    user_prompt_chars: int,
    estimated_input_tokens: int,
    context_window: int,
    max_output_tokens: int,
    model_name: str = ""
) -> None:
    """
    Log detailed token calculation for debugging and monitoring.

    Args:
        provider_name: Name of the LLM provider
        system_prompt_chars: Character count of system prompt
        user_prompt_chars: Character count of user prompt
        estimated_input_tokens: Estimated input token count
        context_window: Total context window size
        max_output_tokens: Reserved output tokens
        model_name: Model name for logging
    """
    total_chars = system_prompt_chars + user_prompt_chars
    available_context = context_window - max_output_tokens
    utilization = (estimated_input_tokens / available_context * 100) if available_context > 0 else 0

    # L-8: Single-line structured log (multi-line logs break log aggregators)
    logger.info(
        f"[{provider_name}] TOKEN CALCULATION: model={model_name}, "
        f"input_chars={total_chars:,} (system={system_prompt_chars:,}, user={user_prompt_chars:,}), "
        f"est_input_tokens=~{estimated_input_tokens:,}, context_window={context_window:,}, "
        f"reserved_output={max_output_tokens:,}, available_input={available_context:,}, "
        f"utilization={utilization:.1f}%"
    )

    # Log warnings based on utilization
    if utilization > 100:
        logger.error(
            f"[{provider_name}] CONTEXT OVERFLOW! "
            f"Estimated input ({estimated_input_tokens:,}) exceeds available context ({available_context:,}). "
            f"Response may be truncated or fail."
        )
    elif utilization > 90:
        logger.warning(
            f"[{provider_name}] HIGH CONTEXT UTILIZATION ({utilization:.1f}%). "
            f"Consider reducing input size or increasing context window."
        )
    elif utilization > 75:
        logger.info(f"[{provider_name}] Context utilization healthy at {utilization:.1f}%")


# H-5: Pre-compiled regex patterns for JSON parsing (called per LLM response)
_RE_CODE_FENCE_OPEN = re.compile(r'^```(?:json)?\s*\n?', re.MULTILINE)
_RE_CODE_FENCE_CLOSE = re.compile(r'\n?```\s*$', re.MULTILINE)
_RE_JSON_OBJ_GREEDY = re.compile(r'(\{[\s\S]*\})')
_RE_JSON_OBJ_LAZY = re.compile(r'(\{[\s\S]*?\})\s*$')
_RE_JSON_ARR_GREEDY = re.compile(r'(\[[\s\S]*\])')
_RE_JSON_ARR_LAZY = re.compile(r'(\[[\s\S]*?\])\s*$')
_RE_TRAILING_COMMA = re.compile(r',\s*$')


def _robust_json_parse(content: str, provider_name: str = "unknown", error_preview_limit: int = 0) -> Optional[Dict[str, Any]]:
    """
    Robustly parse JSON from LLM response, handling common issues:
    - Markdown code blocks (```json ... ```)
    - Leading/trailing whitespace
    - Truncated JSON (attempts repair)
    - Extra text before/after JSON

    Args:
        content: Raw LLM response string
        provider_name: Provider name for logging

    Returns:
        Parsed JSON dict, or None on failure
    """
    if not content or not content.strip():
        logger.error(f"[{provider_name}] Empty response content")
        return None

    original_content = content

    # Step 1: Try direct parse first (fastest path)
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass

    # Step 2: Strip markdown code fences
    content = _RE_CODE_FENCE_OPEN.sub('', content)
    content = _RE_CODE_FENCE_CLOSE.sub('', content)
    content = content.strip()

    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass

    # Step 3: Extract JSON object from surrounding text.
    # Greedy first: captures from the first { / [ to the last } / ], which is
    # correct for well-formed JSON with leading prose or trailing whitespace.
    # Non-greedy anchored-to-end is a secondary fallback for edge cases where
    # the greedy match pulls in extra trailing characters.
    # L-2: greedy before non-greedy — non-greedy stops at the first } it can
    #      satisfy the \s*$ anchor with, which can undercut the real JSON object.
    json_match = _RE_JSON_OBJ_GREEDY.search(content)
    if not json_match:
        json_match = _RE_JSON_OBJ_LAZY.search(content)
    if not json_match:
        json_match = _RE_JSON_ARR_GREEDY.search(content)
    if not json_match:
        json_match = _RE_JSON_ARR_LAZY.search(content)
    if json_match:
        extracted = json_match.group(1)
        try:
            return json.loads(extracted)
        except json.JSONDecodeError:
            # Try to repair truncated JSON
            repaired = _repair_truncated_json(extracted)
            if repaired:
                try:
                    result = json.loads(repaired)
                    logger.warning(f"[{provider_name}] Repaired truncated JSON (missing closing brackets)")
                    return result
                except json.JSONDecodeError:
                    pass

    # Step 4: Attempt to repair common truncation issues on original
    repaired = _repair_truncated_json(content)
    if repaired:
        try:
            result = json.loads(repaired)
            logger.warning(f"[{provider_name}] Repaired truncated JSON (missing closing brackets)")
            return result
        except json.JSONDecodeError:
            pass

    # All attempts failed — return None so callers can distinguish parse failure from empty result
    content_preview = _truncate_for_log(original_content, error_preview_limit)
    logger.error(f"[{provider_name}] Failed to parse JSON after all attempts. Content: {content_preview}")
    return None


def _repair_truncated_json(content: str) -> Optional[str]:
    """
    Attempt to repair truncated JSON by closing unclosed brackets/braces.

    Common issues:
    - Missing closing brackets/braces at end
    - Incomplete string at end
    """
    if not content:
        return None

    # Count unclosed brackets/braces
    stack = []
    in_string = False
    escape_next = False

    for char in content:
        if escape_next:
            escape_next = False
            continue
        if char == '\\' and in_string:
            escape_next = True
            continue
        # H-4: When we reach this point, escape_next is always False
        # (consumed by the early continue above). The previous `not escape_next`
        # guard was a no-op. The escape logic is correct: backslash sets
        # escape_next=True → next iteration skips via `continue` → never
        # reaches this line with escape_next=True.
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char in '{[':
            stack.append(char)
        elif char == '}' and stack and stack[-1] == '{':
            stack.pop()
        elif char == ']' and stack and stack[-1] == '[':
            stack.pop()

    # If we're in an unclosed string, close it
    if in_string:
        content = content.rstrip()
        # Strip trailing backslash to avoid creating an escaped quote (\")
        # instead of a string-closing quote when we append '"' below.
        if content.endswith('\\'):
            content = content[:-1]
        # Remove incomplete trailing content (like partial key or value)
        if content.endswith(','):
            content = content[:-1]
        content += '"'

    # Strip trailing commas before closing (common in truncated LLM output)
    content = _RE_TRAILING_COMMA.sub('', content)

    # Close unclosed brackets/braces
    closers = {'[': ']', '{': '}'}
    for opener in reversed(stack):
        content += closers[opener]

    # Return repaired content if any fix was applied, otherwise return
    # the original content unchanged (it was already balanced).
    return content

# Real Imports
try:
    import aiohttp
    from openai import AsyncAzureOpenAI, AsyncOpenAI
except ImportError as e:
    logger.error(f"Critical dependencies missing: {e}")
    raise ImportError("Failed to load OpenAI or Aiohttp. Run 'pip install openai aiohttp'")

from llm.token_tracker import get_token_tracker


@dataclass
class LLMResponse:
    """Structured response from LLM with token tracking."""
    content: Dict[str, Any]
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    model: str = ""
    truncated: bool = False  # O-07: True when output hit >=95% of max_tokens


class ILLMProvider(ABC):
    """
    Abstract interface for LLM providers.

    All implementations MUST:
    - Enforce temperature=0 for deterministic output
    - Return valid JSON
    - Track token usage for cost monitoring
    """

    @abstractmethod
    async def generate_json(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model: Optional[Type[BaseModel]] = None
    ) -> Any:
        """
        Generates a JSON response from the LLM.
        MUST enforce temperature=0 for determinism.
        """
        pass

    @abstractmethod
    async def generate_json_with_metrics(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model: Optional[Type[BaseModel]] = None
    ) -> LLMResponse:
        """
        Generates a JSON response with token usage metrics.
        Used for cost tracking and observability.
        """
        pass

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Returns the provider identifier."""
        pass

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Returns the deployment or model name used by this provider."""
        pass

    async def close(self):
        """Release resources held by the provider (connections, sessions)."""
        pass  # Default no-op; subclasses override if they hold resources

    @abstractmethod
    def validate_config(self) -> bool:
        """Validate provider configuration."""
        pass

class BaseLLMProvider(ILLMProvider):
    """Template Method orchestrator for Token Tracking and Logging."""
    
    @abstractmethod
    async def _execute_inference(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model: Optional[Type[BaseModel]] = None
    ) -> Tuple[str, Dict[str, Any], int, int, int]:
        pass

    async def generate_json(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model: Optional[Type[BaseModel]] = None
    ) -> Any:
        response = await self.generate_json_with_metrics(
            system_prompt, user_prompt, max_tokens, response_model
        )
        return response.content

    async def generate_json_with_metrics(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: Optional[int] = None,
        response_model: Optional[Type[BaseModel]] = None
    ) -> LLMResponse:
        start_time = time.monotonic()
        effective_max_tokens = max_tokens if max_tokens is not None else self.max_output_tokens

        log_sys_limit = self.config.LOG_TRUNCATE_SYSTEM_PROMPT
        log_user_limit = self.config.LOG_TRUNCATE_USER_PROMPT
        log_output_limit = self.config.LOG_TRUNCATE_LLM_OUTPUT
        log_error_limit = self.config.LOG_TRUNCATE_JSON_ERROR
        
        system_prompt_chars = len(system_prompt)
        user_prompt_chars = len(user_prompt)
        
        model_name = self.model_name
        model_type = "qwen" if "qwen" in model_name.lower() else "default"
        estimated_input_tokens = estimate_tokens(system_prompt + user_prompt, model_type=model_type, model_name=model_name)
        
        context_window = self.model_context_tokens
        available_context = context_window - effective_max_tokens
        
        log_token_calculation(
            provider_name=self.provider_name,
            system_prompt_chars=system_prompt_chars,
            user_prompt_chars=user_prompt_chars,
            estimated_input_tokens=estimated_input_tokens,
            context_window=context_window,
            max_output_tokens=effective_max_tokens,
            model_name=model_name
        )
        
        if estimated_input_tokens > available_context:
            overflow_tokens = estimated_input_tokens - available_context
            overflow_chars = int(overflow_tokens * _APPROX_CHARS_PER_TOKEN)
            raise ContextOverflowError(
                f"[{self.provider_name}] Input exceeds context window by ~{overflow_tokens:,} tokens (~{overflow_chars:,} chars). "
                f"Consider: 1) Reduce input size, 2) Reduce max_output_tokens, 3) Increase context window"
            )

        logger.info(f"[{self.provider_name}] LLM CALL START: model={model_name}, max_tokens={effective_max_tokens}")
        logger.info(f"[{self.provider_name}] SYSTEM PROMPT ({system_prompt_chars:,} chars): {_truncate_for_log(system_prompt, log_sys_limit)}")
        logger.info(f"[{self.provider_name}] USER PROMPT ({user_prompt_chars:,} chars): {_truncate_for_log(user_prompt, log_user_limit)}")
        
        prompt_tokens = 0
        completion_tokens = 0
        total_tokens = 0

        # H-01: Retry transient failures (timeouts, connection errors, rate limits)
        # with exponential backoff. Deterministic errors (auth, context overflow,
        # config) are NOT retried.
        max_retries = 2
        base_wait = 5.0
        backoff_factor = 2.0
        last_error: Optional[Exception] = None

        for attempt in range(max_retries + 1):
            try:
                attempt_start = time.monotonic()
                raw_content, parsed_content, p_tok, c_tok, t_tok = await self._execute_inference(
                    system_prompt, user_prompt, effective_max_tokens, response_model
                )
                prompt_tokens, completion_tokens, total_tokens = p_tok, c_tok, t_tok

                if not parsed_content:
                    parsed_content = _robust_json_parse(raw_content, self.provider_name, log_error_limit)
                    if parsed_content is None:
                        raise UnparseableJSONError(f"[{self.provider_name}] LLM returned unparseable JSON ({len(raw_content):,} chars, {c_tok:,} tokens)")

                duration_ms = int((time.monotonic() - start_time) * 1000)
                tokens_per_second = (completion_tokens / (duration_ms / 1000)) if duration_ms > 0 else 0

                logger.info(
                    f"[{self.provider_name}] LLM CALL COMPLETE: "
                    f"duration={duration_ms:,}ms, output_chars={len(raw_content):,}, "
                    f"speed={tokens_per_second:.1f} tok/s, "
                    f"tokens(prompt={prompt_tokens:,}, completion={completion_tokens:,}, total={total_tokens:,})"
                )

                if completion_tokens >= effective_max_tokens * 0.95:
                    logger.warning(
                        f"[{self.provider_name}] Output may be TRUNCATED! "
                        f"completion_tokens ({completion_tokens:,}) is ≥95% of max_tokens ({effective_max_tokens:,})."
                    )

                logger.info(f"[{self.provider_name}] LLM OUTPUT: {_truncate_for_log(raw_content, log_output_limit)}")

                get_token_tracker().record_call(
                    input_tokens=prompt_tokens, output_tokens=completion_tokens,
                    success=True, model=model_name, duration_ms=duration_ms
                )

                is_truncated = completion_tokens >= effective_max_tokens * 0.95
                return LLMResponse(
                    content=parsed_content, prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens, total_tokens=total_tokens,
                    model=model_name, truncated=is_truncated,
                )

            except (ContextOverflowError, ProviderConfigurationError):
                # Deterministic errors — same input will always fail. Don't retry.
                duration_ms = int((time.monotonic() - start_time) * 1000)
                logger.error(f"[{self.provider_name}] Non-retryable error after {duration_ms}ms: {type(last_error).__name__ if last_error else 'unknown'}")
                get_token_tracker().record_call(
                    input_tokens=prompt_tokens, output_tokens=completion_tokens,
                    success=False, model=model_name, duration_ms=duration_ms
                )
                raise

            except Exception as e:
                last_error = e
                duration_ms = int((time.monotonic() - attempt_start) * 1000)

                # Check for auth errors — don't retry these.
                # Skip string-based check for InstructorRetryException: it wraps
                # multiple retry attempts and its string may contain auth keywords
                # from transient errors even though the root cause is not auth.
                is_auth = getattr(e, 'status_code', None) == 401
                if not is_auth and not isinstance(e, InstructorRetryException):
                    err_lower = str(e).lower()
                    is_auth = '401' in err_lower or 'unauthorized' in err_lower or 'authentication' in err_lower
                if is_auth:
                    logger.error(f"[{self.provider_name}] Auth error (no retry): {type(e).__name__}")
                    get_token_tracker().record_call(
                        input_tokens=prompt_tokens, output_tokens=completion_tokens,
                        success=False, model=model_name, duration_ms=duration_ms
                    )
                    raise

                # Check for client errors (4xx) — don't retry except 429 (rate limit)
                status_code = getattr(e, 'status_code', None)
                if status_code is not None and 400 <= status_code < 500 and status_code != 429:
                    logger.error(
                        f"[{self.provider_name}] Client error {status_code} (no retry): "
                        f"{type(e).__name__}: {e}"
                    )
                    get_token_tracker().record_call(
                        input_tokens=prompt_tokens, output_tokens=completion_tokens,
                        success=False, model=model_name, duration_ms=duration_ms
                    )
                    raise

                if attempt < max_retries:
                    wait = base_wait * (backoff_factor ** attempt)
                    logger.warning(
                        f"[{self.provider_name}] Transient error (attempt {attempt + 1}/{max_retries + 1}), "
                        f"retrying in {wait:.0f}s: {type(e).__name__}: {e}"
                    )
                    await asyncio.sleep(wait)
                else:
                    duration_ms = int((time.monotonic() - start_time) * 1000)
                    logger.error(
                        f"[{self.provider_name}] Failed after {max_retries + 1} attempts "
                        f"({duration_ms}ms total): {type(e).__name__}: {e}"
                    )
                    get_token_tracker().record_call(
                        input_tokens=prompt_tokens, output_tokens=completion_tokens,
                        success=False, model=model_name, duration_ms=duration_ms
                    )
                    raise


class AzureOpenAIProvider(BaseLLMProvider):
    """
    Azure OpenAI GPT-4 Provider.

    Features:
    - Azure SDK async client
    - Model warmup for cold-start elimination
    - Async context manager for clean resource management
    """

    def __init__(self, config: "Settings"):
        import instructor
        self.config = config
        self.azure_client = AsyncAzureOpenAI(
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            timeout=httpx.Timeout(config.LLM_REQUEST_TIMEOUT_SECONDS),
        )
        self.client = instructor.from_openai(self.azure_client, mode=instructor.Mode.JSON)
        self.deployment = config.AZURE_OPENAI_DEPLOYMENT_NAME

        # Context window configuration (configurable per model via .env)
        self.model_context_tokens = config.LLM_MODEL_CONTEXT_TOKENS
        self.max_output_tokens = config.LLM_MAX_OUTPUT_TOKENS

        logger.info(f"Initialized Azure OpenAI Provider: {self.deployment}")
        logger.info(f"  Context Window: {self.model_context_tokens} tokens, Max Output: {self.max_output_tokens} tokens")

    async def close(self):
        """Close the client when done."""
        if hasattr(self.azure_client, 'close'):
            await self.azure_client.close()
            logger.info("Closed Azure OpenAI provider")

    async def __aenter__(self):
        """Async context manager entry - optionally warm up model."""
        enable_warmup = getattr(self.config, 'LLM_ENABLE_WARMUP', True)
        if enable_warmup:
            await self.warmup_model()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - ensures cleanup."""
        await self.close()
        return False

    async def warmup_model(self) -> bool:
        """Warm up the model with a minimal request."""
        try:
            if not self.config.AZURE_OPENAI_API_KEY or \
               not self.config.AZURE_OPENAI_ENDPOINT or \
               not self.config.AZURE_OPENAI_DEPLOYMENT_NAME:
                logger.error("Azure OpenAI configuration is incomplete. "
                             f"Key:{bool(self.config.AZURE_OPENAI_API_KEY)}, "
                             f"Endpt:{bool(self.config.AZURE_OPENAI_ENDPOINT)}, "
                             f"Deploy:{bool(self.config.AZURE_OPENAI_DEPLOYMENT_NAME)}")
                return False
            logger.info(f"Warming up Azure model: {self.deployment}")
            await self.azure_client.chat.completions.create(
                model=self.deployment,
                messages=[{"role": "user", "content": "Hi"}],
                max_completion_tokens=50,
            )
            logger.info(f"Model {self.deployment} warmed up and ready")
            return True
        except Exception as e:
            logger.warning(f"Model warmup failed (non-critical): {e}")
            return False

    @property
    def provider_name(self) -> str:
        return "azure_openai"

    @property
    def model_name(self) -> str:
        return self.deployment

    async def _execute_inference(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model: Optional[Type[BaseModel]] = None
    ) -> Tuple[str, Dict[str, Any], int, int, int]:
        api_kwargs = {
            "model": self.deployment,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "max_completion_tokens": max_tokens,
            "temperature": self.config.LLM_TEMPERATURE,
        }
        if response_model:
            api_kwargs["response_model"] = response_model
        else:
            api_kwargs["response_format"] = {"type": "json_object"}

        reasoning_effort = getattr(self.config, 'LLM_REASONING_EFFORT', None)
        if reasoning_effort:
            api_kwargs["reasoning_effort"] = reasoning_effort

        # L-4: Initialize before the if/else to avoid unbound variable risk
        parsed_content = {}
        content = ""

        if response_model:
            parsed_model = await self.client.chat.completions.create(**api_kwargs)
            parsed_content = parsed_model.model_dump()
            # instructor >= 1.x exposes _raw_response on patched model instances.
            # If this disappears after an upgrade, token counts degrade to 0 (warning logged).
            # Pin instructor version in requirements.txt to prevent silent breakage.
            raw = getattr(parsed_model, '_raw_response', None)
            if raw is None:
                logger.warning(
                    f"[{self.provider_name}] instructor _raw_response unavailable — "
                    "token counts will be 0. Check instructor/openai version compatibility."
                )
            usage = raw.usage if raw else None
            content = raw.choices[0].message.content if (raw and raw.choices) else "{}"
        else:
            response = await self.azure_client.chat.completions.create(**api_kwargs)
            content = response.choices[0].message.content or ""
            usage = response.usage

        prompt_tokens = usage.prompt_tokens if usage else 0
        completion_tokens = usage.completion_tokens if usage else 0
        total_tokens = usage.total_tokens if usage else 0

        return content, parsed_content, prompt_tokens, completion_tokens, total_tokens

    def validate_config(self) -> bool:
        """Validate Azure configuration."""
        if not self.config.AZURE_OPENAI_API_KEY:
            logger.error("AZURE_OPENAI_API_KEY is missing")
            return False
        if not self.config.AZURE_OPENAI_ENDPOINT:
            logger.error("AZURE_OPENAI_ENDPOINT is missing")
            return False
        return True


class KeepAliveTCPConnector(aiohttp.TCPConnector):
    """
    Custom TCPConnector that enables TCP Keep-Alive on the socket.
    This prevents firewalls/NATs from dropping idle connections during long LLM inference.
    """

    def __init__(
        self,
        *args,
        keepalive_idle: int = 30,
        keepalive_interval: int = 10,
        keepalive_count: int = 3,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self._ka_idle = keepalive_idle
        self._ka_interval = keepalive_interval
        self._ka_count = keepalive_count

    async def _create_connection(self, req, traces, timeout):
        # aiohttp 3.13.2 returns only proto (ResponseHandler), not (transport, proto)
        proto = await super()._create_connection(req, traces, timeout)

        try:
            transport = proto.transport
            sock = transport.get_extra_info('socket')
            if sock:
                # 1. Enable TCP Keep-Alive
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)

                # 2. Set Keep-Alive parameters (Platform dependent)

                # Linux / MacOS specific options
                if hasattr(socket, 'TCP_KEEPIDLE'):
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, self._ka_idle)
                if hasattr(socket, 'TCP_KEEPINTVL'):
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, self._ka_interval)
                if hasattr(socket, 'TCP_KEEPCNT'):
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, self._ka_count)

                # MacOS specific (some versions use TCP_KEEPALIVE instead of TCP_KEEPIDLE)
                if hasattr(socket, 'TCP_KEEPALIVE') and not hasattr(socket, 'TCP_KEEPIDLE'):
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPALIVE, self._ka_idle)

                # Windows specific (SIO_KEEPALIVE_VALS)
                if hasattr(socket, 'SIO_KEEPALIVE_VALS'):
                    # L-9: Compute ms values only when needed (Windows path)
                    ka_idle_ms = self._ka_idle * 1000
                    ka_interval_ms = self._ka_interval * 1000
                    # (on/off, keepalivetime_ms, keepaliveinterval_ms)
                    try:
                        # Handle asyncio ProactorEventLoop TransportSocket wrapper
                        raw_sock = sock
                        if hasattr(sock, 'ioctl'):
                            raw_sock.ioctl(socket.SIO_KEEPALIVE_VALS, (1, ka_idle_ms, ka_interval_ms))
                        elif hasattr(sock, '_sock') and hasattr(sock._sock, 'ioctl'):
                            sock._sock.ioctl(socket.SIO_KEEPALIVE_VALS, (1, ka_idle_ms, ka_interval_ms))
                        else:
                            logger.debug("Socket does not support ioctl (likely Proactor wrapper), skipping Windows-specific Keep-Alive tuning.")
                    except Exception as e:
                        logger.warning(f"Failed to set SIO_KEEPALIVE_VALS on Windows: {e}")

                logger.debug(f"TCP Keep-Alive enabled on socket for {req.host}")

        except Exception as e:
            logger.warning(f"Failed to set TCP Keep-Alive options: {e}")

        return proto


class OllamaProvider(BaseLLMProvider):
    """
    Ollama Provider using OpenAI-compatible API with connection pooling.

    Features:
    - Connection pooling for faster repeated requests
    - Model warmup to eliminate cold-start latency
    - Async context manager for clean resource management

    Requires Ollama server running with v1 API compatibility.
    """

    def __init__(self, config: "Settings"):
        self.config = config
        self.base_url = config.OLLAMA_BASE_URL
        # C-1: Redact credentials from base_url for logging.
        # Pattern matches http://user:pass@host and strips the user:pass@ part.
        self._safe_url = re.sub(r'://[^@]+@', '://[REDACTED]@', self.base_url)
        self.api_key = config.OLLAMA_API_KEY or "ollama"
        self.model = config.OLLAMA_MODEL_NAME

        # Context window configuration (configurable per model via .env)
        self.model_context_tokens = config.LLM_MODEL_CONTEXT_TOKENS

        # Production configuration from settings (defaults match config.py for T4 GPU)
        self.max_output_tokens = config.LLM_MAX_OUTPUT_TOKENS
        self.request_timeout = config.LLM_REQUEST_TIMEOUT_SECONDS

        # Connection pooling configuration (defaults match config.py for T4 single-GPU)
        self._session: Optional[aiohttp.ClientSession] = None
        self._session_lock = asyncio.Lock()  # M-2: Prevent concurrent session creation
        self._connector_limit = config.OLLAMA_CONNECTION_POOL_SIZE
        self._keepalive_timeout = config.OLLAMA_KEEPALIVE_TIMEOUT

        logger.info(f"Initialized Ollama Provider: {self.model} at {self._safe_url}")
        logger.info(f"  Context Window: {self.model_context_tokens} tokens, Max Output: {self.max_output_tokens} tokens")
        logger.info(f"  Timeout: {self.request_timeout}s")
        logger.info(f"  Connection Pool: {self._connector_limit} connections, {self._keepalive_timeout}s keepalive")

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create a reusable session with connection pooling.

        M-2: Uses double-checked locking to prevent concurrent session creation.
        """
        # Fast path: session already exists and is open
        if self._session is not None and not self._session.closed:
            return self._session

        async with self._session_lock:
            # Re-check after acquiring lock (another coroutine may have created it)
            if self._session is not None and not self._session.closed:
                return self._session

            # Create connector with connection pooling and TCP Keep-Alive
            connector = KeepAliveTCPConnector(
                limit=self._connector_limit,
                limit_per_host=self._connector_limit,
                keepalive_timeout=self._keepalive_timeout,
                enable_cleanup_closed=True,
                force_close=False,
                keepalive_idle=self.config.TCP_KEEPALIVE_IDLE,
                keepalive_interval=self.config.TCP_KEEPALIVE_INTERVAL,
                keepalive_count=self.config.TCP_KEEPALIVE_COUNT,
            )
            # Create timeout config
            timeout = aiohttp.ClientTimeout(total=self.request_timeout)
            self._session = aiohttp.ClientSession(
                connector=connector,
                timeout=timeout
            )
            logger.debug("Created new aiohttp session with connection pooling")
        return self._session

    async def close(self):
        """Close the session when done - call this for cleanup."""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
            logger.info("Closed Ollama provider connection pool")

    async def __aenter__(self):
        """Async context manager entry - optionally warm up model."""
        enable_warmup = getattr(self.config, 'LLM_ENABLE_WARMUP', True)
        if enable_warmup:
            await self.warmup_model()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - ensures cleanup."""
        await self.close()
        return False

    async def warmup_model(self) -> bool:
        """
        Warm up the model by loading it into memory.
        This eliminates cold start latency on the first real request.
        """
        try:
            logger.info(f"Warming up Ollama model: {self.model}")
            endpoint = f"{self.base_url.rstrip('/')}/chat/completions"

            # Send minimal request to load the model into GPU/memory
            payload = {
                "model": self.model,
                "messages": [{"role": "user", "content": "Hi"}],
                "stream": False,
                "max_tokens": 1,  # Generate just 1 token
                "temperature": 0.0
            }

            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }

            session = await self._get_session()
            async with session.post(endpoint, json=payload, headers=headers) as resp:
                if resp.status == 200:
                    logger.info(f"Model {self.model} warmed up and ready")
                    return True
                else:
                    logger.warning(f"Warmup returned status {resp.status}")
                    return False

        except Exception as e:
            logger.warning(f"Model warmup failed (non-critical): {e}")
            return False

    @property
    def provider_name(self) -> str:
        return "ollama"

    @property
    def model_name(self) -> str:
        return self.model

    async def _execute_inference(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model: Optional[Type[BaseModel]] = None
    ) -> Tuple[str, Dict[str, Any], int, int, int]:
        if response_model:
            logger.warning(
                f"[{self.provider_name}] response_model={response_model.__name__} was provided "
                "but Ollama does not support instructor-based schema enforcement. "
                "Output will be validated by the caller via JSON parsing only."
            )

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "stream": False,
            "temperature": self.config.LLM_TEMPERATURE,
            "max_tokens": max_tokens,
            "response_format": {"type": "json_object"},
            "options": {
                "num_ctx": self.model_context_tokens,
                "num_batch": self.config.OLLAMA_NUM_BATCH,
                "num_predict": max_tokens,
                "mirostat": 0,
                "repeat_penalty": self.config.OLLAMA_REPEAT_PENALTY,
                "top_k": self.config.OLLAMA_TOP_K,
                "top_p": self.config.OLLAMA_TOP_P,
            }
        }

        endpoint = f"{self.base_url.rstrip('/')}/chat/completions"

        session = await self._get_session()
        async with session.post(endpoint, json=payload, headers=headers) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                raise LLMConnectionError(f"Ollama HTTP {resp.status}: {error_text}")

            data = await resp.json()

            choices = data.get("choices", [])
            if not choices:
                raise EmptyResponseError("[ollama] LLM returned empty response (no choices)")

            content = choices[0].get("message", {}).get("content", "")
            usage = data.get("usage", {})

            prompt_tokens = usage.get("prompt_tokens", 0)
            completion_tokens = usage.get("completion_tokens", 0)
            total_tokens = usage.get("total_tokens", 0)

            return content, {}, prompt_tokens, completion_tokens, total_tokens

    def validate_config(self) -> bool:
        """Validate Ollama configuration."""
        if not self.base_url:
            logger.error("OLLAMA_BASE_URL is missing")
            return False
        return True


def get_llm_provider(settings: "Settings") -> ILLMProvider:
    """
    Factory function to get the appropriate LLM provider.

    Supported providers:
    - azure: Azure OpenAI (GPT-4)
    - ollama: Local Ollama server
    """
    provider_type = settings.LLM_PROVIDER.lower()

    if provider_type == "azure":
        provider = AzureOpenAIProvider(settings)
    elif provider_type == "ollama":
        provider = OllamaProvider(settings)
    else:
        raise ProviderConfigurationError(f"Unknown LLM Provider: {provider_type}. Supported: azure, ollama")

    if not provider.validate_config():
        raise ProviderConfigurationError(
            f"Provider '{provider_type}' configuration is invalid. Check logs for details."
        )
    return provider
