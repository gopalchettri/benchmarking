"""
Rate Limiter Module

Implements token bucket rate limiting for LLM calls to prevent overloading.

Features:
- Token bucket algorithm with configurable rate and burst
- Async-compatible with proper locking
- Automatic token replenishment
- Metrics integration for monitoring
"""

import asyncio
import random
import time
from dataclasses import dataclass
from typing import Optional

from utils.logging_config import logger


@dataclass
class RateLimitConfig:
    """Configuration for rate limiting."""
    requests_per_minute: float = 8.0   # Max sustained rate
    burst_size: int = 2                # Max burst (bucket capacity)
    min_interval_seconds: float = 2.0  # Minimum between requests


class TokenBucketRateLimiter:
    """
    Token bucket rate limiter for LLM API calls.

    Algorithm:
    - Bucket holds up to `burst_size` tokens
    - Tokens replenish at `requests_per_minute / 60` per second
    - Each request consumes 1 token
    - If no tokens available, wait until one is replenished

    This prevents:
    - Overwhelming the LLM server with too many concurrent requests
    - Getting rate-limited by external APIs (Azure, etc.)
    - Resource exhaustion on self-hosted LLMs (Ollama)
    """

    def __init__(self, config: Optional[RateLimitConfig] = None):
        self.config = config or RateLimitConfig()

        # Token bucket state
        self._tokens = float(self.config.burst_size)
        self._last_update = time.monotonic()
        self._lock = asyncio.Lock()

        # Calculate replenishment rate
        self._tokens_per_second = self.config.requests_per_minute / 60.0

        # Metrics
        self._total_requests = 0
        self._total_wait_time = 0.0
        self._throttled_requests = 0

        logger.info(
            f"RateLimiter initialized: {self.config.requests_per_minute} req/min, "
            f"burst={self.config.burst_size}, min_interval={self.config.min_interval_seconds}s"
        )

    def _replenish(self) -> None:
        """Replenish tokens based on elapsed time. Must be called under lock."""
        now = time.monotonic()
        elapsed = now - self._last_update
        self._tokens = min(
            self.config.burst_size,
            self._tokens + elapsed * self._tokens_per_second
        )
        self._last_update = now

    async def acquire(self) -> float:
        """
        Acquire permission to make a request.

        Uses atomic check-and-consume under a single lock acquisition
        to prevent race conditions between concurrent coroutines.

        Returns:
            Total wait time in seconds (0 if no wait was needed)
        """
        total_wait = 0.0

        # M-1: Count once per logical request, before the retry loop.
        # Previously _total_requests was incremented inside the while-True loop,
        # causing a single throttled request to be counted multiple times and
        # making the throttle_rate metric meaningless.
        async with self._lock:
            self._total_requests += 1

        # H-4: Track whether this request was ever throttled.
        # Increment _throttled_requests at most once per logical request,
        # not once per wait cycle (which caused throttle_rate > 100%).
        was_throttled = False

        while True:
            async with self._lock:
                self._replenish()

                if self._tokens >= 1.0:
                    # Atomic: check and consume in one lock scope
                    self._tokens -= 1.0
                    if was_throttled:
                        self._throttled_requests += 1
                    return total_wait

                # Not enough tokens — calculate wait time
                deficit = 1.0 - self._tokens
                wait_time = deficit / self._tokens_per_second
                wait_time = max(wait_time, self.config.min_interval_seconds)
                wait_time = min(wait_time, 60.0)  # Cap to prevent pathological waits
                was_throttled = True
                logger.debug(f"Rate limited: waiting {wait_time:.2f}s (tokens={self._tokens:.2f})")

            # H-4: Add jitter (±15%) to prevent thundering herd when multiple
            # coroutines are throttled simultaneously.
            jittered = wait_time * (0.85 + random.random() * 0.30)
            # Sleep outside the lock so other coroutines can proceed
            await asyncio.sleep(jittered)
            total_wait += jittered
            # M-3: Update aggregate metric under lock to prevent concurrent
            # coroutines from interleaving += during their wait phases.
            async with self._lock:
                self._total_wait_time += jittered

    async def __aenter__(self):
        """Context manager entry - acquires rate limit token."""
        await self.acquire()
        return self

    async def __aexit__(self, _exc_type, _exc_val, _exc_tb):
        """Context manager exit — does not suppress exceptions."""
        return False

    async def get_metrics(self) -> dict:
        """Get rate limiter metrics (consistent snapshot under lock)."""
        async with self._lock:
            return {
                "total_requests": self._total_requests,
                "throttled_requests": self._throttled_requests,
                "total_wait_time_seconds": round(self._total_wait_time, 2),
                "current_tokens": round(self._tokens, 2),
                "throttle_rate": (
                    round(self._throttled_requests / self._total_requests * 100, 1)
                    if self._total_requests > 0 else 0
                ),
            }

    def reset(self):
        """Reset the rate limiter to initial state.

        WARNING: Not safe to call while acquire() is in progress.
        Only call during initialization, tests, or when no concurrent
        work is running. The asyncio.Lock used by acquire() cannot be
        acquired from a synchronous method.
        """
        self._tokens = float(self.config.burst_size)
        self._last_update = time.monotonic()
        self._total_requests = 0
        self._total_wait_time = 0.0
        self._throttled_requests = 0


