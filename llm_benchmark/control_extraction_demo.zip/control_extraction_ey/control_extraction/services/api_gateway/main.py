"""
API Gateway — FastAPI application entry point.

Thin orchestration layer: assembles middleware, mounts route modules,
and runs startup health checks.  All business logic lives in routes/
and services/.
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import get_settings
from shared_core.health import check_redis, check_azure_blob, enforce_startup_checks
from shared_core.middlewares.tracing import RequestTracingMiddleware
from shared_core.middlewares.rate_limiting import RateLimitingMiddleware

settings = get_settings()

# ── OpenTelemetry bootstrap ──
from shared_core.telemetry import setup_telemetry, instrument_fastapi, instrument_httpx
setup_telemetry(service_name=settings.APP_NAME_GATEWAY)
instrument_httpx()

# ── Logging ──
from utils.logging_config import setup_logging
setup_logging(service_name=settings.APP_NAME_GATEWAY, environment=settings.ENVIRONMENT)
from shared_core.intercept_handler import install_intercept_handler
install_intercept_handler(["uvicorn", "uvicorn.access", "uvicorn.error", "fastapi"])


# ── Lifespan: startup health checks ──
@asynccontextmanager
async def lifespan(app: FastAPI):
    checks = {
        "redis": check_redis(settings.REDIS_URL),
    }
    if settings.AZURE_STORAGE_CONNECTION_STRING:
        checks["azure_blob"] = check_azure_blob(
            settings.AZURE_STORAGE_CONNECTION_STRING,
            settings.AZURE_BLOB_CONTAINER_NAME,
        )

    # Import here so the module-level dict is populated before routes use it
    from routes.health import startup_health
    startup_health.update(
        await enforce_startup_checks(
            service_name=settings.APP_NAME_GATEWAY,
            checks=checks,
            critical={"redis"},
        )
    )
    yield


# ── App factory ──
app = FastAPI(
    title=settings.APP_NAME_GATEWAY,
    version=settings.APP_VERSION,
    lifespan=lifespan,
)

# C-1: CORS — disable credentials when wildcard (browser spec requirement)
_cors_origins = settings.CORS_ALLOWED_ORIGINS
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials="*" not in _cors_origins,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition", "Content-Length"],
)

app.add_middleware(RequestTracingMiddleware)
app.add_middleware(
    RateLimitingMiddleware,
    max_requests=settings.GLOBAL_RATE_LIMIT_MAX_REQUESTS,
    window_seconds=settings.GLOBAL_RATE_LIMIT_WINDOW_SECONDS,
)
instrument_fastapi(app)


# ── Global exception handler ──
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Catch-all: ensures unhandled exceptions return JSON instead of crashing ASGI."""
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": f"{exc.status_code}: {exc.detail}"},
        )
    logging.getLogger(__name__).exception(
        f"Unhandled exception on {request.method} {request.url.path}"
    )
    detail = str(exc) if settings.ENVIRONMENT != "production" else "Internal server error"
    return JSONResponse(status_code=500, content={"detail": detail})


# ── Mount route modules ──
from routes.health import router as health_router
from routes.jobs import router as jobs_router
from routes.storage import router as storage_router

app.include_router(health_router)
app.include_router(jobs_router)
app.include_router(storage_router)
