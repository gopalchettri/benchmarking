"""
FastAPI dependencies and shared constants for the API Gateway.

Keeps singleton storage, framework lookup, and validation constants
in one place so route modules stay focused on request handling.
"""

import os
from typing import Optional

import httpx

from config import get_settings
from shared_core.interfaces.storage_port import (
    FileStoragePort, LocalBlobStorage, AzureBlobStorage,
)

settings = get_settings()

# ── Downstream HTTP timeout (configurable would be DOWNSTREAM_HTTP_TIMEOUT_SECONDS) ──
DOWNSTREAM_TIMEOUT = httpx.Timeout(30.0)

# ── Upload validation ──
ALLOWED_CONTENT_TYPES = {"application/pdf"}
ALLOWED_EXTENSIONS = {".pdf"}

# ── Framework name normalization ──
# Canonical names must match seed/builders profile names.
_KNOWN_FRAMEWORKS = {
    "ISO-27001", "NIST-CSF", "PCI-DSS", "SWIFT-CSCF",
    "SAMA-CSF", "DESC-ISR", "ECC", "NCA-ECC", "UAE-IAS",
}
_FRAMEWORK_LOOKUP = {name.upper(): name for name in _KNOWN_FRAMEWORKS}


def normalize_framework(raw: str) -> str:
    """Normalize a user-provided framework name to its canonical form.

    Strips whitespace, uppercases, replaces underscores with hyphens,
    then looks up in the known frameworks set.  Returns the canonical
    name if found, otherwise returns the cleaned string as-is (for
    custom/generic frameworks).
    """
    cleaned = raw.strip().upper().replace("_", "-")
    return _FRAMEWORK_LOOKUP.get(cleaned, cleaned)


# ── Singleton file storage ──
_file_storage_instance: Optional[FileStoragePort] = None


def get_file_storage() -> FileStoragePort:
    """Return the singleton FileStoragePort (Azure Blob or local disk)."""
    global _file_storage_instance
    if _file_storage_instance is not None:
        return _file_storage_instance
    if settings.USE_AZURE_STORAGE and settings.AZURE_STORAGE_CONNECTION_STRING:
        _file_storage_instance = AzureBlobStorage(
            settings.AZURE_STORAGE_CONNECTION_STRING,
            settings.AZURE_BLOB_CONTAINER_NAME,
        )
    else:
        os.makedirs(settings.BLOB_STORAGE_DIR, exist_ok=True)
        _file_storage_instance = LocalBlobStorage(base_dir=settings.BLOB_STORAGE_DIR)
    return _file_storage_instance
