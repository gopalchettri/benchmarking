"""
Saga orchestration — triggers the doc-processing pipeline via HTTP.

Runs as a FastAPI BackgroundTask after job submission returns 202.
Uses tenacity for exponential backoff on transient HTTP failures.
"""

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from config import get_settings
from shared_core.redis_client import update_job_state
from shared_core.constants import STATE_DOC_PROCESSING
from dependencies import DOWNSTREAM_TIMEOUT
from helpers import sanitize_error

settings = get_settings()

DOC_SERVICE_URL = settings.DOC_SERVICE_URL


@retry(
    stop=stop_after_attempt(settings.SAGA_RETRY_ATTEMPTS),
    wait=wait_exponential(
        multiplier=1,
        min=settings.SAGA_RETRY_MIN_WAIT,
        max=settings.SAGA_RETRY_MAX_WAIT,
    ),
    retry=retry_if_exception_type(httpx.RequestError),
)
async def _trigger_saga_with_retry(
    client: httpx.AsyncClient,
    file_path: str,
    toc_start: int,
    toc_end: int,
    content_start: int,
    content_end: int,
    job_id: str,
    framework: str,
    framework_profile_id: str = "",
):
    """Execute the HTTP POST to doc_processing with exponential backoff."""
    await client.post(
        f"{DOC_SERVICE_URL}{settings.API_V1_STR}/extract_text",
        json={
            "pdf_path": file_path,
            "toc_start_page": toc_start,
            "toc_end_page": toc_end,
            "content_start_page": content_start,
            "content_end_page": content_end,
            "orchestration_job_id": job_id,
            "framework": framework,
            "framework_profile_id": framework_profile_id,
        },
    )


async def trigger_saga(
    file_path: str,
    toc_start: int,
    toc_end: int,
    content_start: int,
    content_end: int,
    job_id: str,
    framework: str,
    framework_profile_id: str = "",
):
    """Background task: trigger doc-processing and update job state."""
    from utils.logging_config import start_job_logging, stop_job_logging, get_job_logger

    start_job_logging(job_id, "gateway_saga")
    job_log = get_job_logger(job_id)
    job_log.info("Initiating saga HTTP call to doc_processing...")

    async with httpx.AsyncClient(timeout=DOWNSTREAM_TIMEOUT) as client:
        try:
            await _trigger_saga_with_retry(
                client, file_path, toc_start, toc_end,
                content_start, content_end, job_id, framework,
                framework_profile_id,
            )
            await update_job_state(job_id, STATE_DOC_PROCESSING)
            job_log.info("Saga trigger successful.")
        except Exception as exc:
            safe_err = sanitize_error(exc)
            await update_job_state(
                job_id, f"Failed to start doc processing: {safe_err}"
            )
            job_log.error(f"Saga trigger failed: {safe_err}")
        finally:
            stop_job_logging(job_id)
