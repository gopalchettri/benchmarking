"""Job submission and status polling endpoints."""

import asyncio
import os
import uuid

from fastapi import APIRouter, UploadFile, File, Form, Depends, BackgroundTasks, HTTPException
from pydantic import BaseModel
from typing import Optional

from config import get_settings
from shared_core.redis_client import update_job_state, fetch_job_state
from shared_core.constants import STATE_QUEUED
from shared_core.interfaces.storage_port import FileStoragePort, _sanitize_filename

from dependencies import (
    get_file_storage, normalize_framework,
    ALLOWED_EXTENSIONS, ALLOWED_CONTENT_TYPES,
)
from services.saga import trigger_saga

settings = get_settings()

router = APIRouter(prefix=settings.API_V1_STR, tags=["Orchestration"])


class ExtractionJobStatus(BaseModel):
    job_id: str
    status: str
    stage: str


@router.post(
    "/jobs/extract",
    response_model=ExtractionJobStatus,
    status_code=202,
    summary="Submit extraction job",
    description="Upload a PDF and start the control extraction pipeline. "
                "Returns immediately with a job ID for status polling.",
)
async def submit_extraction_job(
    background_tasks: BackgroundTasks,
    framework: str = Form(...),
    toc_start_page: int = Form(..., ge=0),
    toc_end_page: int = Form(..., ge=0),
    content_start_page: int = Form(..., ge=1),
    content_end_page: int = Form(..., ge=1),
    file: UploadFile = File(...),
    framework_profile_id: Optional[str] = Form(None),
    storage: FileStoragePort = Depends(get_file_storage),
):
    framework = normalize_framework(framework)

    # Cross-field page range validation
    if toc_end_page < toc_start_page:
        raise HTTPException(status_code=422, detail="toc_end_page must be >= toc_start_page")
    if content_end_page < content_start_page:
        raise HTTPException(status_code=422, detail="content_end_page must be >= content_start_page")

    # Enforce maximum payload size (defends against zip bombs)
    max_bytes = settings.MAX_FILE_UPLOAD_BYTES
    if file.size and file.size > max_bytes:
        mb = max_bytes / (1024 * 1024)
        raise HTTPException(status_code=413, detail=f"File too large. Max size is {mb:.0f}MB.")

    # H-3: Validate file extension (runs even when Content-Type header is absent)
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file extension: '{ext}'. Allowed: {', '.join(ALLOWED_EXTENSIONS)}",
        )

    # Secondary MIME type check (extension is authoritative)
    if file.content_type and file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type: {file.content_type}. Allowed: PDF.",
        )

    from utils.logging_config import start_job_logging, stop_job_logging, get_job_logger

    job_id = str(uuid.uuid4())
    safe_original_name = _sanitize_filename(file.filename or "upload")
    filename = f"{framework}/{job_id}/{safe_original_name}"

    start_job_logging(job_id, file.filename)
    job_log = get_job_logger(job_id)
    job_log.info(
        f"Received extraction job for {framework}. "
        f"File: {file.filename}, Profile: {framework_profile_id or 'none'}"
    )

    # H-1: File I/O on threadpool to avoid blocking the event loop
    file_ref = await asyncio.to_thread(storage.save_file, file.file, filename)
    job_log.info(f"File saved: {file_ref}")

    # Verify actual file size via storage port
    try:
        actual_size = await asyncio.to_thread(storage.get_file_size, file_ref)
        if actual_size > max_bytes:
            mb = max_bytes / (1024 * 1024)
            raise HTTPException(
                status_code=413,
                detail=f"File too large ({actual_size} bytes). Max size is {mb:.0f}MB.",
            )
    except HTTPException:
        raise
    except Exception as exc:
        job_log.warning(f"Could not verify file size: {exc}")

    await update_job_state(job_id, STATE_QUEUED)

    # Create persistent job record
    from shared_core.job_client import create_job_record
    await create_job_record(
        job_id=job_id,
        framework=framework,
        file_name=safe_original_name,
        blob_path=file_ref,
        framework_profile_id=framework_profile_id or None,
    )

    # Audit trail
    from shared_core.audit_client import log_audit
    await log_audit(
        action="job.created",
        entity_type="job",
        entity_id=job_id,
        details={"framework": framework, "filename": safe_original_name},
    )

    # Offload inter-service trigger so HTTP responds instantly
    background_tasks.add_task(
        trigger_saga, file_ref, toc_start_page, toc_end_page,
        content_start_page, content_end_page, job_id, framework,
        framework_profile_id or "",
    )
    job_log.info("Saga triggered in background. Returning 202.")

    stop_job_logging(job_id)
    return ExtractionJobStatus(job_id=job_id, status="accepted", stage="queued")


@router.get(
    "/jobs/{job_id}/status",
    summary="Get job status",
    description="Poll the current processing stage of an extraction job.",
)
async def get_job_status(job_id: str):
    stage = await fetch_job_state(job_id)
    if not stage:
        raise HTTPException(status_code=404, detail="Job not found")
    return {"job_id": job_id, "stage": stage}
