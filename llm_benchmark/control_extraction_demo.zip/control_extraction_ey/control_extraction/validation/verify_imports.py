"""
Comprehensive static import verification for all microservice layers.
Run with: .\venv\Scripts\python.exe validation\verify_imports.py

Updated for v2 architecture:
- FrameworkProfileModel + CanonicalControlModel (replaces ExtractionModel)
- ControlRepositoryPort + ProfileRepositoryPort (replaces ExtractionRepositoryPort)
- Per-framework prompt modules (prompts/)
- JWT auth middleware
- No OSCAL, no Celery
"""
import sys, os, importlib.util

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
STORAGE = os.path.join(BASE, 'services', 'storage')
AI_EXT  = os.path.join(BASE, 'services', 'ai_extraction')
DOC_PROC = os.path.join(BASE, 'services', 'doc_processing')
SHARED  = os.path.join(BASE, 'shared_core')

# Only pre-load paths that are unambiguous
for p in [BASE, SHARED]:
    if p not in sys.path:
        sys.path.insert(0, p)

PASS = 0
FAIL = 0

def check(label, fn):
    global PASS, FAIL
    try:
        fn()
        print(f"  [PASS] {label}")
        PASS += 1
    except Exception as e:
        print(f"  [FAIL] {label}")
        print(f"         {type(e).__name__}: {e}")
        FAIL += 1

print("=" * 60)
print("Layer 0: config.py")
print("=" * 60)
from config import get_settings
settings = get_settings()
print(f"  [PASS] config.py  env={settings.ENVIRONMENT}  provider={settings.LLM_PROVIDER}")
check("config — DB_BACKEND setting exists",
      lambda: getattr(settings, 'DB_BACKEND'))
check("config — MAX_FILE_UPLOAD_BYTES = 200MB",
      lambda: (
          assert_val := settings.MAX_FILE_UPLOAD_BYTES,
          None if assert_val == 209715200 else (_ for _ in ()).throw(
              AssertionError(f"Expected 209715200, got {assert_val}")
          )
      ))
check("config — DOC_PROCESSING_DEVICE setting exists",
      lambda: getattr(settings, 'DOC_PROCESSING_DEVICE'))
check("config — DLQ_MAX_DELIVERY_ATTEMPTS setting exists",
      lambda: getattr(settings, 'DLQ_MAX_DELIVERY_ATTEMPTS'))


print()
print("=" * 60)
print("Layer 1: shared_core")
print("=" * 60)
check("storage_port — LocalBlobStorage",
      lambda: __import__('shared_core.interfaces.storage_port', fromlist=['LocalBlobStorage']))
check("storage_port — AzureBlobStorage",
      lambda: __import__('shared_core.interfaces.storage_port', fromlist=['AzureBlobStorage']))
check("telemetry — setup_telemetry, instrument_fastapi, instrument_httpx, get_tracer",
      lambda: __import__('shared_core.telemetry', fromlist=['setup_telemetry']))
check("middlewares.tracing",
      lambda: __import__('shared_core.middlewares.tracing', fromlist=['RequestTracingMiddleware']))
check("middlewares.rate_limiting",
      lambda: __import__('shared_core.middlewares.rate_limiting', fromlist=['RateLimitingMiddleware']))
check("middlewares.auth — JWTAuthMiddleware",
      lambda: __import__('shared_core.middlewares.auth', fromlist=['JWTAuthMiddleware']))


print()
print("=" * 60)
print("Layer 2: ai_extraction service")
print("=" * 60)

# Isolated loader to avoid shadowing storage/models.py
def _load_ai_module(name):
    spec = importlib.util.spec_from_file_location(f"ai_{name}", os.path.join(AI_EXT, f"{name}.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def _check_ai_models():
    mod = _load_ai_module('models')
    assert hasattr(mod, 'ExtractionsWrapper'), 'Missing ExtractionsWrapper'
    assert hasattr(mod, 'SubControl'), 'Missing SubControl'
    assert hasattr(mod, 'ControlExtraction'), 'Missing ControlExtraction'
    # New: extraction_confidence field
    fields = mod.ControlExtraction.model_fields
    assert 'extraction_confidence' in fields, 'Missing extraction_confidence field'

def _check_ai_prompts():
    # prompts.py imports models — use the isolated loader path
    if AI_EXT not in sys.path:
        sys.path.insert(0, AI_EXT)
    import importlib
    prompts = importlib.import_module('prompts')
    assert hasattr(prompts, 'get_subcontrol_prompts')
    assert hasattr(prompts, 'get_toc_prompts')
    assert hasattr(prompts, 'load_framework_prompts')

def _check_prompt_modules():
    if AI_EXT not in sys.path:
        sys.path.insert(0, AI_EXT)
    import importlib
    # Check base module
    base = importlib.import_module('prompts.base')
    assert hasattr(base, 'build_toc_prompts')
    assert hasattr(base, 'build_subcontrol_prompts')
    # Check a framework-specific module
    iso = importlib.import_module('prompts.iso_27001')
    assert hasattr(iso, 'get_toc_prompts')
    assert hasattr(iso, 'get_subcontrol_prompts')
    # Check generic fallback
    generic = importlib.import_module('prompts.generic')
    assert hasattr(generic, 'get_toc_prompts')

def _check_structural_parser():
    mod = _load_ai_module('structural_parser')
    assert hasattr(mod, 'StructuralParser'), 'Missing StructuralParser'

def _check_profile_validator():
    mod = _load_ai_module('profile_validator')
    assert hasattr(mod, 'ProfileValidator'), 'Missing ProfileValidator'

check("models — SubControl, ControlExtraction, ExtractionsWrapper + extraction_confidence", _check_ai_models)
check("prompts — get_subcontrol_prompts, get_toc_prompts, load_framework_prompts", _check_ai_prompts)
check("prompts/ — base, iso_27001, generic modules", _check_prompt_modules)
check("structural_parser — StructuralParser", _check_structural_parser)
check("profile_validator — ProfileValidator", _check_profile_validator)


print()
print("=" * 60)
print("Layer 3: storage service")
print("=" * 60)

# Use file-based loader to avoid ai_extraction/models.py shadowing
def _load_storage_module(name):
    spec = importlib.util.spec_from_file_location(f"storage_{name}", os.path.join(STORAGE, f"{name}.py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[f"storage_{name}"] = mod  # register to avoid re-import conflicts
    spec.loader.exec_module(mod)
    return mod

def _check_storage_models():
    mod = _load_storage_module('models')
    assert hasattr(mod, 'FrameworkProfileModel'), 'Missing FrameworkProfileModel'
    assert hasattr(mod, 'CanonicalControlModel'), 'Missing CanonicalControlModel'
    assert hasattr(mod, 'AuditLogModel'), 'Missing AuditLogModel'
    # Verify key columns
    profile_cols = [c.key for c in mod.FrameworkProfileModel.__table__.columns]
    assert 'prompt_module' in profile_cols, f'Missing prompt_module — got: {profile_cols}'
    control_cols = [c.key for c in mod.CanonicalControlModel.__table__.columns]
    assert 'control_id_raw' in control_cols, f'Missing control_id_raw — got: {control_cols}'
    print(f"         FrameworkProfile columns: {len(profile_cols)}")
    print(f"         CanonicalControl columns: {len(control_cols)}")

def _check_storage_repos():
    if 'models' not in sys.modules:
        m = _load_storage_module('models')
        sys.modules['models'] = m
    if STORAGE not in sys.path:
        sys.path.insert(0, STORAGE)
    import importlib
    repos = importlib.import_module('repositories')
    assert hasattr(repos, 'ControlRepositoryPort'), 'Missing ControlRepositoryPort'
    assert hasattr(repos, 'ProfileRepositoryPort'), 'Missing ProfileRepositoryPort'
    assert hasattr(repos, 'PostgresControlRepository'), 'Missing PostgresControlRepository'
    assert hasattr(repos, 'PostgresProfileRepository'), 'Missing PostgresProfileRepository'

check("storage/models — FrameworkProfileModel, CanonicalControlModel, AuditLogModel", _check_storage_models)
check("storage/repositories — ControlRepositoryPort, ProfileRepositoryPort, Postgres implementations", _check_storage_repos)


print()
print("=" * 60)
print("Layer 4: doc_processing service")
print("=" * 60)

def _load_doc_module(name):
    spec = importlib.util.spec_from_file_location(f"doc_{name}", os.path.join(DOC_PROC, f"{name}.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def _check_format_detector():
    mod = _load_doc_module('format_detector')
    assert hasattr(mod, 'detect_format'), 'Missing detect_format'

def _check_gpu_detector():
    mod = _load_doc_module('gpu_detector')
    assert hasattr(mod, 'detect_gpu'), 'Missing detect_gpu'
    assert hasattr(mod, 'get_device'), 'Missing get_device'

def _check_docx_extractor():
    mod = _load_doc_module('docx_extractor')
    assert hasattr(mod, 'DOCXExtractor'), 'Missing DOCXExtractor'

def _check_xlsx_extractor():
    mod = _load_doc_module('xlsx_extractor')
    assert hasattr(mod, 'XLSXExtractor'), 'Missing XLSXExtractor'

check("format_detector — detect_format", _check_format_detector)
check("gpu_detector — detect_gpu, get_device", _check_gpu_detector)
check("docx_extractor — DOCXExtractor", _check_docx_extractor)
check("xlsx_extractor — XLSXExtractor", _check_xlsx_extractor)


print()
print("=" * 60)
print("Layer 5: Seed script")
print("=" * 60)

def _check_seed():
    seed_path = os.path.join(BASE, 'seed', 'framework_profiles.py')
    spec = importlib.util.spec_from_file_location("seed_profiles", seed_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    assert hasattr(mod, 'PROFILES'), 'Missing PROFILES list'
    assert hasattr(mod, 'seed_profiles'), 'Missing seed_profiles function'
    assert len(mod.PROFILES) == 9, f'Expected 9 profiles, got {len(mod.PROFILES)}'
    names = [p['name'] for p in mod.PROFILES]
    print(f"         Profiles: {', '.join(names)}")

check("seed/framework_profiles — 9 predefined profiles", _check_seed)


print()
print("=" * 60)
print("ExtractionsWrapper AST Schema Test")
print("=" * 60)

def _run_wrapper_test():
    if AI_EXT not in sys.path:
        sys.path.insert(0, AI_EXT)
    from models import ExtractionsWrapper

    raw_dict = {
        "extractions": [
            {
                "control_id": "PCI-1.1",
                "title": "Firewall Configuration",
                "sections": {},
                "sub_controls": [
                    {"number": "1", "id": "PCI-1.1.1", "text": "Install a firewall.", "children": []}
                ]
            }
        ]
    }
    wrapper = ExtractionsWrapper(**raw_dict)
    assert len(wrapper.extractions) == 1
    assert wrapper.extractions[0].control_id == "PCI-1.1"
    assert len(wrapper.extractions[0].sub_controls) == 1
    dumped = wrapper.model_dump()
    assert 'extractions' in dumped
    # Verify extraction_confidence field exists
    assert 'extraction_confidence' in dumped['extractions'][0]

check("ExtractionsWrapper Pydantic validation + model_dump()", _run_wrapper_test)


print()
print("=" * 60)
print("Anti-Regression: OSCAL and Celery removed")
print("=" * 60)

def _verify_no_oscal():
    oscal_path = os.path.join(STORAGE, 'oscal_mapper.py')
    assert not os.path.exists(oscal_path), f'oscal_mapper.py still exists at {oscal_path}'

def _verify_no_celery():
    celery_path = os.path.join(BASE, 'shared_core', 'celery_app.py')
    assert not os.path.exists(celery_path), f'celery_app.py still exists at {celery_path}'

check("oscal_mapper.py deleted", _verify_no_oscal)
check("celery_app.py deleted", _verify_no_celery)


print()
print("=" * 60)
total = PASS + FAIL
print(f"RESULT: {PASS}/{total} checks passed  ({FAIL} failed)")
print("=" * 60)
sys.exit(0 if FAIL == 0 else 1)
