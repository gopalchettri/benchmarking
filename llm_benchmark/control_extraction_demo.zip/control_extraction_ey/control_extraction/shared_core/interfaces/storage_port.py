import abc
import os
import shutil
from datetime import datetime, timezone, timedelta
from typing import BinaryIO, Optional
from urllib.parse import urlparse

from azure.storage.blob import BlobServiceClient, ContentSettings, generate_blob_sas, BlobSasPermissions

from utils.logging_config import logger


# ── Module-level constants ───────────────────────────────────────────────────

# Windows reserved device names for sanitization
_WINDOWS_RESERVED = frozenset({
    'CON', 'PRN', 'AUX', 'NUL',
    'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
    'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9',
})

# Mapping of file extensions to MIME content types  
_CONTENT_TYPE_MAP = {
    '.pdf': 'application/pdf',
    '.md': 'text/markdown',
    '.txt': 'text/plain',
    '.log': 'text/plain',
    '.json': 'application/json',
}


def _sanitize_filename(filename: str) -> str:
    """Strip directory traversal components from a filename.

    Returns only the basename, rejecting empty results.
    Raises ValueError if the sanitized name is empty.
    """
    sanitized = os.path.basename(filename)
    sanitized = sanitized.replace('\\', '').replace('/', '')
    if not sanitized or sanitized in ('.', '..'):
        raise ValueError(f"Invalid filename after sanitization: '{filename}'")
    return sanitized


def _sanitize_blob_path(blob_path: str) -> str:
    """Sanitize a blob path that may contain subdirectories.

    Allows forward-slash-separated paths like 'framework/job_id/file.pdf'
    but rejects directory traversal ('..'), absolute paths, null bytes,
    Windows drive letters, and reserved device names.

    Raises ValueError on any detected traversal or invalid path.
    """
    if not blob_path or not blob_path.strip():
        raise ValueError("Blob path cannot be empty")

    if '\x00' in blob_path:
        raise ValueError("Blob path contains null byte")

    normalised = blob_path.replace('\\', '/')

    if normalised.startswith('/'):
        raise ValueError(f"Absolute blob paths are not allowed: '{blob_path}'")
    if len(normalised) >= 2 and normalised[1] == ':':
        raise ValueError(f"Drive-letter paths are not allowed: '{blob_path}'")

    segments = normalised.split('/')
    clean_segments = []
    for seg in segments:
        seg = seg.strip()
        if not seg:
            continue
        if seg in ('.', '..'):
            raise ValueError(f"Path traversal detected in blob path: '{blob_path}'")
        stem = seg.split('.')[0].upper()
        if stem in _WINDOWS_RESERVED:
            raise ValueError(f"Windows reserved device name in blob path: '{seg}'")
        clean_segments.append(seg)

    if not clean_segments:
        raise ValueError(f"Blob path resolved to empty after sanitization: '{blob_path}'")

    return '/'.join(clean_segments)


class FileStoragePort(abc.ABC):
    """Dependency Inversion: Abstract port for file storage operations."""

    @abc.abstractmethod
    def save_file(self, file_obj: BinaryIO, filename: str) -> str:
        pass

    @abc.abstractmethod
    def download_file(self, identifier: str, dest_dir: str) -> str:
        """Download or resolve a file to a local path.

        For local storage, returns the existing path within base_dir
        (the file is already on the local filesystem, so no copy is needed).
        For remote storage (Azure), downloads the blob to dest_dir.
        """
        pass

    @abc.abstractmethod
    def get_file_size(self, identifier: str) -> int:
        """Return the size in bytes of a stored file."""
        pass

    @abc.abstractmethod
    def read_file(self, identifier: str) -> bytes:
        """Read the entire file content into memory."""
        pass

    @abc.abstractmethod
    def file_exists(self, identifier: str) -> bool:
        """Check whether a file exists in storage."""
        pass

    @abc.abstractmethod
    def list_files(self, prefix: str = "") -> list:
        """List files in storage, optionally filtered by prefix.

        Returns a list of dicts with at minimum 'name' and 'size' keys.
        """
        pass

    @abc.abstractmethod
    def delete_file(self, identifier: str) -> bool:
        """Delete a file from storage. Returns True if deleted, False if not found."""
        pass

    @abc.abstractmethod
    def generate_download_url(self, identifier: str, expiry_minutes: int = 30) -> str:
        """Generate a direct download URL for a file.

        For Azure: returns a time-limited SAS URL for direct browser download.
        For local: returns a relative path (caller must prepend the server base URL).
        """
        pass


class LocalBlobStorage(FileStoragePort):
    """Concrete implementation handling local file I/O."""

    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        # H-3: Cache resolved base_dir once instead of per-call
        self._resolved_base = os.path.realpath(base_dir)
        os.makedirs(self.base_dir, exist_ok=True)

    def _resolve_safe_path(self, identifier: str) -> str:
        """Sanitize identifier and resolve to an absolute local path.

        Returns the absolute filesystem path. Raises ValueError if the
        resolved path escapes base_dir (symlink / traversal attack).
        """
        safe_path = _sanitize_blob_path(identifier)
        file_path = os.path.join(self.base_dir, *safe_path.split('/'))
        resolved = os.path.realpath(file_path)
        # Append os.sep to prevent prefix collision ("/store" matching "/store2")
        if resolved != self._resolved_base and not resolved.startswith(self._resolved_base + os.sep):
            raise ValueError(f"Path traversal detected: {identifier}")
        return file_path

    def save_file(self, file_obj: BinaryIO, filename: str) -> str:
        file_path = self._resolve_safe_path(filename)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file_obj, buffer)
        return _sanitize_blob_path(filename)

    def download_file(self, identifier: str, dest_dir: str) -> str:
        """Resolve a blob identifier to its absolute local path.

        For local storage the file already exists on disk, so no
        copy to dest_dir is performed.  The dest_dir parameter is accepted
        for interface compatibility with AzureBlobStorage but is unused.
        """
        return self._resolve_safe_path(identifier)

    def get_file_size(self, identifier: str) -> int:
        return os.path.getsize(self._resolve_safe_path(identifier))

    def read_file(self, identifier: str) -> bytes:
        with open(self._resolve_safe_path(identifier), "rb") as f:
            return f.read()

    def file_exists(self, identifier: str) -> bool:
        return os.path.exists(self._resolve_safe_path(identifier))

    def list_files(self, prefix: str = "") -> list:
        results = []
        if prefix:
            safe_prefix = _sanitize_blob_path(prefix)
            search_dir = os.path.join(self.base_dir, *safe_prefix.split('/'))
        else:
            search_dir = self.base_dir
        if not os.path.isdir(search_dir):
            return results
        for root, _dirs, files in os.walk(search_dir):
            for fname in files:
                full_path = os.path.join(root, fname)
                rel_path = os.path.relpath(full_path, self.base_dir).replace('\\', '/')
                results.append({"name": rel_path, "size": os.path.getsize(full_path)})
        return results

    def delete_file(self, identifier: str) -> bool:
        file_path = self._resolve_safe_path(identifier)
        if not os.path.exists(file_path):
            return False
        os.remove(file_path)
        return True

    def generate_download_url(self, identifier: str, expiry_minutes: int = 30) -> str:
        """Local storage: return the relative blob path (no SAS needed)."""
        safe_path = _sanitize_blob_path(identifier)
        if not os.path.exists(self._resolve_safe_path(identifier)):
            raise FileNotFoundError(f"File not found: {identifier}")
        return f"/api/v1/documents/{safe_path}"


class AzureBlobStorage(FileStoragePort):
    """Implementation: Streams files to Azure Blob Storage natively."""

    def __init__(
        self,
        connection_string: str,
        container_name: str,
        connection_timeout: int = 15,
        read_timeout: int = 60,
        max_retries: int = 3
    ):
        
        self.blob_service_client = BlobServiceClient.from_connection_string(
            connection_string,
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            retry_total=max_retries,
        )
        self.container_name = container_name
        # Parse account name and key from connection string for SAS generation
        parts = dict(part.split("=", 1) for part in connection_string.split(";") if "=" in part)
        self._account_name = parts.get("AccountName", "")
        self._account_key = parts.get("AccountKey", "")

        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            if not container_client.exists():
                container_client.create_container()
        except Exception as e:
            logger.error(
                f"Could not initialize Azure Container '{container_name}': {e}"
            )
            raise

    def save_file(self, file_obj: BinaryIO, filename: str) -> str:
        """Upload a file to Azure Blob Storage."""
        safe_path = _sanitize_blob_path(filename)
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=safe_path
        )
        ext = os.path.splitext(safe_path)[1].lower()
        content_type = _CONTENT_TYPE_MAP.get(ext, 'application/octet-stream')
        settings = ContentSettings(content_type=content_type)
        blob_client.upload_blob(file_obj, overwrite=True, content_settings=settings)
        return safe_path

    def download_file(self, identifier: str, dest_dir: str) -> str:
        """Download a file from Azure Blob Storage."""
        safe_path = _sanitize_blob_path(identifier)
        os.makedirs(dest_dir, exist_ok=True)
        local_name = safe_path.replace('/', '_')
        local_path = os.path.join(dest_dir, local_name)
        resolved = os.path.realpath(local_path)
        resolved_dest = os.path.realpath(dest_dir)
        if resolved != resolved_dest and not resolved.startswith(resolved_dest + os.sep):
            raise ValueError(f"Path traversal detected: {identifier}")
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=safe_path
        )
        with open(local_path, "wb") as dl_file:
            dl_file.write(blob_client.download_blob().readall())
        return local_path

    def get_file_size(self, identifier: str) -> int:
        """Return the size in bytes of a stored file."""
        safe_path = _sanitize_blob_path(identifier)
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=safe_path
        )
        return blob_client.get_blob_properties().size

    def read_file(self, identifier: str) -> bytes:
        """Read the entire file content into memory."""
        safe_path = _sanitize_blob_path(identifier)
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=safe_path
        )
        return blob_client.download_blob().readall()

    def file_exists(self, identifier: str) -> bool:
        """Check whether a file exists in storage."""
        safe_path = _sanitize_blob_path(identifier)
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=safe_path
        )
        return blob_client.exists()

    def list_files(self, prefix: str = "") -> list:
        """List blobs in the container, optionally filtered by prefix."""
        container_client = self.blob_service_client.get_container_client(self.container_name)
        if prefix:
            safe_prefix = _sanitize_blob_path(prefix)
            blobs = container_client.list_blobs(name_starts_with=safe_prefix)
        else:
            blobs = container_client.list_blobs()
        return [{"name": blob.name, "size": blob.size} for blob in blobs]

    def delete_file(self, identifier: str) -> bool:
        """Delete a blob from storage. Returns True if deleted, False if not found."""
        safe_path = _sanitize_blob_path(identifier)
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=safe_path
        )
        if not blob_client.exists():
            return False
        blob_client.delete_blob()
        return True

    def generate_download_url(self, identifier: str, expiry_minutes: int = 30) -> str:
        """Generate a time-limited SAS URL for direct browser download from Azure."""
        safe_path = _sanitize_blob_path(identifier)
        sas_token = generate_blob_sas(
            account_name=self._account_name,
            container_name=self.container_name,
            blob_name=safe_path,
            account_key=self._account_key,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.now(timezone.utc) + timedelta(minutes=expiry_minutes),
            content_disposition=f'attachment; filename="{os.path.basename(safe_path)}"',
        )
        return f"https://{self._account_name}.blob.core.windows.net/{self.container_name}/{safe_path}?{sas_token}"
