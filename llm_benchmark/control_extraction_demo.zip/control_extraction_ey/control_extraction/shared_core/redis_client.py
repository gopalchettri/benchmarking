"""
Redis Client Utilities
=======================
Async Redis client for lightweight job-state key-value tracking.
Task queuing is handled by Redis Streams (shared_core/stream_client.py).
"""
import re

import redis.asyncio as aioredis

from shared_core.constants import (
    STATE_QUEUED, STATE_DOC_PROCESSING, STATE_AI_EXTRACTION,
    STATE_MERGE, STATE_COMPLETED, STATE_AI_EXTRACTION_FAILED,
    STATE_DOC_PROCESSING_FAILED, STATE_STORAGE_FAILED,
    STATE_STORAGE_COMPLETED,
)

_JOB_STATE_TTL_SECONDS = 86400  # 24 hours

# Allowed characters in job_id: UUID hex, hyphens, underscores
_JOB_ID_PATTERN = re.compile(r'^[a-zA-Z0-9_-]{1,128}$')

# Valid states that can be stored via update_job_state
_VALID_STATES = frozenset({
    STATE_QUEUED, STATE_DOC_PROCESSING, STATE_AI_EXTRACTION,
    STATE_MERGE, STATE_COMPLETED, STATE_AI_EXTRACTION_FAILED,
    STATE_DOC_PROCESSING_FAILED, STATE_STORAGE_FAILED,
    STATE_STORAGE_COMPLETED,
})

# C-2: Connection pool with health checks — prevents silent connection death
# after firewall/NAT timeouts on idle connections. Mirrors stream_client.py pattern.
_pool: aioredis.ConnectionPool | None = None


def _get_redis_url() -> str:
    from config import get_settings
    return get_settings().REDIS_URL


def _get_pool() -> aioredis.ConnectionPool:
    """Lazily create a module-level connection pool for the Redis client."""
    global _pool
    if _pool is None:
        _pool = aioredis.ConnectionPool.from_url(
            _get_redis_url(),
            decode_responses=True,
            max_connections=10,
            health_check_interval=30,
        )
    return _pool


def get_async_redis_client() -> aioredis.Redis:
    """Returns an async, string-decoded Redis client backed by a connection pool."""
    return aioredis.Redis(connection_pool=_get_pool())


def _validate_job_id(job_id: str) -> None:
    """Validate job_id format to prevent Redis key injection."""
    if not job_id or not _JOB_ID_PATTERN.match(job_id):
        raise ValueError(f"Invalid job_id format: {job_id!r}")


async def update_job_state(job_id: str, state: str):
    """Async utility for standardised job state updates."""
    _validate_job_id(job_id)
    if state not in _VALID_STATES:
        raise ValueError(f"Invalid state: {state!r}. Must be one of: {_VALID_STATES}")
    client = get_async_redis_client()
    await client.set(f"job_state:{job_id}", state, ex=_JOB_STATE_TTL_SECONDS)


async def fetch_job_state(job_id: str) -> str:
    """Async utility for standardised job state retrieval."""
    _validate_job_id(job_id)
    client = get_async_redis_client()
    return await client.get(f"job_state:{job_id}")


async def close_pool() -> None:
    """Gracefully close the module-level Redis connection pool."""
    global _pool
    if _pool is not None:
        await _pool.aclose()
        _pool = None
