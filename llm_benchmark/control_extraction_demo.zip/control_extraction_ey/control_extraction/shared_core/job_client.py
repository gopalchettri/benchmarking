"""
Job Status Client
==================
Lightweight async client that updates extraction job status in the
persistent jobs table via the storage service HTTP API.

Usage::

    from shared_core.job_client import update_job_record

    await update_job_record(job_id, status="processing", started_at=now_iso())

All errors are swallowed with a warning log — job tracking must NEVER
break the extraction pipeline.
"""

from datetime import datetime, timezone
from typing import Any, Dict, Optional

from utils.logging_config import logger

_TIMEOUT = 10.0  # seconds


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def create_job_record(
    job_id: str,
    framework: str,
    user_id: Optional[str] = None,
    file_name: Optional[str] = None,
    file_hash: Optional[str] = None,
    blob_path: Optional[str] = None,
    framework_version: Optional[str] = None,
    framework_profile_id: Optional[str] = None,
) -> None:
    """Create a new job record in the persistent jobs table.

    Fire-and-forget — errors are logged but never raised.
    """
    try:
        import httpx
        from config import get_settings
        settings = get_settings()
        url = f"{settings.STORAGE_SERVICE_URL}{settings.API_V1_STR}/jobs"

        payload: Dict[str, Any] = {
            "id": job_id,
            "framework": framework,
        }
        if user_id:
            payload["user_id"] = user_id
        if file_name:
            payload["file_name"] = file_name
        if file_hash:
            payload["file_hash"] = file_hash
        if blob_path:
            payload["blob_path"] = blob_path
        if framework_version:
            payload["framework_version"] = framework_version
        if framework_profile_id:
            payload["framework_profile_id"] = framework_profile_id

        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.post(url, json=payload)
            if resp.status_code == 201:
                logger.debug(f"[JobClient] Created job record: {job_id}")
            else:
                logger.warning(f"[JobClient] Create job returned {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        logger.warning(f"[JobClient] Failed to create job record (non-fatal): {e}")


async def fetch_job_record(job_id: str) -> Optional[dict]:
    """Fetch an existing job record from the storage service.

    Returns the job record dict, or None if not found (404).
    Raises on non-404 HTTP errors.
    """
    try:
        import httpx
        from config import get_settings
        settings = get_settings()
        url = f"{settings.STORAGE_SERVICE_URL}{settings.API_V1_STR}/jobs/{job_id}"

        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.get(url)
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        logger.warning(f"[JobClient] Failed to fetch job record {job_id}: {e}")
        raise


async def update_job_record(
    job_id: str,
    **updates: Any,
) -> None:
    """Update a job record in the persistent jobs table.

    Accepts any combination of: status, controls_extracted, total_nodes,
    error_message, started_at, completed_at.

    Fire-and-forget — errors are logged but never raised.
    """
    if not updates:
        return
    try:
        import httpx
        from config import get_settings
        settings = get_settings()
        url = f"{settings.STORAGE_SERVICE_URL}{settings.API_V1_STR}/jobs/{job_id}"

        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.patch(url, json=updates)
            if resp.status_code == 200:
                logger.debug(f"[JobClient] Updated job {job_id}: {list(updates.keys())}")
            elif resp.status_code == 404:
                logger.debug(f"[JobClient] Job {job_id} not found in DB (may not be tracked)")
            else:
                logger.warning(f"[JobClient] Update job returned {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        logger.warning(f"[JobClient] Failed to update job record (non-fatal): {e}")
