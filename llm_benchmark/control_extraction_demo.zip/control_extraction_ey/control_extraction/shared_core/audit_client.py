"""
Audit Client
=============
Lightweight async client that publishes audit events to Redis Stream
``audit:stream`` in a non-blocking, fire-and-forget manner.

Usage::

    from shared_core.audit_client import log_audit

    await log_audit(
        action="job.created",
        entity_type="job",
        entity_id=job_id,
    )

All errors are swallowed with a warning log — audit logging must NEVER
break the extraction pipeline.
"""

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from utils.logging_config import logger

AUDIT_STREAM = "audit:stream"


async def log_audit(
    action: str,
    entity_type: str,
    entity_id: str,
    user_id: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Publish an audit event to the audit:stream Redis Stream.

    Fire-and-forget — errors are logged but never raised.

    Args:
        action: Event type (e.g., "job.created", "job.doc_processing.started")
        entity_type: Entity category ("job", "profile")
        entity_id: Entity identifier (job_id, profile_id)
        user_id: Optional user who triggered the action
        details: Optional JSON-serializable dict with extra context
    """
    try:
        from shared_core.stream_client import publish_task

        await publish_task(
            stream=AUDIT_STREAM,
            task_name="audit_event",
            payload={
                "id": str(uuid.uuid4()),
                "action": action,
                "entity_type": entity_type,
                "entity_id": entity_id,
                "user_id": user_id or "",
                "details": details or {},
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
        )
        logger.debug(f"[Audit] Published: action={action} entity={entity_type}:{entity_id}")
    except Exception as e:
        # Fire-and-forget: never let audit failures break the pipeline
        logger.warning(f"[Audit] Failed to publish event (non-fatal): {e}")
