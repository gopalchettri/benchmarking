# ============================================================
# Control Extraction - Local Run Script
# Run from project root:
#   .\run_local.ps1
# ============================================================

$ROOT = $PSScriptRoot
$VENV = "$ROOT\venv\Scripts"
$PYTHON = "$VENV\python.exe"

$env:PYTHONPATH = "$ROOT;$ROOT\shared_core"

function Write-Header($msg) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

# ============================================================
# STEP 0 - Prerequisites: Redis via Docker, MySQL is local
# ============================================================
Write-Header "STEP 0: Starting Redis (Docker)"

$redisRunning = docker ps --filter "name=redis-local" --filter "status=running" -q
if (-not $redisRunning) {
    Write-Host "[Redis] Starting redis-local on localhost:6379..." -ForegroundColor Yellow
    docker run -d --name redis-local -p 6379:6379 redis:7-alpine
    Start-Sleep -Seconds 2
}
else {
    Write-Host "[Redis] Already running" -ForegroundColor Green
}

# ============================================================
# STEP 1 - Health Pre-flight (Redis + MySQL)
# ============================================================
Write-Header "STEP 1: Health Pre-flight"
& $PYTHON validation\check_deps.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Dependencies not ready. Aborting." -ForegroundColor Red
    exit 1
}

# ============================================================
# STEP 2 - Start FastAPI Services (each in a new window)
# ============================================================
Write-Header "STEP 2: Starting FastAPI Services"

# Storage (port 8003) - first, creates DB tables on startup
Write-Host "[Storage]        http://localhost:8003  /health" -ForegroundColor Blue
Start-Process powershell -ArgumentList @(
    "-NoExit", "-Command",
    "`$env:PYTHONPATH='$ROOT;$ROOT\shared_core;$ROOT\services\storage'; " +
    "cd '$ROOT\services\storage'; " +
    "& '$PYTHON' -m uvicorn main:app --host 127.0.0.1 --port 8003 --reload"
)
Start-Sleep -Seconds 3

# Doc Processing (port 8001)
Write-Host "[Doc Processing] http://localhost:8001  /health" -ForegroundColor Green
Start-Process powershell -ArgumentList @(
    "-NoExit", "-Command",
    "`$env:PYTHONPATH='$ROOT;$ROOT\shared_core;$ROOT\services\doc_processing'; " +
    "cd '$ROOT\services\doc_processing'; " +
    "& '$PYTHON' -m uvicorn main:app --host 127.0.0.1 --port 8001 --reload"
)
Start-Sleep -Seconds 1

# AI Extraction (port 8002)
Write-Host "[AI Extraction]  http://localhost:8002  /health" -ForegroundColor Yellow
Start-Process powershell -ArgumentList @(
    "-NoExit", "-Command",
    "`$env:PYTHONPATH='$ROOT;$ROOT\shared_core;$ROOT\services\ai_extraction'; " +
    "cd '$ROOT\services\ai_extraction'; " +
    "& '$PYTHON' -m uvicorn main:app --host 127.0.0.1 --port 8002 --reload"
)
Start-Sleep -Seconds 1

# API Gateway (port 8000) - start last
Write-Host "[API Gateway]    http://localhost:8000  /health" -ForegroundColor Cyan
Start-Process powershell -ArgumentList @(
    "-NoExit", "-Command",
    "`$env:PYTHONPATH='$ROOT;$ROOT\shared_core;$ROOT\services\api_gateway'; " +
    "cd '$ROOT\services\api_gateway'; " +
    "& '$PYTHON' -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload"
)
Start-Sleep -Seconds 2

# ============================================================
# STEP 3 - Start Redis Stream Workers (each in a new window)
# ============================================================
Write-Header "STEP 3: Starting Redis Stream Workers"

Write-Host "[Worker] doc_processing  --> doc_processing:stream" -ForegroundColor Magenta
Start-Process powershell -ArgumentList @(
    "-NoExit", "-Command",
    "`$env:PYTHONPATH='$ROOT;$ROOT\shared_core;$ROOT\services\doc_processing'; " +
    "cd '$ROOT\services\doc_processing'; " +
    "& '$PYTHON' worker.py"
)

# Write-Host "[Worker] ai_extraction   --> ai_extraction:stream" -ForegroundColor Magenta
Start-Process powershell -ArgumentList @(
    "-NoExit", "-Command",
    "`$env:PYTHONPATH='$ROOT;$ROOT\shared_core;$ROOT\services\ai_extraction'; " +
    "cd '$ROOT\services\ai_extraction'; " +
    "& '$PYTHON' worker.py"
)

Write-Host "[Worker] storage         --> storage:stream & audit:stream" -ForegroundColor Magenta
Start-Process powershell -ArgumentList @(
    "-NoExit", "-Command",
    "`$env:PYTHONPATH='$ROOT;$ROOT\shared_core;$ROOT\services\storage'; " +
    "cd '$ROOT\services\storage'; " +
    "& '$PYTHON' worker.py"
)

# ============================================================
# STEP 4 - Verify /health endpoints
# ============================================================
Write-Header "STEP 4: Verifying /health endpoints (waiting 12s...)"
Start-Sleep -Seconds 12

$services = @(
    @{ Name = "API Gateway"; Port = 8000 },
    @{ Name = "Doc Processing"; Port = 8001 },
    @{ Name = "AI Extraction"; Port = 8002 },
    @{ Name = "Storage"; Port = 8003 }
)

foreach ($svc in $services) {
    try {
        $resp = Invoke-RestMethod "http://localhost:$($svc.Port)/health" -TimeoutSec 10
        $status = $resp.status
        $color = if ($status -eq "ok") { "Green" } else { "Yellow" }
        Write-Host "  [$($svc.Name)] status=$status" -ForegroundColor $color
    }
    catch {
        Write-Host "  [$($svc.Name)] UNREACHABLE - check terminal window" -ForegroundColor Red
    }
}

# ============================================================
# Done
# ============================================================
Write-Header "All services launched!"
Write-Host "  Swagger UI:   http://localhost:8000/docs" -ForegroundColor White
Write-Host "  API Base:     http://localhost:8000/api/v1/" -ForegroundColor White
Write-Host ""
Write-Host "  To stop: close each terminal window" -ForegroundColor Gray
Write-Host "  To stop Redis: docker stop redis-local" -ForegroundColor Gray
Write-Host ""
