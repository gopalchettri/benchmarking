"""Tests for core/page_offset.py — page offset detection and application."""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'services', 'ai_extraction'))

from core.page_offset import detect_page_offset, apply_offset_to_page_range, apply_offset_to_toc_entries


# ── Helper: build page_texts with realistic footer patterns ──────────────────

def _build_pages_standalone(offset: int, num_pages: int = 20) -> dict[int, str]:
    """Build page_texts where footer is a standalone number (plain text)."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 1:
            # Front-matter pages with roman numerals (no digit detection)
            pages[physical] = f"Front matter content\n\niv"
        else:
            pages[physical] = f"Body content for page {printed}\n\n{printed}"
    return pages


def _build_pages_bold_standalone(offset: int, num_pages: int = 20) -> dict[int, str]:
    """Build page_texts where footer is bold markdown (ISO 27001 odd pages)."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 1:
            pages[physical] = f"Front matter\n\n**iv**"
        else:
            pages[physical] = f"Body content\n\n**{printed}**"
    return pages


def _build_pages_trailing(offset: int, num_pages: int = 20) -> dict[int, str]:
    """Build page_texts with UAE IAS-style footer (number at end of line)."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 0:
            pages[physical] = "Cover page content"
        else:
            pages[physical] = f"Body content\n\n**Document Classification: Open** **{printed}**"
    return pages


def _build_pages_iso_mixed(offset: int, num_pages: int = 26) -> dict[int, str]:
    """Build page_texts mimicking ISO 27001's alternating footer format."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 1:
            # Front matter with roman numerals
            pages[physical] = f"Front matter\n\n© ISO/IEC 2022 – All rights reserved **\ufeff** iii"
        elif printed % 2 == 1:
            # Odd printed pages: standalone bold number on its own line
            pages[physical] = (
                f"**ISO/IEC 27001:2022(E)**\n\nBody content\n\n"
                f"© ISO/IEC 2022 – All rights reserved **\ufeff**\n\ufeff\n\n\n**{printed}**"
            )
        else:
            # Even printed pages: bold number embedded in copyright line
            pages[physical] = (
                f"**ISO/IEC 27001:2022(E)**\n\nBody content\n\n"
                f"**{printed}** **\ufeff** © ISO/IEC 2022 – All rights reserved"
            )
    return pages


# ═══════════════════════════════════════════════════════════════════════════════
# detect_page_offset
# ═══════════════════════════════════════════════════════════════════════════════

class TestDetectPageOffset:
    """Test offset detection across different footer formats."""

    def test_empty_dict(self):
        assert detect_page_offset({}) == 0

    def test_too_few_samples(self):
        pages = {1: "Content\n\n1", 2: "Content\n\n2"}
        assert detect_page_offset(pages, min_samples=5) == 0

    def test_standalone_plain_numbers(self):
        pages = _build_pages_standalone(offset=4, num_pages=20)
        assert detect_page_offset(pages) == 4

    def test_standalone_bold_numbers(self):
        """ISO 27001 odd pages: **3** on its own line."""
        pages = _build_pages_bold_standalone(offset=6, num_pages=20)
        assert detect_page_offset(pages) == 6

    def test_trailing_numbers_uae_ias(self):
        """UAE IAS: Document Classification: Open 1."""
        pages = _build_pages_trailing(offset=4, num_pages=20)
        assert detect_page_offset(pages) == 4

    def test_iso_mixed_format(self):
        """ISO 27001 with alternating odd (standalone bold) and even (embedded) footers."""
        pages = _build_pages_iso_mixed(offset=6, num_pages=26)
        result = detect_page_offset(pages)
        assert result == 6

    def test_zero_offset(self):
        """No front matter — printed == physical."""
        pages = _build_pages_standalone(offset=0, num_pages=20)
        assert detect_page_offset(pages) == 0

    def test_no_page_numbers_returns_zero(self):
        """Pages with no detectable numbers (e.g., DESC ISR with only headers)."""
        pages = {
            i: f"Some body text\n\nMore content here."
            for i in range(1, 25)
        }
        assert detect_page_offset(pages) == 0

    def test_low_agreement_returns_zero(self):
        """Scattered offsets with no consensus should return 0."""
        pages = {}
        # Each page has a different standalone number producing different offsets
        for i in range(1, 25):
            pages[i] = f"Content\n\n{i * 3}"  # offsets: 1-3=-2, 2-6=-4, etc. all different
        assert detect_page_offset(pages) == 0

    def test_negative_offset_rejected(self):
        """Physical < printed should never produce a positive offset."""
        pages = {}
        for i in range(1, 20):
            pages[i] = f"Content\n\n{i + 10}"  # printed > physical → negative offset
        assert detect_page_offset(pages) == 0

    def test_large_offset_rejected(self):
        """Offset > 50 should be rejected by guard."""
        pages = {}
        for i in range(60, 80):
            pages[i] = f"Content\n\n{i - 55}"  # offset=55 > 50 guard
        assert detect_page_offset(pages) == 0

    def test_footer_checked_before_header(self):
        """Footer page number should win over a chapter number in the header."""
        pages = {}
        for i in range(5, 25):
            printed = i - 4
            # Header has chapter number "3", footer has real page number
            pages[i] = f"3\nChapter Three Content\n\nBody text\n\nMore text\n\n{printed}"
        assert detect_page_offset(pages) == 4

    def test_bom_characters_stripped(self):
        """Zero-width chars (\ufeff) should not interfere with detection."""
        pages = {}
        for i in range(5, 25):
            printed = i - 4
            pages[i] = f"Body content\n\n\ufeff**{printed}**\ufeff"
        assert detect_page_offset(pages) == 4

    def test_version_numbers_not_false_positive(self):
        """VERSION 3.1 trailing '1' produces inconsistent offsets → no consensus."""
        pages = {}
        for i in range(1, 25):
            pages[i] = (
                f"{i} INFORMATION SECURITY REGULATION – VERSION 3.1\n"
                f"Body content for page {i}"
            )
        assert detect_page_offset(pages) == 0


# ═══════════════════════════════════════════════════════════════════════════════
# apply_offset_to_page_range
# ═══════════════════════════════════════════════════════════════════════════════

class TestApplyOffsetToPageRange:
    """Test page range adjustment."""

    def test_basic_range(self):
        assert apply_offset_to_page_range("11-18", 6) == "17-24"

    def test_single_page(self):
        assert apply_offset_to_page_range("11", 4) == "15"

    def test_zero_offset_returns_original(self):
        assert apply_offset_to_page_range("11-18", 0) == "11-18"

    def test_empty_string_returns_original(self):
        assert apply_offset_to_page_range("", 4) == ""

    def test_none_returns_none(self):
        assert apply_offset_to_page_range(None, 4) is None

    def test_batch_returns_original(self):
        """Non-numeric input should not crash."""
        assert apply_offset_to_page_range("batch", 4) == "batch"

    def test_non_numeric_returns_original(self):
        assert apply_offset_to_page_range("abc-def", 4) == "abc-def"

    def test_en_dash_normalized(self):
        """En-dash (\u2013) should be treated as a regular hyphen."""
        assert apply_offset_to_page_range("11\u201318", 6) == "17-24"

    def test_em_dash_normalized(self):
        """Em-dash (\u2014) should be treated as a regular hyphen."""
        assert apply_offset_to_page_range("11\u201418", 6) == "17-24"

    def test_spaces_around_dash(self):
        assert apply_offset_to_page_range("11 - 18", 6) == "17-24"

    def test_negative_result_returns_original(self):
        """Offset that produces page < 1 should return original."""
        assert apply_offset_to_page_range("1-5", 0) == "1-5"
        result = apply_offset_to_page_range("1-5", -2)
        # offset is falsy when negative? No, -2 is truthy. But guard 0 <= offset <= 50 is in detect only.
        # apply_offset doesn't guard against negative offset — it guards negative result.
        # With offset=-2: 1 + (-2) = -1 < 1 → returns original
        assert result == "1-5"


# ═══════════════════════════════════════════════════════════════════════════════
# apply_offset_to_toc_entries
# ═══════════════════════════════════════════════════════════════════════════════

class _FakeTOCEntry:
    """Minimal stand-in for TOCEntry (avoids importing the full model)."""
    def __init__(self, control_id: str, page: int | None):
        self.control_id = control_id
        self.page = page


class TestApplyOffsetToTocEntries:
    """Test in-place TOC entry adjustment."""

    def test_basic_adjustment(self):
        entries = [_FakeTOCEntry("A.5.1", 11), _FakeTOCEntry("A.5.2", 12)]
        count = apply_offset_to_toc_entries(entries, 6)
        assert count == 2
        assert entries[0].page == 17
        assert entries[1].page == 18

    def test_none_pages_skipped(self):
        entries = [_FakeTOCEntry("A.5.1", None), _FakeTOCEntry("A.5.2", 12)]
        count = apply_offset_to_toc_entries(entries, 6)
        assert count == 1
        assert entries[0].page is None
        assert entries[1].page == 18

    def test_zero_offset_no_change(self):
        entries = [_FakeTOCEntry("A.5.1", 11)]
        count = apply_offset_to_toc_entries(entries, 0)
        assert count == 0
        assert entries[0].page == 11

    def test_empty_list(self):
        assert apply_offset_to_toc_entries([], 6) == 0

    def test_none_list(self):
        assert apply_offset_to_toc_entries(None, 6) == 0
