"""Tests for config.py settings."""

import pytest
from config import Settings


class TestConfigDefaults:
    """Verify critical default values."""

    def test_db_backend_default(self):
        s = Settings()
        assert s.DB_BACKEND == "postgresql"

    def test_max_file_upload_200mb(self):
        s = Settings()
        assert s.MAX_FILE_UPLOAD_BYTES == 209715200  # 200MB

    def test_dlq_max_delivery_attempts(self):
        s = Settings()
        assert s.DLQ_MAX_DELIVERY_ATTEMPTS == 3

    def test_jwt_secret_none_by_default(self):
        s = Settings()
        assert s.JWT_SECRET is None

    def test_jwt_algorithm_default(self):
        s = Settings()
        assert s.JWT_ALGORITHM == "HS256"

    def test_database_url_assembled(self):
        s = Settings()
        assert s.DATABASE_URL.startswith("postgresql://")


class TestTokenAutoScaling:
    """Verify token ceilings auto-derive from LLM_MODEL_CONTEXT_TOKENS."""

    def test_auto_derive_128k_defaults(self):
        s = Settings(LLM_MODEL_CONTEXT_TOKENS=128000)
        assert s.SUBCONTROL_MAX_TOKENS == 16384    # 128000 × 0.128
        assert s.LLM_MAX_OUTPUT_TOKENS == 16000    # 128000 × 0.125
        assert s.TOC_MAX_TOKENS == 4096            # 128000 × 0.032
        assert s.DISCOVERY_MAX_TOKENS == 2048      # 128000 × 0.016

    def test_auto_derive_60k(self):
        s = Settings(LLM_MODEL_CONTEXT_TOKENS=60000)
        assert s.SUBCONTROL_MAX_TOKENS == 7680     # 60000 × 0.128
        assert s.LLM_MAX_OUTPUT_TOKENS == 7500     # 60000 × 0.125
        assert s.TOC_MAX_TOKENS == 1920            # 60000 × 0.032
        assert s.DISCOVERY_MAX_TOKENS == 960       # 60000 × 0.016

    def test_explicit_override(self):
        s = Settings(SUBCONTROL_MAX_TOKENS=8000)
        assert s.SUBCONTROL_MAX_TOKENS == 8000     # not overridden

    def test_content_budget_too_small(self):
        with pytest.raises(ValueError, match="Content budget too small"):
            Settings(LLM_MODEL_CONTEXT_TOKENS=10000)

    def test_content_budget_positive(self):
        s = Settings(LLM_MODEL_CONTEXT_TOKENS=128000)
        budget = (
            int(s.LLM_MODEL_CONTEXT_TOKENS * s.CHUNK_CONTEXT_RATIO)
            - s.CHUNK_PROMPT_OVERHEAD_TOKENS
            - s.SUBCONTROL_MAX_TOKENS
        )
        assert budget > 50000
