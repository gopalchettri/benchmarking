"""
Tests for post_extraction_validator — renest_interleaved_children and
detect_letter_sequence_gaps.

All test data is generic (no framework-specific IDs or structure).
"""

import os
import sys

import pytest

# Ensure ai_extraction is first on sys.path so its models.py wins over storage's.
_AI_DIR = os.path.join(
    os.path.dirname(__file__), "..", "services", "ai_extraction"
)
sys.path.insert(0, os.path.abspath(_AI_DIR))

from models import ControlExtraction, SubControl, count_all_sub_controls  # noqa: E402
from post_extraction_validator import (  # noqa: E402
    merge_lowercase_continuations,
    renest_interleaved_children,
    detect_letter_sequence_gaps,
)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _sc(number: str, text: str = "", parent_id: str = "X",
        children: list | None = None) -> SubControl:
    """Build a SubControl with auto-computed id."""
    sc_id = f"{parent_id}.{number}"
    return SubControl(
        number=number, id=sc_id, text=text or f"text-{number}",
        children=children or [],
    )


def _extraction(control_id: str, sub_controls: list[SubControl]) -> ControlExtraction:
    return ControlExtraction(
        control_id=control_id, title="Test", sub_controls=sub_controls,
    )


def _ids(items: list[SubControl]) -> list[str]:
    """Flat list of top-level IDs."""
    return [sc.id for sc in items]


def _child_ids(item: SubControl) -> list[str]:
    """IDs of direct children."""
    return [c.id for c in item.children]


# ═════════════════════════════════════════════════════════════════════════════
# renest_interleaved_children
# ═════════════════════════════════════════════════════════════════════════════

class TestRenestBasic:
    """Core re-nesting scenarios."""

    def test_flanked_letters_between_numbers(self):
        """[1, 2, 3, a, b, 4] → a,b become children of 3."""
        scs = [_sc(n, parent_id="C") for n in ["1", "2", "3", "a", "b", "4"]]
        ext = _extraction("C", scs)
        before = count_all_sub_controls(ext.sub_controls)

        moved = renest_interleaved_children([ext])

        assert moved == 2
        assert _ids(ext.sub_controls) == ["C.1", "C.2", "C.3", "C.4"]
        assert _child_ids(ext.sub_controls[2]) == ["C.3.a", "C.3.b"]
        assert count_all_sub_controls(ext.sub_controls) == before

    def test_flanked_numbers_between_letters(self):
        """[a, b, c, 1, 2, d] → 1,2 become children of c."""
        scs = [_sc(n, parent_id="C") for n in ["a", "b", "c", "1", "2", "d"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 2
        assert _ids(ext.sub_controls) == ["C.a", "C.b", "C.c", "C.d"]
        assert _child_ids(ext.sub_controls[2]) == ["C.c.1", "C.c.2"]

    def test_alternating_one_to_one(self):
        """[1, a, 2, b, 3, c] → each letter becomes child of its preceding digit."""
        scs = [_sc(n, parent_id="C") for n in ["1", "a", "2", "b", "3", "c"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 3
        assert _ids(ext.sub_controls) == ["C.1", "C.2", "C.3"]
        assert _child_ids(ext.sub_controls[0]) == ["C.1.a"]
        assert _child_ids(ext.sub_controls[1]) == ["C.2.b"]
        assert _child_ids(ext.sub_controls[2]) == ["C.3.c"]

    def test_multiple_interleaved_runs(self):
        """[1, 2, a, b, 3, c, d, 4] → a,b under 2; c,d under 3."""
        scs = [_sc(n, parent_id="C") for n in
               ["1", "2", "a", "b", "3", "c", "d", "4"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 4
        assert _ids(ext.sub_controls) == ["C.1", "C.2", "C.3", "C.4"]
        assert _child_ids(ext.sub_controls[1]) == ["C.2.a", "C.2.b"]
        assert _child_ids(ext.sub_controls[2]) == ["C.3.c", "C.3.d"]


class TestRenestNoOp:
    """Cases where no re-nesting should occur."""

    def test_homogeneous_numbers(self):
        """[1, 2, 3, 4] — all same type, no action."""
        scs = [_sc(n, parent_id="C") for n in ["1", "2", "3", "4"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 0
        assert len(ext.sub_controls) == 4

    def test_homogeneous_letters(self):
        """[a, b, c, d] — all same type, no action."""
        scs = [_sc(n, parent_id="C") for n in ["a", "b", "c", "d"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 0
        assert len(ext.sub_controls) == 4

    def test_stray_at_start_not_moved(self):
        """[a, 1, 2, 3] — 'a' at start has no preceding anchor, left alone."""
        scs = [_sc(n, parent_id="C") for n in ["a", "1", "2", "3"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 0
        assert len(ext.sub_controls) == 4

    def test_discontinuous_sequence_no_action(self):
        """[1, 2, 3, a, b, 7] → 3+1≠7, not continuous, no action."""
        scs = [_sc(n, parent_id="C") for n in ["1", "2", "3", "a", "b", "7"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 0
        assert len(ext.sub_controls) == 6

    def test_other_type_items_never_moved(self):
        """Items with 'other' type numbers (e.g., '1.1') are never moved."""
        scs = [_sc(n, parent_id="C") for n in ["a", "b", "1.1", "c"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 0
        assert len(ext.sub_controls) == 4

    def test_single_item_list(self):
        """Single-item list — nothing to do."""
        ext = _extraction("C", [_sc("1", parent_id="C")])

        moved = renest_interleaved_children([ext])

        assert moved == 0

    def test_empty_sub_controls(self):
        """Empty sub_controls list — nothing to do."""
        ext = _extraction("C", [])

        moved = renest_interleaved_children([ext])

        assert moved == 0


class TestRenestTrailing:
    """Trailing run at end of list."""

    def test_trailing_letter_after_established_sequence(self):
        """[1, 2, 3, a] → trailing, preceded by ≥2 items → a under 3."""
        scs = [_sc(n, parent_id="C") for n in ["1", "2", "3", "a"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 1
        assert _ids(ext.sub_controls) == ["C.1", "C.2", "C.3"]
        assert _child_ids(ext.sub_controls[2]) == ["C.3.a"]

    def test_trailing_not_moved_when_preceding_run_too_short(self):
        """[1, a] → preceding run has only 1 item, not moved."""
        scs = [_sc(n, parent_id="C") for n in ["1", "a"]]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 0
        assert len(ext.sub_controls) == 2


class TestRenestEdgeCases:
    """Edge cases and production safety."""

    def test_anchor_with_existing_children_appends(self):
        """When the anchor already has children, new items are appended."""
        existing_child = _sc("x", parent_id="C.3", text="existing child")
        anchor = SubControl(
            number="3", id="C.3", text="anchor",
            children=[existing_child],
        )
        scs = [
            _sc("1", parent_id="C"), _sc("2", parent_id="C"),
            anchor,
            _sc("a", parent_id="C"), _sc("4", parent_id="C"),
        ]
        ext = _extraction("C", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 1
        assert len(ext.sub_controls[2].children) == 2
        assert ext.sub_controls[2].children[0].id == "C.3.x"
        assert ext.sub_controls[2].children[1].id == "C.3.a"

    def test_ids_recomputed_after_renest(self):
        """Verify IDs are correctly recomputed for moved items and their children."""
        grandchild = SubControl(
            number="1", id="WRONG.1", text="grandchild", children=[],
        )
        letter_item = SubControl(
            number="a", id="C.a", text="has grandchild",
            children=[grandchild],
        )
        scs = [
            _sc("1", parent_id="C"), _sc("2", parent_id="C"),
            _sc("3", parent_id="C"),
            letter_item,
            _sc("4", parent_id="C"),
        ]
        ext = _extraction("C", scs)

        renest_interleaved_children([ext])

        moved_item = ext.sub_controls[2].children[0]
        assert moved_item.id == "C.3.a"
        assert moved_item.children[0].id == "C.3.a.1"

    def test_data_loss_assertion(self):
        """Total sub-control count is preserved after re-nesting."""
        scs = [_sc(n, parent_id="C") for n in
               ["1", "2", "a", "b", "3", "c", "d", "e", "4"]]
        ext = _extraction("C", scs)
        before = count_all_sub_controls(ext.sub_controls)

        renest_interleaved_children([ext])

        after = count_all_sub_controls(ext.sub_controls)
        assert before == after

    def test_recursive_renesting_in_children(self):
        """Re-nesting also applies inside nested children."""
        # Build a child list with its own interleaving: [1, a, 2]
        nested = [
            SubControl(number="1", id="C.1.1", text="n1", children=[]),
            SubControl(number="a", id="C.1.a", text="na", children=[]),
            SubControl(number="2", id="C.1.2", text="n2", children=[]),
        ]
        parent = SubControl(
            number="1", id="C.1", text="parent", children=nested,
        )
        ext = _extraction("C", [parent])

        moved = renest_interleaved_children([ext])

        assert moved == 1
        assert len(ext.sub_controls[0].children) == 2  # [1, 2]
        assert _child_ids(ext.sub_controls[0].children[0]) == ["C.1.1.a"]

    def test_multiple_extractions_only_affected_modified(self):
        """When processing multiple extractions, only affected ones change."""
        ext1 = _extraction("A", [_sc(n, parent_id="A") for n in ["1", "2"]])
        ext2 = _extraction("B", [_sc(n, parent_id="B") for n in
                                  ["1", "2", "3", "a", "4"]])

        moved = renest_interleaved_children([ext1, ext2])

        assert moved == 1
        assert len(ext1.sub_controls) == 2  # unchanged
        assert len(ext2.sub_controls) == 4  # "a" moved under "3"


class TestRenestRealWorldScenario:
    """Reproduce the actual 3.3.14 bug."""

    def test_sama_3_3_14_pattern(self):
        """Replicate the exact 3.3.14 scenario from the bug report."""
        scs = [
            SubControl(number="1", id="3.3.14.1",
                        text="The security event management process should be defined.",
                        children=[]),
            SubControl(number="2", id="3.3.14.2",
                        text="The effectiveness should be measured.",
                        children=[]),
            SubControl(number="3", id="3.3.14.3",
                        text="To support this process a security event monitoring standard should be defined.",
                        children=[]),
            SubControl(number="a", id="3.3.14.a",
                        text="the standard should address for all information assets the mandatory events.",
                        children=[]),
            SubControl(number="4", id="3.3.14.4",
                        text="The security event management process should include requirements for:",
                        children=[
                            SubControl(number="a", id="3.3.14.4.a",
                                        text="establishment of SOC", children=[]),
                        ]),
        ]
        ext = _extraction("3.3.14", scs)

        moved = renest_interleaved_children([ext])

        assert moved == 1
        assert len(ext.sub_controls) == 4
        assert ext.sub_controls[2].id == "3.3.14.3"
        assert len(ext.sub_controls[2].children) == 1
        assert ext.sub_controls[2].children[0].id == "3.3.14.3.a"
        # Item 4's existing children should be untouched.
        assert len(ext.sub_controls[3].children) == 1
        assert ext.sub_controls[3].children[0].id == "3.3.14.4.a"


# ═════════════════════════════════════════════════════════════════════════════
# detect_letter_sequence_gaps
# ═════════════════════════════════════════════════════════════════════════════

class TestGapDetection:
    """Letter-sequence gap detection."""

    def test_gap_detected(self):
        """[a, c, d] → reports missing 'b'."""
        scs = [_sc(n, parent_id="C") for n in ["a", "c", "d"]]
        ext = _extraction("C", scs)

        gaps = detect_letter_sequence_gaps([ext])

        assert len(gaps) == 1
        assert gaps[0] == ("C", "b")

    def test_multiple_gaps(self):
        """[a, d] → reports missing 'b' and 'c'."""
        scs = [_sc(n, parent_id="C") for n in ["a", "d"]]
        ext = _extraction("C", scs)

        gaps = detect_letter_sequence_gaps([ext])

        assert len(gaps) == 2
        assert ("C", "b") in gaps
        assert ("C", "c") in gaps

    def test_no_gap_complete_sequence(self):
        """[a, b, c, d] → no gaps."""
        scs = [_sc(n, parent_id="C") for n in ["a", "b", "c", "d"]]
        ext = _extraction("C", scs)

        gaps = detect_letter_sequence_gaps([ext])

        assert len(gaps) == 0

    def test_no_gap_numeric_only(self):
        """[1, 2, 3] → no letter items, no gaps reported."""
        scs = [_sc(n, parent_id="C") for n in ["1", "2", "3"]]
        ext = _extraction("C", scs)

        gaps = detect_letter_sequence_gaps([ext])

        assert len(gaps) == 0

    def test_single_letter_no_check(self):
        """[a] → too few letters, no gaps reported."""
        scs = [_sc("a", parent_id="C")]
        ext = _extraction("C", scs)

        gaps = detect_letter_sequence_gaps([ext])

        assert len(gaps) == 0

    def test_recursive_gap_in_children(self):
        """Gap inside nested children is also detected."""
        children = [_sc(n, parent_id="C.1") for n in ["a", "c"]]
        parent = SubControl(
            number="1", id="C.1", text="parent", children=children,
        )
        ext = _extraction("C", [parent])

        gaps = detect_letter_sequence_gaps([ext])

        assert len(gaps) == 1
        assert gaps[0] == ("C.1", "b")

    def test_sama_3_3_13_4_pattern(self):
        """Replicate the 3.3.13.4 gap: [a, c, d] missing 'b'."""
        scs = [
            SubControl(number="a", id="3.3.13.4.a", text="brand protection",
                        children=[]),
            SubControl(number="c", id="3.3.13.4.c", text="ATMs and POSs",
                        children=[]),
            SubControl(number="d", id="3.3.13.4.d", text="SMS notification",
                        children=[]),
        ]
        parent = SubControl(
            number="4", id="3.3.13.4", text="Electronic banking services",
            children=scs,
        )
        ext = _extraction("3.3.13", [parent])

        gaps = detect_letter_sequence_gaps([ext])

        assert len(gaps) == 1
        assert gaps[0] == ("3.3.13.4", "b")


# ═════════════════════════════════════════════════════════════════════════════
# merge_lowercase_continuations — lettered-item guard
# ═════════════════════════════════════════════════════════════════════════════

class TestMergeDoesNotEatLetteredChildren:
    """Lettered sub-items (a, b, c…) must NOT be merged even when lowercase."""

    def test_lettered_children_preserved(self):
        """Children [a, b, c] starting with lowercase should NOT be merged."""
        children = [
            SubControl(number="a", id="C.1.a",
                       text="the establishment of a designated team", children=[]),
            SubControl(number="b", id="C.1.b",
                       text="skilled and trained staff", children=[]),
            SubControl(number="c", id="C.1.c",
                       text="continuous monitoring of events", children=[]),
        ]
        parent = SubControl(
            number="1", id="C.1",
            text="The process should include requirements for:",
            children=children,
        )
        ext = _extraction("C", [parent])

        merged = merge_lowercase_continuations([ext])

        assert merged == 0
        assert len(ext.sub_controls[0].children) == 3

    def test_lettered_top_level_preserved(self):
        """Top-level lettered sub-controls should NOT be merged."""
        scs = [
            SubControl(number="a", id="C.a",
                       text="title of incident", children=[]),
            SubControl(number="b", id="C.b",
                       text="classification of the incident", children=[]),
        ]
        ext = _extraction("C", scs)

        merged = merge_lowercase_continuations([ext])

        assert merged == 0
        assert len(ext.sub_controls) == 2

    def test_numeric_continuation_still_merged(self):
        """Numbered items starting lowercase (PDF artifacts) still get merged."""
        scs = [
            SubControl(number="1", id="C.1",
                       text="The process should be defined", children=[]),
            SubControl(number="2", id="C.2",
                       text="and approved by management", children=[]),
        ]
        ext = _extraction("C", scs)

        merged = merge_lowercase_continuations([ext])

        assert merged == 1
        assert len(ext.sub_controls) == 1
        assert "and approved" in ext.sub_controls[0].text
