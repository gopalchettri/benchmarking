"""
Shared test fixtures for the control extraction platform.
"""

import os
import sys
import pytest

# Ensure project root is on sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Ensure each service directory is on sys.path for imports
for service_dir in ["services/ai_extraction", "services/storage", "services/doc_processing", "services/api_gateway"]:
    full_path = os.path.join(PROJECT_ROOT, service_dir)
    if full_path not in sys.path:
        sys.path.insert(0, full_path)


@pytest.fixture
def sample_profile_dict():
    """A minimal framework profile dict for testing."""
    return {
        "id": "test-iso-27001",
        "name": "ISO-27001",
        "display_name": "ISO/IEC 27001:2022",
        "version": "2022",
        "prompt_module": "prompts.iso_27001",
        "control_layout": "annex",
        "domain_mapping": {
            "A.5": "Organizational Controls",
            "A.6": "People Controls",
            "A.7": "Physical Controls",
            "A.8": "Technological Controls",
        },
    }


@pytest.fixture
def sample_extraction_dict():
    """A minimal extraction dict for testing validators and scorers."""
    return {
        "control_id": "A.5.1",
        "title": "Policies for information security",
        "sections": {"Purpose": "To ensure suitability..."},
        "sub_controls": [
            {"number": "a", "id": "A.5.1.a", "text": "be defined by management", "children": []}
        ],
        "description": "A set of policies for information security.",
        "source_pages": "15-16",
        "extraction_confidence": None,
        "verbatim_verified": True,
    }
