"""Tests for document format detection."""

import pytest
from format_detector import detect_format


class TestFormatDetector:
    """Verify MIME/extension-based format routing."""

    def test_pdf_extension(self):
        assert detect_format("document.pdf") == "pdf"

    def test_docx_extension(self):
        assert detect_format("report.docx") == "docx"

    def test_xlsx_extension(self):
        assert detect_format("controls.xlsx") == "xlsx"

    def test_html_extension(self):
        assert detect_format("page.html") == "html"

    def test_htm_extension(self):
        assert detect_format("page.htm") == "html"

    def test_image_extensions(self):
        assert detect_format("scan.tiff") == "image"
        assert detect_format("photo.png") == "image"
        assert detect_format("pic.jpeg") == "image"

    def test_unknown_extension_raises(self):
        with pytest.raises(ValueError, match="Unsupported"):
            detect_format("file.xyz")

    def test_case_insensitive(self):
        assert detect_format("DOC.PDF") == "pdf"
        assert detect_format("sheet.XLSX") == "xlsx"

    def test_mime_type_takes_priority(self):
        assert detect_format("file.txt", content_type="application/pdf") == "pdf"

    def test_docx_mime(self):
        mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        assert detect_format("file", content_type=mime) == "docx"
