"""Tests for the framework profiles seed script.

These tests require a PostgreSQL connection because the seed module
creates tables at import time. Mark as integration tests.
"""

import pytest


def _import_profiles():
    """Try importing PROFILES, skip test if DB is unavailable."""
    try:
        from seed.framework_profiles import PROFILES
        return PROFILES
    except Exception as e:
        pytest.skip(f"Cannot import seed profiles (DB unavailable?): {e}")


@pytest.mark.integration
class TestSeedProfiles:
    """Verify all predefined framework profiles are valid."""

    def test_seed_has_4_profiles(self):
        PROFILES = _import_profiles()
        assert len(PROFILES) == 4

    def test_all_profiles_have_required_fields(self):
        PROFILES = _import_profiles()
        required_fields = [
            "name", "display_name", "version", "prompt_module",
        ]
        for profile in PROFILES:
            for field in required_fields:
                assert field in profile, f"Profile {profile.get('name', '?')} missing field: {field}"

    def test_unique_profile_names(self):
        PROFILES = _import_profiles()
        names = [p["name"] for p in PROFILES]
        assert len(names) == len(set(names)), f"Duplicate profile names: {names}"

    def test_prompt_modules_reference_existing_modules(self):
        PROFILES = _import_profiles()
        from prompts import load_framework_prompts
        for profile in PROFILES:
            mod = load_framework_prompts(profile["prompt_module"])
            assert hasattr(mod, "get_toc_prompts"), (
                f"Prompt module {profile['prompt_module']} missing get_toc_prompts"
            )
