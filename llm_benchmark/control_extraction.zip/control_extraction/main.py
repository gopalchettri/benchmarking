"""
Sub-Control Extraction Tool — Main CLI Entry Point

Extracts sub-controls from cybersecurity framework PDFs using LLM.

Usage:
    # Interactive (2-prompt flow: ToC pages + content pages)
    python main.py --pdf UAE_IAS_2.1.pdf --framework "UAE IAS 2.1"

    # Batch auto-range (ToC-driven)
    python main.py --pdf doc.pdf --framework "NIST 800-53" --no-interactive --toc-pages "3-5" --content-pages "6-120"

    # Batch legacy (manual page ranges)
    python main.py --pdf doc.pdf --framework "NIST 800-53" --pages "15-25,50-60" --no-interactive
"""

import argparse
import asyncio
import json
import re
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from config import Settings, get_settings, validate_config, resolve_env_file
from llm.providers import get_llm_provider, ILLMProvider
from llm.rate_limiter import RateLimitConfig, AdaptiveRateLimiter
from llm.token_tracker import get_token_tracker
from models import (
    ControlExtraction,
    ExtractionMetadata,
    ExtractionResult,
    FrameworkTOC,
    TOCEntry,
    TOOL_VERSION,
    count_all_sub_controls,
)
from pdf_extractor import PDFExtractor
from sub_control_extractor import SubControlExtractor
from toc_extractor import extract_toc
from utils.logging_config import logger, setup_logging, start_job_logging, stop_job_logging

# --- Graceful Ctrl+C ---
_shutdown_requested = False


def _signal_handler(signum, frame):
    global _shutdown_requested
    if _shutdown_requested:
        sys.exit(1)
    _shutdown_requested = True



# =============================================================================
# Helpers
# =============================================================================

def sanitize_filename(name: str) -> str:
    """Make framework name safe for filenames."""
    safe = re.sub(r'[^\w\-.]', '_', name)
    safe = re.sub(r'_+', '_', safe)
    return safe.strip('_') or "unknown"


def parse_page_range(user_input: str, total_pages: int) -> Tuple[int, int]:
    """Parse user input like '15-25', '15 to 25', '15,25'."""
    text = user_input.strip()
    start, end = None, None

    for sep in ['-', 'to', ',', '..']:
        if sep in text:
            parts = text.split(sep, 1)
            try:
                start = int(parts[0].strip())
                end = int(parts[1].strip())
                break
            except ValueError:
                continue

    if start is None or end is None:
        try:
            start = end = int(text)
        except ValueError:
            raise ValueError(f"Cannot parse page range: '{user_input}'. Use format: 15-25")

    if start < 1:
        raise ValueError(f"Start page must be >= 1 (got {start})")
    if end > total_pages:
        raise ValueError(f"End page {end} exceeds PDF total ({total_pages} pages)")
    if start > end:
        raise ValueError(f"Start page ({start}) > end page ({end})")

    return start, end





def remove_parent_extractions(
    extractions_by_id: Dict[str, ControlExtraction],
) -> Dict[str, ControlExtraction]:
    """Remove extractions that are parent/domain-level entries.

    An extraction is considered a parent if its control_id is a proper
    prefix of another extraction's control_id (separator-aware).

    Example: if both "3.2" and "3.2.1" exist, "3.2" is removed.

    Framework-agnostic: works for any ID scheme where parents are
    prefixes of their children (dot, dash, parenthesis, or slash).
    """
    all_ids = set(extractions_by_id.keys())
    parents_to_remove: set = set()

    for candidate_id in all_ids:
        for other_id in all_ids:
            if other_id == candidate_id:
                continue
            if other_id.startswith(candidate_id):
                remainder = other_id[len(candidate_id):]
                if remainder and remainder[0] in '.-(/: _':
                    parents_to_remove.add(candidate_id)
                    break

    if parents_to_remove:
        logger.info(
            f"Removing {len(parents_to_remove)} parent-level extraction(s): "
            f"{sorted(parents_to_remove)}"
        )
        for pid in parents_to_remove:
            del extractions_by_id[pid]

    return extractions_by_id


def save_pdf_markdown(
    pdf_extractor: PDFExtractor,
    output_dir: Path,
    framework_name: str,
    timestamp: str,
) -> Optional[Path]:
    """Save the full PDF-to-markdown extraction to a .md file."""
    if not pdf_extractor._full_markdown:
        logger.warning("Full markdown not available (large PDF uses disk caching). Skipping markdown save.")
        return None
    safe_name = sanitize_filename(framework_name)
    md_path = output_dir / f"{safe_name}_{timestamp}.md"
    md_path.parent.mkdir(parents=True, exist_ok=True)
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(pdf_extractor._full_markdown)
    logger.info(f"PDF markdown saved to {md_path}")
    return md_path


def save_results(
    result: ExtractionResult,
    output_path: Path,
) -> None:
    """Save extraction results to JSON."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result.model_dump(), f, indent=2, ensure_ascii=False)
    logger.info(f"Results saved to {output_path}")


def build_result(
    framework_name: str,
    extractions_by_id: Dict[str, ControlExtraction],
    toc_total: Optional[int],
    pages_processed: List[str],
    pdf_file: str,
    config: Settings,
    session_start: float,
    errors: List[str],
) -> ExtractionResult:
    """Build the final ExtractionResult model."""
    tracker = get_token_tracker()
    summary = tracker.get_summary()

    # Determine model name
    model_name = ""
    if config.LLM_PROVIDER == "azure":
        model_name = config.AZURE_OPENAI_DEPLOYMENT_NAME or ""
    elif config.LLM_PROVIDER == "ollama":
        model_name = config.OLLAMA_MODEL_NAME or ""

    extractions = list(extractions_by_id.values())
    return ExtractionResult(
        framework_name=framework_name,
        total_controls_in_toc=toc_total,
        controls_processed=len(extractions),
        extractions=extractions,
        metadata=ExtractionMetadata(
            extracted_at=datetime.now(timezone.utc).isoformat(),
            tool_version=TOOL_VERSION,
            llm_provider=config.LLM_PROVIDER,
            llm_model=model_name,
            total_tokens_used=summary['total_tokens'],
            total_duration_seconds=round(time.monotonic() - session_start, 1),
            pages_processed=pages_processed,
            pdf_file=pdf_file,
            errors=errors,
        ),
    )


def print_summary(result: ExtractionResult) -> None:
    """Print session summary to console and log."""
    tracker = get_token_tracker()
    summary = tracker.get_summary()
    tracker.log_summary()

    total_sub = sum(
        count_all_sub_controls(e.sub_controls) for e in result.extractions
    )
    nested = sum(
        count_all_sub_controls(e.sub_controls) - len(e.sub_controls)
        for e in result.extractions
    )
    verified = sum(1 for e in result.extractions if e.verbatim_verified is True)
    total_ext = len(result.extractions)
    nested_str = f" ({nested} nested)" if nested else ""
    cost_str = f"\n  Estimated cost: ${summary['estimated_cost_usd']:.4f}" if summary.get('estimated_cost_usd') else ""

    summary_text = (
        f"\n{'=' * 54}\n"
        f"  Summary\n"
        f"  Framework: {result.framework_name}\n"
        + (f"  Controls in ToC: {result.total_controls_in_toc}\n" if result.total_controls_in_toc is not None else "")
        + f"  Controls processed: {result.controls_processed}\n"
        f"  Total sub-controls: {total_sub}{nested_str}\n"
        f"  Verbatim verified: {verified}/{total_ext}\n"
        f"  Token usage: {summary['total_tokens']:,} "
        f"(in: {summary['total_input_tokens']:,}, out: {summary['total_output_tokens']:,})\n"
        f"  LLM calls: {summary['total_calls']} "
        f"(success: {summary['successful_calls']}, failed: {summary['failed_calls']})\n"
        f"  Duration: {result.metadata.total_duration_seconds}s\n"
        f"  Errors: {len(result.metadata.errors)}"
        f"{cost_str}\n"
        f"{'=' * 54}"
    )
    print(summary_text)
    logger.info(summary_text)


def _save_final_output(
    framework: str,
    extractions_by_id: Dict[str, ControlExtraction],
    toc_total: Optional[int],
    pages_processed: List[str],
    pdf_path: str,
    config: Settings,
    session_start: float,
    session_errors: List[str],
    pdf_extractor: Optional[PDFExtractor] = None,
    output_override: Optional[Path] = None,
    prefix: str = "",
) -> None:
    """Save extraction results, PDF markdown, and print summary. Used for normal, interrupt, and error saves."""
    if not extractions_by_id:
        logger.warning("No extractions to save.")
        return

    result = build_result(
        framework, extractions_by_id, toc_total,
        pages_processed, pdf_path, config, session_start, session_errors,
    )

    safe_name = sanitize_filename(framework)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = output_override or Path(config.OUTPUT_DIR) / f"{safe_name}_{prefix}{timestamp}.json"

    try:
        save_results(result, output_path)
    except Exception as e:
        logger.error(f"Cannot save output: {e}. Printing JSON to console instead.")
        print(json.dumps(result.model_dump(), indent=2, ensure_ascii=False))

    if pdf_extractor:
        save_pdf_markdown(pdf_extractor, Path(config.OUTPUT_DIR), framework, timestamp)

    print_summary(result)


# =============================================================================
# Main Async Logic
# =============================================================================

async def async_main(args: argparse.Namespace) -> None:
    global _shutdown_requested

    session_start = time.monotonic()

    # --- Banner ---
    print("\n" + "=" * 54)
    print(f"  Sub-Control Extraction Tool v{TOOL_VERSION}")
    print(f"  Framework: {args.framework}")
    print("=" * 54 + "\n")

    # --- Config ---
    env_path = resolve_env_file(getattr(args, 'env_file', None))
    if env_path:
        logger.info(f"Using .env: {env_path}")
    config = get_settings(getattr(args, 'env_file', None))

    setup_logging(
        service_name="control_extraction",
        log_level=config.LOG_LEVEL,
        environment=config.ENVIRONMENT,
    )

    # --- Per-run Job Logging ---
    pdf_stem = Path(args.pdf).stem
    job_id = f"{sanitize_filename(args.framework)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    job_log_file = start_job_logging(job_id=job_id, file_name=pdf_stem)
    logger.info(f"Run log file: {job_log_file}")
    logger.info(f"Run started: framework={args.framework}, pdf={args.pdf}, job_id={job_id}")

    errors_list = validate_config(config)
    if errors_list:
        for err in errors_list:
            logger.error(f"Config error: {err}")
        logger.error("Fix these in your .env file and retry.")
        sys.exit(1)

    deployment_name = ""
    if config.LLM_PROVIDER == "azure":
        deployment_name = config.AZURE_OPENAI_DEPLOYMENT_NAME or ""
    elif config.LLM_PROVIDER == "ollama":
        deployment_name = config.OLLAMA_MODEL_NAME or ""
    logger.info(f"Config OK: provider={config.LLM_PROVIDER}, model={deployment_name}")

    # --- Token Tracker (singleton initialized from config) ---
    get_token_tracker()

    # --- Rate Limiter ---
    # Honour the model-profile registry so the standalone CLI runner picks
    # the same defaults as the worker. Env vars still override (positive
    # value wins); when sentinels are in effect (rpm=0 / burst=0 /
    # min_interval=-1.0) the profile or DEFAULT_PROFILE supplies values.
    from services.ai_extraction.llm.model_profiles import resolve_profile
    _profile = resolve_profile(config.LLM_PROVIDER, deployment_name)
    _rpm = config.LLM_RATE_LIMIT_RPM if config.LLM_RATE_LIMIT_RPM > 0 else _profile.rpm
    _burst = config.LLM_RATE_LIMIT_BURST if config.LLM_RATE_LIMIT_BURST > 0 else _profile.burst
    _min_gap = (
        config.LLM_RATE_LIMIT_MIN_INTERVAL
        if config.LLM_RATE_LIMIT_MIN_INTERVAL >= 0
        else _profile.min_gap_seconds
    )
    rate_config = RateLimitConfig(
        requests_per_minute=_rpm,
        burst_size=_burst,
        min_gap_seconds=_min_gap,
    )
    rate_limiter = AdaptiveRateLimiter(rate_config)
    logger.info(
        f"Rate limiter resolved: rpm={_rpm} burst={_burst} min_gap={_min_gap}s"
    )

    # --- LLM Provider ---
    provider: Optional[ILLMProvider] = None
    pdf_extractor: Optional[PDFExtractor] = None

    # Session state
    extractions_by_id: Dict[str, ControlExtraction] = {}
    pages_processed: List[str] = []
    extracted_ranges: List[Tuple[int, int]] = []
    toc_total: Optional[int] = None
    toc: Optional[FrameworkTOC] = None
    session_errors: List[str] = []

    try:
        # --- Provider Init ---
        provider = get_llm_provider(config)
        if config.LLM_ENABLE_WARMUP:
            logger.info("Warming up LLM provider...")
            success = await provider.warmup_model()
            if success:
                logger.info("LLM warmup complete")
            else:
                logger.warning("LLM warmup failed (non-critical). Continuing.")

        # --- PDF ---
        pdf_extractor = PDFExtractor(config)
        pdf_extractor.convert_pdf(args.pdf)
        total_pages = pdf_extractor.get_total_pages()
        logger.info(f"PDF ready: {args.pdf}, {total_pages} pages")

        # --- Sub-Control Extractor ---
        extractor = SubControlExtractor(provider, config, rate_limiter)

        # --- Auto-range Batch Mode (--no-interactive --toc-pages --content-pages) ---
        if (getattr(args, 'no_interactive', False)
                and getattr(args, 'toc_pages', None)
                and getattr(args, 'content_pages', None)):
            logger.info(f"Auto-range batch mode: toc_pages={args.toc_pages}, content_pages={args.content_pages}")

            toc_start, toc_end = parse_page_range(args.toc_pages, total_pages)
            toc = await extract_toc(
                pdf_extractor, toc_start, toc_end,
                args.framework, provider, config, rate_limiter,
            )
            toc_total = toc.total_controls
            toc_ids = {e.control_id for e in toc.controls}

            content_start, content_end = parse_page_range(args.content_pages, total_pages)

            if toc and toc.controls and any(e.page is not None for e in toc.controls):
                # We have a ToC. We no longer try to split by individual pages (which causes overlaps and duplicates).
                # We extract the entire block and rely on the agnositic regex chunker.
                try:
                    content = pdf_extractor.extract_pages(content_start, content_end)
                    logger.info(f"Batch extracting ToC-guided block pages {content_start}-{content_end} ({len(content):,} chars)")
                    results = await extractor.extract(
                        args.framework, content, f"{content_start}-{content_end}",
                        known_control_ids=list(toc_ids) if toc_ids else None,
                        toc_entries=toc.controls if toc else None,
                        control_start_page=content_start,
                        control_end_page=content_end,
                    )
                    for r in results:
                        if toc_ids and r.control_id not in toc_ids:
                            logger.debug(f"Skipping non-ToC extraction '{r.control_id}'")
                            continue

                        # Gap 6 Fix: Merge extractions instead of overwriting to prevent data loss on split chunks
                        if r.control_id in extractions_by_id:
                            existing = extractions_by_id[r.control_id]
                            existing.sub_controls.extend(r.sub_controls)
                            if r.sections:
                                existing.sections.update(r.sections)
                        else:
                            extractions_by_id[r.control_id] = r
                    pages_processed.append(f"{content_start}-{content_end}")
                    extracted_ranges.append((content_start, content_end))
                except Exception as e:
                    err = f"Full-range extraction pages {content_start}-{content_end}: {e}"
                    logger.error(err)
                    session_errors.append(err)

        # --- Legacy Batch Mode (--no-interactive --pages) ---
        elif getattr(args, 'no_interactive', False) and args.pages:
            logger.info("Legacy batch mode (non-interactive)")
            page_ranges = [p.strip() for p in args.pages.split(',') if p.strip()]
            for pr in page_ranges:
                if _shutdown_requested:
                    break
                try:
                    start, end = parse_page_range(pr, total_pages)
                    content = pdf_extractor.extract_pages(start, end)
                    logger.info(f"Extracting pages {start}-{end} ({len(content):,} chars)")
                    results = await extractor.extract(
                        args.framework, content, f"{start}-{end}",
                        known_control_ids=list(toc_ids) if toc_ids else None
                    )
                    for r in results:
                        # Gap 6 Fix: Merge extractions instead of overwriting
                        if r.control_id in extractions_by_id:
                            existing = extractions_by_id[r.control_id]
                            existing.sub_controls.extend(r.sub_controls)
                            if r.sections:
                                existing.sections.update(r.sections)
                        else:
                            extractions_by_id[r.control_id] = r
                        # Legacy mode: keep first extraction (no targeted control)
                    pages_processed.append(f"{start}-{end}")
                    extracted_ranges.append((start, end))
                except Exception as e:
                    err = f"Pages {pr}: {e}"
                    logger.error(err)
                    session_errors.append(err)

        else:
            # --- Interactive Mode: 2-prompt upfront flow ---

            # Collect both inputs upfront
            print()
            toc_input = input("Enter ToC page range (e.g., 3-5): ").strip()
            content_input = input("Enter control content page range (e.g., 6-120): ").strip()
            logger.info(f"User input: toc_pages={toc_input}, content_pages={content_input}")

            # Parse content range first (required)
            try:
                content_start, content_end = parse_page_range(content_input, total_pages)
            except ValueError as e:
                logger.error(f"Invalid content page range: {e}")
                sys.exit(1)

            # Step 1: Extract ToC
            logger.info(f"Step 1: Extracting Table of Contents from pages {toc_input}...")
            toc = None
            try:
                toc_start, toc_end = parse_page_range(toc_input, total_pages)
                toc = await extract_toc(
                    pdf_extractor, toc_start, toc_end,
                    args.framework, provider, config, rate_limiter,
                )
                toc_total = toc.total_controls
                toc_ids = {e.control_id for e in toc.controls}
                logger.info(f"ToC extracted: {toc_total} controls found")
            except Exception as e:
                logger.error(f"ToC extraction failed: {e}")
                session_errors.append(f"ToC extraction: {e}")

            toc_ids = {e.control_id for e in toc.controls} if toc and toc.controls else set()

            # Step 2: Compute per-control page ranges and extract
            if toc and toc.controls and any(e.page is not None for e in toc.controls):
                try:
                    content = pdf_extractor.extract_pages(content_start, content_end)
                    logger.info(f"Extracting bounded ToC block pages {content_start}-{content_end} ({len(content):,} chars)")
                    results = await extractor.extract(
                        args.framework, content, f"{content_start}-{content_end}",
                        known_control_ids=list(toc_ids) if toc_ids else None,
                        toc_entries=toc.controls if toc else None,
                        control_start_page=content_start,
                        control_end_page=content_end,
                    )
                    for r in results:
                        if toc_ids and r.control_id not in toc_ids:
                            logger.debug(f"Skipping non-ToC extraction '{r.control_id}'")
                            continue

                        # Gap 6 Fix: Merge extractions instead of overwriting
                        if r.control_id in extractions_by_id:
                            existing = extractions_by_id[r.control_id]
                            existing.sub_controls.extend(r.sub_controls)
                            if r.sections:
                                existing.sections.update(r.sections)
                        else:
                            extractions_by_id[r.control_id] = r
                    pages_processed.append(f"{content_start}-{content_end}")
                    extracted_ranges.append((content_start, content_end))
                    sub_count = sum(count_all_sub_controls(r.sub_controls) for r in results)
                    logger.info(f"Extracted block: {len(results)} controls, {sub_count} sub-controls from pages {content_start}-{content_end}")
                except Exception as exc:
                    err = f"Block extraction pages {content_start}-{content_end}: {exc}"
                    logger.error(err)
                    session_errors.append(err)
            else:
                # No page numbers from ToC — extract entire content range as single chunk
                if toc:
                    logger.info("ToC entries have no page numbers. Extracting entire range as one chunk.")
                else:
                    logger.info("No ToC available. Extracting entire content range as one chunk.")
                try:
                    content = pdf_extractor.extract_pages(content_start, content_end)
                    logger.info(f"Extracting pages {content_start}-{content_end} ({len(content):,} chars)")
                    results = await extractor.extract(
                        args.framework, content, f"{content_start}-{content_end}",
                        known_control_ids=list(toc_ids) if toc_ids else None
                    )
                    for r in results:
                        # Gap 6 Fix: Merge extractions instead of overwriting
                        if r.control_id in extractions_by_id:
                            existing = extractions_by_id[r.control_id]
                            existing.sub_controls.extend(r.sub_controls)
                            if r.sections:
                                existing.sections.update(r.sections)
                        else:
                            extractions_by_id[r.control_id] = r
                    pages_processed.append(f"{content_start}-{content_end}")
                    extracted_ranges.append((content_start, content_end))
                except Exception as e:
                    err = f"Pages {content_start}-{content_end}: {e}"
                    logger.error(err)
                    session_errors.append(err)

        # --- Post-processing: Apply authoritative titles from ToC ---
        if toc and toc.controls and extractions_by_id:
            toc_titles = {e.control_id: e.title for e in toc.controls}
            corrected = 0
            for ctrl_id, extraction in extractions_by_id.items():
                if ctrl_id in toc_titles and extraction.title != toc_titles[ctrl_id]:
                    logger.info(
                        f"Title correction: {ctrl_id} "
                        f"'{extraction.title}' -> '{toc_titles[ctrl_id]}'"
                    )
                    extraction.title = toc_titles[ctrl_id]
                    corrected += 1
            if corrected:
                logger.info(f"Corrected {corrected} title(s) from ToC")

        # --- Post-processing: Remove parent/domain-level extractions ---
        if extractions_by_id:
            extractions_by_id = remove_parent_extractions(extractions_by_id)

        # --- Save Results ---
        _save_final_output(
            framework=args.framework,
            extractions_by_id=extractions_by_id,
            toc_total=toc_total,
            pages_processed=pages_processed,
            pdf_path=args.pdf,
            config=config,
            session_start=session_start,
            session_errors=session_errors,
            pdf_extractor=pdf_extractor,
            output_override=Path(args.output) if getattr(args, 'output', None) else None,
            prefix="partial_" if _shutdown_requested else "",
        )

    except KeyboardInterrupt:
        logger.warning("Interrupted — saving partial results...")
        _save_final_output(
            framework=args.framework,
            extractions_by_id=extractions_by_id,
            toc_total=toc_total,
            pages_processed=pages_processed,
            pdf_path=args.pdf,
            config=config,
            session_start=session_start,
            session_errors=session_errors,
            pdf_extractor=pdf_extractor,
            prefix="partial_",
        )

    except Exception as e:
        logger.exception(f"Fatal error: {e}")
        try:
            _save_final_output(
                framework=args.framework,
                extractions_by_id=extractions_by_id,
                toc_total=toc_total,
                pages_processed=pages_processed,
                pdf_path=args.pdf,
                config=config,
                session_start=session_start,
                session_errors=session_errors,
                pdf_extractor=pdf_extractor,
                prefix="partial_",
            )
        except Exception:
            pass
        sys.exit(1)

    finally:
        stop_job_logging(job_id)
        if pdf_extractor:
            pdf_extractor.cleanup()
        if provider:
            await provider.close()
            logger.info("Provider connections closed.")


# =============================================================================
# CLI Entry Point
# =============================================================================

def cli_entry():
    """Sync entry point for CLI."""
    signal.signal(signal.SIGINT, _signal_handler)

    parser = argparse.ArgumentParser(
        description="Sub-Control Extraction Tool — Extract sub-controls from cybersecurity framework PDFs"
    )
    parser.add_argument("--pdf", required=True, help="Path to framework PDF")
    parser.add_argument("--framework", required=True, help="Framework name (e.g., 'UAE IAS 2.1')")
    parser.add_argument("--toc-pages", help="ToC page range for auto-extraction (e.g., '3-5')")
    parser.add_argument("--content-pages", help="Content page range for auto-extraction (e.g., '6-120')")
    parser.add_argument("--pages", help="Page ranges for legacy batch mode (e.g., '15-25,50-60')")
    parser.add_argument("--no-interactive", action="store_true", help="Batch mode (no prompts)")
    parser.add_argument("--output", help="Custom output file path")
    parser.add_argument("--env-file", help="Path to .env file")
    args = parser.parse_args()

    asyncio.run(async_main(args))


if __name__ == "__main__":
    cli_entry()
