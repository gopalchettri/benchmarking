# ============================================================
# Control Extraction - Log Rotation Script
# Run from project root:
#   .\rotate_logs.ps1
# ============================================================

function Write-Header($msg) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

$root = $PSScriptRoot
$logsDir = Join-Path $root "logs"
$stderrPath = Join-Path $root "stderr.log"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$archiveDir = Join-Path $logsDir "archive_$timestamp"

Write-Header "Rotating Logs"

if (-not (Test-Path $logsDir)) {
    Write-Host "  Logs directory not found: $logsDir" -ForegroundColor Yellow
    exit 0
}

New-Item -ItemType Directory -Path $archiveDir -Force | Out-Null

$logFiles = Get-ChildItem $logsDir -File -ErrorAction SilentlyContinue
if ($logFiles) {
    foreach ($file in $logFiles) {
        Move-Item -LiteralPath $file.FullName -Destination $archiveDir
        Write-Host "  Archived $($file.Name)" -ForegroundColor Green
    }
}
else {
    Write-Host "  No log files found in logs/" -ForegroundColor Gray
}

if (Test-Path $stderrPath) {
    Move-Item -LiteralPath $stderrPath -Destination (Join-Path $archiveDir "stderr.log")
    Write-Host "  Archived stderr.log" -ForegroundColor Green
}
else {
    Write-Host "  No stderr.log file found" -ForegroundColor Gray
}

New-Item -ItemType File -Path $stderrPath -Force | Out-Null

Write-Header "Done"
Write-Host "  Archive: $archiveDir" -ForegroundColor White
Write-Host "  Fresh stderr.log created." -ForegroundColor White
Write-Host ""
