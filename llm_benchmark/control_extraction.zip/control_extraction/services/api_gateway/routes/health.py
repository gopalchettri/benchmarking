"""Health check endpoint."""

from fastapi import APIRouter

from config import get_settings
from shared_core.health import check_redis

settings = get_settings()
router = APIRouter(tags=["Health"])


# Populated during app lifespan startup
startup_health: dict = {}


@router.get("/health")
async def health():
    live_redis = await check_redis(settings.REDIS_URL)
    return {
        "service": settings.APP_NAME_GATEWAY,
        "status": "ok" if live_redis["status"] == "ok" else "degraded",
        "checks": {"redis": live_redis, "startup": startup_health},
    }
