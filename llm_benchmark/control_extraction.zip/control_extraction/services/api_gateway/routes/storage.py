"""Storage proxy endpoints — results retrieval and document download."""

from fastapi import APIRouter
from fastapi.responses import RedirectResponse

from config import get_settings
from dependencies import DOWNSTREAM_TIMEOUT
from helpers import proxy_storage_get

settings = get_settings()

STORAGE_SERVICE_URL = settings.STORAGE_SERVICE_URL

router = APIRouter(prefix=settings.API_V1_STR, tags=["Storage"])


@router.get(
    "/storage/{job_id}/results",
    summary="Get extraction results",
    description="Retrieve the extracted controls for a completed job from the storage service.",
)
async def get_results(job_id: str):
    url = f"{STORAGE_SERVICE_URL}{settings.API_V1_STR}/storage/{job_id}/results"
    return await proxy_storage_get(url, timeout=DOWNSTREAM_TIMEOUT)


@router.get(
    "/documents/{blob_path:path}",
    summary="Download a document",
    description="Redirects to a time-limited Azure Blob SAS URL for direct download.",
)
async def download_document(blob_path: str):
    url = f"{STORAGE_SERVICE_URL}{settings.API_V1_STR}/documents/download-url/{blob_path}"
    data = await proxy_storage_get(url, timeout=DOWNSTREAM_TIMEOUT)
    return RedirectResponse(url=data["download_url"], status_code=302)
