"""
Shared helpers for the API Gateway service.

Centralizes error sanitization and downstream HTTP proxying
to avoid duplicating try/except patterns across route handlers.
"""

import re

import httpx
from fastapi import HTTPException

from utils.logging_config import logger


def sanitize_error(err: Exception, max_length: int = 200) -> str:
    """Sanitize an exception message for safe external exposure.

    Strips internal URLs (httpx exceptions can leak service addresses)
    and truncates to *max_length* characters.
    """
    raw = f"{type(err).__name__}: {str(err)[:max_length]}"
    return re.sub(r'https?://\S+', '[URL]', raw)


async def proxy_storage_get(url: str, *, timeout: httpx.Timeout) -> dict:
    """Proxy a GET request to the storage service.

    Handles httpx errors uniformly:
    - HTTPStatusError  → logs full detail, returns 502 to caller
    - Any other error  → logs, returns 502

    Keeps internal URLs and response bodies out of client-facing errors.
    """
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            resp = await client.get(url)
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as exc:
            logger.error(
                f"Storage service error: HTTP {exc.response.status_code}: "
                f"{exc.response.text[:500]}"
            )
            # Forward 404 and 400 as-is — they're client errors, not gateway failures
            if exc.response.status_code == 404:
                raise HTTPException(status_code=404, detail="Not found")
            if exc.response.status_code == 400:
                raise HTTPException(status_code=400, detail="Bad request")
            raise HTTPException(
                status_code=502, detail="Storage service returned an error"
            )
        except Exception as exc:
            logger.error(f"Storage service unavailable: {exc}")
            raise HTTPException(
                status_code=502, detail="Storage service unavailable"
            )
