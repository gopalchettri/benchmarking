"""Subprocess entrypoint for isolated PDF conversion."""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, "shared_core"))
sys.path.insert(0, os.path.dirname(__file__))

# Ensure all log output (including docling/torch progress) is written to stderr
# so the parent process can capture it via the subprocess stdout/stderr relay.
# Must run before any library imports that configure their own handlers.
# Only add if no handler is present yet — avoids duplicate lines if utils.logging_config
# already attached a stderr handler.
if not logging.getLogger().handlers:
    _handler = logging.StreamHandler(sys.stderr)
    _handler.setFormatter(logging.Formatter("%(levelname)s | %(name)s | %(message)s"))
    logging.getLogger().addHandler(_handler)
    logging.getLogger().setLevel(logging.INFO)

from config import get_settings
from pdf_extractor import PDFExtractor
from utils.logging_config import logger


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run PDF conversion in an isolated subprocess.")
    parser.add_argument("--pdf-path", required=True, help="Absolute path to the local PDF file")
    parser.add_argument("--framework-name", required=True, help="Framework name used for output paths")
    parser.add_argument("--job-id", required=True, help="Job identifier used for output paths")
    parser.add_argument("--result-json", required=True, help="Path where result metadata JSON will be written")
    parser.add_argument("--work-dir", default="", help="Optional working directory for conversion outputs")
    return parser.parse_args()


def _write_result(result_path: Path, payload: dict[str, object]) -> None:
    result_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = result_path.with_suffix(result_path.suffix + ".tmp")
    temp_path.write_text(json.dumps(payload), encoding="utf-8")
    temp_path.replace(result_path)


def main() -> int:
    args = parse_args()
    settings = get_settings()
    extractor = PDFExtractor(settings)
    work_dir = args.work_dir or None

    logger.info(
        f"PDF conversion subprocess starting for job={args.job_id} "
        f"parser={settings.PARSE_TYPE} work_dir={work_dir or '[default]'}"
    )

    try:
        extractor.convert_pdf(
            args.pdf_path,
            framework_name=args.framework_name,
            job_id=args.job_id,
            work_dir=work_dir,
        )
        combined_markdown_path = extractor.get_combined_markdown_path()
        job_dir = extractor.get_job_dir()
        total_pages = extractor.get_total_pages()
        if combined_markdown_path is None or job_dir is None or total_pages < 1:
            raise ValueError("PDF conversion completed without valid output metadata")

        _write_result(
            Path(args.result_json),
            {
                "combined_markdown_path": str(combined_markdown_path),
                "job_dir": str(job_dir),
                "total_pages": total_pages,
            },
        )
        logger.info(f"PDF conversion subprocess completed for job={args.job_id}")
        return 0
    except Exception:
        logger.exception(f"PDF conversion subprocess failed for job={args.job_id}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
