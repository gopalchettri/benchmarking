"""
PDF Extractor — Orchestrator
============================
Selects a parser via the `PARSE_TYPE` setting in `.env`, runs it inside
the doc_processing subprocess, and persists per-page outputs to disk
for downstream services to consume.

Parser implementations live in the `parsers/` subpackage (one file per
parser).  This module is a slim orchestrator that handles:
  - PDF validation (existence, encryption, page count limits)
  - Page-offset detection from the source PDF
  - Parser dispatch via the registry in `parsers/__init__.py`
  - Per-page text persistence (pg_N.txt files + combined.md)
  - Re-attachment to existing output (`load_output`)
  - Page-range extraction for downstream consumers (`extract_pages`)

Storage layout (under work_dir or BLOB_STORAGE_DIR from config):
  {base}/
    {framework_name}/
      {job_id}/
        pg_1.txt       <- per-page markdown files
        pg_2.txt
        ...
        combined.md    <- combined markdown with page markers
"""

from __future__ import annotations

import re
import shutil
from collections import Counter
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

import fitz

from utils.logging_config import logger

# Absolute import — `services/doc_processing` is on sys.path in all
# execution contexts (conversion subprocess, doc_processing worker, tests),
# so `parsers` is reachable as a top-level package.
from parsers import (
    docling_parser,
    get_parser,
)

if TYPE_CHECKING:
    from config import Settings


# ── Page-offset-detection regex patterns (orchestrator-level utility) ────────

_PAGE_NUMBER_STRIP_RE = re.compile(r'[\*\ufeff\u200b]')

# ASCII-only digit patterns — [0-9] is deliberate: str.isdigit() and \d both
# accept non-ASCII Unicode digits (e.g. Arabic-Indic ١, superscript ², enclosed ③)
# which would cause int() to raise ValueError on most platforms.
_STANDALONE_PAGE_NUM_RE = re.compile(r'^[0-9]+$')
_TRAILING_PAGE_NUM_RE   = re.compile(r'\b([0-9]{1,4})\s*$')


class PDFExtractor:
    """PDF to per-page text/markdown converter with disk persistence.

    This class is a thin orchestrator over the parser registry in
    `parsers/__init__.py`.  See the module-level docstring for storage
    layout details.
    """

    def __init__(self, config: "Settings"):
        self._config = config
        self._total_pages: int = 0
        self._job_dir: Optional[Path] = None
        self._combined_markdown_path: Optional[Path] = None

    # ── Backward-compatible delegation to docling_parser module ─────────────
    # These thin wrappers preserve the historical PDFExtractor public API
    # so existing tests and external callers continue to work after the
    # parser-module split.  All real logic lives in `parsers/docling_parser.py`.

    @staticmethod
    def _normalize_docling_page(text: str) -> str:
        return docling_parser.normalize_docling_page(text)

    @classmethod
    def _split_trailing_page_markers(cls, content: str) -> dict[int, str]:
        return docling_parser.split_trailing_page_markers(content)

    @classmethod
    def _split_docling_batch_markdown(
        cls, markdown: str, expected_pages: int,
    ) -> Optional[list[str]]:
        return docling_parser.split_docling_batch_markdown(markdown, expected_pages)

    # ── Per-page progress logging (used by parsers via parsers.base) ────────

    @staticmethod
    def _log_page_capture(parser_name: str, page_number: int, page_count: int, text: str) -> None:
        """Backward-compatible wrapper around `parsers.base.log_page_capture`."""
        from parsers.base import log_page_capture
        log_page_capture(parser_name, page_number, page_count, text)

    # ── Page-offset detection (orchestrator-level utility, not a parser) ────

    @staticmethod
    def _try_extract_printed_page_number(clean: str) -> int | None:
        """Extract a likely printed page number from a header/footer line."""
        # Strategy 1: Entire line is a standalone number (ASCII digits only)
        if _STANDALONE_PAGE_NUM_RE.match(clean):
            n = int(clean)
            if 1 <= n <= 9999:
                return n

        # Strategy 2: Trailing number at end of line (ASCII digits only)
        match = _TRAILING_PAGE_NUM_RE.search(clean)
        if match:
            n = int(match.group(1))
            if 1 <= n <= 9999:
                return n

        return None

    @classmethod
    def detect_page_offset_from_pdf(cls, pdf_path: str, min_samples: int = 5) -> int:
        """Detect printed-vs-physical page offset directly from the original PDF.

        Uses PyMuPDF (fitz) to read the raw PDF text in content-stream order.
        This is independent of PARSE_TYPE — fitz always reads the PDF content
        stream directly, regardless of which markdown parser is configured.

        Args:
            pdf_path:    Path to the source PDF file.
            min_samples: Minimum agreeing pages needed for a reliable offset.
        """
        offsets: list[int] = []

        with fitz.open(pdf_path) as doc:
            for physical_idx, page in enumerate(doc, start=1):
                text = page.get_text("text") or ""
                lines = text.strip().splitlines()
                if not lines:
                    continue

                # Always scan header area first (6 lines) then footer (last 3).
                # fitz.get_text("text") returns lines in PDF content-stream order,
                # which is PDF-specific and unrelated to the configured parser.
                # For NCA-ECC and similar PDFs, the page-number footer element is
                # emitted first in the content stream and lands at raw line index 3
                # — outside a [:3] window.  Domain/section icon digits sit at the
                # tail of section-start pages, so footer-first scanning would grab
                # them before the real page number.  Header-first with a 6-line
                # window catches both without breaking PDFs where the page number
                # appears only at the tail.
                candidates = lines[:6] + lines[-3:]
                for line in candidates:
                    clean = _PAGE_NUMBER_STRIP_RE.sub('', line.strip()).strip()
                    if not clean:
                        continue

                    printed = cls._try_extract_printed_page_number(clean)
                    if printed is None:
                        continue

                    offset = physical_idx - printed
                    if 0 <= offset <= 50:
                        offsets.append(offset)
                        break
                    # Out of range (e.g., printed=2024 from a year-bearing
                    # header like "June 2024", or a large figure/chapter
                    # number). Keep scanning other candidate lines on this
                    # page rather than giving up. Previously we broke here,
                    # which silently failed detection on all dated PDFs in
                    # the frameworks/ directory (PCI DSS, NIST CSF, SWIFT).

        if len(offsets) < min_samples:
            logger.info(
                f"PDF page offset detection found {len(offsets)} sample(s); "
                "using offset=0"
            )
            return 0

        consensus, agreement = Counter(offsets).most_common(1)[0]
        if agreement / len(offsets) < 0.5:
            logger.warning(
                f"PDF page offset detection had low agreement ({agreement}/{len(offsets)}); "
                "using offset=0"
            )
            return 0

        if consensus:
            logger.info(
                f"PDF page offset detected from source PDF: offset={consensus} "
                f"({agreement}/{len(offsets)} pages agree)"
            )
        return consensus

    # ── Output management ───────────────────────────────────────────────────

    def load_output(self, job_dir: str | Path, total_pages: Optional[int] = None) -> None:
        """Attach this extractor instance to written page files."""
        if self._total_pages > 0:
            raise RuntimeError("Extractor already has loaded output. Create a new PDFExtractor instance.")

        resolved_job_dir = Path(job_dir).resolve()
        if not resolved_job_dir.exists():
            raise FileNotFoundError(f"Job directory not found: {resolved_job_dir}")

        combined_markdown_path = resolved_job_dir / "combined.md"
        if not combined_markdown_path.exists():
            raise FileNotFoundError(f"Combined markdown not found: {combined_markdown_path}")

        if total_pages is None:
            page_numbers: list[int] = []
            for page_file in resolved_job_dir.glob("pg_*.txt"):
                match = re.fullmatch(r"pg_(\d+)\.txt", page_file.name)
                if match:
                    page_numbers.append(int(match.group(1)))
            if not page_numbers:
                raise ValueError(f"No page files found in {resolved_job_dir}")
            total_pages = max(page_numbers)

        if total_pages < 1:
            raise ValueError(f"Invalid page count: {total_pages}")

        missing_pages = [
            pg for pg in range(1, total_pages + 1)
            if not (resolved_job_dir / f"pg_{pg}.txt").exists()
        ]
        if missing_pages:
            raise ValueError(
                f"Job directory is missing page files: "
                f"{missing_pages[:20]}{'...' if len(missing_pages) > 20 else ''}"
            )

        self._job_dir = resolved_job_dir
        self._combined_markdown_path = combined_markdown_path
        self._total_pages = int(total_pages)
        logger.info(f"Loaded PDF conversion output from: {resolved_job_dir} ({self._total_pages} pages)")

    def _resolve_job_dir(self, framework_name: str, job_id: str, work_dir: Optional[str]) -> Path:
        if not framework_name or not job_id:
            raise ValueError("framework_name and job_id must be non-empty strings")
        base_dir = Path(work_dir if work_dir else self._config.BLOB_STORAGE_DIR).resolve()
        job_dir = (base_dir / framework_name / job_id).resolve()
        if not job_dir.is_relative_to(base_dir):
            raise ValueError(
                f"framework_name or job_id escapes base directory: "
                f"{framework_name!r}, {job_id!r}"
            )
        return job_dir

    def _write_outputs(self, job_dir: Path, page_count: int, page_map: dict[int, str]) -> None:
        missing_pages = [pg for pg in range(1, page_count + 1) if pg not in page_map]
        if missing_pages:
            raise ValueError(
                f"{self._config.PARSE_TYPE} did not return all pages. Missing pages: "
                f"{missing_pages[:20]}{'...' if len(missing_pages) > 20 else ''}"
            )

        min_chars = self._config.PDF_MIN_CHARS_PER_PAGE
        total_chars = 0
        thin: List[int] = []
        for pg in range(1, page_count + 1):
            stripped = page_map[pg].strip()
            total_chars += len(stripped)
            if len(stripped) < min_chars:
                thin.append(pg)

        logger.info(
            f"PDF converted via {self._config.PARSE_TYPE}: {page_count} pages, {total_chars:,} chars"
        )
        if thin:
            logger.warning(f"Pages with thin content (<{min_chars} chars): {thin}")

        if job_dir.exists():
            shutil.rmtree(job_dir)
        job_dir.mkdir(parents=True, exist_ok=True)

        combined_markdown_path = job_dir / "combined.md"
        with combined_markdown_path.open("w", encoding="utf-8") as combined:
            for pg in range(1, page_count + 1):
                text = page_map[pg]
                (job_dir / f"pg_{pg}.txt").write_text(text, encoding="utf-8")
                if text.strip():
                    combined.write(f"{text}\n\n<!-- page={pg}/{page_count} -->\n\n")

        self._total_pages = page_count
        self._job_dir = job_dir
        self._combined_markdown_path = combined_markdown_path
        logger.info(f"Saved to: {job_dir} ({page_count} page files)")

    # ── Main entry point: dispatcher ────────────────────────────────────────

    def convert_pdf(
        self,
        pdf_path: str,
        framework_name: str,
        job_id: str,
        work_dir: Optional[str] = None,
        _force_parser: Optional[str] = None,
    ) -> None:
        """Convert a PDF to per-page markdown with disk persistence.

        Args:
            _force_parser: Override PARSE_TYPE for this call only.  Used by
                the subprocess crash fallback in tasks.py to retry with
                "fitz" when docling's C++ backend killed the subprocess.
                Accepted values: "docling", "fitz", "OpenDataLoaderPDF",
                "pymupdf4llm", "kreuzberg".
        """
        logger.info(f"Loading PDF: {pdf_path}")

        if self._total_pages > 0:
            raise RuntimeError("convert_pdf() already called. Create a new PDFExtractor instance.")

        pdf = Path(pdf_path)
        if not pdf.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        with fitz.open(pdf_path) as doc:
            if doc.is_encrypted:
                logger.error(f"Rejected encrypted PDF: {pdf_path}")
                raise ValueError("PDF is password-protected. Provide an unencrypted PDF.")
            page_count = len(doc)

        if page_count == 0:
            raise ValueError(f"PDF has 0 pages: {pdf_path}")

        max_pages = getattr(self._config, "PDF_MAX_PAGES", 0)
        if max_pages and page_count > max_pages:
            raise ValueError(
                f"PDF has {page_count} pages (maximum allowed: {max_pages})"
            )

        job_dir = self._resolve_job_dir(framework_name, job_id, work_dir)

        parse_type = _force_parser or self._config.PARSE_TYPE
        if _force_parser:
            logger.info(
                f"Parser override: using {_force_parser} instead of {self._config.PARSE_TYPE}"
            )

        # Dispatch via the parser registry — see parsers/__init__.py for the
        # available keys.  ValueError is raised for unknown PARSE_TYPE values
        # with a helpful message listing available parsers.
        parser_fn = get_parser(parse_type)
        page_map = parser_fn(pdf_path, page_count, self._config)

        self._write_outputs(job_dir, page_count, page_map)

    # ── Page-range extraction for downstream consumers ──────────────────────

    def extract_pages(self, start_page: int, end_page: int) -> str:
        if self._total_pages == 0:
            raise ValueError("No PDF conversion cached. Call convert_pdf() first.")

        total = self._total_pages
        if start_page < 1 or end_page > total or start_page > end_page:
            raise ValueError(f"Invalid page range {start_page}-{end_page} (PDF has {total} pages)")

        logger.debug(f"Extracting pages {start_page}–{end_page} of {total}")

        parts = []
        for pg in range(start_page, end_page + 1):
            page_file = self._job_dir / f"pg_{pg}.txt"
            try:
                text = page_file.read_text(encoding="utf-8").strip()
            except OSError as e:
                raise ValueError(f"Disk cache missing page {pg}: {e}") from e

            if text:
                parts.append(f"{text}\n\n<!-- page={pg}/{total} -->")

        content = "\n\n".join(parts)
        if len(content.strip()) < self._config.SUBCONTROL_MIN_CONTENT_CHARS:
            logger.warning(f"Pages {start_page}-{end_page}: only {len(content)} chars (below minimum)")

        return content

    # ── Accessors ───────────────────────────────────────────────────────────

    def get_total_pages(self) -> int:
        return self._total_pages

    def get_job_dir(self) -> Optional[Path]:
        return self._job_dir

    def get_combined_markdown_path(self) -> Optional[Path]:
        return self._combined_markdown_path

    # ── Context-manager protocol (no-op cleanup; output is on disk) ─────────

    def __enter__(self) -> "PDFExtractor":
        return self

    def __exit__(self, *_) -> None:
        pass
