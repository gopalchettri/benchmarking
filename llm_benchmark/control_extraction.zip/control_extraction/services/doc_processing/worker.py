"""
doc_processing Redis Stream Worker
=====================================
Starts an async consumer loop listening on the "doc_processing:stream" Redis Stream.

Run from the project root:
    python services/doc_processing/worker.py

Or with the venv:
    .\\venv\\Scripts\\python.exe services/doc_processing/worker.py

No fork() — fully async, native Windows support.
Requires: REDIS_URL in .env (e.g. redis://localhost:6379/0)
"""
import asyncio
import os
import sys

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, 'shared_core'))
sys.path.insert(0, os.path.dirname(__file__))

from shared_core.stream_client import consume_stream
from tasks import HANDLERS, DOC_STREAM, DOC_GROUP
from utils.logging_config import setup_logging, logger
from config import get_settings

settings = get_settings()
setup_logging(service_name=settings.APP_NAME_DOC_PROCESSING + " Worker", environment=settings.ENVIRONMENT)


async def main():
    logger.info(f"[doc_processing worker] Starting. Listening on stream={DOC_STREAM} group={DOC_GROUP}")
    await consume_stream(
        stream=DOC_STREAM,
        group=DOC_GROUP,
        handlers=HANDLERS,
    )


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("[doc_processing worker] Stopped by user.")
