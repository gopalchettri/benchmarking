"""
PDF Extractor
=============
Converts PDF to markdown with per-page mapping.
- Primary: pymupdf4llm.to_markdown(page_chunks=True) — preserves numbered list markers
  AND produces structured markdown (bold headers, list formatting) for better LLM quality.

Storage layout (under work_dir or BLOB_STORAGE_DIR from config):
  {base}/
    {framework_name}/
      {job_id}/
        pg_1.txt       <- per-page markdown files
        pg_2.txt
        ...
        _complete      <- sentinel written last; absence means a prior run crashed mid-write

When work_dir is provided (e.g. Azure mode), per-page files are written there as
intermediate artifacts. The caller is responsible for persisting them to blob storage.
When work_dir is omitted, files are written to BLOB_STORAGE_DIR (local mode).

Full PDF is converted ONCE via convert_pdf(). Subsequent extract_pages() calls read
directly from the per-page files on disk.
"""

import fitz          # PyMuPDF — PDF rendering and text extraction
import pymupdf4llm   # Structured markdown conversion with page chunking
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from utils.logging_config import logger

if TYPE_CHECKING:
    from config import Settings


class PDFExtractor:
    """PDF to markdown converter with permanent per-page disk persistence."""

    def __init__(self, config: "Settings"):
        self._config = config
        self._total_pages: int = 0              # 0 until convert_pdf() succeeds
        self._job_dir: Optional[Path] = None    # {BLOB_STORAGE_DIR}/{framework}/{job_id}/

    def convert_pdf(self, pdf_path: str, framework_name: str, job_id: str,
                    work_dir: Optional[str] = None) -> None:
        """
        Full PDF conversion. Saves per-page text files to a working directory.

        When *work_dir* is provided, per-page files are written under
        ``{work_dir}/{framework_name}/{job_id}/``.  When omitted, the default
        ``BLOB_STORAGE_DIR`` from config is used (backward-compatible).

        Conversion is skipped if the job directory already contains a _complete sentinel,
        which is written only after all files are successfully persisted. A directory without
        the sentinel indicates a prior run crashed mid-write and conversion will re-run.

        Args:
            pdf_path:       Path to the source PDF file
            framework_name: Framework name used as the top-level folder (e.g. "SAMA")
            job_id:         Unique job identifier used as the second-level folder
            work_dir:       Optional base directory for intermediate per-page files.
                            Defaults to BLOB_STORAGE_DIR when None.

        Raises:
            FileNotFoundError: PDF file does not exist
            ValueError: PDF is password-protected, empty, or framework_name/job_id escapes
                        base directory (path traversal)
            RuntimeError: Called more than once on the same instance
        """
        logger.info(f"Loading PDF: {pdf_path}")

        if self._total_pages > 0:
            raise RuntimeError("convert_pdf() already called. Create a new PDFExtractor instance.")

        pdf = Path(pdf_path)
        if not pdf.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        # Single fitz open: check encryption and get page count in one call (avoids 3× file opens)
        with fitz.open(pdf_path) as doc:
            if doc.is_encrypted:
                logger.error(f"Rejected encrypted PDF: {pdf_path}")
                raise ValueError("PDF is password-protected. Provide an unencrypted PDF.")
            page_count = len(doc)

        if page_count == 0:
            raise ValueError(f"PDF has 0 pages: {pdf_path}")

        max_pages = getattr(self._config, "PDF_MAX_PAGES", 0)
        if max_pages and page_count > max_pages:
            raise ValueError(
                f"PDF has {page_count} pages (maximum allowed: {max_pages})"
            )

        # Resolve and validate job directory.
        # Both sides are resolved so that:
        #   - Symlinked mount points (Docker volumes, K8s PVCs) are followed consistently
        #   - Relative BLOB_STORAGE_DIR values (e.g. "./parsed_pages") become absolute
        #   - ".." traversal and absolute-path injection are detected regardless of OS
        # is_relative_to() uses Path parts comparison — correct on Windows (case-insensitive),
        # Linux, and macOS without relying on string separators.
        if not framework_name or not job_id:
            raise ValueError("framework_name and job_id must be non-empty strings")
        base_dir = Path(work_dir if work_dir else self._config.BLOB_STORAGE_DIR).resolve()
        job_dir = (base_dir / framework_name / job_id).resolve()
        if not job_dir.is_relative_to(base_dir):
            raise ValueError(
                f"framework_name or job_id escapes base directory: "
                f"{framework_name!r}, {job_id!r}"
            )

        # Skip conversion only when _complete sentinel exists. job_dir.exists() alone is
        # insufficient: a crashed previous run leaves a partial directory that would cause
        # extract_pages() to fail with OSError on the missing pg_N.txt files.
        if (job_dir / "_complete").exists():
            logger.info(f"Job directory already exists, skipping conversion: {job_dir}")
            self._total_pages = page_count
            self._job_dir = job_dir
            return

        logger.info("Converting PDF via pymupdf4llm (structured markdown)...")
        chunks = pymupdf4llm.to_markdown(pdf_path, page_chunks=True)        
        page_map = {i + 1: chunk.get("text", "") for i, chunk in enumerate(chunks)}

        # Validate pymupdf4llm returned content for every page fitz reported
        if len(page_map) != page_count:
            logger.warning(
                f"Page count mismatch: fitz={page_count}, pymupdf4llm={len(page_map)} "
                f"— some pages may be absent from extraction"
            )

        # Single pass: compute total chars and identify thin pages (covers, dividers, scanned-only)
        min_chars = self._config.PDF_MIN_CHARS_PER_PAGE
        total_chars = 0
        thin: List[int] = []
        for pg, text in page_map.items():
            stripped = text.strip()
            total_chars += len(stripped)
            if len(stripped) < min_chars:
                thin.append(pg)
        thin.sort()

        logger.info(f"PDF converted: {page_count} pages, {total_chars:,} chars")
        if thin:
            logger.warning(f"Pages with thin content (<{min_chars} chars): {thin}")

        # Write all files. State committed only after all writes succeed —
        # prevents broken state if a write fails mid-way.
        job_dir.mkdir(parents=True, exist_ok=True)

        # Per-page text files
        for pg, text in page_map.items():
            (job_dir / f"pg_{pg}.txt").write_text(text, encoding="utf-8")

        # Sentinel — written last so a crash before this point forces re-conversion
        (job_dir / "_complete").touch()

        self._total_pages = page_count
        self._job_dir = job_dir
        logger.info(f"Saved to: {job_dir} ({page_count} page files)")

    def extract_pages(self, start_page: int, end_page: int) -> str:
        """
        Extract specific pages from the persisted markdown. 1-indexed, inclusive.

        Args:
            start_page: First page (1-indexed, inclusive)
            end_page: Last page (1-indexed, inclusive)

        Returns:
            Concatenated markdown for the page range

        Raises:
            ValueError: Invalid page range or convert_pdf() not yet called
        """
        if self._total_pages == 0:
            raise ValueError("No PDF conversion cached. Call convert_pdf() first.")

        total = self._total_pages
        if start_page < 1 or end_page > total or start_page > end_page:
            raise ValueError(f"Invalid page range {start_page}-{end_page} (PDF has {total} pages)")

        logger.debug(f"Extracting pages {start_page}–{end_page} of {total}")

        parts = []
        for pg in range(start_page, end_page + 1):
            page_file = self._job_dir / f"pg_{pg}.txt"
            try:
                text = page_file.read_text(encoding="utf-8").strip()
            except OSError as e:
                raise ValueError(f"Disk cache missing page {pg}: {e}") from e

            if text:
                # HTML comment marker: provides page context to the LLM without colliding
                # with real PDF content the way a plain "Page X of Y" string would.
                parts.append(f"{text}\n\n<!-- page={pg}/{total} -->")

        content = "\n\n".join(parts)
        if len(content.strip()) < self._config.SUBCONTROL_MIN_CONTENT_CHARS:
            logger.warning(f"Pages {start_page}-{end_page}: only {len(content)} chars (below minimum)")

        return content

    def get_total_pages(self) -> int:
        """Total page count from the PDF (set after successful convert_pdf())."""
        return self._total_pages

    def get_job_dir(self) -> Optional[Path]:
        """Path to the job directory holding all saved files. None before convert_pdf()."""
        return self._job_dir

    def __enter__(self) -> "PDFExtractor":
        return self

    def __exit__(self, *_) -> None:
        pass  # files are permanent; nothing to clean up
