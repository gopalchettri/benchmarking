"""
doc_processing task handlers
=============================
Plain async functions — no Celery, no RQ.
Dispatched via Redis Streams (shared_core.stream_client).

Worker reads tasks from the "doc_processing:stream" Redis Stream,
calls the matching handler, and ACKs on success.
"""
import asyncio
import hashlib
import os
import shutil
import sys
import tempfile
import threading
from pathlib import Path
from datetime import datetime, timezone
from config import get_settings
from conversion_subprocess import run_pdf_conversion_subprocess
from shared_core.constants import STATE_AI_EXTRACTION, STATE_DOC_PROCESSING_FAILED
from shared_core.redis_client import update_job_state
from shared_core.stream_client import publish_task

# Add project root to sys.path for imports
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, 'shared_core'))

# Import settings and constants
settings = get_settings()

# ── Stream name consumed by this service ─────────────────────────────────────
DOC_STREAM = settings.DOC_PROCESSING_STREAM
DOC_GROUP  = settings.DOC_PROCESSING_GROUP

# Singleton storage instance — avoids creating a new BlobServiceClient per call
# Thread-safe initialization via lock (matches config.py pattern)
_storage_instance = None
_storage_lock = threading.Lock()


def _get_storage():
    """Factory to get the configured FileStoragePort implementation (cached singleton)."""
    global _storage_instance
    if _storage_instance is not None:
        return _storage_instance
    with _storage_lock:
        if _storage_instance is not None:
            return _storage_instance
        from shared_core.interfaces.storage_port import LocalBlobStorage, AzureBlobStorage
        if settings.BLOB_BACKEND == "azure" and settings.AZURE_STORAGE_CONNECTION_STRING:
            _storage_instance = AzureBlobStorage(
                settings.AZURE_STORAGE_CONNECTION_STRING,
                settings.AZURE_BLOB_CONTAINER_NAME,
            )
        else:
            _storage_instance = LocalBlobStorage(settings.BLOB_STORAGE_DIR)
        return _storage_instance


def _sha256_file(path: str) -> str:
    """Compute SHA-256 of a file using chunked reads (avoids loading full file into memory)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


async def process_pdf(
    *,
    job_id: str,
    pdf_path: str,
    toc_start_page: int,
    toc_end_page: int,
    content_start_page: int,
    content_end_page: int,
    framework: str,
    framework_profile_id: str = "",
    toc_numbering: str = "printed",
    **_extra,            # absorb unknown fields gracefully
) -> None:
    """
    Heavy OCR extraction handler.
    Resolved from the Redis Stream by the worker loop.

    toc_numbering semantics:
    "printed"  (default) — toc_start_page / toc_end_page are the numbers
                            PRINTED in the document. Offset is applied to
                            convert them to physical PDF page indices.
    "physical"           — toc_start_page / toc_end_page are the PDF
                            reader's page counter (1-indexed physical
                            indices). No offset applied; used as-is.

    content_start_page / content_end_page are ALWAYS printed page numbers
    (read from the TOC entries themselves). Offset is always applied to
    them regardless of toc_numbering.
    """
    # Normalize + validate toc_numbering (defence-in-depth; FastAPI validator
    # covers the HTTP path, but the Redis Stream path bypasses it).
    if toc_numbering not in ("printed", "physical"):
        raise ValueError(
            f"Invalid toc_numbering={toc_numbering!r}; expected 'printed' or 'physical'"
        )

    from utils.logging_config import start_job_logging, stop_job_logging, get_job_logger
    from utils.progress import PhaseTracker
    start_job_logging(job_id, "doc_processing")
    job_log = get_job_logger(job_id)
    job_log.info(
        f"Starting document processing for pdf: {pdf_path}, "
        f"TOC pages: {toc_start_page}-{toc_end_page} ({toc_numbering}), "
        f"Content pages: {content_start_page}-{content_end_page} (printed)"
    )

    # Console-visible phase tracker. Weights are tuned to wall-clock share:
    # PDF conversion (Docling/pymupdf4llm/PyMuPDF) is by far the longest leg,
    # framework auto-detection is short, blob I/O is fast on local backends
    # but can be 1–2s each on Azure.
    progress = PhaseTracker("doc_processing", job_id, [
        ("Download PDF", 5),
        ("Hash + page-offset", 5),
        ("Convert PDF", 60),
        ("Save parsed markdown", 10),
        ("Framework auto-detect", 15),
        ("Hand off to AI extraction", 5),
    ])

    from shared_core.audit_client import log_audit

    tmp_dir = None

    try:
        await log_audit(action="job.doc_processing.started", entity_type="job", entity_id=job_id)

        # Update persistent job record
        from shared_core.job_client import update_job_record
        await update_job_record(job_id, status="processing", started_at=datetime.now(timezone.utc).isoformat(), framework=framework)
        use_azure = settings.BLOB_BACKEND == "azure" and settings.AZURE_STORAGE_CONNECTION_STRING
        storage = _get_storage()
        parsed_filename = f"{framework}/{job_id}/{job_id}_{framework}_parsed.md"

        with progress.phase("Download PDF"):
            tmp_dir = tempfile.mkdtemp(prefix=f"doc_{job_id}_")
            local_path = await asyncio.to_thread(storage.download_file, pdf_path, tmp_dir)

        with progress.phase("Hash + page-offset"):
            source_pdf_hash = await asyncio.to_thread(_sha256_file, local_path)
            job_log.info(f"PDF SHA-256: {source_pdf_hash}")

            from pdf_extractor import PDFExtractor
            page_offset = await asyncio.to_thread(
                PDFExtractor.detect_page_offset_from_pdf, local_path
            )
            job_log.info(f"Detected page offset={page_offset} from source PDF")

        # In Azure mode, write intermediate per-page files to the temp directory
        work_dir = tmp_dir if use_azure else None
        result_json_path = os.path.join(tmp_dir, f"conversion_result_{job_id}.json")

        progress_phase_convert = progress.phase("Convert PDF")
        progress_phase_convert.__enter__()
        try:
            conversion_result = await run_pdf_conversion_subprocess(
                pdf_path=local_path,
                framework_name=framework,
                job_id=job_id,
                result_json_path=result_json_path,
                work_dir=work_dir,
                timeout_seconds=settings.PDF_CONVERSION_TIMEOUT_SECONDS,
                terminate_grace_seconds=settings.PDF_CONVERSION_TERMINATE_GRACE_SECONDS,
                log_line=job_log.info,
            )
        except RuntimeError as subprocess_err:
            # Docling's C++ preprocessing stage can crash the subprocess on
            # pathological pages (std::bad_alloc → Windows 0xC0000005 access
            # violation).  Fall back to fitz (PyMuPDF), which uses a different
            # memory model than docling-parse and won't reproduce the same
            # crash.  The user's extraction proceeds with plain-text output
            # (no markdown layout), but no data is lost.
            error_str = str(subprocess_err)
            if "std::bad_alloc" in error_str or "3221225477" in error_str:
                job_log.warning(
                    f"Docling subprocess crashed (C++ memory error). "
                    f"Falling back to fitz for this document."
                )
                extractor = PDFExtractor(settings)
                await asyncio.to_thread(
                    extractor.convert_pdf,
                    local_path,
                    framework_name=framework,
                    job_id=job_id,
                    work_dir=work_dir,
                    _force_parser="fitz",
                )
            else:
                raise

            conversion_result = None  # signal that extractor is already loaded
        finally:
            progress_phase_convert.__exit__(None, None, None)

        if conversion_result is not None:
            extractor = PDFExtractor(settings)
            extractor.load_output(
                conversion_result.job_dir,
                total_pages=conversion_result.total_pages,
            )

        # Save the full parsed markdown to blob storage.
        # ai_extraction will fetch it by reference — large content is NOT
        # transmitted through Redis.
        saved_blob_path = ""
        total_pages = conversion_result.total_pages
        with progress.phase("Save parsed markdown"):
            if total_pages > 0:
                combined_markdown_path = Path(conversion_result.combined_markdown_path)
                if not combined_markdown_path.exists():
                    raise ValueError("Combined markdown path missing after PDF conversion")
                with combined_markdown_path.open("rb") as f:
                    saved_blob_path = await asyncio.to_thread(
                        storage.save_file, f, parsed_filename,
                    )
                job_log.info(f"Saved parsed markdown to storage: {saved_blob_path}")

                # Persist parsed blob path in job record
                from shared_core.job_client import update_job_record
                await update_job_record(job_id, parsed_blob_path=saved_blob_path)

        # --- Framework auto-detection if no profile provided ---
        detected_profile_id = framework_profile_id
        progress_phase_detect = progress.phase("Framework auto-detect")
        progress_phase_detect.__enter__()
        if not framework_profile_id:
            try:
                from framework_detector import detect_framework, fetch_profiles_for_detection

                # extract_pages() reads PHYSICAL pg_{N}.txt files from disk.
                # - TOC input: user may have given printed OR physical pages
                #   (controlled by toc_numbering). When "physical", use as-is;
                #   when "printed", add page_offset.
                # - Content input: always printed (read from the TOC entries
                #   themselves), so always add page_offset.
                # Values are clamped to valid PDF bounds to avoid ValueError
                # from extract_pages() on malformed input.
                total_phys = extractor.get_total_pages()

                def _clamp(start: int, end: int, original_start: int, original_end: int) -> tuple[int, int]:
                    phys_start = max(1, start)
                    phys_end = min(total_phys, end)
                    if phys_start > phys_end:
                        job_log.warning(
                            f"Auto-detect: requested pages {original_start}-{original_end} "
                            f"map to physical {phys_start}-{phys_end} (out of range "
                            f"for {total_phys}-page PDF). Clamping to PDF bounds."
                        )
                        return (
                            max(1, min(original_start, total_phys)),
                            max(1, min(original_end, total_phys)),
                        )
                    return phys_start, phys_end

                def _toc_to_physical(toc_s: int, toc_e: int) -> tuple[int, int]:
                    if toc_numbering == "physical":
                        return _clamp(toc_s, toc_e, toc_s, toc_e)
                    return _clamp(toc_s + page_offset, toc_e + page_offset, toc_s, toc_e)

                def _content_to_physical(c_s: int, c_e: int) -> tuple[int, int]:
                    # Content pages are always printed (from the TOC entries).
                    return _clamp(c_s + page_offset, c_e + page_offset, c_s, c_e)

                toc_content = ""
                if toc_start_page > 0 and toc_end_page > 0:
                    ts, te = _toc_to_physical(toc_start_page, toc_end_page)
                    toc_content = extractor.extract_pages(ts, te)
                cs, ce = _content_to_physical(content_start_page, content_end_page)
                control_content = extractor.extract_pages(cs, ce)

                profiles = await fetch_profiles_for_detection(
                    settings.STORAGE_SERVICE_URL, settings.API_V1_STR
                )
                detection_text = (toc_content + "\n" + control_content)
                result = detect_framework(
                    text=detection_text,
                    profiles=profiles,
                    confidence_threshold=settings.AUTODETECT_CONFIDENCE_THRESHOLD,
                )
                if result.detected:
                    detected_profile_id = result.selected_profile_id
                    job_log.info(
                        f"Auto-detected framework: {result.selected_profile_name} "
                        f"(confidence={result.confidence:.2f}, "
                        f"profile_id={detected_profile_id})"
                    )
                else:
                    job_log.warning(
                        f"Framework auto-detection inconclusive. "
                        f"Top candidates: "
                        f"{[(c.profile_name, f'{c.confidence:.2f}') for c in result.candidates[:3]]}"
                    )
            except Exception as e:
                job_log.warning(f"Framework auto-detection failed (non-fatal): {e}")
        progress_phase_detect.__exit__(None, None, None)

        with progress.phase("Hand off to AI extraction"):
            await update_job_state(job_id, STATE_AI_EXTRACTION)

            # Forward to AI Extraction via Redis Stream.
            # Pass a blob reference + page ranges — not the raw content strings.
            # toc_pages="" when user signalled "no TOC" (start=0 and end=0); ai_extraction
            # treats the empty string as "skip TOC extraction" rather than slicing page 1.
            toc_pages_payload = (
                "" if (toc_start_page == 0 and toc_end_page == 0)
                else f"{toc_start_page}-{toc_end_page}"
            )
            await publish_task(
                stream=settings.AI_EXTRACTION_STREAM,
                task_name="extract_controls",
                payload={
                    "framework": framework,
                    "parsed_blob_path": saved_blob_path,
                    "toc_pages": toc_pages_payload,
                    "content_pages": f"{content_start_page}-{content_end_page}",
                    "framework_profile_id": detected_profile_id or framework_profile_id,
                    "source_pdf_hash": source_pdf_hash,
                    "page_offset": page_offset,
                    "toc_numbering": toc_numbering,
                },
                job_id=job_id,
            )
            job_log.info(f"[doc_processing] process_pdf done  job_id={job_id}")
            await log_audit(action="job.doc_processing.completed", entity_type="job", entity_id=job_id)
        progress.done(f"parsed {total_pages} pages → ai_extraction queue")

    except Exception as exc:
        # Sanitize error before storing in Redis — Azure SDK exceptions can
        # embed endpoint URLs and partial auth headers in str(exc).
        import re as _re
        safe_error = _re.sub(r'https?://\S+', '[URL]', f"{type(exc).__name__}: {str(exc)[:300]}")
        await update_job_state(job_id, STATE_DOC_PROCESSING_FAILED)
        from shared_core.job_client import update_job_record
        await update_job_record(job_id, status="failed", error_message=safe_error)
        job_log.error(f"[doc_processing] process_pdf failed  job_id={job_id}: {safe_error}")
        await log_audit(action="job.doc_processing.failed", entity_type="job", entity_id=job_id, details={"error": safe_error})
        raise
    finally:
        # Clean up per-job temp directory
        if tmp_dir:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        stop_job_logging(job_id)


# ── Handler registry ─────────────────────────────────────────────────────────
HANDLERS = {
    "process_pdf": process_pdf,
}
