"""
Pre-download docling ML models for offline use.
================================================
Run once before starting the doc-processing service, or as part of a
Docker image build / Kubernetes init-container:

    python services/doc_processing/download_models.py
    python services/doc_processing/download_models.py --artifacts-path /opt/docling_models
    python services/doc_processing/download_models.py --force   # re-download

After the download completes, set DOCLING_ARTIFACTS_PATH in your .env to the
printed directory path.  The doc-processing service will then load models from
the local filesystem with zero network calls at conversion time.

Models downloaded (used by the standard PDF pipeline with OCR disabled):
  - DocLayNet        (docling-project/docling-layout-heron, ~164 MB)
      Detects text blocks, tables, figures, and headings via layout analysis.
  - TableFormer      (docling-project/docling-models, ~342 MB)
      Reconstructs row/column structure inside detected table regions.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path

# Project root on sys.path so config can be imported without installing the package.
_HERE = Path(__file__).resolve().parent
_BASE = _HERE.parent.parent
sys.path.insert(0, str(_BASE))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Model registry
# Each entry maps the docling model class to the local subfolder name that
# PipelineOptions.artifacts_path expects.  The subfolder name is the canonical
# "model_repo_folder" used by docling — it must match exactly.
# ---------------------------------------------------------------------------
_LAYOUT_REPO_ID = "docling-project/docling-layout-heron"
_LAYOUT_REVISION = "main"
_LAYOUT_FOLDER   = "docling-project--docling-layout-heron"
_LAYOUT_MIN_MB   = 80          # safetensors alone is ~164 MB; allow ≥50 % present

_TABLE_REPO_ID   = "docling-project/docling-models"
_TABLE_REVISION  = "v2.3.0"
_TABLE_FOLDER    = "docling-project--docling-models"
_TABLE_MIN_MB    = 150         # both tableformer variants together are ~342 MB


def _dir_size_mb(directory: Path) -> float:
    """Recursively compute total size of a directory in megabytes."""
    return sum(f.stat().st_size for f in directory.rglob("*") if f.is_file()) / (1024 * 1024)


def _model_present(model_dir: Path, min_mb: float) -> bool:
    """Return True when *model_dir* exists and its content passes a size floor check.

    The floor is set at 50 % of the expected size to handle minor revision differences
    while still catching empty or partially downloaded directories.
    """
    if not model_dir.is_dir():
        return False
    # A directory with no files (e.g. only empty subdirs) is not present.
    if not any(model_dir.rglob("*.safetensors")):
        return False
    actual_mb = _dir_size_mb(model_dir)
    return actual_mb >= min_mb


def _download_one(
    *,
    name: str,
    repo_id: str,
    revision: str,
    local_dir: Path,
    force: bool,
    min_mb: float,
) -> None:
    """Download a single HuggingFace model repo to *local_dir*.

    When *local_dir* already passes the size check and *force* is False, the
    download is skipped.  HuggingFace's snapshot_download uses ETag-based
    resumption, so interrupted downloads finish rather than restart.
    """
    from docling.utils.model_downloader import download_hf_model

    if not force and _model_present(local_dir, min_mb):
        logger.info(
            "[SKIP] %-40s already present (%.0f MB) — %s",
            name,
            _dir_size_mb(local_dir),
            local_dir,
        )
        return

    action = "Re-downloading" if local_dir.exists() else "Downloading"
    logger.info(
        "[DOWN] %s %s  repo=%s  rev=%s ...",
        action,
        name,
        repo_id,
        revision,
    )
    local_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.monotonic()
    download_hf_model(
        repo_id=repo_id,
        revision=revision,
        local_dir=local_dir,
        progress=True,    # show tqdm progress bars
        force=force,
    )
    elapsed = time.monotonic() - t0
    size_mb = _dir_size_mb(local_dir)
    logger.info(
        "[DONE] %s — %.0f MB  (%.0fs)  path=%s",
        name,
        size_mb,
        elapsed,
        local_dir,
    )


def download_docling_models(artifacts_path: Path, *, force: bool = False) -> None:
    """Download all docling models required by the standard PDF pipeline.

    Idempotent: skips any model whose directory already exists and passes the
    minimum-size sanity check, unless *force=True*.

    Directory structure created under *artifacts_path*::

        artifacts_path/
          docling-project--docling-layout-heron/   ← layout model files (flat)
          docling-project--docling-models/          ← tableformer model files (flat)

    This flat structure is exactly what ``PipelineOptions.artifacts_path``
    expects; no ``snapshots/`` subdirectory is created.
    """
    artifacts_path.mkdir(parents=True, exist_ok=True)
    logger.info("Artifacts directory: %s", artifacts_path)

    _download_one(
        name="DocLayNet (layout analysis)",
        repo_id=_LAYOUT_REPO_ID,
        revision=_LAYOUT_REVISION,
        local_dir=artifacts_path / _LAYOUT_FOLDER,
        force=force,
        min_mb=_LAYOUT_MIN_MB,
    )
    _download_one(
        name="TableFormer (table structure)",
        repo_id=_TABLE_REPO_ID,
        revision=_TABLE_REVISION,
        local_dir=artifacts_path / _TABLE_FOLDER,
        force=force,
        min_mb=_TABLE_MIN_MB,
    )


def verify_docling_models(artifacts_path: Path) -> bool:
    """Validate that *artifacts_path* contains all required model subdirectories.

    Returns True when the directory is ready for use as ``DOCLING_ARTIFACTS_PATH``.
    Logs a warning for each missing or undersized model directory.
    """
    all_ok = True
    for folder, min_mb, label in (
        (_LAYOUT_FOLDER, _LAYOUT_MIN_MB, "DocLayNet"),
        (_TABLE_FOLDER,  _TABLE_MIN_MB,  "TableFormer"),
    ):
        model_dir = artifacts_path / folder
        if _model_present(model_dir, min_mb):
            logger.info("[OK]   %-40s %.0f MB  %s", label, _dir_size_mb(model_dir), model_dir)
        else:
            logger.warning(
                "[FAIL] %-40s not found or too small (need ≥%.0f MB) — %s",
                label,
                min_mb,
                model_dir,
            )
            all_ok = False
    return all_ok


def _resolve_artifacts_path(cli_path: str | None) -> Path:
    """Resolve the artifacts directory from (in priority order):

    1. ``--artifacts-path`` CLI argument
    2. ``DOCLING_ARTIFACTS_PATH`` from .env (via config)
    3. ``./docling_models/`` next to this script (default)
    """
    if cli_path:
        return Path(cli_path).resolve()

    try:
        from config import get_settings
        env_val = getattr(get_settings(), "DOCLING_ARTIFACTS_PATH", "") or ""
        if env_val.strip():
            return Path(env_val.strip()).resolve()
    except Exception:
        pass  # config not yet configured — fall through to default

    return (_HERE / "docling_models").resolve()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Pre-download docling models for offline use.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "After downloading, add this line to your .env file:\n"
            "  DOCLING_ARTIFACTS_PATH=<printed directory path>\n\n"
            "Docling will then load models locally with no HuggingFace network calls."
        ),
    )
    parser.add_argument(
        "--artifacts-path",
        metavar="DIR",
        help=(
            "Directory to store models. "
            "Defaults to DOCLING_ARTIFACTS_PATH from .env, or ./docling_models."
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-download even if models already exist.",
    )
    parser.add_argument(
        "--verify",
        action="store_true",
        help="Check whether models are present without downloading.",
    )
    args = parser.parse_args()

    artifacts_path = _resolve_artifacts_path(args.artifacts_path)

    if args.verify:
        logger.info("Verifying docling models at: %s", artifacts_path)
        ok = verify_docling_models(artifacts_path)
        if ok:
            logger.info("All models present and ready.")
        else:
            logger.error(
                "One or more models missing. Run without --verify to download them."
            )
        return 0 if ok else 1

    logger.info("Target directory: %s", artifacts_path)
    t_start = time.monotonic()
    download_docling_models(artifacts_path, force=args.force)
    total_elapsed = time.monotonic() - t_start

    logger.info("")
    ok = verify_docling_models(artifacts_path)
    if not ok:
        logger.error("Verification failed after download — check network or disk space.")
        return 1

    total_mb = _dir_size_mb(artifacts_path)
    logger.info("")
    logger.info("All docling models ready — %.0f MB total (%.0fs)", total_mb, total_elapsed)
    logger.info("")
    logger.info("Add to your .env:")
    logger.info("  DOCLING_ARTIFACTS_PATH=%s", artifacts_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
