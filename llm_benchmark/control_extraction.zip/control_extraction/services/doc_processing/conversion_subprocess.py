"""Helpers for running PDF conversion in a killable subprocess."""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import signal
import subprocess
import sys
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class PDFConversionResult:
    """Metadata emitted by the isolated PDF conversion subprocess."""

    combined_markdown_path: str
    job_dir: str
    total_pages: int


def build_pdf_conversion_command(
    *,
    pdf_path: str,
    framework_name: str,
    job_id: str,
    result_json_path: str,
    work_dir: str | None = None,
) -> list[str]:
    """Build the command line used to invoke the conversion runner."""
    if not sys.executable:
        raise RuntimeError("sys.executable is empty; cannot launch PDF conversion subprocess")

    runner_path = Path(__file__).with_name("conversion_runner.py")
    if not runner_path.exists():
        raise FileNotFoundError(f"PDF conversion runner not found: {runner_path}")

    command = [
        sys.executable,
        str(runner_path),
        "--pdf-path",
        pdf_path,
        "--framework-name",
        framework_name,
        "--job-id",
        job_id,
        "--result-json",
        result_json_path,
    ]
    if work_dir:
        command.extend(["--work-dir", work_dir])
    return command


async def _relay_subprocess_stream(
    stream: asyncio.StreamReader | None,
    *,
    log_line: Callable[[str], None],
    prefix: str,
    tail: deque[str],
) -> None:
    """Forward child-process output into the parent job log."""
    if stream is None:
        return

    while True:
        line = await stream.readline()
        if not line:
            break
        text = line.decode("utf-8", errors="replace").rstrip()
        if not text:
            continue
        tail.append(text)
        log_line(f"[pdf_conversion:{prefix}] {text}")


def _format_tail(lines: deque[str]) -> str:
    if not lines:
        return ""
    return " | ".join(lines)


async def _terminate_subprocess(
    process: asyncio.subprocess.Process,
    *,
    grace_seconds: int,
    log_line: Callable[[str], None],
) -> None:
    """Terminate the subprocess and, where possible, its child process tree."""
    if process.returncode is not None:
        return

    if os.name == "nt":
        log_line(f"Terminating PDF conversion subprocess pid={process.pid} on Windows")
        process.terminate()
        try:
            await asyncio.wait_for(process.wait(), timeout=grace_seconds)
            return
        except asyncio.TimeoutError:
            log_line(f"Force-killing PDF conversion subprocess tree pid={process.pid}")
            killer = await asyncio.create_subprocess_exec(
                "taskkill",
                "/PID",
                str(process.pid),
                "/T",
                "/F",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await killer.wait()
            with contextlib.suppress(ProcessLookupError):
                process.kill()
            await process.wait()
        return

    log_line(f"Terminating PDF conversion subprocess group pid={process.pid}")
    with contextlib.suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGTERM)
    try:
        await asyncio.wait_for(process.wait(), timeout=grace_seconds)
        return
    except asyncio.TimeoutError:
        log_line(f"Force-killing PDF conversion subprocess group pid={process.pid}")
        with contextlib.suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
        await process.wait()


async def run_pdf_conversion_subprocess(
    *,
    pdf_path: str,
    framework_name: str,
    job_id: str,
    result_json_path: str,
    work_dir: str | None,
    timeout_seconds: int,
    terminate_grace_seconds: int,
    log_line: Callable[[str], None],
) -> PDFConversionResult:
    """Run PDF conversion in a subprocess with enforced timeout and logging."""
    result_path = Path(result_json_path)
    with contextlib.suppress(FileNotFoundError):
        result_path.unlink()

    command = build_pdf_conversion_command(
        pdf_path=pdf_path,
        framework_name=framework_name,
        job_id=job_id,
        result_json_path=result_json_path,
        work_dir=work_dir,
    )

    popen_kwargs: dict[str, object] = {
        "stdout": asyncio.subprocess.PIPE,
        "stderr": asyncio.subprocess.PIPE,
    }
    if os.name == "nt":
        popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        popen_kwargs["start_new_session"] = True

    log_line(
        f"Launching PDF conversion subprocess for job={job_id} "
        f"parser command={Path(command[0]).name}"
    )
    process = await asyncio.create_subprocess_exec(*command, **popen_kwargs)

    stdout_tail: deque[str] = deque(maxlen=20)
    stderr_tail: deque[str] = deque(maxlen=40)
    stdout_task = asyncio.create_task(
        _relay_subprocess_stream(
            process.stdout,
            log_line=log_line,
            prefix="stdout",
            tail=stdout_tail,
        )
    )
    stderr_task = asyncio.create_task(
        _relay_subprocess_stream(
            process.stderr,
            log_line=log_line,
            prefix="stderr",
            tail=stderr_tail,
        )
    )

    try:
        await asyncio.wait_for(process.wait(), timeout=timeout_seconds)
    except asyncio.TimeoutError as exc:
        log_line(
            f"PDF conversion subprocess timed out after {timeout_seconds}s "
            f"(pid={process.pid})"
        )
        await _terminate_subprocess(
            process,
            grace_seconds=terminate_grace_seconds,
            log_line=log_line,
        )
        raise TimeoutError(
            f"PDF conversion exceeded {timeout_seconds}s and the subprocess was terminated"
        ) from exc
    except asyncio.CancelledError:
        log_line(f"Parent task cancelled while PDF conversion subprocess pid={process.pid} was running")
        await _terminate_subprocess(
            process,
            grace_seconds=terminate_grace_seconds,
            log_line=log_line,
        )
        raise
    finally:
        await asyncio.gather(stdout_task, stderr_task, return_exceptions=True)

    if process.returncode != 0:
        detail = _format_tail(stderr_tail) or _format_tail(stdout_tail)
        message = (
            f"PDF conversion subprocess exited with code {process.returncode} "
            f"for job {job_id}"
        )
        if detail:
            message = f"{message}: {detail[:500]}"
        raise RuntimeError(message)

    if not result_path.exists():
        raise RuntimeError(
            f"PDF conversion subprocess completed for job {job_id} "
            f"but did not write result metadata"
        )

    try:
        payload = json.loads(result_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"PDF conversion subprocess wrote invalid result metadata for job {job_id}"
        ) from exc

    try:
        result = PDFConversionResult(
            combined_markdown_path=str(payload["combined_markdown_path"]),
            job_dir=str(payload["job_dir"]),
            total_pages=int(payload["total_pages"]),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise RuntimeError(
            f"PDF conversion subprocess wrote incomplete result metadata for job {job_id}"
        ) from exc

    return result
