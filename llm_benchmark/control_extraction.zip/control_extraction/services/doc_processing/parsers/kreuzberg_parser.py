"""
Kreuzberg Parser
================
Markdown extraction with per-page output via the Kreuzberg library.

Kreuzberg is a third-party PDF parser that emits structured markdown.
Page entries may be returned as either dicts or objects depending on
the library version, so we normalize via `_page_number_and_content()`.

Lazy-imports `kreuzberg` inside `convert()` to keep the parser registry
cheap.
"""
from __future__ import annotations

from utils.logging_config import logger
from .base import log_page_capture


def _page_number_and_content(page) -> tuple[int, str]:
    """Normalize Kreuzberg page entries across dict/object return shapes."""
    if isinstance(page, dict):
        return int(page["page_number"]), page.get("content", "")
    return int(page.page_number), getattr(page, "content", "")


def convert(pdf_path: str, page_count: int, config=None) -> dict[int, str]:
    """Convert a PDF to per-page markdown via Kreuzberg.

    Args:
        pdf_path:   Absolute path to the PDF file.
        page_count: Expected total page count from the orchestrator.
        config:     Unused (kreuzberg config is constructed inline).

    Returns:
        Dict mapping page numbers (as reported by Kreuzberg) to markdown
        content.  Page numbers are 1-indexed by Kreuzberg's contract.
    """
    from kreuzberg import ExtractionConfig, PageConfig, extract_file_sync

    logger.info("Converting PDF via kreuzberg (markdown + per-page extraction)...")
    extraction_config = ExtractionConfig(
        output_format="markdown",
        pages=PageConfig(extract_pages=True),
    )
    result = extract_file_sync(pdf_path, config=extraction_config)
    page_map: dict[int, str] = {}
    for page in (result.pages or []):
        page_number, content = _page_number_and_content(page)
        page_map[page_number] = content
        log_page_capture("Kreuzberg", page_number, page_count, content)
    return page_map
