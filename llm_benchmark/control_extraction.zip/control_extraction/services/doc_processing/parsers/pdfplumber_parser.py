"""
pdfplumber Parser
=================
Per-page text + table extraction via the `pdfplumber` library.

pdfplumber's strength is table detection via geometric line analysis —
for compliance frameworks whose content lives in tables (ISO Annex A,
NIST CSF subcategory grids, PCI-DSS requirement matrices), it can
produce cleaner table output than fitz's pure-text extraction because
it reconstructs row/column structure from PDF rules rather than guessing
from glyph positions.

Its weakness is speed (~3-5x slower than fitz) and the absence of a
native markdown exporter, so we render detected tables as GitHub-flavored
markdown ourselves.  Body text is extracted via `page.extract_text()`,
then any detected tables are appended after the page text.

Lazy-imports `pdfplumber` inside `convert()` to keep the parser registry
cheap — pdfplumber pulls in pdfminer.six which is slow to import.
"""
from __future__ import annotations

from utils.logging_config import logger
from .base import log_page_capture


def _table_to_markdown(table: list[list]) -> str:
    """Render a pdfplumber-extracted table (list-of-lists) as GFM markdown.

    Returns an empty string for tables with no header row or no cells.
    Cell text is normalized: `None` → empty, embedded pipes escaped,
    embedded newlines collapsed to spaces (GFM tables don't support
    multi-line cells).  Short rows are right-padded to header width so
    the rendered markdown stays rectangular.
    """
    if not table or not table[0]:
        return ""

    def _clean(cell) -> str:
        if cell is None:
            return ""
        return str(cell).replace("|", "\\|").replace("\n", " ").strip()

    header = [_clean(c) for c in table[0]]
    width = len(header)
    if width == 0:
        return ""

    lines = [
        "| " + " | ".join(header) + " |",
        "|" + "|".join(["---"] * width) + "|",
    ]
    for row in table[1:]:
        cells = [_clean(c) for c in row]
        if len(cells) < width:
            cells.extend([""] * (width - len(cells)))
        elif len(cells) > width:
            cells = cells[:width]
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def convert(pdf_path: str, page_count: int, config=None) -> dict[int, str]:
    """Convert a PDF to per-page text + rendered tables via pdfplumber.

    Args:
        pdf_path:   Absolute path to the PDF file.
        page_count: Expected total page count from the orchestrator.
        config:     Unused (pdfplumber takes no configuration here;
                    future: expose table_settings via Settings if needed).

    Returns:
        Dict mapping 1-indexed page numbers to extracted text.  Every
        index from 1 to page_count is populated (empty string when a
        page has neither text nor tables).  Text and tables are joined
        with a blank line; tables always appear AFTER the page's prose.
    """
    import pdfplumber

    logger.info(
        f"Converting {page_count}-page PDF via pdfplumber "
        f"(text + table detection)..."
    )
    page_map: dict[int, str] = {}
    with pdfplumber.open(pdf_path) as pdf:
        n = min(len(pdf.pages), page_count)
        for idx in range(1, n + 1):
            page = pdf.pages[idx - 1]
            try:
                text = page.extract_text() or ""
            except Exception as exc:
                logger.warning(f"pdfplumber page {idx}: text extraction failed: {exc}")
                text = ""

            try:
                tables = page.extract_tables() or []
            except Exception as exc:
                logger.warning(f"pdfplumber page {idx}: table extraction failed: {exc}")
                tables = []

            parts: list[str] = []
            if text.strip():
                parts.append(text.strip())
            for tbl in tables:
                md = _table_to_markdown(tbl)
                if md:
                    parts.append(md)

            page_map[idx] = "\n\n".join(parts)
            log_page_capture("pdfplumber", idx, page_count, page_map[idx])

    # Backfill any indices the loop didn't reach (e.g., PDF has fewer
    # pages than the orchestrator's pre-validation reported) so the
    # every-page-present invariant in _write_outputs holds.
    for idx in range(1, page_count + 1):
        page_map.setdefault(idx, "")
    return page_map
