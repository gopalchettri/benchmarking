"""
PDF Parser Registry
===================
Each parser lives in its own module and exposes a `convert(pdf_path,
page_count, config) -> dict[int, str]` function.  See `base.py` for the
full parser contract.

The PARSERS dict maps PARSE_TYPE configuration values to parser
functions.  The orchestrator (pdf_extractor.py) uses this as a dispatch
table — adding a new parser is a one-line registry entry plus a new
parser module.

Parser modules are NOT eagerly imported here — the registry uses module
references that perform their heavy library imports only inside
`convert()`.  This keeps `import parsers` cheap (~milliseconds rather
than seconds for docling/torch loading).
"""
from __future__ import annotations

from typing import Callable, Dict

from . import (
    docling_parser,
    fitz_parser,
    kreuzberg_parser,
    opendataloader_parser,
    pdfplumber_parser,
    pymupdf4llm_parser,
)

# Type alias for the parser convert function signature.
ParserFn = Callable[[str, int, object], dict[int, str]]

# Registry: PARSE_TYPE value → parser convert function.
# Keys MUST match the values accepted by the `PARSE_TYPE` config Literal
# in `config.py`.  Operators select a parser by setting `PARSE_TYPE` in
# `.env`; the orchestrator's `_force_parser` argument also accepts these
# keys for runtime overrides (e.g., subprocess crash fallback in tasks.py).
PARSERS: Dict[str, ParserFn] = {
    "docling":           docling_parser.convert,
    "fitz":              fitz_parser.convert,
    "OpenDataLoaderPDF": opendataloader_parser.convert,
    "kreuzberg":         kreuzberg_parser.convert,
    "pdfplumber":        pdfplumber_parser.convert,
    "pymupdf4llm":       pymupdf4llm_parser.convert,
}


def get_parser(parse_type: str) -> ParserFn:
    """Return the parser convert function for the given PARSE_TYPE.

    Raises:
        ValueError: If `parse_type` is not a registered parser key.
            The exception message lists all available parsers.
    """
    fn = PARSERS.get(parse_type)
    if fn is None:
        available = ", ".join(sorted(PARSERS.keys()))
        raise ValueError(
            f"Unsupported PARSE_TYPE: {parse_type!r}. "
            f"Available parsers: {available}"
        )
    return fn


__all__ = [
    "PARSERS",
    "ParserFn",
    "get_parser",
    "docling_parser",
    "fitz_parser",
    "kreuzberg_parser",
    "opendataloader_parser",
    "pdfplumber_parser",
    "pymupdf4llm_parser",
]
