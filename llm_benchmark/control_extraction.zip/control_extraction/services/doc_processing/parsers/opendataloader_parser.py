"""
OpenDataLoaderPDF Parser
========================
Markdown extraction via the OpenDataLoaderPDF Java CLI.

OpenDataLoaderPDF is a Python wrapper around a bundled Java JAR.  It
requires a JRE on PATH and runs as a subprocess (~1-2s JVM startup
per invocation).  Useful as an alternative to docling for documents
that trigger docling's C++ memory issues.

The CLI writes its output to a markdown file in a temp directory; we
read that file, split it by HTML-comment page markers we requested via
the `markdown_page_separator` parameter, and return the per-page dict.

Lazy-imports `opendataloader_pdf` inside `convert()` to keep the parser
registry cheap.
"""
from __future__ import annotations

import concurrent.futures
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

from utils.logging_config import logger
from .base import log_page_capture


# Page-separator template passed to opendataloader's `markdown_page_separator`.
# `%page-number%` is interpolated by the CLI with the current page number,
# producing markers like `<!-- ODL_PAGE=1 -->` between pages.  The marker
# format intentionally differs from docling's `<!-- page=N/T -->` so the
# two never collide if mixed in downstream processing.
_PAGE_SEPARATOR_TEMPLATE = "<!-- ODL_PAGE=%page-number% -->"
_PAGE_SEPARATOR_RE = re.compile(r"<!--\s*ODL_PAGE=(\d+)\s*-->")


# Module-level cache for the Java availability check.  The result does
# not change at runtime, so we run `java -version` exactly once per
# process and cache the boolean.
_java_available_cache: Optional[bool] = None


def is_java_available() -> bool:
    """Return True if the `java` executable can be invoked.

    Uses `subprocess.run(["java", "-version"])` rather than `shutil.which`
    because we want to verify the binary is actually executable, not just
    findable on PATH (e.g. broken symlinks would pass `which` but fail at
    invocation time).

    The result is cached at module level — this is safe because Java's
    location does not change at runtime, and the check costs ~50ms on
    Windows (subprocess startup).
    """
    global _java_available_cache
    if _java_available_cache is not None:
        return _java_available_cache
    try:
        from config import get_settings
        settings = get_settings()
        result = subprocess.run(
            ["java", "-version"],
            capture_output=True,
            timeout=settings.JAVA_DETECTION_TIMEOUT_SECONDS,
        )
        _java_available_cache = (result.returncode == 0)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        _java_available_cache = False
    return _java_available_cache


def reset_java_availability_cache() -> None:
    """Reset the Java availability cache (test-only helper)."""
    global _java_available_cache
    _java_available_cache = None


def split_markdown(markdown: str, page_count: int) -> dict[int, str]:
    """Split OpenDataLoaderPDF markdown output by `<!-- ODL_PAGE=N -->` markers.

    The markers are placed BETWEEN pages by the CLI's
    `markdown_page_separator` argument.  Each marker number refers to the
    page that JUST ENDED, so the chunk AFTER a marker belongs to the
    next page.

    Layout:
        Page 1 content
        <!-- ODL_PAGE=1 -->        ← page 1 ends here
        Page 2 content
        <!-- ODL_PAGE=2 -->        ← page 2 ends here
        Page 3 content             ← (no trailing marker — last page)

    Pages with no extracted content yield empty strings.  All page
    indices 1..page_count are guaranteed present in the result.
    """
    page_map: dict[int, str] = {pg: "" for pg in range(1, page_count + 1)}
    matches = list(_PAGE_SEPARATOR_RE.finditer(markdown))
    if not matches:
        # No separators found — opendataloader didn't emit page markers
        # OR the document is single-page.  Put everything on page 1.
        page_map[1] = markdown.strip()
        return page_map

    # Content before the first marker is page 1
    first_chunk = markdown[: matches[0].start()].strip()
    if first_chunk:
        page_map[1] = first_chunk

    # Walk markers in order: chunk AFTER marker(N) belongs to page (N+1).
    for i, m in enumerate(matches):
        page_num = int(m.group(1))
        if not (1 <= page_num <= page_count):
            continue
        content_start = m.end()
        content_end = matches[i + 1].start() if i + 1 < len(matches) else len(markdown)
        chunk = markdown[content_start:content_end].strip()
        target = page_num + 1
        if 1 <= target <= page_count and chunk:
            # Append (don't overwrite) to handle the edge case where two
            # markers somehow bracket the same logical page.
            if page_map[target]:
                page_map[target] = page_map[target] + "\n\n" + chunk
            else:
                page_map[target] = chunk
    return page_map


def _resolve_settings(config):
    """Return the Settings-like object to read timeouts/thresholds from.

    Callers may pass the live config object from the orchestrator.  When
    they don't (legacy paths, tests), fall back to the global Settings
    singleton.  A single indirection here keeps the convert() body from
    doing conditional imports inline.
    """
    if config is not None:
        return config
    from config import get_settings
    return get_settings()


def convert(pdf_path: str, page_count: int, config=None) -> dict[int, str]:
    """Convert a PDF to per-page markdown via OpenDataLoaderPDF.

    Args:
        pdf_path:   Absolute path to the PDF file.
        page_count: Expected total page count from the orchestrator.
        config:     Settings-like object.  Reads OPENDATALOADER_TIMEOUT_SECONDS
                    and OPENDATALOADER_MIN_OUTPUT_CHARS.  When None, the
                    global singleton is used.

    Returns:
        Dict mapping 1-indexed page numbers to markdown content.

    Raises:
        RuntimeError: If Java is not available on PATH, the Java CLI
            exceeds the per-document timeout, the conversion fails, the
            expected output file is not produced, or the output is too
            small to be considered a successful extraction.
    """
    import opendataloader_pdf

    if not is_java_available():
        raise RuntimeError(
            "OpenDataLoaderPDF requires Java but the 'java' command was "
            "not found on PATH.  Install JRE 17+ and ensure java is on "
            "PATH, or change PARSE_TYPE to a parser that doesn't need Java."
        )

    settings = _resolve_settings(config)
    timeout_s = float(settings.OPENDATALOADER_TIMEOUT_SECONDS)
    min_output_chars = int(settings.OPENDATALOADER_MIN_OUTPUT_CHARS)

    logger.info(
        f"Converting {page_count}-page PDF via OpenDataLoaderPDF "
        f"(Java CLI, markdown output, timeout={timeout_s:.0f}s)..."
    )

    # Use a per-call temp directory so concurrent jobs don't collide.
    # The directory and its contents are deleted on context exit.
    with tempfile.TemporaryDirectory(prefix="odl_") as out_dir:
        # Run the Java wrapper in a worker thread so we can enforce a
        # parser-level timeout.  The outer doc_processing subprocess
        # also has a timeout, but that kills the whole subprocess —
        # this narrower timeout lets us surface a RuntimeError that
        # tasks.py can catch and route to a different parser.
        #
        # IMPORTANT: opendataloader_pdf.convert() internally spawns a
        # Java subprocess.  When the worker thread times out, the Java
        # process may still be running; we shut the pool down with
        # wait=False so we don't block on it.  The orphaned Java process
        # dies with its parent doc_processing subprocess.
        #
        # quiet=False lets Java stderr flow to the parent subprocess's
        # stderr, which conversion_subprocess.py relays into the main
        # log stream.  Helpful for diagnosing CLI failures.
        pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="odl-convert"
        )
        future = pool.submit(
            opendataloader_pdf.convert,
            input_path=pdf_path,
            output_dir=out_dir,
            format="markdown",
            quiet=False,
            keep_line_breaks=True,
            markdown_page_separator=_PAGE_SEPARATOR_TEMPLATE,
        )
        try:
            future.result(timeout=timeout_s)
        except concurrent.futures.TimeoutError as exc:
            pool.shutdown(wait=False)
            raise RuntimeError(
                f"OpenDataLoaderPDF timed out after {timeout_s:.0f}s on "
                f"{pdf_path}.  The Java subprocess may still be running; "
                f"it will be terminated when the doc_processing subprocess "
                f"exits."
            ) from exc
        except FileNotFoundError as exc:
            pool.shutdown(wait=True)
            raise RuntimeError(
                f"OpenDataLoaderPDF invocation failed (java or input missing): "
                f"{exc}"
            ) from exc
        except Exception as exc:
            pool.shutdown(wait=True)
            raise RuntimeError(
                f"OpenDataLoaderPDF conversion failed for {pdf_path}: {exc}"
            ) from exc
        else:
            pool.shutdown(wait=True)

        # OpenDataLoaderPDF names the output file after the input stem.
        md_path = Path(out_dir) / f"{Path(pdf_path).stem}.md"
        if not md_path.exists():
            produced = sorted(p.name for p in Path(out_dir).iterdir())
            raise RuntimeError(
                f"OpenDataLoaderPDF produced no markdown for {pdf_path}. "
                f"Output directory contains: {produced}"
            )

        markdown = md_path.read_text(encoding="utf-8", errors="replace")

    # Degenerate-output guard: fail loudly rather than emit empty pages
    # downstream.  Common trigger: scanned/image-only PDFs where the Java
    # pipeline has no OCR and returns near-empty markdown.  Raising here
    # lets tasks.py fall back to another parser (e.g. docling with OCR
    # enabled, or direct fitz) rather than wasting an LLM extraction on
    # a blank document.
    stripped_len = len(markdown.strip())
    if stripped_len < min_output_chars:
        raise RuntimeError(
            f"OpenDataLoaderPDF produced only {stripped_len} chars of "
            f"markdown for a {page_count}-page PDF (minimum: "
            f"{min_output_chars}).  Likely a scanned or image-only "
            f"document that needs an OCR-capable parser."
        )

    page_map = split_markdown(markdown, page_count)
    for pg in range(1, page_count + 1):
        log_page_capture("OpenDataLoaderPDF", pg, page_count, page_map[pg])
    return page_map
