"""
Parser Module — Shared Utilities
================================
Contracts and shared helpers used across all parser modules.

PARSER CONTRACT
---------------
Every parser module exposes a `convert()` function with this signature:

    def convert(pdf_path: str, page_count: int, config) -> dict[int, str]:
        '''Convert a PDF to per-page text/markdown.

        Args:
            pdf_path:   Absolute path to the source PDF file.
            page_count: Total page count from the orchestrator's pre-validation
                        (use this rather than re-reading from the PDF — the
                        orchestrator already paid that cost).
            config:     The Settings object from `config.get_settings()`.
                        May be None if the parser does not consume any
                        configuration (e.g. fitz, pymupdf4llm).

        Returns:
            A dict mapping 1-indexed page numbers to extracted text.
            EVERY page index from 1 to page_count MUST be present in the
            returned dict (use empty string for pages that yielded no text).

        Raises:
            RuntimeError, FileNotFoundError, or other Exception subtypes
            on hard failures.  The orchestrator catches these and routes
            to a fallback parser if configured.
        '''

Parser modules that perform heavy imports (docling, pymupdf4llm, kreuzberg
opendataloader_pdf) MUST do those imports inside the function body, not
at module top level.  This keeps `import parsers` cheap — the registry
loads in milliseconds rather than seconds, and the parsers themselves
are pulled in only when actually invoked.
"""
from __future__ import annotations

from utils.logging_config import logger


def log_page_capture(parser_name: str, page_number: int, page_count: int, text: str) -> None:
    """Emit per-page progress to the console.

    Used by every parser at the end of each page extraction so operators
    can see real-time progress regardless of which backend is running.
    """
    percent_complete = (page_number * 100) // page_count if page_count > 0 else 0
    logger.info(
        f"{parser_name} progress: {page_number}/{page_count} pages "
        f"({percent_complete}% complete), {len(text.strip()):,} chars"
    )
