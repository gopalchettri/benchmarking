"""
pymupdf4llm Parser
==================
Structured-markdown extraction via the `pymupdf4llm` library.

This parser is preserved as a configurable PARSE_TYPE option but is
NOT used as a fallback by any other parser.  Docling crash recovery
uses `fitz_parser` (plain PyMuPDF) instead — see fitz_parser.py.

Lazy-imports `pymupdf4llm` inside `convert()` to keep the parser
registry cheap.
"""
from __future__ import annotations

from utils.logging_config import logger
from .base import log_page_capture


def convert(pdf_path: str, page_count: int, config=None) -> dict[int, str]:
    """Convert a PDF to per-page markdown via pymupdf4llm.

    Args:
        pdf_path:   Absolute path to the PDF file.
        page_count: Expected total page count from the orchestrator.
        config:     Unused (pymupdf4llm takes no configuration).

    Returns:
        Dict mapping 1-indexed page numbers to markdown content.
    """
    import pymupdf4llm

    logger.info("Converting PDF via pymupdf4llm (structured markdown)...")
    chunks = pymupdf4llm.to_markdown(pdf_path, page_chunks=True)
    page_map: dict[int, str] = {}
    for pg, chunk in enumerate(chunks, start=1):
        text = chunk.get("text", "")
        page_map[pg] = text
        log_page_capture("PyMuPDF4LLM", pg, page_count, text)
    return page_map
