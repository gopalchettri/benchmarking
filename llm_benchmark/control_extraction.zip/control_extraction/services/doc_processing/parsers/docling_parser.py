"""
Docling Parser
==============
High-quality structured PDF extraction via the Docling pipeline.

Docling is the default parser for the project — it produces markdown
with table structure detection and layout-aware paragraph reconstruction.
However, its C++ backend (`docling-parse`) can throw `std::bad_alloc`
on memory-heavy pages.  This module wraps the raw conversion in a
five-layer safety net so the docling code path NEVER produces a broken
result:

L1a — `raises_on_error=False` returns ConversionStatus instead of
        raising for normal pipeline errors.
L1b — `_DoclingFailureCapture` log handler captures pages docling
        silently fails on (std::bad_alloc caught internally).
L2  — Per-page recovery via `fitz_parser.single_page` for any page
        docling left empty.
L3  — If the entire DoclingParse C++ backend produces a degenerate
        result, retry the WHOLE document with `PyPdfiumDocumentBackend`
        before falling back further.
L4  — If both backends fail or produce degenerate results, fall back
        to `fitz_parser.convert` for the entire document.

The fallback chain is: DoclingParse → PyPdfium → PyMuPDF (fitz).
Each layer trades some layout quality for resilience, but text coverage
is preserved at every level.
"""
from __future__ import annotations
import gc  # Added for manual memory management
import logging
import os
import re
import threading
import time
from pathlib import Path
from typing import Optional, Any

from utils.logging_config import logger

from .base import log_page_capture
from . import fitz_parser


# ── Docling markdown serializer fix: force disable_numparse ──────────────
# Docling's table markdown serializer calls `tabulate(tablefmt="github")`
# which, by default, reformats cells that look numeric.  `"5.10"` → 5.10
# → float → `"5.1"`.  Trailing zero is silently dropped.
#
# Real-world impact: ISO 27001 Annex A controls 5.10, 5.20, 5.30 were
# rendered as 5.1, 5.2, 5.3 — colliding with the actual 5.1/5.2/5.3 and
# causing downstream dedup to drop them entirely.  Any framework with
# two-digit subsection IDs ending in zero (NIST 800-53 AC-10, PCI-DSS 1.20,
# SWIFT CSCF 2.30, etc.) is vulnerable.
#
# Fix: wrap `tabulate` in docling_core's namespace so every call has
# `disable_numparse=True` set as a default.  Idempotent and process-local.
# Runs once at first converter build (lazy import keeps the parser registry
# cheap — see __init__.py).
#
# Thread-safety: the patch is guarded by `_DOCLING_TABULATE_PATCH_LOCK`
# because multiple threads in the same process can reach converter build
# concurrently (e.g., the outer doc_processing harness parallelizing doc
# conversions).  Without the lock, two threads entering the function
# simultaneously would both see the flag False and both wrap, producing
# a wrapped_wrapped_original chain.  Functionally harmless but wastes
# one wrapper call per invocation forever.
_DOCLING_TABULATE_PATCHED = False
_DOCLING_TABULATE_PATCH_LOCK = threading.Lock()


def _patch_docling_tabulate_disable_numparse() -> None:
    """Ensure docling's markdown serializer renders numeric cells verbatim.

    Docling calls `tabulate(rows, headers, tablefmt="github")` without
    `disable_numparse=True` — `tabulate`'s default number parsing strips
    trailing zeros from cells like "5.10" (→ "5.1").  We can't modify
    docling_core, so we rebind the `tabulate` name in its module to a
    wrapper that injects the flag.

    Safe because:
      - `disable_numparse=True` is idempotent with tabulate's output for
        cells that aren't affected by numparse.
      - The wrapper calls the original function with a defaulted kwarg, so
        any explicit caller-supplied value wins.
      - Double-checked locking ensures exactly one wrap even under
        concurrent first-callers.
    """
    # `global` must precede any read/write of the name in this function —
    # Python raises SyntaxError otherwise (name used prior to global
    # declaration). The flag is assigned below inside the lock, so we
    # must hoist the declaration here.
    global _DOCLING_TABULATE_PATCHED

    # Fast path: no lock acquisition on the common case (already patched).
    # The module-level flag write below is protected by the lock, but
    # reading it without the lock is safe because:
    #   - Python attribute reads are atomic.
    #   - The only transition is False → True (monotonic), so a stale
    #     read of False simply causes the thread to acquire the lock and
    #     re-check inside the critical section.
    if _DOCLING_TABULATE_PATCHED:
        return

    with _DOCLING_TABULATE_PATCH_LOCK:
        # Re-check under the lock — another thread may have patched while
        # we were waiting for the lock.
        if _DOCLING_TABULATE_PATCHED:
            return

        try:
            import docling_core.transforms.serializer.markdown as _mdmod
        except Exception as exc:
            logger.warning(
                f"Could not patch docling tabulate (numparse bug): {exc}. "
                f"Two-digit IDs ending in 0 (e.g. A.5.10) may render as 5.1."
            )
            return
        orig = _mdmod.tabulate

        def _wrapped_tabulate(*args, **kwargs):
            kwargs.setdefault("disable_numparse", True)
            return orig(*args, **kwargs)

        _mdmod.tabulate = _wrapped_tabulate
        _DOCLING_TABULATE_PATCHED = True
        logger.debug(
            "Patched docling markdown tabulate with disable_numparse=True "
            "(prevents trailing-zero stripping on numeric-looking table cells)."
        )

# NOTE ON THREAD CONTROL:
# Thread-count env vars (OMP_NUM_THREADS, MKL_NUM_THREADS) are NOT set at
# module import time.  Setting them here would leak to every library in the
# process (numpy, torch, scipy, sklearn) and override any caller configuration.
# Instead, we set them inside `get_cached_converter()` just before the first
# DocumentConverter build — this narrows the blast radius to the subprocess's
# conversion window and respects the `PDF_DOCLING_NUM_THREADS` config value.

# ── Heuristic threshold for "extraction is mostly broken" ─────────────────
# If, after docling + per-page recovery, more than this fraction of pages
# that fitz says contain text are still empty, we consider the docling
# extraction degenerate and fall back to a full PyMuPDF (fitz) conversion.
# 0.30 means: tolerate up to 30% of text-bearing pages being empty before
# declaring docling's output unreliable. The exact threshold is configurable
# through Settings.DOCLING_DEGENERATE_THRESHOLD.

# Pattern matching docling's preprocessing-failure log line:
#   "Stage preprocess failed for run 1, pages [56]: std::bad_alloc"
#   "Stage preprocess failed for run 1, pages [55, 56]: std::bad_alloc"
_DOCLING_FAILURE_PAGES_RE = re.compile(
    r"Stage preprocess failed for run \d+, pages \[([\d,\s]+)\]"
)

# Trailing page marker emitted by docling's serializer in some pipeline paths.
DOCLING_PAGE_MARKER_RE = re.compile(r"<!--\s*page=(\d+)/\d+\s*-->")
DOCLING_PAGE_BREAK_PLACEHOLDER = "<!-- __DOC_PROCESSING_PAGE_BREAK__ -->"

# Invisible Unicode characters to strip from docling output before sending
# to the LLM.  Includes soft hyphens (U+00AD from PDF hyphenation), zero-
# width joiners/non-joiners, RTL/LTR marks (U+200E/F — appear in GCC
# Arabic frameworks), zero-width spaces, and BOMs.
#
# U+0002 (STX) is included because docling's text decoder can emit STX
# where the source PDF uses a soft-hyphen line break (observed in ISO
# 27001 Annex A tables: `secu \x02 rity`, `con \x02 tinuity`).  The other
# C0 controls are left alone — TAB/LF/CR are structural, and isolated
# FF/VT are extremely rare in text-layer PDFs.
_DOCLING_INVISIBLE_CHARS_RE = re.compile(
    r'[\u0002\u00AD\u200B\u200C\u200D\u200E\u200F\uFEFF]'
)
# Soft-hyphen line breaks emerge from docling as `word1 <SHY|STX> word2`
# with spaces on either side of the break marker.  Simply stripping the
# marker would leave `word1  word2` which the justified-space collapse
# then reduces to `word1 word2` — two tokens instead of the original
# single hyphenated word.  This regex joins the fragments by consuming
# the surrounding whitespace together with the marker.  Runs BEFORE
# the plain invisible-chars stripper so we catch the space-wrapped case
# first.
_DOCLING_SOFT_BREAK_RE = re.compile(r"(\S) *[\u0002\u00AD] *(\S)")
# Two-or-more spaces between non-whitespace characters are PDF justification
# artefacts introduced when docling reads glyph positions from justified
# text.  Collapse to a single space; leading indentation is preserved by
# the \S lookbehind.
_PDF_JUSTIFIED_SPACE_RE = re.compile(r"(?<=\S)  +(?=\S)")


# ── Logging handler that captures docling's silent per-page failures ──────
# Global cache for the converter to avoid re-loading models from disk every time.
# This saves ~5-10 seconds per file in production.
_CONVERTER_CACHE: dict[str, Any] = {}

class DoclingFailureCapture(logging.Handler):
    """Logging handler that captures pages docling silently fails on.

    Attached to the docling pipeline logger during conversion.  Parses
    "Stage preprocess failed for run N, pages [X, Y]" log records and
    accumulates the page numbers in a set.  Thread-safe via the GIL —
    set operations are atomic in CPython, and log records arrive
    serially within a single converter.convert() call.
    """

    def __init__(self) -> None:
        super().__init__(level=logging.ERROR)
        self.failed_pages: set[int] = set()

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = record.getMessage()
        except Exception:
            return
        match = _DOCLING_FAILURE_PAGES_RE.search(message)
        if not match:
            return
        for token in match.group(1).split(","):
            token = token.strip()
            if token.isdigit():
                self.failed_pages.add(int(token))

def get_cached_converter(config, backend=None) -> Any:
    """Return (and cache) a DocumentConverter for the given backend.

    Caching rationale: DocumentConverter eagerly loads the layout and
    table-structure models on first `.convert()` call — ~5-10s of disk
    I/O plus ~340MB RAM.  Caching per-backend means the PyPdfium retry
    layer (L3 in convert()) doesn't pay that cost a second time if the
    same backend handles multiple documents within a subprocess lifetime.

    The cache is per-process (this subprocess only handles one document
    before exiting), so there's no cross-job staleness risk.  Backend is
    the only dimension that changes within a single job, so we key on it.
    """
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from docling.datamodel.base_models import InputFormat

    # Apply the tabulate numparse patch before any export path is reachable.
    # Idempotent; costs a dict lookup on subsequent calls.
    _patch_docling_tabulate_disable_numparse()

    cache_key = backend.__name__ if backend else "default"
    if cache_key not in _CONVERTER_CACHE:
        # Set OMP_NUM_THREADS just-in-time before the first model load.
        # Docling and its torch/numpy dependencies snapshot this value
        # when they initialize their thread pools on first use.  Setting
        # it here (rather than at module import) keeps the side effect
        # scoped to docling and respects the operator's config.
        #
        # We ask the device-aware resolver for num_threads so the value
        # matches what we'll pass to AcceleratorOptions in the pipeline —
        # on GPU this is the higher GPU default; on CPU it's the operator's
        # config value (typically 1 for crash-safety).
        accel = _resolve_accelerator_settings(config)
        os.environ["OMP_NUM_THREADS"] = str(accel["num_threads"])
        os.environ["MKL_NUM_THREADS"] = str(accel["num_threads"])

        pipeline_options = _get_pipeline_options(config)
        pdf_format_option = PdfFormatOption(
            pipeline_options=pipeline_options,
            backend=backend,
        )
        _CONVERTER_CACHE[cache_key] = DocumentConverter(
            format_options={InputFormat.PDF: pdf_format_option}
        )
    return _CONVERTER_CACHE[cache_key]

# ── Device-aware auto-tuning ──────────────────────────────────────────────
#
# Docling's pipeline is two completely different workloads depending on the
# accelerator:
#
# • On CPU, heavy neural-network operations flow through the C++ docling-parse
#   backend.  Large batch sizes and high thread counts trigger std::bad_alloc
#   on memory-pressure pages — that's the bug the original low defaults
#   (1 / 1 / 1) were designed to avoid.
#
# • On GPU (CUDA / MPS / XPU), layout and table inference runs in GPU VRAM.
#   There is no CPU-heap pressure, so the CPU-safety caps don't apply, and
#   a batch size of 1 starves the GPU — utilisation drops to ~5% and wall
#   time is close to CPU throughput despite having GPU hardware.
#
# The auto-tuning resolver below returns device-appropriate values while
# honouring any operator-supplied config values that are already higher.
# The rule is `max(config_value, device_default)` — explicit high values
# win; low defaults get bumped on GPU.

def _get_device_defaults(config) -> dict[str, dict[str, int]]:
    return {
        "cpu": {
            "num_threads": config.PDF_DOCLING_CPU_NUM_THREADS,
            "nn_batch": config.PDF_DOCLING_CPU_BATCH_SIZE,
            "page_batch": config.PDF_DOCLING_CPU_PAGE_BATCH_SIZE,
        },
        "cuda": {
            "num_threads": config.PDF_DOCLING_CUDA_NUM_THREADS,
            "nn_batch": config.PDF_DOCLING_CUDA_BATCH_SIZE,
            "page_batch": config.PDF_DOCLING_CUDA_PAGE_BATCH_SIZE,
        },
        "mps": {
            "num_threads": config.PDF_DOCLING_MPS_NUM_THREADS,
            "nn_batch": config.PDF_DOCLING_MPS_BATCH_SIZE,
            "page_batch": config.PDF_DOCLING_MPS_PAGE_BATCH_SIZE,
        },
        "xpu": {
            "num_threads": config.PDF_DOCLING_XPU_NUM_THREADS,
            "nn_batch": config.PDF_DOCLING_XPU_BATCH_SIZE,
            "page_batch": config.PDF_DOCLING_XPU_PAGE_BATCH_SIZE,
        },
    }


# Memoized accelerator resolution.  `_resolve_accelerator_settings` is
# called from three call-sites per convert (pipeline options build, cached
# converter build, unsafe conversion for logging), but its result is a
# pure read of config fields + a torch device probe that never changes
# mid-process.  Keying on id(config) is safe: Settings is a process-wide
# singleton, so the id is stable across the subprocess's lifetime.
_ACCEL_CACHE: Optional[tuple[int, dict]] = None


def _resolve_accelerator_settings(config) -> dict:
    """Resolve the best accelerator device + device-appropriate tuning.

    Returns a dict with keys:
        device:         'cpu' | 'cuda:0' | 'mps' | 'xpu' (from decide_device)
        device_family:  'cpu' | 'cuda' | 'mps' | 'xpu'   (the _DEVICE_DEFAULTS key)
        num_threads:    effective thread count for AcceleratorOptions
        nn_batch:       effective layout/table batch size
        page_batch:     effective in-flight page count (docling_settings.perf)
        use_flash_attn: True if CUDA AND available on this GPU

    Memoized on `id(config)` — `decide_device` is cheap but still a few
    torch attribute lookups, and config values never change mid-process.
    Subsequent calls within the same subprocess are a single dict lookup.
    """
    global _ACCEL_CACHE
    cache_key = id(config)
    if _ACCEL_CACHE is not None and _ACCEL_CACHE[0] == cache_key:
        return _ACCEL_CACHE[1]

    from docling.datamodel.accelerator_options import AcceleratorDevice
    from docling.utils.accelerator_utils import decide_device

    device_str = decide_device(AcceleratorDevice.AUTO.value)  # e.g. 'cuda:0'
    # Strip any ':N' suffix to get the device family for defaults lookup.
    device_family = device_str.split(":", 1)[0]
    device_defaults = _get_device_defaults(config)
    defaults = device_defaults.get(device_family, device_defaults["cpu"])

    # Honour explicit operator config values that are higher than the
    # device-default.  This preserves CPU behaviour exactly (since CPU
    # defaults are 1/1/1, max(config, 1) == config) and auto-scales on
    # GPU where the low CPU defaults would starve the accelerator.
    num_threads = max(defaults["num_threads"], int(config.PDF_DOCLING_NUM_THREADS or 0))
    nn_batch = max(defaults["nn_batch"], int(config.PDF_DOCLING_BATCH_SIZE or 0))
    page_batch = max(defaults["page_batch"], int(config.PDF_DOCLING_PAGE_BATCH_SIZE or 0))

    # Flash Attention 2 is a pure-speed win on Ampere+ NVIDIA GPUs
    # (sm_80 and newer).  Docling's layout/table models inherit it from
    # AcceleratorOptions.cuda_use_flash_attention2 — when the GPU doesn't
    # support it, docling silently falls back to standard attention.
    use_flash_attn = device_family == "cuda"

    accel = {
        "device": device_str,
        "device_family": device_family,
        "num_threads": num_threads,
        "nn_batch": nn_batch,
        "page_batch": page_batch,
        "use_flash_attn": use_flash_attn,
    }
    _ACCEL_CACHE = (cache_key, accel)
    return accel


def _get_pipeline_options(config) -> Any:
    """Build a PdfPipelineOptions tuned for the detected accelerator.

    Uses `_resolve_accelerator_settings()` to pick batch sizes and thread
    counts appropriate for CPU vs GPU, then applies docling's feature
    disablers (which are device-independent — we never want VLMs or
    image buffers regardless of hardware).
    """
    from docling.datamodel.pipeline_options import (
        PdfPipelineOptions, TableFormerMode, TableStructureOptions
    )
    from docling.datamodel.accelerator_options import AcceleratorDevice, AcceleratorOptions
    from docling.datamodel.settings import settings as docling_settings

    accel = _resolve_accelerator_settings(config)

    artifacts_path = resolve_artifacts(config)
    pipeline_options = PdfPipelineOptions(artifacts_path=artifacts_path)

    # Cap page batch size. On CPU this prevents C++ heap crashes;
    # on GPU it sets a healthy in-flight pipeline depth.
    docling_settings.perf.page_batch_size = accel["page_batch"]

    # Disable all non-essential features.  These are DEVICE-INDEPENDENT —
    # we don't want VLMs or image buffers whether we're on CPU or GPU.
    # (a) Loads additional ML models we don't need (VLM for picture
    #     descriptions, code-formula VLM)
    # (b) Buffers bitmaps we don't consume (page/picture/table images)
    # Together these save ~1-2GB peak RAM/VRAM and eliminate several
    # sources of std::bad_alloc on memory-pressure pages.
    pipeline_options.do_ocr = False                   # PDFs have embedded text
    pipeline_options.generate_page_images = False     # no bitmap output needed
    pipeline_options.generate_picture_images = False  # ditto
    pipeline_options.generate_table_images = False    # ditto
    pipeline_options.do_picture_classification = False
    pipeline_options.do_picture_description = False   # VLM model not needed
    pipeline_options.do_code_enrichment = False       # code-formula VLM not needed
    pipeline_options.do_formula_enrichment = False

    # Table structure: ACCURATE mode + cell matching is required for the
    # Annex A-style control tables found in every framework (ISO 27001,
    # NIST CSF, PCI-DSS, etc.).  FAST mode miscounts multi-row-span cell
    # boundaries and, with do_cell_matching=False, that error cascades —
    # rows shift, control descriptions land under the wrong control ID,
    # and PDF soft-hyphen line breaks fragment titles ("secu" / "rity")
    # across cells.  ACCURATE is ~40% slower on table pages but body-text
    # pages are unaffected, so the overall document cost is +10-15%.
    # do_cell_matching=True re-aligns extracted tokens to cell bboxes via
    # geometric overlap — the post-pass that actually prevents the
    # mis-assignment seen in the mangled ISO 27001 extraction.
    pipeline_options.do_table_structure = True
    pipeline_options.table_structure_options = TableStructureOptions(
        mode=TableFormerMode.ACCURATE,
        do_cell_matching=True,
    )

    # Accelerator: device=AUTO tells docling to re-probe and pick itself.
    # We pass num_threads resolved by _resolve_accelerator_settings (CPU:
    # config value; GPU: max(config, GPU default)) plus flash-attn flag.
    pipeline_options.accelerator_options = AcceleratorOptions(
        num_threads=accel["num_threads"],
        device=AcceleratorDevice.AUTO,
        cuda_use_flash_attention2=accel["use_flash_attn"],
    )

    # Neural-network internal batch sizes.  Tuned by the resolver based on
    # hardware — high on GPU (utilisation), capped at 1 on CPU (stability).
    pipeline_options.layout_batch_size = accel["nn_batch"]
    pipeline_options.table_batch_size = accel["nn_batch"]

    outer_timeout = config.PDF_CONVERSION_TIMEOUT_SECONDS
    pipeline_options.document_timeout = outer_timeout * 0.8

    return pipeline_options

# ── Pure-function helpers (text normalization, page splitting, etc.) ──────


def normalize_docling_page(text: str) -> str:
    """Fix docling-specific artefacts before the text reaches the LLM.

    1. PDF justification spaces — docling reads absolute glyph x-positions,
       so justified text arrives with 2+ spaces between every word.  Collapse
       them to a single space between non-whitespace tokens.
    2. Invisible Unicode — strip soft hyphens, RTL/LTR marks, zero-width
       spaces/joiners, and BOMs that docling occasionally preserves.
    3. Non-breaking spaces (U+00A0) — replace with regular ASCII space so
       downstream tokenisation and regex matching work correctly.
    """
    # Order matters:
    # 1. NBSP → space first so the justified-space regex sees only ASCII spaces.
    # 2. Soft-hyphen join (word1 <SHY|STX> word2 → word1word2) — MUST run
    #    before the plain invisible stripper, otherwise we'd strip the
    #    marker and leave double-spaced fragments the justified-space
    #    regex would normalise to a single space instead of joining.
    # 3. Invisible chars stripped (catches isolated SHY/STX with no
    #    surrounding non-space characters).
    # 4. Justified-space collapse last, with clean ASCII-space input.
    text = text.replace('\u00A0', ' ')
    text = _DOCLING_SOFT_BREAK_RE.sub(r"\1\2", text)
    text = _DOCLING_INVISIBLE_CHARS_RE.sub("", text)
    text = _PDF_JUSTIFIED_SPACE_RE.sub(" ", text)
    return text


def split_trailing_page_markers(content: str) -> dict[int, str]:
    """Split markdown that uses trailing <!-- page=X/Y --> markers."""
    pages: dict[int, str] = {}
    last_start = 0

    for match in DOCLING_PAGE_MARKER_RE.finditer(content):
        page_num = int(match.group(1))
        pages[page_num] = content[last_start:match.start()].strip()
        last_start = match.end()

    remaining = content[last_start:].strip()
    if remaining and pages:
        last_page = max(pages.keys())
        pages[last_page] = f"{pages[last_page]}\n{remaining}".strip()

    return pages


def split_docling_batch_markdown(markdown: str, expected_pages: int) -> Optional[list[str]]:
    """Split Docling batch markdown into one entry per page.

    Docling may preserve page boundaries either through an explicit
    page-break placeholder or through trailing <!-- page=X/Y --> markers
    depending on the serializer path in use.  Return None when page
    boundaries cannot be recovered reliably so the caller can fall back
    to single-page conversion.
    """
    if expected_pages < 1:
        raise ValueError("expected_pages must be at least 1")

    normalized = markdown.strip()
    if expected_pages == 1:
        return [normalized]

    parts = re.split(
        rf"\s*{re.escape(DOCLING_PAGE_BREAK_PLACEHOLDER)}\s*",
        normalized,
    )
    if len(parts) == expected_pages:
        return [part.strip() for part in parts]

    numbered_pages = split_trailing_page_markers(normalized)
    if len(numbered_pages) == expected_pages:
        return [numbered_pages[pg].strip() for pg in sorted(numbered_pages)]

    return None


def extract_crashed_pages(error_message: str, page_count: int) -> list[int]:
    """Extract page numbers from a docling preprocessing crash message.

    Parses messages like:
        "Stage preprocess failed for run 1, pages [56]: std::bad_alloc"
        "Stage preprocess failed for run 1, pages [55, 56]: ..."

    Returns a sorted list of 1-indexed page numbers in the document's
    range, or an empty list if the message does not match the expected
    pattern.
    """
    match = re.search(r'pages\s*\[([0-9,\s]+)\]', error_message)
    if not match:
        return []
    try:
        raw_pages = [int(p.strip()) for p in match.group(1).split(',') if p.strip()]
        valid = sorted(pg for pg in raw_pages if 1 <= pg <= page_count)
        return valid
    except (ValueError, TypeError):
        return []


def resolve_artifacts(config) -> Optional[Path]:
    """Return the validated local artifacts path, or None to use the HF cache."""
    raw = config.DOCLING_ARTIFACTS_PATH or ""
    if not raw.strip():
        return None
    p = Path(raw.strip()).resolve()
    if not p.is_dir():
        raise FileNotFoundError(
            f"DOCLING_ARTIFACTS_PATH={p} does not exist. "
            "Run `python services/doc_processing/download_models.py` first."
        )
    missing = [
        sub for sub in (
            "docling-project--docling-layout-heron",
            "docling-project--docling-models",
        )
        if not (p / sub).is_dir()
    ]
    if missing:
        raise FileNotFoundError(
            f"DOCLING_ARTIFACTS_PATH={p} is missing model subdirectories: {missing}. "
            "Run `python services/doc_processing/download_models.py --artifacts-path "
            f"{p}` to populate them."
        )
    return p


def _is_degenerate_result(
    page_map: dict[int, str], pdf_path: str, page_count: int, config,
) -> bool:
    """Return True if more than `DOCLING_DEGENERATE_THRESHOLD` of text-
    bearing pages are empty in the page_map.

    Used to decide whether to escalate to the next backend tier.
    """
    empty_pages = [
        pg for pg in range(1, page_count + 1)
        if not page_map.get(pg, "").strip()
    ]
    if not empty_pages:
        return False
    fitz_has_text = fitz_parser.pages_have_text(pdf_path, empty_pages)
    should_have_text = [pg for pg in empty_pages if fitz_has_text.get(pg, False)]
    if not should_have_text:
        return False
    empty_ratio = len(should_have_text) / page_count
    return empty_ratio > config.DOCLING_DEGENERATE_THRESHOLD


# ── The unsafe converter (may raise) and the safe wrapper (never raises) ──


def _convert_unsafe(
    pdf_path: str,
    page_count: int,
    config,
    backend=None,
) -> dict[int, str]:
    """Internal docling conversion that may raise.

    Use `convert()` instead for production calls — it wraps this function
    in a multi-tier fallback safety net.

    Args:
        backend: Optional backend class (e.g. PyPdfiumDocumentBackend).
            When None, uses docling's default DoclingParseDocumentBackend.
            Pass an alternative backend to retry conversion when the
            default backend produces degenerate output due to C++ memory-
            allocation issues.
    """
    # Only the types we reference directly in this function body need to be
    # imported here.  Pipeline options live inside _get_pipeline_options;
    # DocumentConverter construction lives inside get_cached_converter;
    # device detection lives inside _resolve_accelerator_settings.
    from docling.datamodel.base_models import ConversionStatus

    # Pre-run memory cleanup: Python's cyclic-GC collector won't run during
    # docling's C++ calls, so any unreachable large objects from a previous
    # run still occupy RAM.  An explicit collect() here frees that memory
    # before the C++ backend allocates its own large buffers.
    gc.collect()

    # The cached-converter path.  First call for a given backend loads the
    # ML models (~5-10s); subsequent calls are zero-cost dict lookups.
    # The cache also ensures OMP_NUM_THREADS is applied before first model
    # load (see get_cached_converter for details).
    converter = get_cached_converter(config, backend)

    # Resolve the effective accelerator settings for logging.  This must
    # match what _get_pipeline_options saw when building the converter on
    # first call (same helper, same config, same resolution) so the log
    # line accurately describes the running pipeline.
    accel = _resolve_accelerator_settings(config)
    artifacts_path = resolve_artifacts(config)
    logger.info(
        f"Converting {page_count}-page PDF via docling "
        f"(device={accel['device']}, threads={accel['num_threads']}, "
        f"nn_batch={accel['nn_batch']}, page_batch={accel['page_batch']}, "
        f"flash_attn={accel['use_flash_attn']}, "
        f"tableformer=accurate, cell_matching=on, "
        f"artifacts={'local' if artifacts_path else 'hf-cache'}, "
        f"backend={backend.__name__ if backend else 'default'})..."
    )

    t0 = time.monotonic()
    max_pages = config.PDF_MAX_PAGES or page_count
    result = None
    crash_pages: list[int] = []

    # Install a logging handler on the docling pipeline logger to capture
    # pages that fail at preprocessing without raising an exception.
    # Docling catches std::bad_alloc internally, logs the failure at ERROR
    # level, marks the pages as failed, and continues — no Python exception
    # propagates.  Without this capture, the recovery pass would waste time
    # trying docling per-page reconversion (which usually fails for the
    # same reason) before falling back to fitz.
    failure_capture = DoclingFailureCapture()
    docling_pipeline_logger = logging.getLogger("docling.pipeline.standard_pdf_pipeline")
    docling_pipeline_logger.addHandler(failure_capture)

    try:
        try:
            # raises_on_error=False per docling's batch_convert pattern:
            # https://docling-project.github.io/docling/examples/batch_convert/
            # Returns a ConversionResult with status field set instead of raising.
            result = converter.convert(
                pdf_path,
                max_num_pages=max_pages,
                raises_on_error=False,
            )
        except Exception as exc:
            # raises_on_error=False suppresses most exceptions, but truly
            # unrecoverable errors (e.g., model load failures) may still
            # bubble up.  If we can identify which pages crashed, retry
            # with a page_range that excludes them.
            crash_pages = extract_crashed_pages(str(exc), page_count)
            if not crash_pages:
                # Could not identify which pages failed — re-raise so the
                # outer wrapper falls back to fitz.
                raise

            logger.warning(
                f"Docling single-pass raised on page(s) {crash_pages}: {exc}. "
                f"Retrying with page_range excluding crashed pages..."
            )
            # Free the partial/corrupted result before the retry.  The C++
            # backend may be holding onto buffers that caused the crash.
            gc.collect()
            safe_end = min(crash_pages) - 1
            if safe_end >= 1:
                try:
                    result = converter.convert(
                        pdf_path,
                        max_num_pages=max_pages,
                        page_range=(1, safe_end),
                        raises_on_error=False,
                    )
                    logger.info(
                        f"Docling retry succeeded for pages 1-{safe_end} "
                        f"(skipped {crash_pages})"
                    )
                except Exception as retry_exc:
                    logger.error(
                        f"Docling retry also failed for pages 1-{safe_end}: {retry_exc}"
                    )
                    raise retry_exc from exc
    finally:
        docling_pipeline_logger.removeHandler(failure_capture)

    # Inspect ConversionStatus and conv_res.errors per docling's batch_convert
    # pattern: log the structured errors and decide whether we have a usable
    # document.
    if result is not None:
        status = getattr(result, "status", None)
        errors = getattr(result, "errors", []) or []

        if status == ConversionStatus.FAILURE:
            error_summary = "; ".join(
                str(getattr(e, "error_message", e))[:200] for e in errors[:3]
            )
            logger.error(
                f"Docling reported FAILURE status for {pdf_path}: {error_summary}"
            )
            raise RuntimeError(
                f"Docling conversion failed (status=FAILURE): {error_summary}"
            )
        elif status == ConversionStatus.PARTIAL_SUCCESS and errors:
            error_summary = "; ".join(
                str(getattr(e, "error_message", e))[:200] for e in errors[:5]
            )
            logger.warning(
                f"Docling reported PARTIAL_SUCCESS for {pdf_path} "
                f"({len(errors)} error(s)): {error_summary}"
            )

    # Merge silently-failed pages (captured from logs) into crash_pages.
    if failure_capture.failed_pages:
        silently_failed = sorted(failure_capture.failed_pages)
        logger.warning(
            f"Docling silently failed on {len(silently_failed)} page(s): "
            f"{silently_failed}. Recovery will use fitz directly "
            f"(skipping per-page docling retry to avoid wasted attempts)."
        )
        crash_pages = sorted(set(crash_pages) | failure_capture.failed_pages)

    if result is None:
        raise RuntimeError(
            f"Docling conversion returned no result for {pdf_path}"
        )

    elapsed_conv = time.monotonic() - t0
    logger.info(
        f"Docling pipeline finished in {elapsed_conv:.1f}s — "
        f"extracting per-page markdown ({page_count} pages)..."
    )

    # Per-page markdown extraction.  When crash_pages excluded some pages,
    # the result only contains pages within the converted range; pages
    # beyond safe_end will have empty output and are recovered below.
    #
    # Fast path: a single bulk export with a page-break placeholder is
    # O(N) in document size.  Per-page export (page_no=pg in a loop) is
    # O(N²) because docling re-walks the full item tree per call — that's
    # the cost we saw as "export is suspiciously slow on 300-page PDFs".
    #
    # Correctness guard: split_docling_batch_markdown returns None when
    # the recovered chunk count doesn't match expected_pages, so any
    # ambiguity (missed placeholder, extra split, etc.) forces the
    # proven per-page path.  Zero quality risk — the fallback IS the
    # old behaviour.
    page_map: dict[int, str] = {}
    if result is not None:
        batch_pages: Optional[list[str]] = None
        try:
            batch_md = result.document.export_to_markdown(
                escape_underscores=False,
                page_break_placeholder=DOCLING_PAGE_BREAK_PLACEHOLDER,
            )
            batch_pages = split_docling_batch_markdown(batch_md, page_count)
        except TypeError:
            # Older docling without page_break_placeholder kwarg.
            batch_pages = None
        except Exception as exc:
            logger.debug(
                f"Bulk docling export failed ({exc}); falling back to per-page."
            )
            batch_pages = None

        if batch_pages is not None:
            for pg in range(1, page_count + 1):
                raw = batch_pages[pg - 1].strip()
                page_map[pg] = normalize_docling_page(raw)
                log_page_capture("Docling", pg, page_count, page_map[pg])
        else:
            for pg in range(1, page_count + 1):
                try:
                    raw = result.document.export_to_markdown(
                        page_no=pg,
                        escape_underscores=False,
                    ).strip()
                    page_map[pg] = normalize_docling_page(raw)
                except Exception:
                    page_map[pg] = ""
                log_page_capture("Docling", pg, page_count, page_map[pg])

    # Recovery pass for pages lost to preprocessing errors.  First tries
    # docling per-page reconversion (skipped for known-failed pages); if
    # that fails or is skipped, falls back to fitz.
    empty_pages = [
        pg for pg in range(1, page_count + 1)
        if not page_map[pg].strip()
    ]
    fitz_has_text = fitz_parser.pages_have_text(pdf_path, empty_pages) if empty_pages else {}
    failed_pages = [pg for pg in empty_pages if fitz_has_text.get(pg, False)]

    if failed_pages:
        n_known_failed = sum(1 for pg in failed_pages if pg in crash_pages)
        n_unknown = len(failed_pages) - n_known_failed
        logger.warning(
            f"Docling returned empty output for {len(failed_pages)} page(s) "
            f"that contain text: {failed_pages}. Recovering "
            f"({n_known_failed} via fitz directly, "
            f"{n_unknown} via docling-then-fitz)..."
        )

        # I/O optimization: batch-extract the fitz fallback for ALL failed
        # pages in a single PDF open.  The naive alternative (calling the
        # per-page primitive in a loop) would open the PDF once per failed
        # page — N syscalls vs. 1.  Empty entries are returned for pages
        # where fitz also fails, so the loop below cannot raise.
        fitz_recovery = fitz_parser.recover_pages(pdf_path, failed_pages)

        for pg in failed_pages:
            t_pg = time.monotonic()
            recovered = False

            # Attempt 1: docling per-page reconversion (skipped for known-failed pages).
            if pg not in crash_pages:
                try:
                    recovery = converter.convert(
                        pdf_path,
                        page_range=(pg, pg),
                        raises_on_error=False,
                    )
                    if recovery.status not in (
                        ConversionStatus.SUCCESS,
                        ConversionStatus.PARTIAL_SUCCESS,
                    ):
                        logger.debug(
                            f"Per-page recovery for page {pg} returned "
                            f"status={recovery.status}; trying fitz"
                        )
                    else:
                        raw = recovery.document.export_to_markdown(
                            page_no=pg,
                            escape_underscores=False,
                        ).strip()
                        if raw:
                            page_map[pg] = normalize_docling_page(raw)
                            recovered = True
                            logger.info(
                                f"Recovered page {pg} via docling: "
                                f"{len(page_map[pg])} chars in {time.monotonic() - t_pg:.1f}s"
                            )
                except Exception as exc:
                    logger.warning(
                        f"Docling per-page recovery failed for page {pg}: {exc}"
                    )

            # Attempt 2: fitz fallback (uses pre-batched recovery dict — no
            # additional file opens here, just a dict lookup).
            if not recovered:
                page_map[pg] = fitz_recovery.get(pg, "")
                if page_map[pg].strip():
                    logger.info(
                        f"Recovered page {pg} via fitz fallback: "
                        f"{len(page_map[pg])} chars in {time.monotonic() - t_pg:.1f}s"
                    )
                else:
                    logger.warning(
                        f"Page {pg}: fitz also returned empty (page will be "
                        f"empty in the output)"
                    )

    elapsed_total = time.monotonic() - t0
    logger.info(
        f"Docling extraction complete: {page_count} pages in {elapsed_total:.1f}s "
        f"({elapsed_total / page_count:.2f}s/page avg)"
    )
    # Post-run cleanup: Free the reference to the large 'result' object immediately
    del result
    gc.collect()
    return page_map


def convert(pdf_path: str, page_count: int, config) -> dict[int, str]:
    """Docling extraction with guaranteed PyMuPDF (fitz) fallback.

    Five-layer protection so the docling code path NEVER produces a
    broken result.  See module docstring for the layered fallback chain.
    """
    # ── Layer 1+2: Default backend (DoclingParse, C++) ────────────────
    try:
        page_map = _convert_unsafe(pdf_path, page_count, config, backend=None)
        backend_used = "DoclingParse (default)"
    except Exception as docling_exc:
        logger.error(
            f"DoclingParse backend failed entirely "
            f"({type(docling_exc).__name__}: {docling_exc}). "
            f"Trying PyPdfium backend before fitz fallback."
        )
        page_map = None
        backend_used = "DoclingParse (default)"

    # ── Layer 3: PyPdfium backend retry on exception OR degenerate result ──
    needs_pypdfium_retry = (
        page_map is None
        or _is_degenerate_result(page_map, pdf_path, page_count, config)
    )
    if needs_pypdfium_retry and page_map is not None:
        logger.warning(
            f"DoclingParse output degenerate or failed. Retrying entire "
            f"document with PyPdfium backend (different memory model)."
        )
    if needs_pypdfium_retry:
        try:
            from docling.backend.pypdfium2_backend import PyPdfiumDocumentBackend
            pypdfium_map = _convert_unsafe(
                pdf_path, page_count, config, backend=PyPdfiumDocumentBackend
            )
            if not _is_degenerate_result(pypdfium_map, pdf_path, page_count, config):
                logger.info(
                    f"PyPdfium backend retry succeeded "
                    f"(replacing degenerate DoclingParse output)."
                )
                page_map = pypdfium_map
                backend_used = "PyPdfium (retry)"
            else:
                logger.warning(
                    f"PyPdfium backend retry also degenerate. "
                    f"Will fall back to fitz."
                )
                if page_map is None:
                    page_map = pypdfium_map  # at least keep partial output
        except Exception as pypdfium_exc:
            logger.error(
                f"PyPdfium backend retry failed "
                f"({type(pypdfium_exc).__name__}: {pypdfium_exc}). "
                f"Will fall back to fitz."
            )

    # ── Layer 4: fitz fallback if everything else failed/degenerate ──
    still_degenerate = (
        page_map is None
        or _is_degenerate_result(page_map, pdf_path, page_count, config)
    )
    if still_degenerate:
        try:
            logger.warning(
                f"Both DoclingParse and PyPdfium produced unusable output. "
                f"Falling back to PyMuPDF (fitz) for full document."
            )
            return fitz_parser.convert(pdf_path, page_count, config)
        except Exception as fallback_exc:
            if page_map is None:
                raise RuntimeError(
                    f"All PDF parsers failed. Last error: {fallback_exc}"
                ) from fallback_exc
            logger.error(
                f"fitz fallback also failed ({fallback_exc}). "
                f"Returning partial result from {backend_used}."
            )

    return page_map
