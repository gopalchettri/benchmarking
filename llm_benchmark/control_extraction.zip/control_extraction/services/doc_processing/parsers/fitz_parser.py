"""
PyMuPDF (fitz) Parser
=====================
Plain-text per-page extraction using PyMuPDF.

This module serves two roles:
  1. Primary parser when PARSE_TYPE="fitz".
  2. Crash-recovery primitive imported by docling_parser.py:
     - `single_page()` recovers individual pages docling left empty.
     - `pages_have_text()` detects which pages SHOULD have content.
     - `convert()` is the full-document fallback when docling fails entirely.

PyMuPDF is a hard dependency of the project (also used by the orchestrator
for page-offset detection).  It uses different memory-allocation patterns
than docling-parse and does not crash on the kinds of pages that trigger
docling's `std::bad_alloc` errors.
"""
from __future__ import annotations

import fitz

from utils.logging_config import logger
from .base import log_page_capture


def convert(pdf_path: str, page_count: int, config=None) -> dict[int, str]:
    """Convert all pages to plain text via PyMuPDF.

    Opens the PDF once and reads all pages in a single loop — no repeated
    file I/O.  Per-page failures are caught and logged; the page is left
    empty so the orchestrator's `_write_outputs` does not raise.

    Args:
        pdf_path:   Absolute path to the PDF file.
        page_count: Expected total page count from the orchestrator.
        config:     Unused (fitz takes no configuration).

    Returns:
        Dict mapping 1-indexed page numbers to plain-text content.
        Every index from 1 to page_count is present (empty string if
        extraction failed for that page).
    """
    logger.info("Converting PDF via PyMuPDF/fitz (plain text per page)...")
    page_map: dict[int, str] = {}
    with fitz.open(pdf_path) as doc:
        n = min(len(doc), page_count)
        for pg in range(1, n + 1):
            try:
                text = doc[pg - 1].get_text("text") or ""
            except Exception as exc:
                logger.warning(f"fitz page {pg} extraction failed: {exc}")
                text = ""
            page_map[pg] = text
            log_page_capture("PyMuPDF", pg, page_count, text)
    # Cheap insurance: ensure all expected page indices are populated.
    # Should not happen but protects against PDFs with a mismatched page
    # count vs the orchestrator's pre-validation.
    for pg in range(1, page_count + 1):
        page_map.setdefault(pg, "")
    return page_map


def single_page(pdf_path: str, page_number: int) -> str:
    """Extract plain text from a single PDF page using PyMuPDF.

    Prefer `recover_pages()` when extracting MULTIPLE pages — that
    primitive opens the PDF once for the whole batch, while this
    function opens it for every call.

    Args:
        pdf_path:    Absolute path to the PDF file.
        page_number: 1-indexed page number to extract.

    Returns:
        The text content of the page, or an empty string if extraction
        fails or the page has no extractable text.  Never raises.
    """
    try:
        with fitz.open(pdf_path) as doc:
            if page_number < 1 or page_number > len(doc):
                return ""
            return doc[page_number - 1].get_text("text") or ""
    except Exception:
        return ""


def recover_pages(pdf_path: str, page_numbers: list[int]) -> dict[int, str]:
    """Batch-extract plain text for a set of 1-based page numbers.

    Opens the PDF exactly once and reads all requested pages — strictly
    more efficient than calling `single_page()` in a loop, which opens
    and closes the PDF for each page (N syscalls vs. 1).

    Used by docling_parser.py's recovery loop when many pages need
    fallback extraction.  Pages outside the document range or that fail
    individually yield empty strings rather than raising.

    Args:
        pdf_path:     Absolute path to the PDF file.
        page_numbers: List of 1-indexed page numbers to extract.

    Returns:
        Dict mapping each input page number to its extracted text
        (empty string if the page is out of range or extraction fails).
        Empty dict if `page_numbers` is empty.  Never raises.
    """
    result: dict[int, str] = {}
    if not page_numbers:
        return result
    try:
        with fitz.open(pdf_path) as doc:
            total = len(doc)
            for pg in page_numbers:
                if pg < 1 or pg > total:
                    result[pg] = ""
                    continue
                try:
                    result[pg] = doc[pg - 1].get_text("text") or ""
                except Exception as exc:
                    logger.warning(f"fitz recovery for page {pg} failed: {exc}")
                    result[pg] = ""
    except Exception as exc:
        # If fitz cannot open the file at all, return empties for every
        # requested page so the recovery loop continues without raising.
        logger.warning(f"fitz recover_pages could not open {pdf_path}: {exc}")
        for pg in page_numbers:
            result.setdefault(pg, "")
    return result


def pages_have_text(pdf_path: str, page_numbers: list[int]) -> dict[int, bool]:
    """Batch text-presence check for a set of 1-based page numbers.

    Opens the PDF once and inspects every requested page.  Returns a dict
    mapping each input page number to True/False.  Used by docling_parser
    to decide which "empty" pages docling actually broke (versus pages
    that legitimately contain no text and so should stay empty).
    """
    result: dict[int, bool] = {}
    if not page_numbers:
        return result
    try:
        with fitz.open(pdf_path) as doc:
            total = len(doc)
            for pg in page_numbers:
                if pg < 1 or pg > total:
                    result[pg] = False
                else:
                    result[pg] = bool(doc[pg - 1].get_text("text").strip())
    except Exception:
        # If fitz cannot open the file at all, conservatively report all
        # pages as having no text.  The recovery loop will then skip them
        # rather than raising.
        for pg in page_numbers:
            result[pg] = False
    return result


def page_has_text(pdf_path: str, page_number: int) -> bool:
    """Single-page text-presence check (kept for backward compatibility).

    Prefer `pages_have_text()` for batch checks — it opens the PDF once
    rather than once per page.
    """
    try:
        with fitz.open(pdf_path) as doc:
            if page_number < 1 or page_number > len(doc):
                return False
            return bool(doc[page_number - 1].get_text("text").strip())
    except Exception:
        return False
