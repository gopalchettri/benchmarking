from fastapi import FastAPI, APIRouter
from fastapi.responses import JSONResponse
from typing import Literal
from pydantic import BaseModel, Field, model_validator
from contextlib import asynccontextmanager
from shared_core.job_client import create_job_record
from shared_core.stream_client import publish_task
from shared_core.redis_client import fetch_job_state
from shared_core.middlewares.tracing import RequestTracingMiddleware
from shared_core.middlewares.rate_limiting import RateLimitingMiddleware
from shared_core.health import check_redis, enforce_startup_checks
import os
from config import get_settings

settings = get_settings()

# ── OpenTelemetry bootstrap ──
from shared_core.telemetry import setup_telemetry, instrument_fastapi
setup_telemetry(service_name=settings.APP_NAME_DOC_PROCESSING)

# ── Logging Setup ──
from utils.logging_config import setup_logging
setup_logging(service_name=settings.APP_NAME_DOC_PROCESSING, environment=settings.ENVIRONMENT)
from shared_core.intercept_handler import install_intercept_handler
install_intercept_handler(["uvicorn", "uvicorn.access", "uvicorn.error", "fastapi"])

# ── Startup health checks ──
_startup_health: dict = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        _startup_health.update(
            await enforce_startup_checks(
                service_name=settings.APP_NAME_DOC_PROCESSING,
                checks={"redis": check_redis(settings.REDIS_URL)},
                critical={"redis"},
            )
        )
    except Exception as exc:
        import logging
        logging.getLogger(__name__).exception(f"Critical startup failure: {exc}")
    yield

app = FastAPI(title=settings.APP_NAME_DOC_PROCESSING, version=settings.APP_VERSION, lifespan=lifespan)
app.add_middleware(RequestTracingMiddleware)
app.add_middleware(
    RateLimitingMiddleware,
    max_requests=settings.GLOBAL_RATE_LIMIT_MAX_REQUESTS,
    window_seconds=settings.GLOBAL_RATE_LIMIT_WINDOW_SECONDS
)
instrument_fastapi(app)

from fastapi import Request
import logging

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logging.getLogger(__name__).exception(f"Unhandled exception in Document Processing: {exc}")
    return JSONResponse(status_code=500, content={"detail": str(exc)})

router = APIRouter(prefix=settings.API_V1_STR, tags=["Document Processing"])

# ── Health endpoint ──
@app.get("/health", tags=["Health"])
async def health():
    live_redis = await check_redis(settings.REDIS_URL)
    return {
        "service": settings.APP_NAME_DOC_PROCESSING,
        "status":  "ok" if live_redis["status"] == "ok" else "degraded",
        "checks":  {"redis": live_redis, "startup": _startup_health},
    }

class ExtractRequest(BaseModel):
    pdf_path: str
    toc_start_page: int = Field(ge=0)
    toc_end_page: int = Field(ge=0)
    content_start_page: int = Field(ge=1)
    content_end_page: int = Field(ge=1)
    orchestration_job_id: str
    framework: str
    framework_profile_id: str = ""
    # Numbering system the user used for toc_start_page / toc_end_page.
    # content_start_page / content_end_page are ALWAYS printed (from the TOC
    # entries themselves), so no flag needed for them.
    toc_numbering: Literal["printed", "physical"] = "printed"

    @model_validator(mode="after")
    def validate_page_ranges(self):
        if self.toc_start_page > 0 and self.toc_start_page > self.toc_end_page:
            raise ValueError("toc_start_page must be <= toc_end_page")
        if self.content_start_page > self.content_end_page:
            raise ValueError("content_start_page must be <= content_end_page")
        return self

@router.post("/extract_text", status_code=202)
async def extract_text(request: ExtractRequest):
    """Dispatch a task to the doc_processing Redis Stream."""
    job_id = await publish_task(
        stream=settings.DOC_PROCESSING_STREAM,
        task_name="process_pdf",
        payload={
            "pdf_path":   request.pdf_path,
            "toc_start_page": request.toc_start_page,
            "toc_end_page":   request.toc_end_page,
            "content_start_page": request.content_start_page,
            "content_end_page":   request.content_end_page,
            "framework":  request.framework,
            "framework_profile_id": request.framework_profile_id,
            "toc_numbering":        request.toc_numbering,
        },
        job_id=request.orchestration_job_id,
    )
    await create_job_record(
        job_id=job_id,
        framework=request.framework,
        framework_profile_id=request.framework_profile_id or None,
        blob_path=request.pdf_path,
    )
    return {"job_id": job_id, "status": "queued"}

@router.get("/jobs/{job_id}")
async def get_job_status(job_id: str):
    state = await fetch_job_state(job_id) or "pending"
    return {"job_id": job_id, "status": state}

app.include_router(router)
