"""
Framework Auto-Detector
========================
Scores extracted document text against all known framework profiles
to automatically identify the compliance framework.

Used when framework_profile_id is not provided in the upload request.
Scoring: keyword_match_score from profile name/display_name tokens.
"""
import httpx
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from config import get_settings
from utils.logging_config import logger

settings = get_settings()


@dataclass
class DetectionCandidate:
    """A framework detection candidate with confidence score."""
    profile_id: str
    profile_name: str
    display_name: str
    confidence: float
    keyword_score: float
    keyword_matches: List[str] = field(default_factory=list)


@dataclass
class DetectionResult:
    """Result of framework auto-detection."""
    detected: bool
    selected_profile_id: Optional[str]
    selected_profile_name: Optional[str]
    confidence: float
    candidates: List[DetectionCandidate]


def _compute_keyword_score(
    text_lower: str,
    title_keywords: List[str],
) -> Tuple[float, List[str]]:
    """
    Case-insensitive keyword matching.

    Returns (score, matched_keywords).
    Score = fraction of profile keywords found in text.
    """
    if not title_keywords:
        return 0.0, []

    matched = [kw for kw in title_keywords if kw.lower() in text_lower]
    score = len(matched) / len(title_keywords)
    return score, matched


def detect_framework(
    text: str,
    profiles: List[dict],
    confidence_threshold: Optional[float] = None,
) -> DetectionResult:
    """
    Score text against all profiles and return detection result.

    Args:
        text: Extracted document text (will be truncated to FRAMEWORK_DETECTION_MAX_SCAN_CHARS)
        profiles: List of profile dicts (from storage service list_profiles)
        confidence_threshold: Minimum score to auto-select (default 0.85)

    Returns:
        DetectionResult with selected profile or candidate list
    """
    if confidence_threshold is None:
        confidence_threshold = settings.AUTODETECT_CONFIDENCE_THRESHOLD

    if not profiles:
        return DetectionResult(
            detected=False,
            selected_profile_id=None,
            selected_profile_name=None,
            confidence=0.0,
            candidates=[],
        )

    scan_text = text[:settings.FRAMEWORK_DETECTION_MAX_SCAN_CHARS]
    scan_text_lower = scan_text.lower()
    candidates: List[DetectionCandidate] = []

    for profile in profiles:
        profile_id = profile.get("id", "")
        profile_name = profile.get("name", "")
        display_name = profile.get("display_name", profile_name)

        # Auto-derive keywords from name and display_name (no manual title_keywords needed)
        raw_tokens = set((display_name + " " + profile_name).lower().replace("-", " ").replace("/", " ").split())
        auto_keywords = [t for t in raw_tokens if len(t) > 2]  # skip short tokens like "v1"
        kw_score, kw_matches = _compute_keyword_score(scan_text_lower, auto_keywords)

        candidates.append(DetectionCandidate(
            profile_id=profile_id,
            profile_name=profile_name,
            display_name=display_name,
            confidence=kw_score,
            keyword_score=kw_score,
            keyword_matches=kw_matches,
        ))

    # Sort by confidence descending
    candidates.sort(key=lambda c: c.confidence, reverse=True)

    top = candidates[0]
    if top.confidence >= confidence_threshold:
        logger.info(
            f"[AutoDetect] Detected: {top.profile_name} "
            f"(confidence={top.confidence:.2f}, keywords={top.keyword_matches})"
        )
        return DetectionResult(
            detected=True,
            selected_profile_id=top.profile_id,
            selected_profile_name=top.profile_name,
            confidence=top.confidence,
            candidates=candidates,
        )

    logger.info(
        f"[AutoDetect] No confident match. Top 3: "
        f"{[(c.profile_name, f'{c.confidence:.2f}') for c in candidates[:3]]}"
    )
    return DetectionResult(
        detected=False,
        selected_profile_id=None,
        selected_profile_name=None,
        confidence=top.confidence,
        candidates=candidates,
    )


async def fetch_profiles_for_detection(
    storage_service_url: str,
    api_v1_str: str,
) -> List[dict]:
    """
    Fetch all framework profiles from the storage service via HTTP GET.

    Args:
        storage_service_url: Base URL of storage service (e.g., "http://localhost:8003")
        api_v1_str: API version prefix (e.g., "/api/v1")

    Returns:
        List of profile dicts
    """

    url = f"{storage_service_url}{api_v1_str}/admin/framework-profiles"
    try:
        async with httpx.AsyncClient(timeout=settings.PROFILE_FETCH_TIMEOUT_SECONDS) as client:
            resp = await client.get(url)
            if resp.status_code == 200:
                data = resp.json()
                # list_profiles returns a list directly
                if isinstance(data, list):
                    return data
                return data.get("profiles", data.get("items", []))
            logger.warning(f"[AutoDetect] Profile fetch returned {resp.status_code}")
    except Exception as e:
        logger.warning(f"[AutoDetect] Failed to fetch profiles: {e}")
    return []
