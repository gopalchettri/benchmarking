"""
ai_extraction Redis Stream Worker
=====================================
Starts an async consumer loop listening on the "ai_extraction:stream" Redis Stream.

Run from the project root:
    python services/ai_extraction/worker.py

No fork() — fully async, native Windows support.
Requires: REDIS_URL in .env (e.g. redis://localhost:6379/0)
"""
import asyncio
import os
import signal
import sys

# TODO: Replace sys.path manipulation with proper Python packaging (pyproject.toml)
# when the project is restructured as installable packages.
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if BASE not in sys.path:
    sys.path.insert(0, BASE)
if os.path.join(BASE, 'shared_core') not in sys.path:
    sys.path.insert(0, os.path.join(BASE, 'shared_core'))
if os.path.dirname(__file__) not in sys.path:
    sys.path.insert(0, os.path.dirname(__file__))

from shared_core.stream_client import consume_stream
from jobs.handlers import HANDLERS, AI_STREAM, AI_GROUP, cleanup_shared_resources
from utils.logging_config import setup_logging, logger
from config import get_settings

settings = get_settings()
setup_logging(service_name=settings.APP_NAME_AI_EXTRACTION + " Worker", environment=settings.ENVIRONMENT)


async def main():
    # Register SIGTERM for graceful shutdown (Docker, systemd, K8s).
    # Windows ProactorEventLoop doesn't support add_signal_handler — falls
    # back to KeyboardInterrupt handling in the __main__ block below.
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, lambda: loop.stop())
        except NotImplementedError:
            pass  # Windows: not supported in ProactorEventLoop

    logger.info(f"[ai_extraction worker] Starting. Listening on stream={AI_STREAM} group={AI_GROUP}")
    try:
        await consume_stream(
            stream=AI_STREAM,
            group=AI_GROUP,
            handlers=HANDLERS,
        )
    finally:
        await cleanup_shared_resources()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("[ai_extraction worker] Stopped by user.")
