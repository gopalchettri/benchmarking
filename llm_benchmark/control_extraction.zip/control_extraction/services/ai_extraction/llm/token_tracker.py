"""
Token Tracker Module

Tracks token usage across all LLM calls for cost monitoring and observability.
Based on framework_extractor_llm_agnostic implementation.
"""

import threading
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, Deque, List, Optional
from utils.logging_config import logger
from config import get_settings


@dataclass
class CallRecord:
    """Record of a single LLM call"""
    timestamp: datetime
    input_tokens: int
    output_tokens: int
    total_tokens: int
    success: bool
    model: str
    control_id: Optional[str] = None
    duration_ms: Optional[int] = None


class TokenTracker:
    """
    Track token usage across all LLM calls.

    Features:
    - Per-call tracking with timestamps
    - Aggregate statistics
    - Success/failure tracking
    - Cost estimation (configurable rates)
    """

    def __init__(
        self,
        cost_per_1k_input: float = 0.0,
        cost_per_1k_output: float = 0.0,
        history_size: int = 1000,
        log_frequency: int = 5,
    ):
        """
        Initialize TokenTracker.

        Args:
            cost_per_1k_input: Cost per 1000 input tokens (for cost estimation)
            cost_per_1k_output: Cost per 1000 output tokens (for cost estimation)
            history_size: Max call records to keep in deque (configurable via TOKEN_TRACKER_HISTORY_SIZE)
            log_frequency: Log running totals every N calls (configurable via TOKEN_TRACKER_LOG_FREQUENCY)
        """
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_calls = 0
        self.successful_calls = 0
        self.failed_calls = 0
        self._history_size = history_size
        self._log_frequency = log_frequency
        self.call_history: Deque[CallRecord] = deque(maxlen=history_size)
        # Thread-safe mutation guard — record_call may be invoked from
        # asyncio.to_thread or multiple worker threads in production.
        self._record_lock = threading.Lock()

        # Cost tracking
        self.cost_per_1k_input = cost_per_1k_input
        self.cost_per_1k_output = cost_per_1k_output

    def record_call(
        self,
        input_tokens: int,
        output_tokens: int,
        success: bool,
        model: str = "",
        control_id: Optional[str] = None,
        duration_ms: Optional[int] = None
    ):
        """
        Record a single LLM call.

        Args:
            input_tokens: Number of input (prompt) tokens
            output_tokens: Number of output (completion) tokens
            success: Whether the call succeeded
            model: Model name
            control_id: Optional control ID being processed
            duration_ms: Optional call duration in milliseconds
        """
        # Snapshot values for periodic logging under the lock
        should_log_totals = False
        snap_calls = 0
        snap_total_tokens = 0
        snap_success_rate = 0.0

        with self._record_lock:
            self.total_calls += 1
            self.total_input_tokens += input_tokens
            self.total_output_tokens += output_tokens

            if success:
                self.successful_calls += 1
            else:
                self.failed_calls += 1

            record = CallRecord(
                timestamp=datetime.now(timezone.utc),
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=input_tokens + output_tokens,
                success=success,
                model=model,
                control_id=control_id,
                duration_ms=duration_ms
            )
            self.call_history.append(record)

            # Snapshot for periodic logging (reads shared state under lock)
            if self.total_calls % self._log_frequency == 0:
                should_log_totals = True
                snap_calls = self.total_calls
                snap_total_tokens = self.total_input_tokens + self.total_output_tokens
                snap_success_rate = self.successful_calls / self.total_calls * 100

        # Log individual call at INFO level for visibility
        status = "SUCCESS" if success else "FAILED"
        duration_str = f", duration={duration_ms}ms" if duration_ms else ""
        speed_str = ""
        if success and duration_ms and output_tokens > 0:
            speed = output_tokens / (duration_ms / 1000)
            speed_str = f", speed={speed:.1f} tok/s"

        logger.info(
            f"[TokenTracker] LLM Call {status}: "
            f"in={input_tokens:,}, out={output_tokens:,}, total={input_tokens + output_tokens:,}"
            f"{duration_str}{speed_str} (model={model})"
        )

        # Log running totals periodically (using snapshot taken under lock)
        if should_log_totals:
            logger.info(
                f"[TokenTracker] Running totals: "
                f"calls={snap_calls}, "
                f"total_tokens={snap_total_tokens:,}, "
                f"success_rate={snap_success_rate:.0f}%"
            )

    def get_summary(self) -> Dict:
        """
        Get token usage summary (thread-safe snapshot).

        Returns:
            Dictionary with aggregate statistics
        """
        with self._record_lock:
            total_tokens = self.total_input_tokens + self.total_output_tokens
            estimated_cost = (
                (self.total_input_tokens / 1000) * self.cost_per_1k_input +
                (self.total_output_tokens / 1000) * self.cost_per_1k_output
            )

            avg_input = self.total_input_tokens / self.total_calls if self.total_calls > 0 else 0
            avg_output = self.total_output_tokens / self.total_calls if self.total_calls > 0 else 0

            return {
                'total_input_tokens': self.total_input_tokens,
                'total_output_tokens': self.total_output_tokens,
                'total_tokens': total_tokens,
                'total_calls': self.total_calls,
                'successful_calls': self.successful_calls,
                'failed_calls': self.failed_calls,
                'success_rate': (self.successful_calls / self.total_calls * 100) if self.total_calls > 0 else 0,
                'avg_input_tokens_per_call': int(avg_input),
                'avg_output_tokens_per_call': int(avg_output),
                'estimated_cost_usd': round(estimated_cost, 4) if estimated_cost > 0 else None
            }

    def log_summary(self):
        """Log token usage summary (single-line for log aggregator compatibility)."""
        summary = self.get_summary()
        cost_str = f", est_cost=${summary['estimated_cost_usd']:.4f}" if summary['estimated_cost_usd'] is not None else ""
        logger.info(
            f"[TokenTracker] FINAL SUMMARY: "
            f"calls={summary['total_calls']} (ok={summary['successful_calls']}, fail={summary['failed_calls']}, "
            f"rate={summary['success_rate']:.1f}%), "
            f"tokens(in={summary['total_input_tokens']:,}, out={summary['total_output_tokens']:,}, "
            f"total={summary['total_tokens']:,}), "
            f"avg/call(in={summary['avg_input_tokens_per_call']:,}, out={summary['avg_output_tokens_per_call']:,})"
            f"{cost_str}"
        )

    def reset(self):
        """Reset all counters (thread-safe)."""
        with self._record_lock:
            self.total_input_tokens = 0
            self.total_output_tokens = 0
            self.total_calls = 0
            self.successful_calls = 0
            self.failed_calls = 0
            self.call_history = deque(maxlen=self._history_size)
        logger.info("TokenTracker reset")

    def get_recent_calls(self, n: int = 10) -> List[Dict]:
        """
        Get the N most recent calls (thread-safe snapshot).

        Args:
            n: Number of recent calls to return

        Returns:
            List of call records as dictionaries
        """
        with self._record_lock:
            recent = list(self.call_history)[-n:]
        return [
            {
                'timestamp': r.timestamp.isoformat(),
                'input_tokens': r.input_tokens,
                'output_tokens': r.output_tokens,
                'total_tokens': r.total_tokens,
                'success': r.success,
                'model': r.model,
                'control_id': r.control_id,
                'duration_ms': r.duration_ms
            }
            for r in recent
        ]


# M-7: Thread-safe singleton with double-checked locking
_global_tracker: Optional[TokenTracker] = None
_tracker_lock = threading.Lock()


def get_token_tracker() -> TokenTracker:
    """Get or create global TokenTracker instance (thread-safe, uses config for sizing)."""
    global _global_tracker
    if _global_tracker is not None:
        return _global_tracker
    with _tracker_lock:
        if _global_tracker is not None:
            return _global_tracker
        try:
            _cfg = get_settings()
            _global_tracker = TokenTracker(
                cost_per_1k_input=_cfg.LLM_COST_PER_1K_INPUT,
                cost_per_1k_output=_cfg.LLM_COST_PER_1K_OUTPUT,
                history_size=_cfg.TOKEN_TRACKER_HISTORY_SIZE,
                log_frequency=_cfg.TOKEN_TRACKER_LOG_FREQUENCY,
            )
        except Exception as e:
            logger.warning(
                f"TokenTracker config failed: {e}. "
                "Falling back to defaults — cost rates may be incorrect."
            )
            _global_tracker = TokenTracker()
    return _global_tracker


def reset_token_tracker():
    """Reset the global token tracker"""
    global _global_tracker
    if _global_tracker:
        _global_tracker.reset()
