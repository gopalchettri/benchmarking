"""
LLM pipeline metrics
====================

Lightweight counters for LLM-phase observability. Uses OpenTelemetry meters
when available (OTEL_EXPORTER_OTLP_ENDPOINT configured), otherwise records
structured log lines that operators can ingest via log aggregation.

Emitted counters:
    ai_extraction_llm_calls_total{phase, outcome, framework}
        One increment per LLM roundtrip. outcome ∈ {ok, truncated, error}.

    ai_extraction_llm_splits_total{phase, framework}
        One increment each time a window/content block is bisected due to
        truncation. Tracks how often the split-on-truncation safety net
        activates — high rates signal undersized token budgets.

    ai_extraction_llm_truncations_total{phase, terminal, framework}
        One increment per observed truncation. terminal=true means the
        truncation could NOT be resolved via split (1-page window or
        depth limit reached) — partial results were accepted.

Also emits a histogram of split recursion depth:
    ai_extraction_llm_split_depth{phase, framework}

Consumers:
    - Prometheus / Azure Monitor via the OTel Collector
    - Grafana dashboards for discovery-failure rates per framework
    - Ops alerts when splits_total spikes above baseline
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from utils.logging_config import logger


# Lazy-initialized meters. Holding an attribute on the module lets tests
# reset state between runs if they monkey-patch _get_meters.
_METERS: dict | None = None


def _get_meters() -> dict:
    """Lazily create OpenTelemetry counters/histograms.

    Returns a dict with keys:
        "calls"        — Counter for ai_extraction_llm_calls_total
        "splits"       — Counter for ai_extraction_llm_splits_total
        "truncations"  — Counter for ai_extraction_llm_truncations_total
        "split_depth"  — Histogram for ai_extraction_llm_split_depth

    Each value is either a real OTel instrument or None if OTel isn't
    available (graceful degradation — we still log structured lines).
    """
    global _METERS
    if _METERS is not None:
        return _METERS

    instruments = {
        "calls": None,
        "splits": None,
        "truncations": None,
        "split_depth": None,
    }
    try:
        from opentelemetry import metrics as otel_metrics

        meter = otel_metrics.get_meter("control_extraction.ai_extraction.llm")
        instruments["calls"] = meter.create_counter(
            name="ai_extraction_llm_calls_total",
            unit="1",
            description="Count of LLM calls by extraction phase and outcome",
        )
        instruments["splits"] = meter.create_counter(
            name="ai_extraction_llm_splits_total",
            unit="1",
            description="Count of window/content splits due to truncation",
        )
        instruments["truncations"] = meter.create_counter(
            name="ai_extraction_llm_truncations_total",
            unit="1",
            description="Count of LLM responses that hit the max_tokens ceiling",
        )
        instruments["split_depth"] = meter.create_histogram(
            name="ai_extraction_llm_split_depth",
            unit="1",
            description="Recursion depth of split-on-truncation branches",
        )
    except Exception as exc:
        # OTel not installed or not configured: all instruments stay None.
        # Structured log fallback below still fires for every event.
        logger.debug(f"[Metrics] OpenTelemetry meter unavailable — using log-only: {exc}")

    _METERS = instruments
    return _METERS


def _stable_attrs(phase: str, framework: str | None) -> dict:
    """Normalise label values so cardinality stays bounded."""
    return {
        "phase": phase,
        "framework": framework or "unknown",
    }


def record_llm_call(
    *,
    phase: str,
    outcome: str,
    framework: str | None = None,
) -> None:
    """Record one LLM call completion.

    Args:
        phase:     "discovery" | "toc" | "subcontrol" | other pipeline phase
        outcome:   "ok" | "truncated" | "error"
        framework: Framework profile name (e.g. "PCI-DSS") for per-framework
                grouping in dashboards. None accepted for pre-detection calls.
    """
    meters = _get_meters()
    counter = meters["calls"]
    attrs = _stable_attrs(phase, framework)
    if counter is not None:
        counter.add(1, {**attrs, "outcome": outcome})
    # Always log — gives operators signal without requiring OTel.
    logger.debug(
        f"[Metrics] llm_call phase={phase} outcome={outcome} framework={attrs['framework']}"
    )


def record_split(
    *,
    phase: str,
    depth: int,
    framework: str | None = None,
) -> None:
    """Record one window/content bisection event."""
    meters = _get_meters()
    attrs = _stable_attrs(phase, framework)
    counter = meters["splits"]
    if counter is not None:
        counter.add(1, attrs)
    hist = meters["split_depth"]
    if hist is not None:
        hist.record(depth, attrs)
    logger.info(
        f"[Metrics] split phase={phase} depth={depth} framework={attrs['framework']}"
    )


def record_truncation(
    *,
    phase: str,
    terminal: bool,
    framework: str | None = None,
) -> None:
    """Record one truncation observation.

    Args:
        phase:    "discovery" | "toc" | "subcontrol"
        terminal: True when truncation could NOT be recovered via split
                (1-page window, single-block content, or depth limit).
                False when the caller intends to split and retry.
        framework: optional framework name.
    """
    meters = _get_meters()
    attrs = _stable_attrs(phase, framework)
    counter = meters["truncations"]
    if counter is not None:
        counter.add(1, {**attrs, "terminal": str(terminal).lower()})
    level = logger.warning if terminal else logger.info
    level(
        f"[Metrics] truncation phase={phase} terminal={terminal} "
        f"framework={attrs['framework']}"
    )


def reset_for_tests() -> None:
    """Test-only hook: force re-lookup of meters on next call.

    Public tests should not rely on OTel instruments; they should monkey-patch
    _get_meters or observe the structured log lines.
    """
    global _METERS
    _METERS = None
