"""
Rate Limiter Module

Implements token bucket rate limiting for LLM calls to prevent overloading.

Features:
- Token bucket algorithm with configurable rate and burst
- Async-compatible with proper locking
- Automatic token replenishment
- Always-on minimum gap between granted calls (not just during throttled waits)
- 429-aware adaptive backoff via notify_rate_limited()
- Metrics integration for monitoring
"""

import asyncio
import random
import time
from dataclasses import dataclass
from typing import Optional

from utils.logging_config import logger


@dataclass
class RateLimitConfig:
    """Configuration for rate limiting.

    ``min_gap_seconds`` (formerly ``min_interval_seconds``) is enforced as a
    floor between any two granted calls — including during the burst — not
    only when the bucket is empty. The legacy ``min_interval_seconds`` kwarg
    is still accepted for backward compatibility; if both are passed,
    ``min_gap_seconds`` wins.
    """
    requests_per_minute: float = 8.0
    burst_size: int = 2
    min_gap_seconds: float = 2.0

    # Legacy alias — kept so existing callers using min_interval_seconds=...
    # don't break. Not stored on the dataclass; consumed in __post_init__.
    min_interval_seconds: Optional[float] = None

    def __post_init__(self) -> None:
        if self.min_interval_seconds is not None:
            # Only adopt the legacy value when min_gap_seconds was left at
            # the field default (2.0) — i.e. caller did not set it explicitly.
            if self.min_gap_seconds == 2.0:
                self.min_gap_seconds = float(self.min_interval_seconds)
        # Drop the alias so logging / repr show only the canonical name.
        object.__setattr__(self, "min_interval_seconds", None)


class TokenBucketRateLimiter:
    """
    Token bucket rate limiter for LLM API calls.

    Algorithm:
    - Bucket holds up to `burst_size` tokens
    - Tokens replenish at `requests_per_minute / 60` per second
    - Each request consumes 1 token
    - If no tokens available, wait until one is replenished
    - After a token is granted, next call waits at least ``min_gap_seconds``

    This prevents:
    - Overwhelming the LLM server with too many concurrent requests
    - Getting rate-limited by external APIs (Azure, etc.)
    - Resource exhaustion on self-hosted LLMs (Ollama)
    """

    def __init__(self, config: Optional[RateLimitConfig] = None):
        self.config = config or RateLimitConfig()

        # Token bucket state
        self._tokens = float(self.config.burst_size)
        self._last_update = time.monotonic()
        # Timestamp of the most recent granted token. Used to enforce
        # min_gap_seconds even when bucket has tokens available.
        # Initialised far in the past so the first call never waits.
        self._last_grant = time.monotonic() - max(self.config.min_gap_seconds, 0.0) - 1.0
        self._lock = asyncio.Lock()

        # Calculate replenishment rate
        self._tokens_per_second = self.config.requests_per_minute / 60.0

        # Metrics
        self._total_requests = 0
        self._total_wait_time = 0.0
        self._throttled_requests = 0

        logger.info(
            f"RateLimiter initialized: {self.config.requests_per_minute} req/min, "
            f"burst={self.config.burst_size}, min_gap={self.config.min_gap_seconds}s"
        )

    def _replenish(self) -> None:
        """Replenish tokens based on elapsed time. Must be called under lock."""
        now = time.monotonic()
        elapsed = now - self._last_update
        self._tokens = min(
            self.config.burst_size,
            self._tokens + elapsed * self._tokens_per_second
        )
        self._last_update = now

    async def acquire(self) -> float:
        """
        Acquire permission to make a request.

        Uses atomic check-and-consume under a single lock acquisition
        to prevent race conditions between concurrent coroutines.

        Returns:
            Total wait time in seconds (0 if no wait was needed)
        """
        total_wait = 0.0

        # M-1: Count once per logical request, before the retry loop.
        async with self._lock:
            self._total_requests += 1

        # H-4: Track whether this request was ever throttled.
        was_throttled = False

        while True:
            async with self._lock:
                self._replenish()

                # Min-gap enforcement (always-on, including during burst).
                # If the previous grant was too recent, sleep the residual
                # before consuming a token.
                gap = self.config.min_gap_seconds
                gap_wait = 0.0
                if gap > 0:
                    elapsed_since_grant = time.monotonic() - self._last_grant
                    if elapsed_since_grant < gap:
                        gap_wait = gap - elapsed_since_grant

                if self._tokens >= 1.0 and gap_wait <= 0:
                    # Atomic: check and consume in one lock scope
                    self._tokens -= 1.0
                    self._last_grant = time.monotonic()
                    if was_throttled:
                        self._throttled_requests += 1
                    return total_wait

                if self._tokens >= 1.0 and gap_wait > 0:
                    # Tokens available, but min-gap floor not yet satisfied.
                    wait_time = gap_wait
                else:
                    # Bucket exhausted — wait for replenishment.
                    deficit = 1.0 - self._tokens
                    wait_time = deficit / self._tokens_per_second
                    # Honour min-gap as well (whichever is larger applies).
                    wait_time = max(wait_time, gap_wait)

                wait_time = min(wait_time, 60.0)  # Cap to prevent pathological waits
                was_throttled = True
                logger.debug(
                    f"Rate limited: waiting {wait_time:.2f}s "
                    f"(tokens={self._tokens:.2f}, gap_wait={gap_wait:.2f}s)"
                )

            # Add jitter (±15%) to prevent thundering herd when multiple
            # coroutines are throttled simultaneously.
            jittered = wait_time * (0.85 + random.random() * 0.30)
            # Sleep outside the lock so other coroutines can proceed
            await asyncio.sleep(jittered)
            total_wait += jittered
            # Update aggregate metric under lock to prevent concurrent
            # coroutines from interleaving += during their wait phases.
            async with self._lock:
                self._total_wait_time += jittered

    async def notify_rate_limited(self, retry_after: Optional[float] = None) -> None:
        """Inform the limiter that the upstream returned a 429.

        Drains the bucket and pushes the next replenishment forward by
        ``retry_after`` seconds (default 5s when the header is missing) so
        the next ``acquire()`` waits at least that long.

        Safe to call concurrently with ``acquire()`` — guarded by the same
        lock. Idempotent within a single quiet window (multiple notifications
        during the same backoff just extend the deferral).
        """
        wait = float(retry_after) if (retry_after is not None and retry_after > 0) else 5.0
        async with self._lock:
            self._tokens = 0.0
            # Defer replenishment: the next _replenish() call will compute
            # elapsed from this future timestamp, yielding zero new tokens
            # until ``wait`` seconds have actually passed.
            self._last_update = time.monotonic() + wait
            # Also push _last_grant forward so min_gap is honoured against
            # the deferral window (callers won't sneak in via the gap path).
            self._last_grant = time.monotonic() + wait
        logger.warning(
            f"RateLimiter: upstream 429 received — backing off for {wait:.1f}s"
        )

    async def __aenter__(self):
        """Context manager entry - acquires rate limit token."""
        await self.acquire()
        return self

    async def __aexit__(self, _exc_type, _exc_val, _exc_tb):
        """Context manager exit — does not suppress exceptions."""
        return False

    async def get_metrics(self) -> dict:
        """Get rate limiter metrics (consistent snapshot under lock)."""
        async with self._lock:
            return {
                "total_requests": self._total_requests,
                "throttled_requests": self._throttled_requests,
                "total_wait_time_seconds": round(self._total_wait_time, 2),
                "current_tokens": round(self._tokens, 2),
                "throttle_rate": (
                    round(self._throttled_requests / self._total_requests * 100, 1)
                    if self._total_requests > 0 else 0
                ),
            }

    def reset(self):
        """Reset the rate limiter to initial state.

        WARNING: Not safe to call while acquire() is in progress.
        Only call during initialization, tests, or when no concurrent
        work is running. The asyncio.Lock used by acquire() cannot be
        acquired from a synchronous method.
        """
        if self._lock.locked():
            raise RuntimeError(
                "TokenBucketRateLimiter.reset() called while a coroutine "
                "holds the lock — would corrupt state. Call only when no "
                "concurrent acquire() is in progress."
            )
        self._tokens = float(self.config.burst_size)
        self._last_update = time.monotonic()
        self._last_grant = time.monotonic() - max(self.config.min_gap_seconds, 0.0) - 1.0
        self._total_requests = 0
        self._total_wait_time = 0.0
        self._throttled_requests = 0
