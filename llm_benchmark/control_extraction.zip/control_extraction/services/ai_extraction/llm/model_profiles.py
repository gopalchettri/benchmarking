"""
Model Throughput Profiles
=========================

Maps an LLM model/deployment name to a sensible default throughput profile
(RPM, burst, max-inflight, min-gap, context window). Lets operators switch
the active model without re-tuning four flat env vars.

Resolution order at startup (in handlers._get_shared_rate_limiter):
1. Explicit env var (positive value) wins.
2. Profile match by prefix on the model name.
3. DEFAULT_PROFILE (matches the historical hardcoded defaults exactly).

Numbers below are starting estimates calibrated to typical Azure quotas;
operators should adjust the table once for their actual deployment quota
and never touch ``.env`` again.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ModelProfile:
    """Throughput characteristics for a single LLM model/deployment."""
    rpm: float                # sustained requests per minute (Azure quota or self-hosted limit)
    burst: int                # token bucket capacity — instant calls after a quiet period
    max_inflight: int         # cap on concurrent in-flight LLM calls (orthogonal to burst)
    min_gap_seconds: float    # always-on floor between any two granted calls
    context_tokens: int       # model context window
    is_reasoning: bool        # informational: reasoning models add hidden latency


# Azure OpenAI deployment defaults. Keys are matched as case-insensitive
# prefixes against the deployment name, so e.g. ``gpt-4o-mini-2024-07-18``
# resolves to the ``gpt-4o-mini`` entry.
AZURE_PROFILES: dict[str, ModelProfile] = {
    "gpt-5-mini":   ModelProfile(rpm=60,  burst=10, max_inflight=8,  min_gap_seconds=0.0, context_tokens=128_000, is_reasoning=True),
    "gpt-5":        ModelProfile(rpm=30,  burst=6,  max_inflight=5,  min_gap_seconds=0.0, context_tokens=200_000, is_reasoning=True),
    "gpt-4o-mini":  ModelProfile(rpm=200, burst=20, max_inflight=15, min_gap_seconds=0.0, context_tokens=128_000, is_reasoning=False),
    "gpt-4o":       ModelProfile(rpm=80,  burst=15, max_inflight=10, min_gap_seconds=0.0, context_tokens=128_000, is_reasoning=False),
    "gpt-4.1-mini": ModelProfile(rpm=200, burst=20, max_inflight=15, min_gap_seconds=0.0, context_tokens=1_000_000, is_reasoning=False),
    "gpt-4.1":      ModelProfile(rpm=80,  burst=15, max_inflight=10, min_gap_seconds=0.0, context_tokens=1_000_000, is_reasoning=False),
}

# Local Ollama models. RPM is effectively unbounded; concurrency is the only
# real constraint and it's small (single GPU / CPU saturates fast).
OLLAMA_PROFILES: dict[str, ModelProfile] = {
    "default": ModelProfile(rpm=600, burst=2, max_inflight=2, min_gap_seconds=0.0, context_tokens=32_000, is_reasoning=False),
}

# Conservative fallback. Matches today's hardcoded defaults exactly so an
# unknown model + unset env vars behaves identically to the pre-registry code.
DEFAULT_PROFILE = ModelProfile(
    rpm=8, burst=5, max_inflight=5, min_gap_seconds=0.5,
    context_tokens=128_000, is_reasoning=True,
)


def resolve_profile(provider: str, model_name: Optional[str]) -> ModelProfile:
    """Look up the throughput profile for the active provider+model.

    Falls back to ``DEFAULT_PROFILE`` when the provider is unknown or the
    model name doesn't match any registry entry. Matching is case-insensitive
    and uses the longest-prefix-wins rule, so versioned deployment names
    (``gpt-4o-mini-2024-07-18``) resolve to the right family entry.
    """
    if not model_name:
        return DEFAULT_PROFILE

    table = {
        "azure": AZURE_PROFILES,
        "ollama": OLLAMA_PROFILES,
    }.get((provider or "").lower(), {})

    if not table:
        return DEFAULT_PROFILE

    name_lc = model_name.lower()

    # For Ollama, allow a generic "default" entry to catch any model.
    if provider.lower() == "ollama" and "default" in table:
        # Still prefer an explicit per-model entry if one exists.
        explicit = _longest_prefix_match(name_lc, table)
        return explicit or table["default"]

    return _longest_prefix_match(name_lc, table) or DEFAULT_PROFILE


def _longest_prefix_match(name_lc: str, table: dict[str, ModelProfile]) -> Optional[ModelProfile]:
    best_key = ""
    for key in table:
        key_lc = key.lower()
        if name_lc.startswith(key_lc) and len(key_lc) > len(best_key):
            best_key = key_lc
    if not best_key:
        return None
    # Find the original-cased key that matches.
    for key, profile in table.items():
        if key.lower() == best_key:
            return profile
    return None
