"""
Sub-Control Extractor
=====================
Extracts sub-controls from framework PDF content using LLM.

PRIMARY PATH — TOC page-window groups (PageGroup):
  Requires toc_entries with page numbers + control_start_page/control_end_page.
  One LLM call per PageGroup (controls sharing the same TOC start page).
  ±1 page overlap absorbs TOC off-by-one errors and cross-page content bleed.

Token tracking is done INSIDE providers.py — do NOT call record_call() here.
IDs are computed deterministically from parent_id + number (not from LLM output).
"""

import asyncio
import functools
import math
import re
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from pydantic import ValidationError

from llm.metrics import record_llm_call, record_split, record_truncation
from llm.providers import ILLMProvider, estimate_tokens
from llm.rate_limiter import TokenBucketRateLimiter
from models import (
    ControlExtraction, ExtractionsWrapper, SubControl, TOCEntry,
    compose_sub_control_id,
    PageGroup,
)
from post_extraction_validator import (
    merge_lowercase_continuations,
    renest_interleaved_children,
    detect_letter_sequence_gaps,
)
from prompts import load_framework_prompts
from prompts.base import build_subcontrol_prompts, _SAFE_CONTROL_ID
from utils.logging_config import logger
from extraction.post_process import (
    dedup_extractions,
    locate_controls_in_text,
    consolidate_hierarchy,
    sort_by_toc_order,
)
from extraction.id_pattern import derive_id_pattern
from core.document import split_by_page_markers

if TYPE_CHECKING:
    from config import Settings

# Matches printed page footers (e.g. "Page 3 of 45") to strip from window text.
_PAGE_STRIP_RE = re.compile(r'\n*Page \d+ of \d+\n*')

# Max sub-control nesting depth (parsing guard, NOT rebuild iterations).
# Prevents stack overflow from malformed LLM output with excessive nesting.
# make it configurable via .env if needed, but 20 is a reasonable default for known frameworks
_MAX_NESTING_DEPTH = 20

@functools.lru_cache(maxsize=64)
def _safe_compile_pattern(pattern: str) -> re.Pattern:
    """Compile and cache a regex pattern from a framework profile.

    lru_cache ensures each pattern is compiled only once per process lifetime.
    Raises ValueError on invalid pattern syntax.
    """
    try:
        return re.compile(pattern)
    except re.error as e:
        raise ValueError(f"Invalid regex pattern '{pattern}': {e}") from e





@dataclass
class ExtractionResult:
    """Result of sub-control extraction, preserving errors for auditability."""
    extractions: List[ControlExtraction]
    errors: List[str] = field(default_factory=list)
    missing_control_ids: List[str] = field(default_factory=list)


# ── Module-level helpers ─────────────────────────────────────────────────────


def _natural_sort_key(value: str) -> list:
    """Sort key for mixed dotted IDs without str/int comparison errors."""
    parts = re.split(r'[.\-]', value)
    return [(0, int(p)) if p.isdigit() else (1, p.lower()) for p in parts]


def _merge_sub_control_lists(
    first: List[SubControl],
    second: List[SubControl],
) -> List[SubControl]:
    """Recursively merge two sub_control lists by number.

    When both lists contain the same number, their children and sections
    are merged recursively (not replaced wholesale).  This prevents
    silently dropping children that appear in only one half of a split.
    """
    seen: Dict[str, SubControl] = {}
    for sc in first:
        seen[sc.number] = sc

    for sc in second:
        prev = seen.get(sc.number)
        if prev is None:
            seen[sc.number] = sc
        else:
            # Recursively merge children
            prev.children = _merge_sub_control_lists(prev.children, sc.children)
            # Merge sections (keep existing, add missing)
            for key, val in sc.sections.items():
                if key not in prev.sections:
                    prev.sections[key] = val

    return sorted(seen.values(), key=lambda s: _natural_sort_key(s.number))


def _merge_chunked_extractions(
    first: List[ControlExtraction],
    second: List[ControlExtraction],
) -> List[ControlExtraction]:
    """Merge extractions from two split windows of the same control group.

    When a page group is too large for the context window, it is split into
    sub-windows.  Both halves target the same control_ids, so the results
    may overlap.  This helper merges them by control_id:
    - If only one half has a control, keep it as-is.
    - If both halves extracted the same control_id, recursively merge
        their sections and sub_controls (by number, at every nesting level).
        Sub-controls are sorted by natural order after merging.
    """
    if not first:
        return second
    if not second:
        return first

    by_id: Dict[str, ControlExtraction] = {}
    for ext in first:
        by_id[ext.control_id] = ext

    for ext in second:
        if ext.control_id not in by_id:
            by_id[ext.control_id] = ext
        else:
            existing = by_id[ext.control_id]
            # Merge top-level sections (keep existing values, add missing ones)
            for key, val in ext.sections.items():
                if key not in existing.sections:
                    existing.sections[key] = val
            # Recursively merge sub_controls (children at every level)
            existing.sub_controls = _merge_sub_control_lists(
                existing.sub_controls, ext.sub_controls,
            )

    return list(by_id.values())







def _validate_page_inputs(
    toc_entries: List[TOCEntry],
    control_start_page: int,
    control_end_page: int,
) -> List[str]:
    """Phase 0 sanity checks. Returns warnings (never aborts extraction)."""
    warnings = []
    for e in toc_entries:
        if e.page is not None:
            if e.page < control_start_page or e.page > control_end_page:
                warnings.append(
                    f"Control {e.control_id} TOC page {e.page} outside "
                    f"control range [{control_start_page}, {control_end_page}]"
                )
    pages_with_numbers = [e.page for e in toc_entries if e.page is not None]
    if pages_with_numbers and control_end_page < max(pages_with_numbers):
        warnings.append(
            f"control_end_page={control_end_page} < max TOC page {max(pages_with_numbers)} "
            f"— last control window will be truncated"
        )
    return warnings


def _inject_extra_toc_ids(
    toc_entries: List[TOCEntry],
    extra_ids: Dict[str, List[str]],
) -> List[TOCEntry]:
    """Inject child IDs declared by the prompt module but missing from the TOC.

    When a framework's TOC doesn't list certain sub-sections (e.g., SAMA-CSF
    3.2.1.1-3.2.1.4), the prompt module declares them in EXTRA_TOC_IDS.
    Missing children are added with the parent's page number so they appear
    in the correct page group and extraction constraint.
    """
    existing_ids = {e.control_id for e in toc_entries}
    parent_pages = {e.control_id: e.page for e in toc_entries if e.page is not None}
    injected = 0

    for parent_id, child_ids in extra_ids.items():
        parent_page = parent_pages.get(parent_id)
        if parent_page is None:
            continue
        for child_id in child_ids:
            if child_id not in existing_ids:
                toc_entries.append(TOCEntry(
                    control_id=child_id,
                    title="",
                    page=parent_page,
                ))
                existing_ids.add(child_id)
                injected += 1

    if injected:
        logger.info(
            f"Injected {injected} extra TOC ID(s) from prompt module EXTRA_TOC_IDS"
        )

    return toc_entries


def _build_page_groups(
    toc_entries: List[TOCEntry],
    control_start_page: int,
    control_end_page: int,
    window_overlap: int = 1,
) -> Tuple[List[PageGroup], List[str]]:
    """Build one PageGroup per set of controls sharing the same TOC start page.

    Returns:
        (groups, without_pages) where without_pages are control_ids that had
        no page number in the TOC and could not be assigned to a group.
    """
    if control_start_page > control_end_page:
        raise ValueError(
            f"control_start_page ({control_start_page}) > control_end_page ({control_end_page})"
        )

    with_pages = sorted(
        [(e.control_id, e.page) for e in toc_entries if e.page is not None],
        key=lambda x: x[1],
    )
    without_pages = [e.control_id for e in toc_entries if e.page is None]

    if not with_pages:
        return [], without_pages

    groups: List[PageGroup] = []
    i = 0
    while i < len(with_pages):
        page = with_pages[i][1]
        same_page: List[str] = []
        while i < len(with_pages) and with_pages[i][1] == page:
            same_page.append(with_pages[i][0])
            i += 1
        # Raw end = next group's start - 1, or control_end_page for last group
        raw_end = with_pages[i][1] - 1 if i < len(with_pages) else control_end_page
        window_start = max(page - window_overlap, control_start_page)
        window_end = min(raw_end + window_overlap, control_end_page)
        groups.append(PageGroup(
            control_ids=same_page,
            window_start=window_start,
            window_end=window_end,
        ))

    return groups, without_pages




# ── Main extractor class ─────────────────────────────────────────────────────

# ASCII-only: cybersecurity framework control IDs (NIST, ISO, SAMA, PCI, etc.)
# use only ASCII alphanumerics and separators. International chars not expected.
# Used to detect whether a matched prefix is a true word boundary or a shorter parent ID.
_ID_CONTINUATION_CHARS = frozenset(
    "._-abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
)


def _flatten_expected_from_tree(
    raw: Dict[str, Any],
    known_ids: set,
    is_top_level: bool = True,
) -> List[Dict[str, Any]]:
    """Walk an LLM extraction tree and return dicts for any node whose ID
    matches ``known_ids``.

    Handles the NIST CSF-style hierarchical-over-return case: the LLM returns
    a Function/Category container (e.g. ``RS``) that wraps the requested
    Subcategory (e.g. ``RS.MA-05``) in nested ``sub_controls``/``children``.
    Without this flattening, the outer validator would skip the whole branch
    because the top-level ``control_id`` doesn't match an expected ID.

    Top-level nodes use ``control_id`` + ``sub_controls``; inner nodes use
    ``number`` + ``children``. Returned dicts are normalised to the top-level
    shape so the main parser can process them uniformly.

    Stops descending at the first match so the returned subtree is kept as
    sub_controls of the matched node — prevents double-emission when both
    a parent and its child are in ``known_ids``.
    """
    node_id = (
        str(raw.get("control_id", "")).strip()
        if is_top_level
        else str(raw.get("number", "")).strip()
    )

    if node_id and node_id in known_ids:
        return [{
            "control_id": node_id,
            "title": str(raw.get("title") or raw.get("text", "")).strip(),
            "sections": raw.get("sections", {}) or {},
            "sub_controls": raw.get("sub_controls") or raw.get("children", []) or [],
        }]

    children_key = "sub_controls" if is_top_level else "children"
    raw_children = raw.get(children_key, []) or []
    matches: List[Dict[str, Any]] = []
    for child in raw_children:
        matches.extend(_flatten_expected_from_tree(child, known_ids, is_top_level=False))

    # If the parent is NOT in known_ids but at least one descendant is,
    # AND the parent carries information the descendants don't (e.g. a
    # category-level Description or a meaningful title), emit the parent
    # as a synthetic top-level wrapper that contains the matched
    # descendants. Without this, the parent context (description,
    # objective grouping) is silently dropped.
    #
    # Threshold is ``>= 1`` (not 2) so that page-windows containing only a
    # single requested control still emit the parent wrapper. SWIFT-CSCF
    # relies on this: most controls live alone on their page-window, but
    # the LLM is required to wrap each one under its Objective parent
    # ("1".."7"). Without single-child wrapping, the Objective hierarchy
    # would be lost for any page-window that yields one control.
    #
    # The downstream ``consolidate_hierarchy`` + ``dedup_extractions``
    # passes will collapse any naked-leaf duplicates that survived from
    # other PageGroups, so this is purely additive.
    if node_id and len(matches) >= 1:
        sections = raw.get("sections", {}) or {}
        title = str(raw.get("title") or raw.get("text", "")).strip()
        has_description = any(
            isinstance(v, str) and v.strip()
            for v in sections.values()
        )
        title_is_meaningful = title and title.lower() != node_id.lower()
        if has_description or title_is_meaningful:
            wrapper_children = []
            for m in matches:
                wrapper_children.append({
                    "number": m["control_id"],
                    "text": m.get("title") or m["control_id"],
                    "sections": m.get("sections", {}) or {},
                    "children": m.get("sub_controls", []) or [],
                })
            matches.insert(0, {
                "control_id": node_id,
                "title": title,
                "sections": sections,
                "sub_controls": wrapper_children,
            })

    return matches


class SubControlExtractor:
    """Extracts sub-controls from framework content via LLM."""

    def __init__(
        self,
        provider: "ILLMProvider",
        config: "Settings",
        rate_limiter: TokenBucketRateLimiter,
        inflight_semaphore: Optional[asyncio.Semaphore] = None,
    ):
        self.provider = provider
        self.config = config
        self.rate_limiter = rate_limiter
        # Process-wide cap on in-flight LLM calls. When ``None`` (e.g. in
        # unit tests that build an extractor directly), a per-instance
        # semaphore is created at extraction time using the rate limiter's
        # burst — preserving pre-injection behaviour.
        self._inflight_semaphore = inflight_semaphore
        # Capacity (not current count) — needed for batch-timeout math.
        # asyncio.Semaphore doesn't expose its initial value publicly, so
        # snapshot it at construction time when nothing has acquired yet.
        self._inflight_capacity: Optional[int] = (
            inflight_semaphore._value if inflight_semaphore is not None else None  # type: ignore[attr-defined]
        )
        self._deployment_name = provider.model_name
        # Label used for per-framework telemetry; populated in extract()
        # before any LLM call so record_llm_call() emits the right tag.
        self._framework_name: Optional[str] = None

    async def extract(
        self,
        framework_name: str,
        content: str,
        framework_profile: Optional[Dict[str, Any]] = None,
        toc_entries: Optional[List[TOCEntry]] = None,
        control_start_page: Optional[int] = None,
        control_end_page: Optional[int] = None,
    ) -> ExtractionResult:
        """Extract sub-controls from content via TOC page-window groups.

        Args:
            framework_name:       Framework identifier string
            content:              Markdown content with <!-- page=X/Y --> markers
            framework_profile:    Profile dict with prompt_module, etc.
            toc_entries:          Full TOCEntry list (with .page attributes)
            control_start_page:   First PDF page index of the control section
            control_end_page:     Last PDF page index of the control section
        """
        # Stash framework name for per-framework telemetry emitted inside
        # _call_with_retry (which doesn't otherwise have access to it).
        self._framework_name = framework_name

        # Inject extra TOC IDs from the prompt module (e.g., SAMA-CSF 3.2.1.x)
        # before pattern derivation so the auto-derived pattern covers all
        # expected ID depths (e.g., both 3-part and 4-part).
        if toc_entries and framework_profile and framework_profile.get("prompt_module"):
            prompt_mod = load_framework_prompts(framework_profile["prompt_module"])
            extra = getattr(prompt_mod, 'EXTRA_TOC_IDS', None)
            if extra:
                toc_entries = _inject_extra_toc_ids(toc_entries, extra)

        # Auto-derive ID pattern from TOC entries instead of reading from profile.
        # The pattern is computed from the data itself — no hand-written regex needed.
        _profile_pattern: Optional[re.Pattern] = None
        if toc_entries:
            try:
                _derived = derive_id_pattern([e.control_id for e in toc_entries])
                if _derived:
                    _profile_pattern = _safe_compile_pattern(_derived)
                    logger.info(f"Auto-derived control ID pattern: {_derived}")
            except (ValueError, re.error, TypeError, IndexError) as e:
                logger.warning(f"Pattern derivation failed, no ID validation: {e}")

        # ── PRIMARY PATH ────────────────────────────────────────────────────
        toc_has_pages = bool(toc_entries and any(e.page is not None for e in toc_entries))
        if not (
            toc_has_pages
            and control_start_page is not None
            and control_end_page is not None
        ):
            raise ValueError(
                "PageGroup extraction requires toc_entries with page numbers "
                "and control_start_page/control_end_page. "
                f"toc_has_pages={toc_has_pages}, "
                f"control_start_page={control_start_page}, "
                f"control_end_page={control_end_page}"
            )

        logger.info(
            f"PageGroup primary path: {len(toc_entries)} TOC entries, "
            f"pages {control_start_page}–{control_end_page}"
        )
        return await self._extract_by_page_groups(
            framework_name=framework_name,
            content=content,
            toc_entries=toc_entries,
            control_start_page=control_start_page,
            control_end_page=control_end_page,
            framework_profile=framework_profile,
            _profile_pattern=_profile_pattern,
        )

    # ── PAGE-GROUP PATH ──────────────────────────────────────────────────────

    async def _extract_by_page_groups(
        self,
        framework_name: str,
        content: str,
        toc_entries: List[TOCEntry],
        control_start_page: int,
        control_end_page: int,
        framework_profile: Optional[Dict],
        _profile_pattern: Optional[re.Pattern],
    ) -> ExtractionResult:
        # Phase 0: Validate inputs
        validation_warnings = _validate_page_inputs(
            toc_entries, control_start_page, control_end_page
        )
        for w in validation_warnings:
            logger.warning(f"[PageGroup validation] {w}")

        # Phase 1: Split content by page markers
        page_texts = split_by_page_markers(content)
        if not page_texts:
            raise ValueError(
                "No <!-- page=X/Y --> markers found in content. "
                "Ensure pdf_extractor.py wrote page markers before calling extract()."
            )
        logger.info(
            f"Split content into {len(page_texts)} pages "
            f"({min(page_texts)}–{max(page_texts)})"
        )

        # Phase 2: Build page groups
        groups, without_pages = _build_page_groups(
            toc_entries, control_start_page, control_end_page,
            window_overlap=self.config.WINDOW_OVERLAP,
        )

        if without_pages:
            logger.warning(
                f"No TOC page numbers for: {without_pages} — these controls may be missed"
            )

        all_expected_ids = [e.control_id for e in toc_entries]
        logger.info(
            f"Built {len(groups)} page groups for {len(all_expected_ids)} expected controls"
        )

        # Phase 3: Parallel group extraction
        # A single asyncio.gather with a semaphore is the correct concurrency pattern.
        # The semaphore bounds concurrent LLM calls; creating all coroutines upfront is
        # cheap (~1 KB each) and does not cause OOM even for 500+ groups.
        # Prefer the process-wide semaphore injected by handlers.py so that
        # multiple concurrent extraction jobs share one in-flight cap. Fall
        # back to a local one (sized off the limiter's burst) for direct
        # construction (tests, ad-hoc scripts).
        if self._inflight_semaphore is not None:
            semaphore = self._inflight_semaphore
            concurrency = self._inflight_capacity or self.rate_limiter.config.burst_size
        else:
            concurrency = self.rate_limiter.config.burst_size
            semaphore = asyncio.Semaphore(concurrency)
        errors: List[str] = list(validation_warnings)

        # Console-visible sub-progress within the "Extract controls" phase.
        # The tracker is attached by handlers._get_shared_provider's caller
        # (extract_controls). Absent in unit tests / direct construction —
        # ``getattr`` returns None and the tick() calls become no-ops.
        progress_tracker = getattr(self, "_progress_tracker", None)
        completed_count = 0
        completed_lock = asyncio.Lock()

        async def _process_group(
            i: int, group: PageGroup, _profile_pattern: Optional[re.Pattern]
        ) -> Tuple[int, List[ControlExtraction], Optional[str]]:
            nonlocal completed_count
            async with semaphore:
                try:
                    results = await self._extract_group(
                        framework_name, group, page_texts, framework_profile, _profile_pattern
                    )
                    for r in results:
                        r.source_pages = f"{group.window_start}-{group.window_end}"
                    logger.info(
                        f"Group {i}/{len(groups)} {group.control_ids}: "
                        f"{len(results)} extraction(s)"
                    )
                    if progress_tracker is not None:
                        async with completed_lock:
                            completed_count += 1
                            progress_tracker.tick(
                                completed_count, len(groups),
                                label=f"group {i} ({len(results)} extracted)",
                            )
                    return (i, results, None)
                except Exception as e:
                    msg = f"Group {i} {group.control_ids} failed: {e}"
                    logger.error(msg, exc_info=True)
                    if progress_tracker is not None:
                        async with completed_lock:
                            completed_count += 1
                            progress_tracker.tick(
                                completed_count, len(groups),
                                label=f"group {i} FAILED",
                            )
                    return (i, [], msg)

        # O-03: Job-level timeout prevents a hung LLM call from blocking the
        # entire worker indefinitely. Individual calls have their own timeout
        # (LLM_REQUEST_TIMEOUT_SECONDS), but gather itself had no upper bound.
        #
        # Scale by the number of sequential batches: with `concurrency` slots and
        # `len(groups)` tasks, ceil(groups/concurrency) batches run one after the
        # other. Each batch can take at most LLM_REQUEST_TIMEOUT_SECONDS. This
        # prevents large documents (100+ groups, semaphore=5) from timing out
        # while still making normal progress, since individual hung calls are
        # still bounded by the provider-level timeout.
        batches = math.ceil(len(groups) / max(concurrency, 1))
        # Floor at 1 batch: if groups is empty, gather returns immediately anyway,
        # but timeout=0 would race against asyncio scheduling and produce a
        # nonsensical "timed out after 0s (0 groups)" error.
        gather_timeout = max(batches, 1) * self.config.LLM_REQUEST_TIMEOUT_SECONDS
        try:
            group_results = await asyncio.wait_for(
                asyncio.gather(
                    *[_process_group(i, g, _profile_pattern) for i, g in enumerate(groups, 1)]
                ),
                timeout=gather_timeout,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(
                f"Parallel extraction timed out after {gather_timeout}s "
                f"({len(groups)} groups, {concurrency} concurrent, {batches} batches). "
                "Check LLM provider health."
            )

        all_extractions: List[ControlExtraction] = []
        for _idx, results, error in sorted(group_results, key=lambda x: x[0]):
            if error:
                errors.append(error)
            else:
                all_extractions.extend(results)

        # Phase 4: merge continuations + re-nest interleaved + clean sections
        if all_extractions:
            merge_lowercase_continuations(all_extractions)
            renest_interleaved_children(all_extractions)
            detect_letter_sequence_gaps(all_extractions)
            all_extractions = self._clean_sections(all_extractions)

        # Phase 5: Retry missing controls
        extracted_ids = {ext.control_id for ext in all_extractions}
        
        missing_ids_list = []

        for expected_id in all_expected_ids:
            if expected_id in extracted_ids:
                continue

            expected_prefix = expected_id + "."
            satisfied = any(
                ext_id.startswith(expected_prefix) for ext_id in extracted_ids
            )

            if not satisfied:
                missing_ids_list.append(expected_id)

        missing_ids = sorted(set(missing_ids_list))

        if missing_ids:
            logger.error(
                f"Missing {len(missing_ids)} control(s) after initial extraction: "
                f"{missing_ids}. Retrying with expanded window..."
            )
            group_for_id = {cid: g for g in groups for cid in g.control_ids}
            no_group_ids = [cid for cid in missing_ids if cid not in group_for_id]
            retryable_ids = [cid for cid in missing_ids if cid in group_for_id]

            # Phase 5.5: Text-search recovery for controls with no page group.
            # Zero LLM calls — just searches raw page text for the control ID string.
            if no_group_ids:
                recovered = locate_controls_in_text(
                    no_group_ids, page_texts,
                    control_start_page, control_end_page,
                    self.config.WINDOW_OVERLAP,
                )
                recovered_ids = set()
                for cid, pg in recovered:
                    group_for_id[cid] = pg
                    recovered_ids.add(cid)
                still_no_group = [cid for cid in no_group_ids if cid not in recovered_ids]
                retryable_ids.extend(list(recovered_ids))
                for cid in still_no_group:
                    logger.warning(f"No group found for {cid} — cannot retry")
                if recovered_ids:
                    logger.info(
                        f"Phase 5.5 recovered {len(recovered_ids)} control(s) "
                        f"via text search: {sorted(recovered_ids)}"
                    )
            else:
                still_no_group = []

            async def _retry_one(
                cid: str,
            ) -> Tuple[str, List[ControlExtraction], Optional[Exception]]:
                group = group_for_id[cid]
                try:
                    async with semaphore:
                        retry_group = PageGroup(
                            control_ids=[cid],
                            window_start=max(
                                group.window_start - self.config.WINDOW_OVERLAP,
                                control_start_page,
                            ),
                            window_end=min(
                                group.window_end + self.config.WINDOW_OVERLAP,
                                control_end_page,
                            ),
                        )
                        logger.info(
                            f"Retry {cid}: window [{retry_group.window_start}–"
                            f"{retry_group.window_end}]"
                        )
                        retry_results = await self._extract_group(
                            framework_name, retry_group, page_texts, framework_profile, _profile_pattern
                        )
                        for r in retry_results:
                            r.source_pages = f"{retry_group.window_start}-{retry_group.window_end}"
                    return cid, retry_results, None
                except Exception as e:
                    return cid, [], e

            retry_outcomes = await asyncio.gather(
                *(_retry_one(cid) for cid in retryable_ids)
            )
            still_missing: List[str] = list(still_no_group)
            for cid, retry_results, exc in retry_outcomes:
                if exc is not None:
                    still_missing.append(cid)
                    errors.append(f"Control {cid} retry failed: {exc}")
                    logger.error(f"Retry failed for {cid}: {exc}")
                elif retry_results:
                    all_extractions.extend(retry_results)
                    logger.info(f"Retry recovered: {cid}")
                else:
                    still_missing.append(cid)
                    logger.error(f"Retry returned 0 extractions for {cid}")

            missing_ids = still_missing
            if missing_ids:
                logger.error(
                    f"UNRECOVERABLE: {len(missing_ids)} control(s) missing "
                    f"after retry: {missing_ids}"
                )
                errors.extend(f"Control {cid} missing after retry" for cid in missing_ids)

        all_extractions = dedup_extractions(all_extractions, _profile_pattern)
        # After dedup: pull stray top-level subcategories under their
        # category extraction so the output matches the source document's
        # natural Function → Category → Subcategory hierarchy.
        all_extractions = consolidate_hierarchy(all_extractions)
        # Sort to match the TOC's document order. Without this the result
        # follows PageGroup-completion + retry order, which scrambles the
        # canonical function ordering (e.g. NIST CSF GV→ID→PR→DE→RS→RC).
        all_extractions = sort_by_toc_order(all_extractions, toc_entries)

        return ExtractionResult(
            extractions=all_extractions,
            errors=errors,
            missing_control_ids=missing_ids,
        )

    # This is a recursion guard for the case where the LLM returns malformed output that causes excessive splitting without making progress (e.g. always splitting on the same page boundary). With a reasonable default (10) it should never trigger in normal operation, but if it does, it prevents infinite recursion and stack overflow by aborting further splits and returning partial results for that branch. The warning log helps identify problematic documents and adjust the threshold if needed.
    _MAX_GROUP_RECURSION_DEPTH = 10

    async def _extract_group(
        self,
        framework_name: str,
        group: PageGroup,
        page_texts: Dict[int, str],
        framework_profile: Optional[Dict],
        _profile_pattern: Optional[re.Pattern] = None,
        _depth: int = 0,
    ) -> List[ControlExtraction]:
        """One LLM call extracting all controls in a PageGroup."""
        if _depth >= self._MAX_GROUP_RECURSION_DEPTH:
            logger.warning(
                f"Max recursion depth ({self._MAX_GROUP_RECURSION_DEPTH}) reached "
                f"for group {group.control_ids} — returning partial results"
            )
            return []
        # --- Phase 1: Assemble window text ---
        all_pages = list(range(group.window_start, group.window_end + 1))
        missing_pages = []
        empty_pages = []
        window_parts = []
        for pg in all_pages:
            if pg not in page_texts:
                missing_pages.append(pg)
            elif not page_texts[pg]:
                empty_pages.append(pg)
            else:
                window_parts.append(page_texts[pg])
        if not window_parts:
            logger.warning(
                f"Empty window for {group.control_ids} "
                f"(pages {group.window_start}–{group.window_end}): "
                f"{len(missing_pages)} missing from PDF, {len(empty_pages)} empty"
            )
            return []

        window_text = "\n\n".join(window_parts)
        window_text = _PAGE_STRIP_RE.sub('\n', window_text)
        window_text = re.sub(r' {2,}', ' ', window_text)

        # Context window pre-check — split oversized windows instead of skipping.
        # Uses CHUNK_CONTEXT_RATIO as safety margin (default 0.75 = 25% headroom).
        est_tokens = estimate_tokens(window_text, model_name=self._deployment_name)
        content_budget = int(
            self.config.LLM_MODEL_CONTEXT_TOKENS * self.config.CHUNK_CONTEXT_RATIO
        ) - self.config.CHUNK_PROMPT_OVERHEAD_TOKENS - self.config.SUBCONTROL_MAX_TOKENS
        if est_tokens > content_budget:
            actual_pages = [pg for pg in all_pages if pg in page_texts and page_texts[pg]]
            if len(actual_pages) <= 1:
                logger.warning(
                    f"Single page {group.control_ids} exceeds budget "
                    f"({est_tokens:,} > {content_budget:,} tokens), extracting anyway"
                )
            else:
                # Split so first half gets pages[:mid_idx], second gets pages[mid_idx:].
                # Using mid_idx (not mid_idx+1) guarantees the first half is strictly
                # smaller than the original, preventing infinite recursion.
                mid_idx = len(actual_pages) // 2
                split_page = actual_pages[mid_idx - 1]  # last page of first half
                logger.info(
                    f"Content for {group.control_ids} exceeds budget "
                    f"({est_tokens:,} > {content_budget:,} tokens), "
                    f"splitting after page {split_page} "
                    f"({mid_idx}/{len(actual_pages)} pages in first half)"
                )
                first = PageGroup(
                    control_ids=group.control_ids,
                    window_start=group.window_start,
                    window_end=split_page,
                )
                second = PageGroup(
                    control_ids=group.control_ids,
                    window_start=split_page + 1,
                    window_end=group.window_end,
                )
                r1 = await self._extract_group(
                    framework_name, first, page_texts, framework_profile, _profile_pattern,
                    _depth=_depth + 1,
                )
                r2 = await self._extract_group(
                    framework_name, second, page_texts, framework_profile, _profile_pattern,
                    _depth=_depth + 1,
                )
                return _merge_chunked_extractions(r1, r2)

        # --- Phase 2: Build prompts ---
        if framework_profile and framework_profile.get("prompt_module"):
            prompt_mod = load_framework_prompts(framework_profile["prompt_module"])
            system_prompt, user_prompt = prompt_mod.get_subcontrol_prompts(window_text)
            # Framework-specific prompts don't receive target_control_ids,
            # so we append the constraint here (with sanitization).
            safe_ids = [cid for cid in group.control_ids if _SAFE_CONTROL_ID.match(cid)]
            if len(safe_ids) != len(group.control_ids):
                logger.warning(
                    "Dropped %d control ID(s) with unsafe characters from prompt constraint",
                    len(group.control_ids) - len(safe_ids),
                )
            if safe_ids:
                user_prompt += (
                    f"\n\nExtract ONLY these controls: {', '.join(safe_ids)}. "
                    "Ignore any other control sections you may see."
                )
        else:
            # PE-03 fix: build_subcontrol_prompts already appends "Extract ONLY"
            # when target_control_ids is provided — don't duplicate it.
            system_prompt, user_prompt = build_subcontrol_prompts(
                framework_name, window_text, target_control_ids=group.control_ids,
            )

        # --- Phase 3: LLM call + parse ---
        raw, truncated = await self._call_with_retry(
            system_prompt, user_prompt,
            self.config.SUBCONTROL_MAX_TOKENS,
            response_model=ExtractionsWrapper,
            control_ids=group.control_ids,
        )

        # Auto-rechunk on truncation: a truncated response means _repair_truncated_json
        # closed dangling objects with empty fields, so tail controls in this chunk
        # will come back with sections: {}.  When we still have room to split
        # (multiple pages, depth budget remaining), halve the window and recurse —
        # reusing the same split pattern as the content-budget branch above.
        # Falls through to a best-effort parse when splitting isn't possible.
        if truncated:
            actual_pages = [pg for pg in all_pages if pg in page_texts and page_texts[pg]]
            if len(actual_pages) > 1 and _depth + 1 < self._MAX_GROUP_RECURSION_DEPTH:
                mid_idx = len(actual_pages) // 2
                split_page = actual_pages[mid_idx - 1]
                logger.warning(
                    f"Auto-rechunking truncated response for {group.control_ids}: "
                    f"splitting after page {split_page} "
                    f"({mid_idx}/{len(actual_pages)} pages in first half, depth={_depth})"
                )
                record_truncation(phase="subcontrol", terminal=False, framework=framework_name)
                record_split(phase="subcontrol", depth=_depth + 1, framework=framework_name)
                first = PageGroup(
                    control_ids=group.control_ids,
                    window_start=group.window_start,
                    window_end=split_page,
                )
                second = PageGroup(
                    control_ids=group.control_ids,
                    window_start=split_page + 1,
                    window_end=group.window_end,
                )
                r1 = await self._extract_group(
                    framework_name, first, page_texts, framework_profile, _profile_pattern,
                    _depth=_depth + 1,
                )
                r2 = await self._extract_group(
                    framework_name, second, page_texts, framework_profile, _profile_pattern,
                    _depth=_depth + 1,
                )
                return _merge_chunked_extractions(r1, r2)
            logger.error(
                f"Truncated response for {group.control_ids} cannot be rechunked "
                f"(pages={len(actual_pages)}, depth={_depth}); parsing as best effort"
            )
            record_truncation(phase="subcontrol", terminal=True, framework=framework_name)

        return self._parse_response(
            raw,
            known_control_ids=group.control_ids,
            profile_pattern=_profile_pattern,
        )

    # ── SHARED HELPERS ───────────────────────────────────────────────────────


    async def _call_with_retry(
        self,
        system: str,
        user: str,
        max_tokens: int,
        response_model: Optional[type] = None,
        control_ids: Optional[List[str]] = None,
    ) -> Tuple[Dict, bool]:
        """Single LLM call with rate limiting. Retries handled by provider layer.

        Returns (content, truncated) so callers can react to truncation
        (e.g. halve the PageGroup and recurse rather than trust a
        JSON-repaired response with empty trailing sections).
        """
        await self.rate_limiter.acquire()

        # Sub-control extraction is reasoning-heavy (nested sections,
        # letter/number sequences, continuation rules), so it keeps the
        # project-wide LLM_REASONING_EFFORT by default. Operators can
        # override per-phase via SUBCONTROL_REASONING_EFFORT in .env
        # when running on small-context reasoning models.
        reasoning_effort = getattr(
            self.config, "SUBCONTROL_REASONING_EFFORT", None
        )

        est_in = estimate_tokens(system + user, model_name=self._deployment_name)
        effort_note = (
            f", reasoning_effort={reasoning_effort!r}"
            if reasoning_effort else ""
        )
        logger.info(
            f"LLM call: est_input={est_in:,}, max_output={max_tokens:,}{effort_note}"
        )

        start_time = time.monotonic()
        llm_response = await self.provider.generate_json_with_metrics(
            system, user, max_tokens, response_model,
            reasoning_effort=reasoning_effort,
        )
        duration = time.monotonic() - start_time
        speed = llm_response.completion_tokens / duration if duration > 0 else 0
        logger.info(
            f"LLM response: {llm_response.prompt_tokens:,} in, "
            f"{llm_response.completion_tokens:,} out, {duration:.1f}s "
            f"({speed:.1f} tok/s)"
        )
        # O-07 visibility: when the LLM's completion hit ≥95% of the output
        # budget, the JSON-repair path may have closed dangling objects with
        # empty fields, silently giving tail controls `sections: {}`.  Surface
        # this at ERROR level with the at-risk control IDs so operators can
        # correlate directly instead of cross-referencing two log lines.
        if llm_response.truncated:
            at_risk = ", ".join(control_ids) if control_ids else "<unknown>"
            logger.error(
                f"LLM response TRUNCATED: completion={llm_response.completion_tokens:,} "
                f"tokens hit ~95% of max_tokens={max_tokens:,}. "
                f"At-risk control IDs (trailing entries likely have empty "
                f"`sections` from JSON-repair close-brace insertion): [{at_risk}]. "
                f"Caller will auto-rechunk if the PageGroup is splittable; "
                f"otherwise reduce chunk size or raise max_output_tokens."
            )
            record_llm_call(
                phase="subcontrol",
                outcome="truncated",
                framework=getattr(self, "_framework_name", None),
            )
        else:
            record_llm_call(
                phase="subcontrol",
                outcome="ok",
                framework=getattr(self, "_framework_name", None),
            )
        return llm_response.content, llm_response.truncated

    def _parse_response(
        self,
        response: Dict,
        known_control_ids: Optional[List[str]] = None,
        profile_pattern: Optional[re.Pattern] = None,
    ) -> List[ControlExtraction]:
        """Parse LLM response dict into ControlExtraction objects."""
        extractions_raw = response.get("extractions", [])
        if not isinstance(extractions_raw, list):
            logger.warning(
                f"Expected 'extractions' list, got {type(extractions_raw).__name__}. "
                f"Response keys: {list(response.keys()) if isinstance(response, dict) else 'N/A'}. "
                f"Wrapping entire response as single extraction."
            )
            extractions_raw = [response]

        # Pre-pass: rescue expected IDs buried inside parent-container responses.
        # NIST CSF-style frameworks have Function → Category → Subcategory
        # hierarchy; the LLM often returns the whole branch rooted at the
        # Function even when asked for a single Subcategory. Walk the tree,
        # promote matching descendants, and drop containers that wrap nothing
        # we asked for.
        if known_control_ids:
            known_ids_set = set(known_control_ids)
            expanded: List[Dict[str, Any]] = []
            for raw in extractions_raw:
                raw_id = str(raw.get("control_id", "")).strip()
                if raw_id in known_ids_set or any(
                    raw_id.startswith(k + ".") for k in known_ids_set
                ):
                    expanded.append(raw)
                    continue
                promoted = _flatten_expected_from_tree(raw, known_ids_set)
                if promoted:
                    logger.info(
                        f"Parent container control_id='{raw_id}' — promoted "
                        f"{len(promoted)} descendant(s): "
                        f"{[p['control_id'] for p in promoted]}"
                    )
                    expanded.extend(promoted)
                else:
                    expanded.append(raw)
            extractions_raw = expanded

        sorted_known = (
            sorted(known_control_ids, key=len, reverse=True)
            if known_control_ids else []
        )

        results: List[ControlExtraction] = []
        for i, raw in enumerate(extractions_raw):
            try:
                control_id = raw.get("control_id", "").strip()
                if not control_id:
                    logger.warning(f"Extraction {i}: empty control_id, skipping")
                    continue

                if profile_pattern and profile_pattern.match(control_id):
                    # Valid ID per the auto-derived pattern — accept natively.
                    # Handles frameworks where TOC format differs from body IDs.
                    pass
                elif not sorted_known and not profile_pattern:
                    # M-7: No known IDs and no pattern — accept all control_ids.
                    # This prevents silently dropping every extraction when both
                    # are empty (latent bug if a caller passes an empty group).
                    pass
                else:
                    matched_id = None
                    is_child_id = False
                    for kid in sorted_known:
                        if control_id == kid:
                            matched_id = kid
                            break
                        if control_id.startswith(kid):
                            remainder = control_id[len(kid):]
                            if not remainder or remainder[0] not in _ID_CONTINUATION_CHARS:
                                matched_id = kid
                                break
                            # Accept child IDs: "1.1" is a valid child of
                            # known TOC entry "1".  Keeps control_id as-is
                            # (no remapping to parent).
                            if remainder[0] == ".":
                                is_child_id = True
                                break

                    if matched_id:
                        control_id = matched_id
                    elif not is_child_id:
                        logger.warning(
                            f"Extraction {i}: invalid control_id '{control_id}', skipping"
                        )
                        continue

                parsed_sections = raw.get("sections", {}) or {}
                parsed_subs = self._parse_sub_controls(
                    raw.get("sub_controls", []), parent_id=control_id
                )

                # Visibility for the "silent empty sections" failure mode:
                # when the LLM returns a control with NEITHER sections NOR
                # sub_controls, the extraction is structurally useless but
                # will still participate in dedup.  Log it so operators can
                # spot chunk/prompt issues early rather than discovering
                # 47% empty controls after storage.
                if not parsed_sections and not parsed_subs:
                    logger.warning(
                        f"Extraction {i} ('{control_id}') has empty sections "
                        f"AND no sub_controls — likely LLM response truncation "
                        f"or chunk boundary issue."
                    )

                extraction = ControlExtraction(
                    control_id=control_id,
                    title=raw.get("title", "").strip(),
                    sections=parsed_sections,
                    sub_controls=parsed_subs,
                )
                results.append(extraction)
            except (ValidationError, AttributeError, TypeError, KeyError) as e:
                logger.warning(f"Skipping malformed extraction {i}: {type(e).__name__}: {e}")
                continue

        return results

    def _parse_sub_controls(
        self, raw_list: list, parent_id: str = "", _depth: int = 0
    ) -> List[SubControl]:
        """Recursively parse sub-controls, computing IDs from parent_id + number.

        IDs are computed deterministically: id = f"{parent_id}.{number}".
        Any id field returned by the LLM is ignored.
        """
        if _depth > _MAX_NESTING_DEPTH:
            logger.warning(
                f"_parse_sub_controls: max recursion depth exceeded at parent_id='{parent_id}'"
            )
            return []
        result: List[SubControl] = []
        for raw in raw_list:
            try:
                number = str(raw.get("number", "")).strip()
                if not number:
                    logger.warning(
                        f"Sub-control missing number under parent '{parent_id}', skipping entry"
                    )
                    raise ValueError(f"Sub-control missing number under parent '{parent_id}'")
                sc_id = compose_sub_control_id(parent_id, number)
                children = self._parse_sub_controls(
                    raw.get("children", []), parent_id=sc_id, _depth=_depth + 1
                )
                sc = SubControl(
                    number=number,
                    id=sc_id,
                    text=str(raw.get("text", "")).strip(),
                    node_type=raw.get("node_type", ""),
                    sections=raw.get("sections", {}),
                    metadata=raw.get("metadata", {}),
                    children=children,
                )
                result.append(sc)
            except Exception as e:
                # H-6: Skip malformed sub-control children instead of raising.
                # A single bad sub-control should not abort the entire control.
                # Covers ValidationError (Pydantic) and any other parsing failure.
                logger.warning(
                    f"Skipping malformed sub-control (parent='{parent_id}'): "
                    f"{type(e).__name__}: {e}"
                )
                continue
        if not result and raw_list:
            logger.warning(
                f"All {len(raw_list)} sub-controls failed parsing. "
                f"First raw item: {raw_list[0]}"
            )
        return result

    @staticmethod
    def _build_ngrams(words: List[str], n: int) -> set:
        """Build a set of n-grams (tuples of n consecutive words).

        Uses a sliding-window comprehension (O(N) memory) rather than
        zip(*slices) which materialises N full list copies simultaneously.
        """
        if len(words) < n:
            return {tuple(words)} if words else set()
        return {tuple(words[i:i + n]) for i in range(len(words) - n + 1)}

    # Section dedup thresholds now read from config (with same defaults).

    def _clean_sections(
        self,
        extractions: List[ControlExtraction],
    ) -> List[ControlExtraction]:
        """Remove sections whose content overlaps with sub_controls text."""
        fwd_threshold = self.config.SECTION_FWD_OVERLAP_THRESHOLD
        rev_threshold = self.config.SECTION_REV_OVERLAP_THRESHOLD
        min_words = self.config.SECTION_MIN_WORDS_FOR_OVERLAP
        ngram_size = self.config.SECTION_NGRAM_SIZE

        for extraction in extractions:
            if not extraction.sections or not extraction.sub_controls:
                continue

            sc_text = " ".join(
                sc.text for sc in self._flatten_sub_controls(extraction.sub_controls)
            )
            sc_words = sc_text.lower().split()
            sc_ngrams = self._build_ngrams(sc_words, ngram_size)
            if not sc_ngrams:
                continue

            cleaned = {}
            for key, value in extraction.sections.items():
                sec_words = value.lower().split()
                if len(sec_words) < min_words:
                    cleaned[key] = value
                    continue
                sec_ngrams = self._build_ngrams(sec_words, ngram_size)
                if not sec_ngrams:
                    cleaned[key] = value
                    continue
                common = len(sec_ngrams & sc_ngrams)
                fwd = common / len(sec_ngrams)
                rev = common / len(sc_ngrams) if sc_ngrams else 0
                if (fwd > fwd_threshold
                        or rev > rev_threshold):
                    logger.info(
                        f"Removed section '{key}' from {extraction.control_id} "
                        f"(fwd={fwd:.0%}, rev={rev:.0%})"
                    )
                else:
                    cleaned[key] = value
            extraction.sections = cleaned

        return extractions

    @staticmethod
    def _flatten_sub_controls(sub_controls: List[SubControl]) -> List[SubControl]:
        """Flatten nested sub-controls into a single list (iterative, document order)."""
        flat: List[SubControl] = []
        # Reverse so pop() yields first-to-last (preserves document order)
        stack = list(reversed(sub_controls))
        while stack:
            sc = stack.pop()
            flat.append(sc)
            # Prepend children in reverse so they're popped in order
            stack.extend(reversed(sc.children))
        return flat
