"""
Post-processing and deduplication utilities for AI Extraction.
"""
from typing import List, Dict, Tuple, Optional, Iterable
import re
from models import ControlExtraction, SubControl, PageGroup, count_all_sub_controls, collect_sub_control_ids, compose_sub_control_id
from utils.logging_config import logger

def locate_controls_in_text(
    control_ids: List[str],
    page_texts: Dict[int, str],
    control_start_page: int,
    control_end_page: int,
    window_overlap: int,
) -> List[Tuple[str, PageGroup]]:
    """Phase 5.5: locate missing controls via text search (zero LLM calls).

    For each control_id, searches all page_texts for the literal control ID
    string. When found, builds a PageGroup from the pages where it appears.

    Returns:
        List of (control_id, PageGroup) for controls that were found.
    """
    results: List[Tuple[str, PageGroup]] = []
    for cid in control_ids:
        # Use lookaround regex instead of \b to avoid false positives.
        # \b treats "." as a word boundary, so "5.1" would match inside "5.10".
        # Negative lookaround ensures the ID isn't part of a longer ID.
        cid_pattern = re.compile(r'(?<![.\-\w])' + re.escape(cid) + r'(?![.\-\w])')
        found_pages: List[int] = []
        for page_num, text in page_texts.items():
            if cid_pattern.search(text):
                found_pages.append(page_num)
        if not found_pages:
            continue
        found_pages.sort()
        w_start = max(min(found_pages) - window_overlap, control_start_page)
        w_end = min(max(found_pages) + window_overlap, control_end_page)
        pg = PageGroup(
            control_ids=[cid],
            window_start=w_start,
            window_end=w_end,
        )
        logger.info(
            f"Phase 5.5: text search located {cid} on page(s) {found_pages} "
            f"→ window [{w_start}–{w_end}]"
        )
        results.append((cid, pg))
    return results

def _matches_or_child_of(control_id: str, pattern: re.Pattern) -> bool:
    """Check if control_id matches the pattern or is a dot-separated child.

    Example: pattern=r"^\d+$", control_id="1.1" → parent "1" matches → True.
    Used so that child IDs (e.g., "1.1" under TOC entry "1") are not
    discarded as phantoms or removed by structural dedup.
    """
    if pattern.match(control_id):
        return True
    parts = control_id.split(".")
    for i in range(1, len(parts)):
        if pattern.match(".".join(parts[:i])):
            return True
    return False


def dedup_extractions(
    all_extractions: List[ControlExtraction],
    _profile_pattern: Optional[re.Pattern],
) -> List[ControlExtraction]:
    """Phantom filter → structural dedup → same-ID dedup (keep richer)."""
    if not all_extractions:
        return all_extractions

    # Phantom filter: remove extractions whose control_id doesn't match the profile pattern
    # (or isn't a child of a pattern-matching parent)
    if _profile_pattern:
        kept, phantom_ids = [], []
        for ext in all_extractions:
            if _matches_or_child_of(ext.control_id, _profile_pattern):
                kept.append(ext)
            else:
                phantom_ids.append(ext.control_id)
        all_extractions = kept
        if phantom_ids:
            logger.warning(f"Removed {len(phantom_ids)} phantom extraction(s): {phantom_ids}")

    # Structural dedup: remove top-level extractions whose ID already
    # appears as a sub_control ID inside another extraction.
    sub_id_to_parents: Dict[str, set] = {}
    for ext in all_extractions:
        for sc_id in collect_sub_control_ids(ext.sub_controls):
            sub_id_to_parents.setdefault(sc_id, set()).add(ext.control_id)

    # Pattern-exemption was historically broad: any TOC-listed ID survived
    # structural dedup. That is wrong when the TOC contains BOTH category
    # and subcategory IDs (e.g. NIST CSF 2.0 lists GV.SC *and* GV.SC-01..-10),
    # because the subcategory then exists twice — as a child of the category
    # AND as a top-level "naked" entry with empty sub_controls + empty
    # sections. Tighten the exemption: an entry is only exempt if it carries
    # information the parent does NOT already represent (its own sub_controls
    # OR non-empty sections). Naked leaf duplicates are dropped regardless.
    structural_exempt: set = set()
    if _profile_pattern:
        for ext in all_extractions:
            if not _matches_or_child_of(ext.control_id, _profile_pattern):
                continue
            has_own_subs = bool(ext.sub_controls)
            has_own_sections = any(
                isinstance(v, str) and v.strip()
                for v in (ext.sections or {}).values()
            )
            if has_own_subs or has_own_sections:
                structural_exempt.add(ext.control_id)

    before = len(all_extractions)
    all_extractions = [
        ext for ext in all_extractions
        if ext.control_id in structural_exempt
        or ext.control_id not in sub_id_to_parents
        or sub_id_to_parents[ext.control_id] == {ext.control_id}
    ]
    removed = before - len(all_extractions)
    if removed:
        logger.info(f"Removed {removed} duplicate child extraction(s)")

    # Same-ID dedup: keep the "richer" extraction.
    #
    # Richness is a lexicographic tuple so an extraction with populated
    # `sections` can never be silently replaced by one with an empty
    # sections dict, even if the replacement has more sub_controls.  This
    # bug was real: ISO 27001 run had 41 of 88 controls come back with
    # `sections: {}` because a later retry/chunk with more sub_controls
    # but empty sections overwrote an earlier correct extraction.
    #
    # Ranking (higher wins):
    #   1) non_empty_sections      — any section text present at all
    #   2) total_section_chars     — combined length of all section values
    #   3) sub_controls_count      — recursive sub-control count (old rule)
    #
    # Ties keep the first-seen extraction (stable).
    def _richness(ext: ControlExtraction) -> tuple:
        sections = ext.sections or {}
        section_chars = sum(
            len(v) for v in sections.values() if isinstance(v, str)
        )
        non_empty_sections = 1 if section_chars > 0 else 0
        return (
            non_empty_sections,
            section_chars,
            count_all_sub_controls(ext.sub_controls),
        )

    seen_ids: Dict[str, int] = {}
    deduped: List[ControlExtraction] = []
    for ext in all_extractions:
        if ext.control_id in seen_ids:
            existing_idx = seen_ids[ext.control_id]
            existing = deduped[existing_idx]
            if _richness(ext) > _richness(existing):
                deduped[existing_idx] = ext
                logger.info(
                    f"Replaced duplicate '{ext.control_id}' with richer "
                    f"extraction (old={_richness(existing)}, "
                    f"new={_richness(ext)})"
                )
            else:
                logger.warning(
                    f"Dropped duplicate '{ext.control_id}' "
                    f"(kept={_richness(existing)}, dropped={_richness(ext)})"
                )
        else:
            seen_ids[ext.control_id] = len(deduped)
            deduped.append(ext)
    if len(deduped) < len(all_extractions):
        logger.info(
            f"Resolved {len(all_extractions) - len(deduped)} same-id duplicate(s)"
        )
    return deduped


# ── Hierarchy consolidation & canonical ordering ─────────────────────────────


def _looks_like_child_of(child_id: str, parent_id: str) -> bool:
    """True if ``child_id`` is a hierarchical descendant of ``parent_id``.

    Frameworks vary in their separator (``GV.SC-05`` uses ``-`` between
    category and subcategory; ``A.5.1`` uses ``.``). Treat both as valid
    boundaries so the check works framework-agnostically.
    """
    if child_id == parent_id or not child_id.startswith(parent_id):
        return False
    sep = child_id[len(parent_id):len(parent_id) + 1]
    return sep in ".-"


def consolidate_hierarchy(
    extractions: List[ControlExtraction],
) -> List[ControlExtraction]:
    """Pull stray top-level subcategories under their category extraction.

    Real-world failure (NIST CSF 2.0): the LLM emits ``RS.MA`` as a top-level
    extraction (with empty ``sub_controls`` because the page window only
    contained the category header), AND emits ``RS.MA-01..RS.MA-05`` as
    five separate top-level extractions (because a *different* PageGroup
    extracted them in flattened form). The reader sees the function order
    fragmented across the output.

    This pass walks every top-level extraction whose ID looks like a
    hierarchical descendant of another top-level extraction's ID and:

    1. Adds it as a ``SubControl`` of the parent (skipping if a child
        with the same ``number`` already exists — preserves any richer
        data the parent already carries).
    2. Removes it from the top level.

    Idempotent and safe to run after dedup. Pure tree manipulation — no
    data invented, no LLM calls.
    """
    if len(extractions) < 2:
        return extractions

    # Sort top-level IDs by length DESC so deeper ancestors are considered
    # before shallower ones — prevents A.5.1.2 from being matched against A
    # when A.5.1 also exists as a top-level entry.
    by_id = {e.control_id: e for e in extractions}
    sorted_ids = sorted(by_id.keys(), key=len, reverse=True)

    absorbed: set[str] = set()
    moves = 0
    for cid in sorted_ids:
        if cid in absorbed:
            continue
        # Find shortest existing ancestor among other top-level IDs.
        ancestor: Optional[str] = None
        for candidate in sorted(by_id.keys(), key=len):
            if candidate == cid or candidate in absorbed:
                continue
            if _looks_like_child_of(cid, candidate):
                ancestor = candidate
                break
        if not ancestor:
            continue

        parent_ext = by_id[ancestor]
        child_ext = by_id[cid]

        # Compute the child's ``number`` relative to the parent. For
        # NIST-CSF this is ``GV.SC-05`` under ``GV.SC`` → number ``GV.SC-05``
        # (the LLM keeps the full form). Match on either ``number`` or
        # composed ``id`` so we don't add duplicates.
        existing_numbers = {sc.number for sc in parent_ext.sub_controls}
        existing_ids = {sc.id for sc in parent_ext.sub_controls if sc.id}
        if cid in existing_numbers or cid in existing_ids:
            absorbed.add(cid)
            continue

        # Build a SubControl from the stray top-level. The text is the
        # extraction's title (LLM stored the actual outcome there when it
        # flattened). Sections AND nested sub_controls (its own children
        # tree) ride along — required for SWIFT-CSCF where the leaf
        # control's Implementation Guidelines tree must survive the
        # re-nesting under its Objective parent.
        text = (child_ext.title or "").strip() or cid
        new_sc = SubControl(
            number=cid,
            id=compose_sub_control_id(parent_ext.control_id, cid),
            text=text,
            sections=dict(child_ext.sections or {}),
            children=list(child_ext.sub_controls or []),
        )
        # Append in document-order if the parent's children are
        # alphabetic/numeric-sorted; otherwise just append at end.
        parent_ext.sub_controls.append(new_sc)
        absorbed.add(cid)
        moves += 1

    if moves:
        logger.info(
            f"consolidate_hierarchy: re-nested {moves} stray subcategory "
            f"extraction(s) under their parent category"
        )

    return [e for e in extractions if e.control_id not in absorbed]


def _toc_index(toc_entries: Optional[Iterable]) -> Dict[str, int]:
    """Map control_id → position in TOC. Used as the canonical sort key."""
    if not toc_entries:
        return {}
    return {e.control_id: i for i, e in enumerate(toc_entries)}


def sort_by_toc_order(
    extractions: List[ControlExtraction],
    toc_entries: Optional[Iterable] = None,
) -> List[ControlExtraction]:
    """Sort extractions to match the document's table-of-contents order.

    Why: the extractor builds results in PageGroup-completion order plus a
    retry tail, which scrambles the function ordering (e.g. NIST CSF's
    GV → ID → PR → DE → RS → RC). Readers expect the file's natural
    order. The TOC is the only framework-agnostic source of canonical
    ordering available — fall back to alpha sort when no TOC is present.

    Stable: ties (e.g. an extraction whose ID isn't in the TOC) sort to
    the end while preserving their relative order.
    """
    toc_idx = _toc_index(toc_entries)
    if not toc_idx:
        return sorted(extractions, key=lambda e: e.control_id)

    def _key(ext: ControlExtraction) -> tuple:
        cid = ext.control_id
        # Direct TOC hit.
        if cid in toc_idx:
            return (0, toc_idx[cid], cid)
        # Otherwise inherit position from the closest TOC ancestor so a
        # synthetic category entry (not in TOC) sorts next to its
        # subcategory siblings (which are).
        for ancestor in sorted(toc_idx.keys(), key=len, reverse=True):
            if _looks_like_child_of(cid, ancestor) or cid == ancestor:
                return (0, toc_idx[ancestor], cid)
        # Unknown — push to the end, alpha within.
        return (1, 0, cid)

    return sorted(extractions, key=_key)
