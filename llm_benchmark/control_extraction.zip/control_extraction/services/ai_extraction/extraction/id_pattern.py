"""
Auto-derive a control ID pattern from a set of control IDs.

Uses automatic structural detection from the extracted IDs themselves.

The algorithm:
1. Pre-filter noise (Table/Figure refs, overly long strings)
2. Try single separators: "." then "-"
3. Fallback: multi-separator split on both "." and "-"
4. Accept ALL observed segment depths (multi-depth support)
5. Classify each segment with 90% majority threshold
    - Dominant depth: standard classification (literal match if all identical)
    - Minority depths: type-based classification (avoids over-specific literals)
6. Combine multiple depths with OR alternation
7. Validate: derived pattern must match >=80% of input IDs

Handles mixed-depth frameworks automatically (e.g., SAMA CSF with both
3-part "3.1.1" and 4-part "3.2.1.1" IDs). No manual pattern override needed.

Safety nets:
- Returns "" when no clear pattern found — callers treat "" as "accept all"
- 90% majority threshold prevents single noise outliers from corrupting segment type
- 80% final validation ensures derived pattern actually matches the data
- Noise pre-filter strips obvious non-control entries before analysis
"""
import logging
import re
from collections import Counter

logger = logging.getLogger(__name__)

# Noise prefixes — entries starting with these are clearly not control IDs.
# Compiled once at module load; checked with re.match (anchored to start).
_NOISE_PREFIX_RE = re.compile(
    r"^(Table|Figure|Section|Chapter|Clause|NOTE|Bibliography)\b", re.IGNORECASE
)
# Empirical: longest real control ID across SAMA, ISO-27001, NIST, PCI-DSS, ECC,
# DESC-ISR is ~20 chars ("Requirement 12.10.1"). 30 provides headroom; entries
# beyond this are chapter titles or ToC artifacts, not control IDs.
_MAX_ID_LENGTH = 30

# Segment type classification threshold. 90% means with 94 SAMA controls,
# up to 9 outliers won't corrupt the segment type. The 80% final validation
# (line ~124) catches bad derivations as a second safety net.
_SEGMENT_TYPE_THRESHOLD = 0.90


def _pre_filter(control_ids: list[str]) -> list[str]:
    """Remove obvious noise entries before pattern derivation."""
    filtered_out = [
        cid for cid in control_ids
        if cid and (len(cid) > _MAX_ID_LENGTH or _NOISE_PREFIX_RE.match(cid))
    ]
    if filtered_out:
        logger.debug(
            f"_pre_filter: removed {len(filtered_out)} noise entries: "
            f"{filtered_out[:5]}{'...' if len(filtered_out) > 5 else ''}"
        )
    return [
        cid for cid in control_ids
        if cid
        and len(cid) <= _MAX_ID_LENGTH
        and not _NOISE_PREFIX_RE.match(cid)
    ]


def _classify_segment(seg_values: list[str], force_type: bool = False) -> str:
    """Classify a segment position using majority-based thresholds.

    Returns a regex fragment for this segment position.
    Uses 90% threshold instead of all() — a single outlier no longer
    corrupts the classification of 93+ valid values.

    Args:
        seg_values: Segment values at this position across all IDs.
        force_type: When True, skip the "all identical → literal" shortcut
            and always use type-based classification. Used for minority
            depths in multi-depth patterns where few examples must produce
            generic patterns (e.g., single value "3" → r"\\d+" not "3").
    """
    if not seg_values:
        return r"[A-Za-z0-9]+"  # Defensive: should never happen (min_ids guard)

    unique = set(seg_values)
    n = len(seg_values)

    # All identical → literal match (strict: requires 100%)
    # Skip when force_type=True: minority depths need generic patterns
    # even from a single example (e.g., 1 four-part ID among 99 three-part).
    if len(unique) == 1 and not force_type:
        return re.escape(seg_values[0])

    digit_ratio = sum(1 for v in seg_values if v.isdigit()) / n
    alpha_ratio = sum(1 for v in seg_values if v.isalpha()) / n

    if digit_ratio >= _SEGMENT_TYPE_THRESHOLD:
        return r"\d+"

    if alpha_ratio >= _SEGMENT_TYPE_THRESHOLD:
        # Sub-classify case
        alpha_vals = [v for v in seg_values if v.isalpha()]
        if all(v.isupper() for v in alpha_vals):
            return r"[A-Z]+"
        elif all(v.islower() for v in alpha_vals):
            return r"[a-z]+"
        return r"[A-Za-z]+"

    return r"[A-Za-z0-9]+"


def _try_separator(
    control_ids: list[str],
    sep: str | None,
) -> str:
    """Try deriving a pattern using a specific separator strategy.

    Args:
        control_ids: Pre-filtered IDs.
        sep: Single character separator ("." or "-"), or None for multi-separator.

    Returns:
        Regex pattern string, or "" if no valid pattern found.
    """
    if sep is not None:
        segments_list = [cid.split(sep) for cid in control_ids]
        escaped_sep = re.escape(sep)
    else:
        # Multi-separator: split on both "." and "-"
        segments_list = [re.split(r"[.\-]", cid) for cid in control_ids]
        escaped_sep = r"[.\-]"

    seg_counts = [len(s) for s in segments_list]
    count_freq = Counter(seg_counts)

    # Accept all observed depths. No minimum threshold — the 80% validation
    # (below) is the safety net. Pre-filtering already removed obvious noise.
    accepted_counts = sorted(count_freq.keys())
    if not accepted_counts:
        return ""

    # Identify the dominant depth (most common). Used to decide classification mode.
    dominant_count = count_freq.most_common(1)[0][0]

    # Build a sub-pattern for each observed depth.
    # Minority depths use force_type=True: avoids literal match from few
    # examples, produces generic patterns (digit→\d+, alpha→[A-Z]+).
    # Dominant depth uses standard classification (preserves precision).
    sub_patterns: list[str] = []
    for depth in accepted_counts:
        depth_ids = [s for s in segments_list if len(s) == depth]
        is_minority = (depth != dominant_count)
        parts = [
            _classify_segment([s[i] for s in depth_ids], force_type=is_minority)
            for i in range(depth)
        ]
        sub_patterns.append(escaped_sep.join(parts))

    # Single depth: simple pattern. Multiple depths: OR alternation.
    if len(sub_patterns) == 1:
        pattern = f"^{sub_patterns[0]}$"
    else:
        pattern = f"^({'|'.join(sub_patterns)})$"

    # Self-validate: derived pattern must match ≥80% of input IDs
    try:
        compiled = re.compile(pattern)
        match_count = sum(1 for cid in control_ids if compiled.match(cid))
        if match_count >= len(control_ids) * 0.8:
            return pattern
    except re.error:
        pass

    return ""


def detect_normalization_prefix(
    domain_mapping: dict[str, str],
    raw_ids: list[str],
) -> str:
    """Auto-detect ID prefix from domain_mapping keys.

    Compares the common prefix of domain_mapping keys against the raw IDs.
    If all domain keys share a prefix (e.g., "A.") that the raw IDs lack,
    returns it as a normalization prefix.

    Examples:
    domain_mapping={"A.5": ..., "A.6": ...}, raw_ids=["5.1", "5.2"] → "A."
    domain_mapping={"3.1": ..., "3.4": ...}, raw_ids=["3.1.1"]       → "" (already prefixed)
    domain_mapping={"1": ..., "13": ...},     raw_ids=["1.1"]         → "" (no common prefix)
    """
    if not domain_mapping or not raw_ids:
        return ""

    keys = list(domain_mapping.keys())
    # Character-level common prefix (replaces os.path.commonprefix which
    # could silently return path-separator-unaware partial matches).
    prefix = keys[0]
    for k in keys[1:]:
        while not k.startswith(prefix):
            prefix = prefix[:-1]
            if not prefix:
                return ""
    if not prefix:
        return ""

    # Truncate to last separator boundary to avoid partial segment matches.
    # e.g., commonprefix(["A.5", "A.56"]) = "A.5" → truncate to "A."
    # Use max() to find the last separator of ANY type in the prefix.
    last_sep = max(prefix.rfind("."), prefix.rfind("-"))
    if last_sep < 0:
        return ""  # No separator in prefix → not a structural prefix
    trimmed = prefix[:last_sep + 1]

    # If majority of raw IDs already start with this prefix, no normalization needed
    already_prefixed = sum(1 for rid in raw_ids if rid.startswith(trimmed))
    if already_prefixed >= len(raw_ids) * 0.5:
        return ""

    return trimmed


def derive_id_pattern(control_ids: list[str], min_ids: int = 3) -> str:
    """Derive a regex pattern from the structural commonality of control IDs.

    Algorithm:
    1. Pre-filter noise (Table/Figure refs, overly long strings)
    2. Try single separators: "." then "-"
    3. Fallback: try multi-separator split on both "." and "-"
    4. For each attempt: accept all observed segment depths, classify
    each segment with 90% majority threshold (minority depths use
    type-based classification), combine with OR alternation if
    multiple depths, validate final pattern matches ≥80% of IDs

    Handles mixed-depth frameworks (e.g., SAMA CSF with 3-part and 4-part
    IDs) automatically — no manual pattern override needed.

    Returns empty string if fewer than min_ids or no clear pattern found.
    The empty return is safe — callers treat "" as "accept all IDs".
    """
    cleaned = _pre_filter(control_ids)
    if len(cleaned) < min_ids:
        return ""

    # Try single separators first (most frameworks use one separator)
    for sep in (".", "-"):
        result = _try_separator(cleaned, sep)
        if result:
            return result

    # Fallback: multi-separator split (handles NIST CSF "GV.OC-01" style)
    result = _try_separator(cleaned, None)
    if result:
        return result

    return ""
