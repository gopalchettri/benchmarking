"""
Blueprint resolution logic.
"""
from models import TOCEntry
from core.document import parse_page_range
from config import get_settings
from extraction.discovery import discover_controls_from_body

config = get_settings()


async def resolve_blueprint(
    provider,
    extractor,
    framework: str,
    control_content: str,
    content_pages: str,
    toc_entries: list[TOCEntry] | None,
    profile: dict | None,
    job_log,
    control_layout: str = "toc_body",
) -> tuple[int, int, list[TOCEntry] | None]:
    """Resolves the control blueprint (TOC vs Discovery) and returns bounds + entries."""
    page_range = parse_page_range(content_pages)
    if not page_range:
        raise ValueError(
            f"Cannot parse content_pages='{content_pages}'. "
            "Provide a valid page range such as '13-38'."
        )
    control_start_page: int = page_range[0]
    control_end_page: int   = page_range[1]

    usable_entries = [e for e in (toc_entries or []) if e.page is not None]

    if len(usable_entries) == 0:
        if control_layout == "annex":
            job_log.info("[ANNEX layout] No TOC entries expected — running discovery.")
        else:
            job_log.warning("TOC extraction returned 0 usable entries. Running discovery fallback.")

        if not profile or not profile.get("prompt_module"):
            raise ValueError("Discovery mode requires a framework profile with prompt_module.")

        job_log.info(f"Running discovery scan on pages {control_start_page}-{control_end_page}...")

        disc_toc = await discover_controls_from_body(
            provider=provider,
            framework_name=framework,
            content=control_content,
            start_page=control_start_page,
            end_page=control_end_page,
            rate_limiter=extractor.rate_limiter,
            config=config,
            framework_profile=profile,
        )
        toc_entries = disc_toc.controls
        if not toc_entries:
            raise ValueError("Discovery scan also found 0 controls.")

        job_log.info(f"Discovery found {len(toc_entries)} controls")

    return control_start_page, control_end_page, toc_entries
