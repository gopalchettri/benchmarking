"""
ai_extraction task handlers
=============================
Plain async functions — no Celery, no RQ.
Dispatched via Redis Streams (shared_core.stream_client).

Supports framework profile-driven extraction: when framework_profile is
passed in the payload, framework-specific prompts and ID validation are used.
"""
import asyncio
import os
import re
import sys
from typing import Optional

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
if BASE not in sys.path:
    sys.path.insert(0, BASE)
if os.path.join(BASE, 'shared_core') not in sys.path:
    sys.path.insert(0, os.path.join(BASE, 'shared_core'))
if os.path.dirname(__file__) not in sys.path:
    sys.path.insert(0, os.path.dirname(__file__))

from config import get_settings
from models import TOCEntry
from shared_core.audit_client import log_audit
from shared_core.constants import STATE_COMPLETED, STATE_AI_EXTRACTION_FAILED
from shared_core.redis_client import get_async_redis_client, update_job_state, fetch_job_state
from shared_core.stream_client import publish_task
from utils.logging_config import logger, start_job_logging, stop_job_logging, get_job_logger
from utils.progress import PhaseTracker

from core.page_offset import apply_offset_to_toc_entries
from core.profile import fetch_profile_via_http
from core.storage import load_content_from_blob, enrich_and_store_payload
from extraction.controls import SubControlExtractor
from extraction.toc import extract_toc_from_text
from jobs.blueprint import resolve_blueprint
from llm.providers import ILLMProvider, get_llm_provider, set_active_rate_limiter
from llm.rate_limiter import TokenBucketRateLimiter, RateLimitConfig
from llm.model_profiles import resolve_profile, ModelProfile
from shared_core.job_client import update_job_record

config = get_settings()

STORAGE_SERVICE_URL = config.STORAGE_SERVICE_URL
API_V1_STR          = config.API_V1_STR


def _sanitize_error(exc: Exception, max_len: int = 200) -> str:
    """Produce a safe error string that won't leak internal structure.

    Strips URLs, connection strings, API keys, and truncates to max_len.
    """
    raw = str(exc)[:max_len]
    # Strip URLs (http/https endpoints)
    safe = re.sub(r'https?://\S+', '[URL]', raw)
    # Strip Azure connection strings
    safe = re.sub(r'DefaultEndpointsProtocol=[^;]+(?:;[^;]+)*', '[CONNECTION_STRING]', safe)
    # Strip anything that looks like an API key (32+ hex or base64 chars)
    safe = re.sub(r'[A-Za-z0-9+/=]{32,}', '[REDACTED]', safe)
    # Strip file system paths
    safe = re.sub(r'(?:/[\w.-]+){3,}', '[PATH]', safe)
    return safe


# ── Alerting callback (A-03) ──────────────────────────────────────────────────
async def _fire_alert(job_id: str, framework: str, error: str) -> None:
    """Fire an alert on extraction failure if ALERT_WEBHOOK_URL is configured.

    Generic webhook-based alerting — works with Slack, PagerDuty, Teams,
    or any HTTP endpoint that accepts JSON POST. Silently no-ops if not configured.
    """
    webhook_url = config.ALERT_WEBHOOK_URL
    if not webhook_url:
        return
    try:
        import httpx
        payload = {
            "text": f"[AI Extraction FAILED] job={job_id} framework={framework}: {error}",
            "job_id": job_id,
            "framework": framework,
            "error": error,
        }
        async with httpx.AsyncClient(timeout=config.ALERT_WEBHOOK_TIMEOUT_SECONDS) as client:
            await client.post(webhook_url, json=payload)
    except Exception as alert_err:
        logger.warning(f"Alert webhook failed (non-critical): {alert_err}")


# ── Stream name consumed by this service ─────────────────────────────────────
AI_STREAM = config.AI_EXTRACTION_STREAM
AI_GROUP  = config.AI_EXTRACTION_GROUP

# ── Singleton provider, rate limiter & in-flight semaphore ───────────────────
_provider: Optional[ILLMProvider] = None
_provider_lock = asyncio.Lock()
_rate_limiter: Optional[TokenBucketRateLimiter] = None
_rate_limiter_lock = asyncio.Lock()
_inflight_sem: Optional[asyncio.Semaphore] = None
_inflight_sem_lock = asyncio.Lock()


def _resolve_model_name(provider: ILLMProvider) -> Optional[str]:
    """Read the active model name off the provider, ignoring empty strings.

    Earlier code used ``getattr(p, 'deployment', None) or getattr(p, 'model', None)``
    which silently fell through to a sibling attribute when the first was an
    empty string (a misconfigured AZURE_OPENAI_DEPLOYMENT_NAME would resolve
    to the Ollama model). This explicit form fails closed.
    """
    for attr in ("deployment", "model"):
        v = getattr(provider, attr, None)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return None


def _resolve_throughput(profile: ModelProfile) -> tuple[float, int, float, int]:
    """Combine env overrides with profile defaults.

    Returns: (rpm, burst, min_gap_seconds, max_inflight)

    Sentinel rules:
      - LLM_RATE_LIMIT_RPM        > 0   → explicit override
      - LLM_RATE_LIMIT_BURST      > 0   → explicit override
      - LLM_RATE_LIMIT_MIN_INTERVAL >= 0 → explicit override (0.0 disables gap)
      - LLM_MAX_INFLIGHT          > 0   → explicit override; else profile;
                                          else falls back to resolved burst
                                          (preserves the historical
                                          concurrency = burst behaviour).
    """
    rpm = config.LLM_RATE_LIMIT_RPM if config.LLM_RATE_LIMIT_RPM > 0 else profile.rpm
    burst = config.LLM_RATE_LIMIT_BURST if config.LLM_RATE_LIMIT_BURST > 0 else profile.burst
    min_gap = (
        config.LLM_RATE_LIMIT_MIN_INTERVAL
        if config.LLM_RATE_LIMIT_MIN_INTERVAL >= 0
        else profile.min_gap_seconds
    )
    if config.LLM_MAX_INFLIGHT > 0:
        max_inflight = config.LLM_MAX_INFLIGHT
    elif profile.max_inflight > 0:
        max_inflight = profile.max_inflight
    else:
        max_inflight = burst
    return rpm, burst, min_gap, max_inflight


async def _get_shared_provider() -> ILLMProvider:
    """Return a singleton LLM provider (async double-checked locking)."""
    global _provider
    if _provider is not None:
        return _provider
    async with _provider_lock:
        if _provider is not None:
            return _provider
        _provider = get_llm_provider(config)
        if config.LLM_ENABLE_WARMUP:
            await _provider.warmup_model()
        return _provider


async def _get_shared_rate_limiter() -> TokenBucketRateLimiter:
    """Return a singleton rate limiter (async double-checked locking).

    Resolves throughput from the model profile registry, with env vars as
    explicit overrides. Also wires the limiter into providers.py so the 429
    retry path can call ``notify_rate_limited()``.
    """
    global _rate_limiter
    if _rate_limiter is not None:
        return _rate_limiter
    async with _rate_limiter_lock:
        if _rate_limiter is not None:
            return _rate_limiter

        # Resolve the active model so we can pick the right profile. The
        # provider singleton may not be built yet; build it first so we can
        # read its model name. _get_shared_provider is itself idempotent.
        provider = await _get_shared_provider()
        model_name = _resolve_model_name(provider)
        profile = resolve_profile(config.LLM_PROVIDER, model_name)
        rpm, burst, min_gap, max_inflight = _resolve_throughput(profile)

        logger.info(
            f"LLM throughput resolved: provider={config.LLM_PROVIDER} "
            f"model={model_name!r} rpm={rpm} burst={burst} "
            f"min_gap={min_gap}s max_inflight={max_inflight} "
            f"(profile={'DEFAULT' if profile.rpm == 8 and profile.burst == 5 else 'matched'})"
        )

        _rate_limiter = TokenBucketRateLimiter(RateLimitConfig(
            requests_per_minute=rpm,
            burst_size=burst,
            min_gap_seconds=min_gap,
        ))
        # Make the limiter visible to the provider's 429 retry handler.
        set_active_rate_limiter(_rate_limiter)
        return _rate_limiter


async def _get_shared_inflight_semaphore() -> asyncio.Semaphore:
    """Process-wide cap on concurrent in-flight LLM calls.

    Built once from the same profile + env resolution as the rate limiter so
    the two stay in sync. Shared across all extraction jobs to prevent
    N concurrent jobs from overcommitting at N × max_inflight.
    """
    global _inflight_sem
    if _inflight_sem is not None:
        return _inflight_sem
    async with _inflight_sem_lock:
        if _inflight_sem is not None:
            return _inflight_sem
        provider = await _get_shared_provider()
        model_name = _resolve_model_name(provider)
        profile = resolve_profile(config.LLM_PROVIDER, model_name)
        _, _, _, max_inflight = _resolve_throughput(profile)
        _inflight_sem = asyncio.Semaphore(max_inflight)
        return _inflight_sem


async def cleanup_shared_resources() -> None:
    """Close shared provider on shutdown. Called from worker/main lifespan."""
    global _provider
    if _provider is not None:
        await _provider.close()
        _provider = None




def _log_extraction_counts(profile: dict | None, results: list, job_log) -> None:
    """Log extracted sub-control counts."""
    if not profile:
        return
    total_sub_controls = sum(r.total_sub_controls for r in results)
    job_log.info(f"[AI Extraction] Total sub-controls extracted: {total_sub_controls}")

async def extract_controls(
    *,
    job_id: str,
    framework: str,
    toc_content: str = "",
    control_content: str = "",
    parsed_blob_path: str = "",
    toc_pages: str = "",
    content_pages: str = "",
    framework_profile_id: str = "",
    framework_profile: dict | None = None,
    source_pdf_hash: str = "",
    page_offset: int | str | None = None,
    toc_numbering: str = "printed",
    **_extra,
) -> None:
    """LLM sub-control extraction handler.

    Accepts content either as a blob reference (parsed_blob_path + page ranges)
    or as inline strings (toc_content / control_content) for backward compatibility.

    When framework_profile is provided (or framework_profile_id is set),
    uses framework-specific prompts and profile-driven validation.
    """
    start_job_logging(job_id, "ai_extraction")
    job_log = get_job_logger(job_id)
    if _extra:
        job_log.debug(f"Ignored unexpected payload keys: {list(_extra.keys())}")

    # A-01: Idempotency guard — skip if this job is already completed.
    # Prevents duplicate extraction on Redis Stream re-delivery after crash.
    existing_state = await fetch_job_state(job_id)
    if existing_state == STATE_COMPLETED:
        job_log.info(f"[ai_extraction] Job {job_id} already completed — skipping (idempotency guard)")
        stop_job_logging(job_id)
        return

    try:
        # Validate blob path against path traversal attacks.
        # Normalizes the path first to catch encoded/obfuscated traversal
        # (e.g., URL-encoded %2e%2e, null bytes, Windows backslashes).
        if parsed_blob_path:
            import posixpath
            # Strip null bytes and normalize separators
            clean = parsed_blob_path.replace('\x00', '').replace('\\', '/')
            normalized = posixpath.normpath(clean)
            if (
                normalized.startswith('/')
                or normalized.startswith('..')
                or '/..' in normalized
                or normalized != clean.strip('/')
            ):
                raise ValueError(
                    f"Invalid blob path (path traversal detected): "
                    f"{parsed_blob_path[:80]}"
                )

        # Defence-in-depth: validate toc_numbering for Redis-delivered payloads
        # that bypassed the FastAPI validator.
        if toc_numbering not in ("printed", "physical"):
            job_log.warning(
                f"Unexpected toc_numbering={toc_numbering!r}; defaulting to 'printed'."
            )
            toc_numbering = "printed"

        # Resolve content from blob storage when a reference is provided.
        # Inline strings (old messages / direct calls) fall through unchanged.
        requested_page_offset = page_offset
        resolved_page_offset = 0
        if parsed_blob_path and not (toc_content or control_content):
            original_toc_pages = toc_pages
            original_content_pages = content_pages
            toc_content, control_content, resolved_page_offset, toc_pages, content_pages = await load_content_from_blob(
                parsed_blob_path,
                toc_pages,
                content_pages,
                job_log,
                known_page_offset=requested_page_offset,
                toc_numbering=toc_numbering,
            )
            if not toc_content:
                job_log.warning(
                    f"Blob slice for toc_pages='{toc_pages}' (user-entered: '{original_toc_pages}') "
                    "returned empty — TOC extraction will be skipped; page-window grouping requires a TOC. "
                    "Ensure page numbers are the printed numbers from the document, "
                    "not the PDF reader's page counter."
                )
            if not control_content:
                raise ValueError(
                    f"Blob slice for content_pages='{content_pages}' returned empty after "
                    f"applying offset={resolved_page_offset} to user-entered '{original_content_pages}'. "
                    "Verify the page numbers are the printed numbers shown in the document's table "
                    "of contents, not the page counter in your PDF reader."
                )
        elif parsed_blob_path and (toc_content or control_content):
            job_log.warning(
                "parsed_blob_path provided alongside inline content — "
                "using inline content; blob path ignored."
            )

        job_log.info(
            f"Starting AI extraction for framework: {framework}. "
            f"TOC chars: {len(toc_content)}, Content chars: {len(control_content)}"
        )
        await log_audit(action="job.ai_extraction.started", entity_type="job", entity_id=job_id)

        await update_job_record(job_id, status="extracting")

        # Console-visible phase tracker. Weights are tuned to wall-clock share:
        # control extraction (N parallel LLM calls) dominates; TOC is one call;
        # blueprint resolution is fast unless discovery is needed.
        progress = PhaseTracker("ai_extraction", job_id, [
            ("Load profile", 5),
            ("Init LLM provider", 5),
            ("Extract TOC", 15),
            ("Resolve blueprint", 5),
            ("Extract controls", 60),
            ("Post-process + persist", 10),
        ])
        # Attach the tracker to the extractor so per-group sub-progress
        # ticks during the long Extract-controls phase.
        # (controls.py reads this if present; absence is fine.)

        # Resolve framework profile
        with progress.phase("Load profile"):
            profile = framework_profile
            if not profile and framework_profile_id:
                job_log.info(f"Fetching framework profile: {framework_profile_id}")
                profile = await fetch_profile_via_http(framework_profile_id)
                if profile:
                    job_log.info(f"Loaded profile: {profile.get('display_name', profile.get('name', 'unknown'))}")
                else:
                    job_log.warning(f"Profile {framework_profile_id} not found, using generic prompts")

            # logic for identifying to use toc or annex or matrix vs discovery routing
            # Resolve document layout — drives TOC vs discovery routing.
            layout = (profile or {}).get("control_layout") or "toc_body"

            if layout == "matrix":
                raise NotImplementedError(
                    f"control_layout='matrix' is not yet supported for framework '{framework}'"
                )

        with progress.phase("Init LLM provider"):
            provider = await _get_shared_provider()
            llm_model = _resolve_model_name(provider)
            rate_limiter = await _get_shared_rate_limiter()
            inflight_sem = await _get_shared_inflight_semaphore()
            extractor = SubControlExtractor(
                provider, config, rate_limiter, inflight_semaphore=inflight_sem
            )
            # Optional: extractor exposes the tracker for per-group ticks.
            extractor._progress_tracker = progress  # type: ignore[attr-defined]
        toc_entries = None

        with progress.phase("Extract TOC"):
            if toc_content and layout != "annex":
                job_log.info("Extracting TOC (sequential — page windows require TOC first)...")
                try:
                    toc = await extract_toc_from_text(
                        provider, framework, toc_content, toc_pages or "batch",
                        extractor.rate_limiter, config, framework_profile=profile,
                    )
                    if toc and toc.controls:
                        toc_entries = toc.controls
                        job_log.info(f"TOC extracted: {len(toc_entries)} entries")
                        if resolved_page_offset:
                            apply_offset_to_toc_entries(toc_entries, resolved_page_offset)
                except Exception as toc_err:
                    raise RuntimeError(f"TOC extraction failed: {_sanitize_error(toc_err)}") from toc_err
            elif layout == "annex":
                job_log.info("[ANNEX layout] Skipping TOC extraction — controls are in Annex, not TOC")

        with progress.phase("Resolve blueprint"):
            control_start_page, control_end_page, toc_entries = await resolve_blueprint(
                provider=provider,
                extractor=extractor,
                framework=framework,
                control_content=control_content,
                content_pages=content_pages,
                toc_entries=toc_entries,
                profile=profile,
                job_log=job_log,
                control_layout=layout,
            )

        with progress.phase("Extract controls"):
            extraction_result = await extractor.extract(
                framework, control_content,
                framework_profile=profile,
                toc_entries=toc_entries,
                control_start_page=control_start_page,
                control_end_page=control_end_page,
            )

        results = extraction_result.extractions
        if extraction_result.errors:
            for err_msg in extraction_result.errors:
                job_log.warning(f"[AI Extraction] Chunk error: {err_msg}")
        if extraction_result.missing_control_ids:
            job_log.error(
                f"[AI Extraction] {len(extraction_result.missing_control_ids)} "
                f"control(s) unrecoverable after retry: "
                f"{extraction_result.missing_control_ids}"
            )

        with progress.phase("Post-process + persist"):
            _log_extraction_counts(profile, results, job_log)

            payload = [r.model_dump() for r in results]

            await enrich_and_store_payload(
                job_id=job_id,
                framework=framework,
                payload=payload,
                profile=profile,
                llm_model=llm_model,
                source_pdf_hash=source_pdf_hash,
            )

            await update_job_state(job_id, STATE_COMPLETED)
            job_log.info(f"[ai_extraction] extract_controls done  job_id={job_id}")
            await log_audit(
                action="job.ai_extraction.completed",
                entity_type="job",
                entity_id=job_id,
                details={"controls_extracted": len(results)},
            )
        progress.done(f"{len(results)} control(s) extracted")

    except Exception as exc:
        await update_job_state(job_id, STATE_AI_EXTRACTION_FAILED)
        safe_error = _sanitize_error(exc, max_len=300)
        await update_job_record(job_id, status="failed", error_message=safe_error)
        await log_audit(action="job.ai_extraction.failed", entity_type="job", entity_id=job_id, details={"error": safe_error})
        job_log.error(f"[ai_extraction] extract_controls failed  job_id={job_id}: {safe_error}")
        # A-03: Fire alerting callback if configured. Enables Slack/PagerDuty/webhook
        # integration without hardcoding any specific provider.
        await _fire_alert(job_id, framework, safe_error)
        raise
    finally:
        stop_job_logging(job_id)


async def extract_toc(
    *,
    job_id: str,
    framework: str,
    content: str,
    toc_pages: str = "",
    framework_profile_id: str = "",
    framework_profile: dict | None = None,
    **_extra,
) -> dict | None:
    """LLM TOC extraction handler."""
    start_job_logging(job_id, "toc_extraction")
    job_log = get_job_logger(job_id)
    if _extra:
        job_log.debug(f"Ignored unexpected payload keys: {list(_extra.keys())}")
    job_log.info(f"Starting TOC extraction for framework: {framework}")

    try:
        # C-1: Resolve profile from ID if not provided inline
        profile = framework_profile
        if not profile and framework_profile_id:
            job_log.info(f"Fetching framework profile: {framework_profile_id}")
            profile = await fetch_profile_via_http(framework_profile_id)
            if profile:
                job_log.info(f"Loaded profile: {profile.get('display_name', profile.get('name', 'unknown'))}")
            else:
                job_log.warning(f"Profile {framework_profile_id} not found, using generic prompts")

        provider = await _get_shared_provider()
        limiter = await _get_shared_rate_limiter()
        toc = await extract_toc_from_text(
            provider, framework, content, toc_pages or config.TOC_DEFAULT_PAGES, limiter, config,
            framework_profile=profile,
        )
        result = toc.model_dump() if toc else None
        entry_count = len((result or {}).get("controls", []))
        job_log.info(f"[ai_extraction] extract_toc done  job_id={job_id}  entries={entry_count}")
        return result
    except Exception as exc:
        safe_exc = _sanitize_error(exc, max_len=300)
        await update_job_state(job_id, STATE_AI_EXTRACTION_FAILED)
        await update_job_record(job_id, status="failed", error_message=safe_exc)
        job_log.error(f"[ai_extraction] extract_toc failed  job_id={job_id}: {safe_exc}")
        raise
    finally:
        stop_job_logging(job_id)


# ── Handler registry ─────────────────────────────────────────────────────────
HANDLERS = {
    "extract_controls": extract_controls,
    "extract_toc":      extract_toc,
}
