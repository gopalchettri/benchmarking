"""
Page Offset Detection and Application
=====================================
Auto-detects the offset between printed page numbers (what users read from
the document's TOC) and physical PDF page indices (the <!-- page=N/T -->
markers in the parsed markdown).

    physical_page_index = printed_page_number + offset

Works on the page_texts dict that split_by_page_markers() produces.
No PDF file access needed. No fitz dependency.

Apply offset to:
YES  profile.toc_pages         (user reads printed pages from document TOC)
YES  profile.content_pages     (user reads printed pages from document TOC)
YES  TOC-extracted page numbers (LLM reads printed pages from document text)


CRITICAL INTEGRATION NOTE
-------------------------
Offset resolution MUST happen once per framework, AT THE TOP of the
ingestion pipeline, BEFORE any code branches on profile.control_layout
(enum values: TOC_BODY, ANNEX, MATRIX).

If the offset application lives inside a TOC-only branch, frameworks that
skip TOC (e.g. NIST CSF 2.0 with control_layout=ANNEX) will silently use
printed page numbers as if they were physical PDF indices, producing wrong
page slices and extraction garbage.

Two supported call patterns:

    # Pattern A — direct, as used in services/ai_extraction/core/storage.py:
    offset = resolve_page_offset(pages, known_page_offset, parse_type=PARSE_TYPE)
    toc_pages     = apply_offset_to_page_range(toc_pages, offset)
    content_pages = apply_offset_to_page_range(content_pages, offset)

    # Pattern B — one-shot profile mutation (for callers that carry the
    # ranges on a profile object):
    offset = apply_offset_to_profile(
        profile, page_texts,
        known_page_offset=known_page_offset,
        parse_type=PARSE_TYPE,
        markdown_text=markdown_text,
        strict=True,
    )
    # profile.toc_pages / profile.content_pages are now physical indices.


DETECTION TIERS (in precedence order)
-------------------------------------
1. Upstream offset (caller-provided non-zero value).
2. Footer/header scanning for standalone printed page numbers.
3. Explicit TOC anchors (caller-supplied heading/page tuples).
4. Self-discovered TOC anchors (scraped from the parsed markdown itself).
Catches documents where the PDF parser stripped footer page numbers
(observed with docling on NIST CSWP 29) but left the TOC intact.

Each tier falls through to the next on inconclusive result. strict=True
raises PageOffsetUndetermined with diagnostic context if all tiers fail.


KNOWN LIMITATIONS
-----------------
- Multi-range page strings like "5-8, 12-15" are not offset-transformed;
they pass through unchanged with a warning.
- Non-contiguous physical page indices in page_texts are accepted but will
produce incorrect offsets if the gap is not consistent across pages.
"""

from __future__ import annotations

import logging
import re
from collections import Counter
from typing import Any

try:
    from loguru import logger
except ImportError:
    # Ensure logs actually appear if caller hasn't configured stdlib logging.
    # Only call basicConfig if no handlers exist, to avoid clobbering caller config.
    if not logging.getLogger().handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )
    logger = logging.getLogger(__name__)


__all__ = [
    "PageOffsetError",
    "PageOffsetUndetermined",
    "detect_page_offset",
    "detect_page_offset_from_toc_anchors",
    "detect_page_offset_from_markdown_toc",
    "discover_toc_anchors_from_markdown",
    "resolve_page_offset",
    "apply_offset_to_page_range",
    "apply_offset_to_toc_entries",
    "apply_offset_to_profile",
    "split_by_page_markers",
    "diagnose",
]


# ─── Regex and scanning constants ────────────────────────────────────────────

# Characters to strip from candidate lines before number extraction.
# Covers markdown bold/italic (*) and common invisible Unicode chars.
_STRIP_RE = re.compile(r"[\*\ufeff\u200b]")

# ASCII-only digit patterns — [0-9] is deliberate: str.isdigit() and \d both
# accept non-ASCII Unicode digits (e.g. Arabic-Indic ١, superscript ², enclosed ③)
# which would cause int() to raise ValueError on most platforms.
_STANDALONE_NUM_RE = re.compile(r"^[0-9]+$")
_TRAILING_NUM_RE = re.compile(r"\b([0-9]{1,4})\s*$")

# "Page N of M" / "N / M" / "N of M" — capture the LEADING number (printed
# page), not the total. Checked BEFORE _TRAILING_NUM_RE so it wins.
_PAGE_OF_TOTAL_RE = re.compile(
    r"""
    (?:page\s+)?                   # optional 'Page ' prefix
    ([0-9]{1,4})                   # the printed page number
    \s*(?:of|/|\|)\s*              # separator
    [0-9]{1,4}                     # the total (discarded)
    \s*$                           # end of line
    """,
    re.VERBOSE | re.IGNORECASE,
)

_HEADER_ZONE_MAX_CHARS = 50
_HEADER_ZONE_MAX_LINES = 15
_FOOTER_ZONE_LINES = 6

# Sanity bounds on a plausible offset. Documents with 50+ pages of front matter
# are exceedingly rare; anything beyond is almost certainly a detection error.
_MIN_PLAUSIBLE_OFFSET = 0
_MAX_PLAUSIBLE_OFFSET = 50

# Markdown page marker emitted by parsers (docling, pymupdf4llm, kreuzberg).
_PAGE_MARKER_RE = re.compile(
    r"<!--\s*page\s*=\s*(\d+)\s*/\s*\d+\s*-->", re.IGNORECASE
)

# Known parse_type values. Anything else warns once and falls back to
# footer-first scanning order.
_KNOWN_PARSE_TYPES = {"docling", "pymupdf4llm", "kreuzberg"}
_UNKNOWN_PARSE_TYPES_WARNED: set[str] = set()


# ─── Exceptions ──────────────────────────────────────────────────────────────

class PageOffsetError(Exception):
    """Base class for page-offset failures."""


class PageOffsetUndetermined(PageOffsetError):
    """Raised in strict mode when no reliable offset can be established.

    Attributes carry diagnostic context for ops:
        toc_anchor_count: Number of explicit TOC anchors available.
        parse_type:       Parser that produced the markdown.
        page_count:       Number of physical pages in page_texts.
    """

    def __init__(
        self,
        message: str,
        *,
        toc_anchor_count: int = 0,
        parse_type: str = "",
        page_count: int = 0,
    ) -> None:
        super().__init__(message)
        self.toc_anchor_count = toc_anchor_count
        self.parse_type = parse_type
        self.page_count = page_count


# ─── Internal helpers ────────────────────────────────────────────────────────

def _detect_header_zone(lines: list[str]) -> list[str]:
    """Return header-area lines from the top of a page.

    Scans from line 0 downward, collecting short lines (metadata, blanks,
    page numbers) until a long content line (body text) is reached.
    Adapts to any header depth without a hardcoded window.
    """
    zone: list[str] = []
    for line in lines[:_HEADER_ZONE_MAX_LINES]:
        if len(line.strip()) > _HEADER_ZONE_MAX_CHARS:
            break
        zone.append(line)
    return zone


def _try_extract_page_number(clean: str) -> int | None:
    """Try to extract a printed page number from a cleaned line.

    Strategies, checked in order:
    1. "Page N of M" / "N / M" / "N of M" — take N.
    2. Standalone number — entire line is digits.
    3. Trailing number — digits at end of line.
    """
    m = _PAGE_OF_TOTAL_RE.search(clean)
    if m:
        n = int(m.group(1))
        if 1 <= n <= 9999:
            return n

    if _STANDALONE_NUM_RE.match(clean):
        n = int(clean)
        if 1 <= n <= 9999:
            return n

    m = _TRAILING_NUM_RE.search(clean)
    if m:
        n = int(m.group(1))
        if 1 <= n <= 9999:
            return n

    return None


def _warn_unknown_parse_type(parse_type: str) -> None:
    """Warn once per unknown parse_type (module-global dedupe)."""
    if parse_type in _KNOWN_PARSE_TYPES:
        return
    if parse_type in _UNKNOWN_PARSE_TYPES_WARNED:
        return
    _UNKNOWN_PARSE_TYPES_WARNED.add(parse_type)
    logger.warning(
        f"[PageOffset] Unknown parse_type={parse_type!r}; "
        f"defaulting to footer-first scan order. "
        f"Known values: {sorted(_KNOWN_PARSE_TYPES)}"
    )


def _candidates_for(lines: list[str], parse_type: str) -> list[str]:
    """Return ordered candidate lines to scan for a page number.

    docling:   header-first (header_zone then footer_zone).
    others:    footer-first (footer_zone then header_zone).
    """
    header_zone = _detect_header_zone(lines)
    footer_zone = lines[-_FOOTER_ZONE_LINES:]
    if parse_type == "docling":
        return header_zone + footer_zone
    return footer_zone + header_zone


# ─── Primary detector (footer/header scanning) ───────────────────────────────

def _detect_page_offset_opt(
    page_texts: dict[int, str],
    min_samples: int = 5,
    parse_type: str = "docling",
) -> int | None:
    """Detect offset via footer/header scan with confident-None semantics.

    Return value distinguishes:
        int   — confident detection. Value may be 0 (document genuinely
                has no offset) or non-zero. Both are valid results.
        None  — inconclusive: insufficient samples or consensus < 50%.
                Caller should try other detector tiers.

    This is the resolver-facing API. The public detect_page_offset()
    wrapper collapses None to 0 for backwards compatibility.
    """
    if not page_texts:
        return None

    _warn_unknown_parse_type(parse_type)

    offsets: list[int] = []

    for physical_idx in sorted(page_texts.keys()):
        text = page_texts[physical_idx]
        lines = text.strip().split("\n")
        if not lines:
            continue

        for line in _candidates_for(lines, parse_type):
            clean = _STRIP_RE.sub("", line.strip()).strip()
            if not clean:
                continue

            printed = _try_extract_page_number(clean)
            if printed is None:
                continue

            offset = physical_idx - printed
            if _MIN_PLAUSIBLE_OFFSET <= offset <= _MAX_PLAUSIBLE_OFFSET:
                offsets.append(offset)
                break
            # Out of range: printed could be a year (2024), chapter number,
            # total-page count, etc. Keep scanning this page for a more
            # plausible candidate rather than giving up.

    if len(offsets) < min_samples:
        logger.debug(
            f"[PageOffset] Only {len(offsets)} samples (need {min_samples}), "
            "footer/header scan inconclusive"
        )
        return None

    consensus, agreement = Counter(offsets).most_common(1)[0]
    total = len(offsets)

    if agreement / total < 0.5:
        logger.warning(
            f"[PageOffset] Agreement too low ({agreement}/{total}), "
            "footer/header scan inconclusive"
        )
        return None

    if agreement / total < 0.8:
        logger.warning(
            f"[PageOffset] Low consensus: {agreement}/{total} pages agree "
            f"on offset={consensus}. Detection may be unreliable."
        )

    if consensus != 0:
        logger.info(
            f"[PageOffset] Footer/header scan: offset={consensus} "
            f"({agreement}/{total} pages agree)"
        )
    else:
        logger.info(
            f"[PageOffset] Footer/header scan: confirmed offset=0 "
            f"({agreement}/{total} pages agree — document has no front matter)"
        )

    return consensus


def detect_page_offset(
    page_texts: dict[int, str],
    min_samples: int = 5,
    parse_type: str = "docling",
) -> int:
    """Detect offset via footer/header page-number scanning.

    Returns 0 on insufficient samples, low consensus, OR a confidently
    detected offset of 0. If you need to distinguish "couldn't detect"
    from "confident zero", call _detect_page_offset_opt() or use
    resolve_page_offset(strict=True).
    """
    result = _detect_page_offset_opt(
        page_texts, min_samples=min_samples, parse_type=parse_type
    )
    return result if result is not None else 0


# ─── Secondary detector (TOC heading cross-check) ────────────────────────────

def _compile_heading_regex(heading_norm: str) -> re.Pattern[str]:
    """Build a regex that matches a heading only as a markdown H-line."""
    return re.compile(
        r"^#{1,6}\s+.*" + re.escape(heading_norm),
        re.MULTILINE | re.IGNORECASE,
    )


def detect_page_offset_from_toc_anchors(
    page_texts: dict[int, str],
    toc_anchors: list[tuple[str, int]],
) -> int | None:
    """Cross-check offset by matching TOC entries against heading occurrences.

    Requires each TOC entry's heading to appear AS a markdown heading
    (``## Heading``) in page_texts. Matching inside table rows is rejected,
    which is critical because the TOC itself contains the heading text and
    would otherwise yield the wrong (too-small) offset.

    Returns consensus offset if ≥2 anchors agree, else None.
    """
    if not toc_anchors or not page_texts:
        return None

    sorted_indices = sorted(page_texts.keys())

    offsets: list[int] = []
    for heading, printed_page in toc_anchors:
        heading_norm = heading.strip().lower()
        if not heading_norm:
            continue

        heading_re = _compile_heading_regex(heading_norm)

        for physical_idx in sorted_indices:
            if heading_re.search(page_texts[physical_idx]):
                offset = physical_idx - printed_page
                if _MIN_PLAUSIBLE_OFFSET <= offset <= _MAX_PLAUSIBLE_OFFSET:
                    offsets.append(offset)
                break

    if len(offsets) < 2:
        return None

    consensus, agreement = Counter(offsets).most_common(1)[0]
    if agreement / len(offsets) < 0.5:
        return None

    logger.info(
        f"[PageOffset] TOC-anchor cross-check: offset={consensus} "
        f"({agreement}/{len(offsets)} anchors agree)"
    )
    return consensus


# ─── Self-discovering TOC anchor detector ────────────────────────────────────

# Matches a TOC-style line:
#   "Appendix A. CSF Core ........................ 15"
#   "| Appendix A. CSF Core ... | 15 |"
#   "1. Cybersecurity Framework Overview .... 1"
_TOC_LINE_RE = re.compile(
    r"""
    ^\|?\s*                                # optional leading pipe (table)
    (?P<heading>[A-Za-z0-9][^|\n]*?)       # heading text (non-greedy)
    \s*[\.\s\|]{3,}                        # 3+ dots/spaces/pipes as leader
    (?P<page>[0-9]{1,4})                   # printed page number
    \s*\|?\s*$                             # optional trailing pipe
    """,
    re.VERBOSE | re.MULTILINE,
)

# List-of-figures / list-of-tables prefixes — deprioritized because their
# entries typically don't have ## heading counterparts in the body.
_AUX_LIST_PREFIXES = ("fig.", "figure", "table", "tbl.", "eq.", "equation")


def discover_toc_anchors_from_markdown(
    markdown_text: str,
    max_anchors: int = 30,
    search_window_bytes: int = 25_000,
) -> list[tuple[str, int]]:
    """Find TOC-style lines in the first N bytes of parsed markdown.

    Emits (heading, printed_page) pairs. Primary chapter/appendix entries
    come first; figure/table lists are appended only if there's budget.
    """
    if not markdown_text:
        return []

    search_window = markdown_text[:search_window_bytes]

    primary: list[tuple[str, int]] = []
    auxiliary: list[tuple[str, int]] = []
    seen_headings: set[str] = set()

    for m in _TOC_LINE_RE.finditer(search_window):
        heading = m.group("heading").strip()
        heading = _STRIP_RE.sub("", heading)
        heading = re.sub(r"^[-\*\s|]+", "", heading).strip()

        if len(heading) < 4 or not any(c.isalpha() for c in heading):
            continue

        key = heading.lower()
        if key in seen_headings:
            continue
        seen_headings.add(key)

        page = int(m.group("page"))
        if not (1 <= page <= 9999):
            continue

        if key.startswith(_AUX_LIST_PREFIXES):
            auxiliary.append((heading, page))
        else:
            primary.append((heading, page))

    anchors = primary[:max_anchors]
    if len(anchors) < max_anchors:
        anchors.extend(auxiliary[: max_anchors - len(anchors)])

    logger.debug(
        f"[PageOffset] Self-discovered {len(anchors)} TOC anchors "
        f"({len(primary)} primary + {len(auxiliary)} auxiliary)"
    )
    return anchors


def detect_page_offset_from_markdown_toc(
    markdown_text: str,
    page_texts: dict[int, str],
    min_anchors: int = 2,
) -> int | None:
    """Discover TOC anchors from markdown, then cross-check against headings.

    Recommended fallback tier. Works even when the PDF parser stripped
    footer page numbers (common with docling).
    """
    anchors = discover_toc_anchors_from_markdown(markdown_text)
    if len(anchors) < min_anchors:
        return None
    return detect_page_offset_from_toc_anchors(page_texts, anchors)


# ─── Resolver ────────────────────────────────────────────────────────────────

def _coerce_upstream(
    known_page_offset: int | str | None,
) -> tuple[int, bool]:
    """Coerce upstream offset to int. Returns (value, was_provided_as_zero).

    was_provided_as_zero is True only when the caller explicitly passed
    something that coerced to 0 — used to log "upstream said 0 but we
    recovered non-zero" as a warning.
    """
    if known_page_offset is None:
        return 0, False
    try:
        value = int(known_page_offset)
    except (TypeError, ValueError):
        logger.warning(
            f"[PageOffset] Invalid provided offset {known_page_offset!r}; "
            "treating as 'not provided' and falling back to detection"
        )
        return 0, False
    return value, value == 0


def resolve_page_offset(
    page_texts: dict[int, str],
    known_page_offset: int | str | None,
    parse_type: str = "docling",
    toc_anchors: list[tuple[str, int]] | None = None,
    markdown_text: str | None = None,
    strict: bool = False,
) -> int:
    """Resolve the best available printed-vs-physical page offset.

    Precedence:
      1. Non-zero upstream value (returned immediately).
      2. Footer/header scan.
      3. Explicit TOC anchors (if provided).
      4. Self-discovered TOC anchors from markdown_text (if provided).
      5. PageOffsetUndetermined if strict=True and every tier was
         inconclusive; otherwise 0.

    A confidently-detected offset of 0 (document has no front matter) is
    a valid result and does NOT raise under strict mode. Only genuine
    detection failure (low samples / low consensus across every tier)
    triggers PageOffsetUndetermined.
    """
    # 1) Upstream wins if non-zero.
    known, upstream_was_zero = _coerce_upstream(known_page_offset)
    if known != 0:
        logger.info(f"[PageOffset] Using provided offset={known}")
        return known

    # 2) Footer/header scan — Optional[int] so we can distinguish
    #    "confident 0" from "inconclusive".
    scan_result = _detect_page_offset_opt(page_texts, parse_type=parse_type)

    # 3) Explicit TOC anchors — also Optional[int].
    toc_result: int | None = None
    if toc_anchors:
        toc_result = detect_page_offset_from_toc_anchors(page_texts, toc_anchors)
        if toc_result is not None and scan_result is not None and toc_result != scan_result:
            logger.warning(
                f"[PageOffset] Detector disagreement: "
                f"footer-scan={scan_result}, toc-anchors={toc_result}. "
                "Preferring TOC-anchors as the stronger signal."
            )
        elif toc_result is not None and scan_result is None:
            logger.info(
                f"[PageOffset] Footer-scan inconclusive; "
                f"using TOC-anchor offset={toc_result}"
            )

    # Combine: TOC anchors trump scan when both are present.
    effective: int | None = toc_result if toc_result is not None else scan_result

    # 4) Self-discovered TOC anchors from markdown.
    if effective is None and markdown_text:
        self_detected = detect_page_offset_from_markdown_toc(
            markdown_text, page_texts
        )
        if self_detected is not None:
            logger.info(
                f"[PageOffset] Footer-scan and explicit TOC inconclusive; "
                f"using self-discovered TOC-anchor offset={self_detected}"
            )
            effective = self_detected

    # 5) Every tier was inconclusive.
    if effective is None:
        if strict:
            raise PageOffsetUndetermined(
                "Could not determine a page offset from upstream, "
                "markdown footer/header scanning, explicit TOC anchors, or "
                "self-discovered TOC anchors. Every detector tier was "
                "inconclusive (insufficient samples or low consensus). "
                "Refusing to continue because strict=True.",
                toc_anchor_count=len(toc_anchors) if toc_anchors else 0,
                parse_type=parse_type,
                page_count=len(page_texts),
            )
        logger.info("[PageOffset] Using offset=0 (no reliable detection found)")
        return 0

    # Detection succeeded — effective may be 0 (confident) or non-zero.
    if upstream_was_zero and effective != 0:
        logger.warning(
            f"[PageOffset] Provided offset=0 but recovered offset={effective}; "
            "using recovered value"
        )
    return effective


# ─── Appliers ────────────────────────────────────────────────────────────────

# Single-range "N" or "N-M" with optional spaces.
_SINGLE_RANGE_RE = re.compile(r"^\s*\d+(?:\s*-\s*\d+)?\s*$")


def apply_offset_to_page_range(
    page_range: str | None, offset: int
) -> str | None:
    """Convert a printed page range to physical page indices.

    Supports:
      "11-18"     with offset=6  → "17-24"
      "3"         with offset=4  → "7"
      "15 – 23"   with offset=5  → "20-28"  (en-dash normalized)
      None, ""                    → unchanged
      "5-8, 12-15"                 → unchanged with warning (multi-range)
      "not-a-range"                → unchanged with warning

    Returns original on offset=0, empty input, or unparseable input.
    """
    if not offset or not page_range:
        return page_range

    normalized = page_range.replace("\u2013", "-").replace("\u2014", "-")

    if not _SINGLE_RANGE_RE.match(normalized):
        logger.warning(
            f"[PageOffset] Page range '{page_range}' is not a simple N or N-M "
            "(multi-range / comma-separated / non-numeric). Returning unchanged."
        )
        return page_range

    parts = normalized.strip().split("-")
    converted = [int(p.strip()) + offset for p in parts]

    if any(p < 1 for p in converted):
        logger.warning(
            f"[PageOffset] Offset {offset} produces non-positive page in "
            f"'{page_range}' → {converted}. Returning original."
        )
        return page_range

    result = "-".join(str(p) for p in converted)
    logger.info(
        f'[PageOffset] Pages: "{page_range}" → "{result}" (offset={offset})'
    )
    return result


def apply_offset_to_toc_entries(toc_entries: list, offset: int) -> int:
    """Apply offset to LLM-extracted TOC page numbers. Modifies in-place.

    Returns count of entries adjusted.
    """
    if not offset or not toc_entries:
        return 0

    adjusted = 0
    for entry in toc_entries:
        page = getattr(entry, "page", None)
        if page is None:
            continue
        try:
            entry.page = int(page) + offset
            adjusted += 1
        except (TypeError, ValueError):
            logger.warning(
                f"[PageOffset] TOC entry has non-numeric page={page!r}; skipping"
            )

    if adjusted:
        logger.info(f"[PageOffset] Adjusted {adjusted} TOC entries by +{offset}")
    return adjusted


# ─── Single-call pipeline entry point ────────────────────────────────────────

_PROFILE_PAGE_ATTRS = ("toc_pages", "content_pages")


def apply_offset_to_profile(
    profile: Any,
    page_texts: dict[int, str],
    known_page_offset: int | str | None = None,
    parse_type: str = "docling",
    toc_anchors: list[tuple[str, int]] | None = None,
    markdown_text: str | None = None,
    strict: bool = False,
) -> int:
    """Resolve offset AND apply it to profile.toc_pages + profile.content_pages.

    Single entry point every framework ingestion should call, once, at the
    top of the pipeline, BEFORE any branch on TOC / layout / etc.

    The profile is mutated in place. Missing attributes are silently skipped.

    Returns the resolved offset.
    Raises PageOffsetUndetermined if strict=True and detection fails.
    """
    offset = resolve_page_offset(
        page_texts=page_texts,
        known_page_offset=known_page_offset,
        parse_type=parse_type,
        toc_anchors=toc_anchors,
        markdown_text=markdown_text,
        strict=strict,
    )

    for attr in _PROFILE_PAGE_ATTRS:
        if hasattr(profile, attr):
            original = getattr(profile, attr)
            if original:
                setattr(profile, attr, apply_offset_to_page_range(original, offset))

    # Stash on profile for any downstream printed-page conversions.
    try:
        setattr(profile, "page_offset", offset)
    except (AttributeError, TypeError):
        logger.debug(
            "[PageOffset] Could not stash page_offset on profile "
            f"(type={type(profile).__name__}); downstream code must call "
            "resolve_page_offset() directly if it needs the value."
        )

    return offset


# ─── Utility: build page_texts from parsed markdown ──────────────────────────

def split_by_page_markers(markdown_text: str) -> dict[int, str]:
    """Split parsed markdown into {physical_page_index: page_text}.

    Assumes the ``<!-- page=N/T -->`` marker is emitted AT THE END of page N's
    content (observed convention for docling, pymupdf4llm, kreuzberg). The
    chunk BEFORE a marker is therefore keyed by that marker's own page number.
    Content after the last marker is attributed to last_marker_page + 1.

    When there are no markers at all, the entire markdown is attributed to
    page 1 (single-page fallback).

    On duplicate markers for the same page, the last occurrence wins and a
    warning is emitted.
    """
    if not markdown_text:
        return {}

    pages: dict[int, str] = {}
    last_pos = 0
    last_marker_idx = 0  # 0 sentinel → tail defaults to page 1 when no markers

    for m in _PAGE_MARKER_RE.finditer(markdown_text):
        chunk = markdown_text[last_pos : m.start()]
        idx = int(m.group(1))
        if chunk.strip():
            if idx in pages:
                logger.warning(
                    f"[PageOffset] Duplicate content for page "
                    f"index={idx}; overwriting"
                )
            pages[idx] = chunk
        last_marker_idx = idx
        last_pos = m.end()

    tail = markdown_text[last_pos:]
    if tail.strip():
        tail_idx = last_marker_idx + 1
        if tail_idx in pages:
            logger.warning(
                f"[PageOffset] Duplicate content for page "
                f"index={tail_idx}; overwriting"
            )
        pages[tail_idx] = tail

    return pages


# ─── Diagnostic entry point ──────────────────────────────────────────────────

def diagnose(
    markdown_text: str,
    parse_type: str = "docling",
    known_page_offset: int | str | None = None,
    toc_anchors: list[tuple[str, int]] | None = None,
) -> dict[str, Any]:
    """Run all detection tiers and return a structured report.

    Ops tool for validating a document before a production ingestion run.
    Does NOT raise; always returns a report.

        >>> with open("parsed.md") as f:
        ...     md = f.read()
        >>> print(diagnose(md, parse_type="docling"))
    """
    report: dict[str, Any] = {
        "parse_type": parse_type,
        "markdown_length_bytes": len(markdown_text or ""),
    }

    page_texts = split_by_page_markers(markdown_text or "")
    report["page_count"] = len(page_texts)
    report["page_indices_min"] = min(page_texts) if page_texts else None
    report["page_indices_max"] = max(page_texts) if page_texts else None
    report["page_indices_contiguous"] = (
        bool(page_texts)
        and sorted(page_texts.keys())
        == list(range(min(page_texts), max(page_texts) + 1))
    )

    # Tier 1
    known, _ = _coerce_upstream(known_page_offset)
    report["tier1_upstream"] = known if known != 0 else None

    # Tier 2 — use Optional variant so the report preserves the
    # "confident 0" vs "inconclusive" distinction.
    t2 = _detect_page_offset_opt(page_texts, parse_type=parse_type)
    report["tier2_footer_scan"] = t2

    # Tier 3
    t3: int | None = None
    if toc_anchors:
        t3 = detect_page_offset_from_toc_anchors(page_texts, toc_anchors)
    report["tier3_explicit_toc"] = t3
    report["tier3_anchor_count"] = len(toc_anchors) if toc_anchors else 0

    # Tier 4
    discovered = discover_toc_anchors_from_markdown(markdown_text or "")
    report["tier4_discovered_anchors"] = len(discovered)
    report["tier4_first_anchors"] = discovered[:5]
    t4 = detect_page_offset_from_markdown_toc(markdown_text or "", page_texts)
    report["tier4_self_discovered"] = t4

    # Resolve: prefer upstream, else tier-ordered first-not-None.
    resolved: int | None = None
    if report["tier1_upstream"] is not None:
        resolved = report["tier1_upstream"]
    elif t3 is not None:
        resolved = t3
    elif t2 is not None:
        resolved = t2
    elif t4 is not None:
        resolved = t4

    report["resolved_offset"] = resolved if resolved is not None else 0
    report["strict_would_raise"] = resolved is None

    return report