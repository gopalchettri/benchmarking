"""
Document parsing utilities for AI Extraction.
"""
import re
from typing import Dict, Tuple, Optional
from utils.logging_config import logger

# Regex that matches the <!-- page=X/Y --> markers written by pdf_extractor.py
PAGE_MARKER_RE = re.compile(r"<!--\s*page=(\d+)/\d+\s*-->")

# Last-result cache — avoids re-parsing the same content string
# when multiple pipeline stages call split_by_page_markers on identical input.
_last_split_hash: int | None = None
_last_split_len: int = 0
_last_split_result: Dict[int, str] | None = None


def split_by_page_markers(content: str) -> Dict[int, str]:
    """Parse <!-- page=X/Y --> markers back into a {page_num: text} dict.

    pdf_extractor.py writes markers as TRAILING sentinels:
        {page N text}\\n\\n<!-- page=N/Total -->
    So the text that precedes marker N belongs to page N, not to N+1.

    Results are cached by content hash. Repeated calls with identical
    content return the cached dict without re-parsing.
    """
    global _last_split_hash, _last_split_len, _last_split_result
    content_hash = hash(content)
    content_len = len(content)
    if (_last_split_hash == content_hash
            and _last_split_len == content_len
            and _last_split_result is not None):
        return _last_split_result

    pages: Dict[int, str] = {}
    last_start = 0
    for m in PAGE_MARKER_RE.finditer(content):
        page_num = int(m.group(1))
        # .strip() is safe here — content between page markers is markdown
        # where leading/trailing whitespace is layout noise from PDF extraction.
        pages[page_num] = content[last_start:m.start()].strip()
        last_start = m.end()

    # Append any trailing content to the last page instead of discarding it.
    remaining = content[last_start:].strip()
    if remaining and pages:
        last_page = max(pages.keys())
        pages[last_page] = (pages[last_page] + "\n" + remaining).strip()
        logger.info(
            f"split_by_page_markers: appended {len(remaining)} trailing chars to page {last_page}"
        )
    elif remaining:
        logger.warning(
            f"split_by_page_markers: {len(remaining)} chars after final marker "
            "but no pages parsed"
        )

    _last_split_hash = content_hash
    _last_split_len = content_len
    _last_split_result = pages
    return pages


def parse_page_range(pages_str: str) -> Optional[Tuple[int, int]]:
    """Parse a page range string into (start, end).

    Accepts "13-38", "13-38" (en-dash), or "13" (single page).
    Returns None for:
    - empty string
    - "batch" sentinel
    - "0-0" or "0" (API convention for "no TOC")
    - unrecognised input
    Pages are 1-indexed; 0 is never a valid page.
    """
    if not pages_str or pages_str.strip().lower() == "batch":
        return None
    # Normalise en-dash to hyphen
    s = pages_str.strip().replace("-", "-")
    m = re.fullmatch(r'(\d+)-(\d+)', s)
    if m:
        start, end = int(m.group(1)), int(m.group(2))
        # "0-0" (and other ranges containing 0) signal "no TOC" per the API
        # contract. Return None so downstream slicing skips cleanly instead
        # of accidentally grabbing page 1 via the max(1, ...) clamp in _slice.
        if start == 0 and end == 0:
            return None
        if start < 1 or end < 1:
            raise ValueError(
                f"Invalid page range '{pages_str}': pages are 1-indexed, "
                f"got start={start}, end={end}"
            )
        if start > end:
            raise ValueError(
                f"Invalid page range '{pages_str}': start ({start}) > end ({end})"
            )
        return start, end
    m2 = re.fullmatch(r'(\d+)', s)
    if m2:
        n = int(m2.group(1))
        if n == 0:
            return None
        return n, n
    return None
