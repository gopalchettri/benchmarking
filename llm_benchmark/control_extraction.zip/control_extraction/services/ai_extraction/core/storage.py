import asyncio
import os
import threading
from config import get_settings
from shared_core.stream_client import publish_task
from core.document import split_by_page_markers, parse_page_range
from core.page_offset import apply_offset_to_page_range, resolve_page_offset
from shared_core.interfaces.storage_port import AzureBlobStorage, LocalBlobStorage

config = get_settings()

# Singleton storage instance — avoids creating a new BlobServiceClient per call
# Thread-safe initialization via lock (matches config.py pattern)
_storage_instance = None
_storage_lock = threading.Lock()

def _get_storage():
    """Factory to get the configured FileStoragePort implementation (cached singleton)."""
    global _storage_instance
    if _storage_instance is not None:
        return _storage_instance
    with _storage_lock:
        if _storage_instance is not None:
            return _storage_instance
        if config.BLOB_BACKEND == "azure" and config.AZURE_STORAGE_CONNECTION_STRING:
            _storage_instance = AzureBlobStorage(
                config.AZURE_STORAGE_CONNECTION_STRING,
                config.AZURE_BLOB_CONTAINER_NAME,
                connection_timeout=config.BLOB_CONNECTION_TIMEOUT_SECONDS,
                read_timeout=config.BLOB_READ_TIMEOUT_SECONDS,
                max_retries=config.BLOB_MAX_RETRIES,
            )
        else:
            blob_dir = config.BLOB_STORAGE_DIR
            if not blob_dir:
                raise RuntimeError(
                    "No storage backend configured: set AZURE_STORAGE_CONNECTION_STRING "
                    "or BLOB_STORAGE_DIR in your .env file"
                )
            _storage_instance = LocalBlobStorage(blob_dir)
        return _storage_instance

async def load_content_from_blob(
    blob_path: str,
    toc_pages: str,
    content_pages: str,
    job_log,
    known_page_offset: int | str | None = None,
    toc_numbering: str = "printed",
) -> tuple[str, str, int, str, str]:
    """Download the full parsed markdown directly into memory and slice it.

    toc_numbering semantics:
    "printed" (default) — toc_pages are printed page numbers (from the
                            document's own TOC). Offset is applied to convert
                            to physical indices before slicing.
    "physical"          — toc_pages are physical page indices (PDF reader's
                            page counter). Used as-is; no offset applied.

    content_pages is ALWAYS printed (read from the TOC entries themselves);
    offset is applied unconditionally.

    Returns:
        (toc_text, control_text, page_offset, adjusted_toc_pages, adjusted_content_pages)
    """

    try:
        storage = _get_storage()
        blob_read_timeout = config.BLOB_READ_TIMEOUT_SECONDS
        # StoragePort.read_file() is synchronous (Azure SDK uses blocking I/O).
        # Wrap in asyncio.to_thread() to avoid blocking the event loop.
        # Timeout prevents a hung blob read from blocking the entire job.
        # NOTE: On timeout, the background thread continues to completion (Python
        # limitation — threads are not interruptible). Downloaded bytes are discarded
        # when the future is garbage-collected, but I/O bandwidth is consumed.
        file_bytes = await asyncio.wait_for(
            asyncio.to_thread(storage.read_file, blob_path),
            timeout=blob_read_timeout,
        )
        # Guard: reject blobs that exceed the configured size ceiling.
        # Prevents OOM from corrupt or malicious blobs.
        if len(file_bytes) > config.BLOB_MAX_BYTES:
            raise ValueError(
                f"Blob size {len(file_bytes):,} bytes exceeds "
                f"BLOB_MAX_BYTES={config.BLOB_MAX_BYTES:,}. "
                "Increase the limit or investigate the blob."
            )
        full_markdown = file_bytes.decode('utf-8', errors='replace')
        if '\ufffd' in full_markdown:
            import logging
            logging.getLogger(__name__).warning(
                "Non-UTF-8 bytes detected in blob %s — replaced with U+FFFD",
                os.path.basename(blob_path) if blob_path else "<empty>",
            )
    except Exception as e:
        # L-4: Include a redacted blob path hint (filename only) in the ERROR log
        # so it's actionable without DEBUG enabled, while keeping the full path at DEBUG.
        blob_name = os.path.basename(blob_path) if blob_path else "<empty>"
        job_log.debug(f"Failed to fetch blob '{blob_path}': {e}")
        job_log.error(f"Failed to fetch blob '{blob_name}': {type(e).__name__}: {str(e)[:200]}")
        raise

    blob_name = os.path.basename(blob_path) if blob_path else "<empty>"
    job_log.info(f"Downloaded parsed blob {blob_name} ({len(full_markdown):,} chars)")
    job_log.debug(f"Full blob path: {blob_path}")

    pages = split_by_page_markers(full_markdown)
    total = max(pages) if pages else 0

    if total == 0:
        job_log.warning("Parsed blob contains no page markers — returning empty slices")
        return "", "", 0, toc_pages, content_pages

    # Defence-in-depth: normalize toc_numbering for anything that bypassed
    # the validators upstream (direct handler calls, custom payloads, etc.).
    if toc_numbering not in ("printed", "physical"):
        job_log.warning(
            f"Unexpected toc_numbering={toc_numbering!r}; defaulting to 'printed'."
        )
        toc_numbering = "printed"

    # Prefer a non-zero source-PDF offset when available. If upstream supplied
    # zero because detection was inconclusive, give the parsed markdown a chance
    # to recover the real offset before slicing the control pages.
    # Pass full_markdown so resolve_page_offset can run tier 4 (self-discovered
    # TOC anchors) when tier 2 (footer scan) fails. This is the recovery path
    # for documents like NIST CSF that use roman-numeral page numbers in their
    # front matter and have no ASCII digits in body footers.
    page_offset = resolve_page_offset(
        pages,
        known_page_offset,
        parse_type=config.PARSE_TYPE,
        markdown_text=full_markdown,
    )
    job_log.info(f"Resolved page offset={page_offset} (toc_numbering={toc_numbering})")
    if page_offset:
        # content_pages are ALWAYS printed (read from the TOC entries
        # themselves) — offset is always applied for them.
        # toc_pages depend on toc_numbering:
        #   "printed"  → apply offset (same as content_pages)
        #   "physical" → use as-is (user already gave physical indices)
        if toc_numbering == "physical":
            job_log.info(
                f"TOC pages treated as physical ({toc_pages!r}) — no offset applied. "
                f"Applying offset={page_offset} to content_pages ({content_pages!r})."
            )
            content_pages = apply_offset_to_page_range(content_pages, page_offset)
        else:
            job_log.info(
                f"Applying offset={page_offset} to both user-provided ranges "
                f"(toc_numbering=printed): toc_pages={toc_pages!r}, content_pages={content_pages!r}"
            )
            toc_pages = apply_offset_to_page_range(toc_pages, page_offset)
            content_pages = apply_offset_to_page_range(content_pages, page_offset)
        job_log.info(
            f"Physical pages after offset: toc_pages='{toc_pages}', content_pages='{content_pages}'. "
            "If these look wrong: 'printed' mode expects numbers printed in the document, "
            "'physical' mode expects the PDF reader's page counter."
        )

    def _slice(pages_str: str, overlap: int = 0) -> str:
        # M-4: `total` refers to the original PDF's highest page number,
        # not the count of pages in this slice. The re-emitted markers
        # (<!-- page=X/total -->) preserve the original PDF pagination
        # so downstream page-window logic maps back to TOC page numbers.
        r = parse_page_range(pages_str)
        if not r:
            return ""
        start = max(1, r[0] - overlap)
        end = min(total, r[1] + overlap)
        parts = [
            f"{pages[pg]}\n\n<!-- page={pg}/{total} -->"
            for pg in range(start, end + 1)
            if pg in pages
        ]
        return "\n\n".join(parts)

    return (
        _slice(toc_pages, overlap=config.WINDOW_OVERLAP),
        _slice(content_pages),
        page_offset,
        toc_pages,
        content_pages,
    )


async def enrich_and_store_payload(
    job_id: str,
    framework: str,
    payload: list[dict],
    profile: dict | None,
    llm_model: str,
    source_pdf_hash: str,
) -> None:
    """Enriches extracted controls with domain mappings, then publishes to storage."""

    if profile and profile.get("domain_mapping"):
        domain_mapping = profile["domain_mapping"]
        sorted_prefixes = sorted(domain_mapping.items(), key=lambda x: -len(x[0]))
        for ex in payload:
            cid = ex.get("control_id", "")
            for prefix, dname in sorted_prefixes:
                if cid.startswith(prefix) and (len(cid) == len(prefix) or cid[len(prefix)] == "."):
                    ex["domain_name"] = dname
                    break

    framework_version = profile.get("version", "") if profile else ""
    await publish_task(
        stream=config.STORAGE_STREAM,
        task_name="store_controls",
        payload={
            "job_id": job_id,
            "framework": framework,
            "framework_version": framework_version,
            "framework_profile_id": profile.get("id", "") if profile else "",
            "extractions": payload,
            "llm_model": llm_model,
            "source_pdf_hash": source_pdf_hash or None,
        },
        job_id=job_id,
    )
