class AIExtractionError(Exception):
    """Base exception for all AI Extraction Service errors."""
    pass

class TransientServiceError(AIExtractionError):
    """Raised when an external service is temporarily unavailable."""
    pass

class ContextOverflowError(AIExtractionError, ValueError):
    """Raised when the prompt token count exceeds the contextual window."""
    pass

class ProviderConfigurationError(AIExtractionError, ValueError):
    """Raised when an LLM provider lacks required configuration (e.g. API keys, URLs)."""
    pass

class UnparseableJSONError(AIExtractionError, ValueError):
    """Raised when the LLM returns output that cannot be parsed into JSON."""
    pass

class EmptyResponseError(AIExtractionError, ValueError):
    """Raised when the LLM returns an empty response."""
    pass

class LLMConnectionError(TransientServiceError):
    """Raised when the LLM Provider cannot be reached (Timeout or Network Error)."""
    pass

class ProfileFetchError(TransientServiceError):
    """Raised when fetching the framework profile from the Storage service fails."""
    pass

class UnsafePathError(AIExtractionError, ValueError):
    """Raised when an unsafe path traversal is detected in payload."""
    pass

class ContentNotFoundError(AIExtractionError, ValueError):
    """Raised when the blob content slice requested is empty or unrecoverable."""
    pass
