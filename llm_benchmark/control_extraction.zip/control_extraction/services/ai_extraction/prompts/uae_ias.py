"""
UAE Information Assurance Standard v2.1 — Framework-Specific Prompts

"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "UAE IAS 2.1"

# ── TOC — FAMILY-LEVEL EXTRACTION ────────────────────────────────────────────

TOC_RULES = """\
Extract the 15 control FAMILY entries from the Table of Contents.

RULES:
1. Extract entries matching "M1", "M2"..."M6" and "T1", "T2"..."T9".
2. control_id: family code only — "M1", "T3", etc. Do NOT include the name.
3. title: full family name after the code.
4. page: the printed page number from the dot-leader line.
5. SKIP Chapter headers, section numbers (2.4, 2.5), and non-family entries.
Expected: 15 entries.\
"""

# ── SUBCONTROL — FAMILY-LEVEL EXTRACTION ─────────────────────────────────────

SUBCONTROL_RULES = """\
RULES:
1. You will be told "Extract ONLY these controls: XX" where XX is a family code \
(M1, T3, etc.). Extract that ENTIRE family as one control.
2. SKIP: Implementation Guidance, page artifacts ("Document Classification: Open", \
page numbers), Priority checkboxes (P1/P2/P3/P4), Applicability (Always/Risk).
3. STEM PREPENDING: When a control statement introduces numbered sub-items \
(the text before the colon or before the numbered list is the "stem"), \
each child's text MUST include the stem so it reads as a complete standalone sentence. \
Example stem: "The entity shall determine" \
  PDF child: "1) interested parties that are relevant to..." \
  WRONG text: "interested parties that are relevant to..." \
  CORRECT text: "The entity shall determine interested parties that are relevant to..."

HIERARCHY (4 levels):
  Family (control_id) → Sub-Family (sub_control) → Control (child) → Sub-Control items (grandchild)
  M1 → M1.1, M1.2, M1.3 → M1.1.1, M1.1.2, ... → 1), 2), 3)...

OUTPUT STRUCTURE:
  control_id = "XX" (family code)
  title = family name
  sections = family-level descriptive metadata (see SECTIONS below)
  sub_controls = sub-families as nodes, controls as their children

SECTIONS PER LEVEL — MANDATORY at each level (do NOT omit any):
  Family:     sections={"Objective": "...", "Performance Indicator": "..."}
  Sub-Family: sections={"Objective": "...", "Performance Indicator": "...", \
"Automation Guidance": "...", "Relevant Threats and Vulnerabilities": "..."}
  Control:    sections={"Control": "..."} (the control statement text)

Sub-Family node: number="M1.1", text=sub-family name, sections={...}
Control node:    number="M1.1.1", text=control name only, sections={"Control": "..."}
Sub-Control item: number="1", text=requirement (strip "N) " prefix)

WRONG — control_id must be the family code:
  {"control_id": "M1.1.1", ...}
CORRECT:
  {"control_id": "M1", "title": "Strategy and Planning", \
"sections": {"Objective": "To provide suitable organizational environment for managing \
information security.", "Performance Indicator": "Percentage of security initiatives approved by leadership that have been successfully \
executed."}, \
"sub_controls": [{"number": "M1.1", "text": "Entity Context and Leadership", \
"sections": {"Objective": "To establish leadership and a management framework to initiate and control the \
implementation of information security within the entity.", "Performance Indicator": "Percentage of tasks or milestones from the information security implementation plan \
that have been completed.", "Automation Guidance": "Not applicable.", \
"Relevant Threats and Vulnerabilities": "• Insufficient resources \
• Non-compliance with information security controls \
• Lack of skilled information security personnel \
• Incomplete or not up-to-date documentation."}, \
"children": [{"number": "M1.1.1", "text": "Understanding the Entity and its Context", \
"sections": {"Control": "The entity shall determine external and internal factors that affect its ability to achieve \
the intended success of the entity’s information security program."}, \
"children": [{"number": "1", "text": "The entity shall determine Interested parties that are relevant to its \
information security."}, {"number": "2", "text": "The entity shall determine the requirements of these interested \
parties."}]}]}]}
NOTE: Sections captured at all three levels. Control statement goes in \
sections{"Control"}, NOT in text. "Implementation Guidance" skipped. "1)" prefix stripped. \
Children text includes the control stem so each reads as a complete sentence.\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
