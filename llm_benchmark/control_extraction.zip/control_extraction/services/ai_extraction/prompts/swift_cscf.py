"""
SWIFT Customer Security Controls Framework (CSCF) v2025 — Framework-Specific Prompts
=====================================================================================

Source:  SWIFT_CSCF_v2025_20240701.pdf  (129 pages, A4, 32 controls)
Layout:  Three overarching objectives → seven numbered sections → leaf controls
         with dotted IDs (X.Y or X.YA for advisory).

Extraction is split into two deterministic stages:
  Stage 1 — TOC extraction from the detailed TOC on pages 2-3 (the only
            source with page numbers).
  Stage 2 — Sub-control extraction: structured sections + actionable
            implementation guidelines as sub_controls with optional children.

Output shape conforms to the framework-agnostic JSON schema shared with
UAE IAS / SAMA CSF / NIST CSF prompts:
  - control_id is the bare code ("1.1", "2.4A")
  - title is the short control name
  - All descriptive prose lives in sections{...}
  - Nested items use sub_controls → children recursion
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "SWIFT CSCF v2025"

# ─────────────────────────────────────────────────────────────────────
# Stage 1 — Table of Contents Extraction
# ─────────────────────────────────────────────────────────────────────

TOC_RULES = """\
DOCUMENT STRUCTURE:
- Detailed Table of Contents on pages 2-3 lists every control with printed page numbers.
- Security Controls Summary Table (pages 26-27) mirrors the list but has NO page numbers.
- Use the detailed TOC on pages 2-3 as the PRIMARY source.

CONTROL ID FORMAT:
- Dotted numeric: X.Y      (e.g., 1.1, 2.7, 6.4)
- Advisory suffix: X.YA    (e.g., 2.4A, 5.3A, 7.3A)
- IDs are single-dot only — no X.Y.Z sub-IDs exist in this framework.

HIERARCHY (do NOT emit as controls):
- Seven numbered section headers are OBJECTIVE GROUPINGS, not controls. Skip them:
    1 Restrict Internet Access and Protect Critical Systems from General IT Environment
    2 Reduce Attack Surface and Vulnerabilities
    3 Physically Secure the Environment
    4 Prevent Compromise of Credentials
    5 Manage Identities and Separate Privileges
    6 Detect Anomalous Activity to Systems or Transaction Records
    7 Plan for Incident Response and Information Sharing

PAGE NUMBERS ARE MANDATORY:
- Extract the printed page number from the dot-leader line for EVERY control.
- A control without a page number cannot be processed downstream.

EXPECTED OUTPUT:
- Exactly 32 leaf controls across sections 1-7.
- Each record: {"control_id": "X.Y[A]", "title": "...", "page": N}
- Advisory controls (suffix A) ARE controls — include them.
- SKIP: appendices, glossary, reference architecture sections, legal notices.
"""


# ─────────────────────────────────────────────────────────────────────
# Stage 2 — Sub-control (Implementation Guideline) Extraction
# ─────────────────────────────────────────────────────────────────────

SUBCONTROL_RULES = """\
─── HIERARCHY (REQUIRED OUTPUT SHAPE) ───

The OUTPUT must preserve the document's three-level hierarchy:

    Objective (1..7)  →  Control (X.Y or X.YA)  →  Implementation Guidelines

Every control extracted from this window MUST be wrapped under its parent \
Objective, even if the window only contains one control. The Objective \
appears as the top-level extractions[i] entry; the controls live in its \
sub_controls list; the Implementation Guidelines (lettered sections, \
bullets, sub-bullets) live in each control's children list.

OBJECTIVE ID → TITLE map (use these EXACT titles for the Objective wrappers):
    "1" → "Restrict Internet Access and Protect Critical Systems from General IT Environment"
    "2" → "Reduce Attack Surface and Vulnerabilities"
    "3" → "Physically Secure the Environment"
    "4" → "Prevent Compromise of Credentials"
    "5" → "Manage Identities and Separate Privileges"
    "6" → "Detect Anomalous Activity to Systems or Transaction Records"
    "7" → "Plan for Incident Response and Information Sharing"

The leaf control's number prefix (e.g., "1.1" → Objective "1"; "5.3A" → \
Objective "5") tells you which Objective wrapper to emit.

CONTROL ID: X.Y or X.YA (single dot — no X.Y.Z sub-IDs). Do NOT include an \
"id" field in any sub_control/child object — the pipeline computes IDs \
from parent + number.

─── PDF EXTRACTION ARTIFACTS ───

1. BULLET MARKERS ON SEPARATE LINES: PyMuPDF puts "•", "−", or "o" on its own \
line and the bullet text on the next line(s). JOIN the marker line with its \
following text lines into one bullet. Never emit a lone marker as a child.

2. ARCHITECTURE GRID: The "Applies to architecture:" block extracts as:
       "A1 \\n ● \\n A2 \\n ● \\n A3 \\n ● \\n A4 \\n   \\n B \\n"
   A token followed by ● is marked; a token with NO following ● is NOT marked. \
Include ONLY marked tokens in "Applies to architecture". Example above → "A1, A2, A3".

3. FOOTNOTES: Small-integer + short-phrase lines at page bottom \
("14 Multi-Vendor Secure IP Network") are NOT sub-controls. SKIP.

4. CROSS-REFERENCES: Inline refs like "see control 6.4" stay VERBATIM in the \
bullet text. Never extract the referenced ID as a separate control.

─── CONTROL SECTIONS — EXACT KEYS, IN ORDER ───

For every leaf control (the SubControl entry under an Objective), populate \
sections{...} with these EXACT keys, in this order. OMIT a key only when the \
field is genuinely absent from the source — never invent content. Use empty \
string "" if the label is present in the source but its value is empty.

   1.  "Control Type"                              ← "Control Type:" value. Exactly one of:
                                                       "Mandatory" | "Advisory" | "Mandatory / Advisory for B"
   2.  "Applies to architecture"                   ← Comma-separated ●-marked tokens ONLY ("A1, A2, A3")
   3.  "Control Objective"                         ← Verbatim from "Control Objective:" paragraph
   4.  "In-scope components"                       ← Verbatim from "In-scope components:" block (preserve list as a single string with "; " separators)
   5.  "Note"                                      ← Verbatim from "Note:" callout if present
   6.  "Risk Drivers"                              ← Verbatim from "Risk Drivers:" block
   7.  "Implementation Guidance"                   ← Verbatim from the intro paragraph that begins "The implementation guidelines are common methods to apply the relevant control..." (this is the boilerplate above the lettered items — capture it here, do NOT emit as a child)
   8.  "Control Statement"                         ← Verbatim from "Control Statement:" paragraph
   9.  "Control Context"                           ← Verbatim from "Control Context:" paragraph
   10. "Optional Enhancements"                     ← Verbatim from "Optional Enhancement(s):" section if present. Do NOT model as children.
   11. "Considerations for alternative implementations"  ← Verbatim from the like-named section if present

The structured Implementation Guidelines (lettered sections, bullets, sub-bullets) \
live as children[...] under the leaf control — NOT as a section text blob. \
This separation is REQUIRED so the UI can render the structured tree alongside \
the prose sections.

─── CHILDREN: Implementation Guidelines (the structured tree) ───

Actionable items live BELOW the "Implementation Guidance" boilerplate. \
Nesting hierarchy in the source:
    letter a)  →  bullet •  →  sub-bullet −  →  sub-sub-bullet o

- Lettered section → child: number="a", text="<heading, 'a) ' prefix stripped>"
- Each • bullet → grandchild: sequential number ("1","2","3"...) within its letter.
- Sub-bullets (−) and sub-sub-bullets (o) nest via further children[].
- Sub-sections like d.1, d.2 are headings under letter d — map as children \
with numbers "1","2" (NOT "d.1","d.2").
- STRIPPED HEADER INFERENCE: bare heading between b) and d) is the missing c).
- PLAIN-BULLET / MIXED: controls without a letter layer use number="1","2"... \
at top level. Plain bullets may precede lettered sections in the same control \
— mixed numeric+letter siblings ("1","2","a","b") at top level are valid.
- PAGE-BREAK: continuation items stay under their original parent — never \
restart numbering or promote across page breaks.

─── WORKED EXAMPLE (Control 1.1 inside Objective 1 — full hierarchy) ───

INPUT (abridged from the document — values shortened with "..." but emit them VERBATIM in your output):
  1.1 Swift Environment Protection
  Control Type: Mandatory
  Applies to architecture: A1 ● A2 ● A3 ● A4   B          ← B is unmarked
  Control Objective: Ensure the protection of the user's local Swift infrastructure...
  Control Statement: A separated secure zone safeguards...
  Control Context:   The Swift-related components are isolated...
  In-scope components: messaging interface; communication interface; ...
  Risk Drivers: Unauthorised access to the messaging interface; ...
  Implementation Guidelines: The implementation guidelines are common methods to apply the relevant control...
  a) Overall design goals
  • Implement a "secure zone"...
  • Passwords usable inside the secure zone are not stored outside it.
  d) Access to the secure zone systems
       d.1 Local Operator Access
       • The secure zone has implemented one of the following designs...
         − Operators connect from dedicated operator PCs...
         − Operators connect from a jump server...
           o Make sure all in-scope security controls are implemented.
       d.2 Remote Operator Access
       • Remote access first requires VPN authentication.

EXPECTED OUTPUT SHAPE (objective wrapper around the leaf control):
{"extractions":[{
  "control_id":"1",
  "title":"Restrict Internet Access and Protect Critical Systems from General IT Environment",
  "sections":{},
  "sub_controls":[{
    "number":"1.1",
    "text":"Swift Environment Protection",
    "sections":{
      "Control Type":"Mandatory",
      "Applies to architecture":"A1, A2, A3",
      "Control Objective":"Ensure the protection of the user's local Swift infrastructure...",
      "In-scope components":"messaging interface; communication interface; ...",
      "Risk Drivers":"Unauthorised access to the messaging interface; ...",
      "Implementation Guidance":"The implementation guidelines are common methods to apply the relevant control...",
      "Control Statement":"A separated secure zone safeguards...",
      "Control Context":"The Swift-related components are isolated..."
    },
    "children":[
      {"number":"a","text":"Overall design goals","children":[
        {"number":"1","text":"Implement a \\"secure zone\\"..."},
        {"number":"2","text":"Passwords usable inside the secure zone..."}
      ]},
      {"number":"d","text":"Access to the secure zone systems","children":[
        {"number":"1","text":"Local Operator Access","children":[
          {"number":"1","text":"The secure zone has implemented...","children":[
            {"number":"1","text":"Operators connect from dedicated operator PCs..."},
            {"number":"2","text":"Operators connect from a jump server...","children":[
              {"number":"1","text":"Make sure all in-scope security controls are implemented."}
            ]}
          ]}
        ]},
        {"number":"2","text":"Remote Operator Access","children":[
          {"number":"1","text":"Remote access first requires VPN authentication."}
        ]}
      ]}
    ]
  }]
}]}

─── WRONG ───
- Top-level extraction with control_id="1.1" — leaf control must be NESTED \
under its Objective ("1"), not at top level.
- Boilerplate emitted as a child node — it belongs in sections{"Implementation Guidance"}.
- "In-scope components" / "Risk Drivers" / "Note" / "Considerations for alternative implementations" \
emitted as children — they belong in the matching sections{} keys.
- Optional Enhancement(s) as children (belongs in sections{"Optional Enhancements"}).
- d.1 as a top-level sibling of d (must nest UNDER d).
- Footnote as a child: {"number":"20","text":"Advanced Encryption Standard"}.
- "Applies to architecture" listing unmarked tokens: "A1, A2, A3, A4, B" when PDF shows "A1● A2● A3● A4  B".
- Keeping letter prefix in text: {"number":"a","text":"a) Overall design goals..."}.
- Inventing the Objective title — use the exact strings from the OBJECTIVE ID → TITLE map above.

─── VALIDATION (self-check before returning) ───
- Every extractions[i].control_id is one of "1","2","3","4","5","6","7" (Objective).
- Every extractions[i].title comes from the OBJECTIVE ID → TITLE map verbatim.
- Every leaf sub_control.number matches X.Y or X.YA (single dot only).
- Each leaf sub_control.sections contains ALL keys present in the source for \
that control (Control Type and Applies to architecture are always present; \
others appear when their labelled paragraph is in the source).
- "Control Type" is exactly: "Mandatory", "Advisory", or "Mandatory / Advisory for B".
- "Applies to architecture" lists ONLY ●-marked tokens.
- No child has text equal to a lone marker ("•", "−", "o").
- No "id" field on any sub_control or child.\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for Stage 1 TOC extraction."""
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for Stage 2 sub-control extraction."""
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
