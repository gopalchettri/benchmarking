"""
Essential Cybersecurity Controls (ECC) 2024 — Framework-Specific Prompts
========================================================================
Saudi Arabia NCA. ~114 controls using hyphenated numeric IDs.
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "ECC 2024"

TOC_RULES = """\
- Control IDs use hyphenated format: X-Y-Z (e.g., 1-1-1, 2-3-4)
- Structure: Domain-Subdomain-Control
- Expected: ~114 controls total
- Skip domain and subdomain headers — only extract leaf controls
- Domains include: Cybersecurity Governance, Cybersecurity Defense, etc.
"""

SUBCONTROL_RULES = """\
- Control IDs: hyphenated numeric (1-1-1, 2-3-4). Format: Domain-Subdomain-Control.
- Control statement (the overall requirement) → sections{"Control Statement": "..."}
- Numbered implementation requirements → sub_controls (one sub_control per numbered item)
- NCA uses "shall" for mandatory requirements — preserve verbatim
- NO ID FIELD: Do NOT include an "id" field in sub_control objects. Output only "number", "text", "children".

EXAMPLE (1-1-1):
INPUT:

1-1-1 Cybersecurity Policy

Control Statement
The organization shall develop, document, and implement a cybersecurity policy approved by senior management.

Implementation Requirements
1. The cybersecurity policy shall define the scope, objectives, and key principles of the cybersecurity program.
2. The policy shall assign roles and responsibilities for cybersecurity across the organization.
3. The policy shall be reviewed and updated at least annually or following significant changes.
4. The policy shall be communicated to all employees and relevant external parties.

EXPECTED OUTPUT:
{"extractions": [{"control_id": "1-1-1", "title": "Cybersecurity Policy", "sections": {"Control Statement": "The organization shall develop, document, and implement a cybersecurity policy approved by senior management."}, "sub_controls": [{"number": "1", "text": "The cybersecurity policy shall define the scope, objectives, and key principles of the cybersecurity program."}, {"number": "2", "text": "The policy shall assign roles and responsibilities for cybersecurity across the organization."}, {"number": "3", "text": "The policy shall be reviewed and updated at least annually or following significant changes."}, {"number": "4", "text": "The policy shall be communicated to all employees and relevant external parties."}]}]}\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
