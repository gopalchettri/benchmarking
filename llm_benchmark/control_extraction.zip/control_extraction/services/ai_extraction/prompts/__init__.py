"""
Per-Framework Prompt Modules
============================
Each framework has its own prompt module with specialized ToC and
sub-control extraction prompts tuned for that framework's structure.

Usage:
    from prompts import load_framework_prompts
    module = load_framework_prompts("prompts.iso_27001")
    system, user = module.get_toc_prompts(content)

Backward-compatible API:
    from prompts import get_toc_prompts, get_subcontrol_prompts
    system, user = get_toc_prompts("ISO 27001", content)
"""

import importlib
import re
from typing import Any

from prompts.base import build_toc_prompts, build_subcontrol_prompts

# L-7: Explicit public API
__all__ = ["load_framework_prompts", "get_toc_prompts", "get_subcontrol_prompts"]

# C-5: Allowlist for dynamic module imports — only prompts.* submodules
_ALLOWED_MODULE_PATTERN = re.compile(r'^prompts\.[a-z0-9_]+$')


def load_framework_prompts(prompt_module: str) -> Any:
    """
    Dynamically load a framework-specific prompt module.

    Args:
        prompt_module: Dotted module path, e.g. "prompts.iso_27001"

    Returns:
        The loaded module with get_toc_prompts() and get_subcontrol_prompts()

    Raises:
        ValueError: If module path doesn't match the allowed pattern
    """
    # C-5: Validate module path against allowlist to prevent arbitrary code loading
    if not _ALLOWED_MODULE_PATTERN.match(prompt_module):
        raise ValueError(
            f"Invalid prompt module '{prompt_module}'. "
            f"Must match pattern 'prompts.<module_name>' (lowercase, alphanumeric + underscore)."
        )
    mod = importlib.import_module(prompt_module)

    # H-07: Validate that .py prompt modules expose the required interface.
    # Missing functions cause silent fallback to base prompts, which may
    # produce a different JSON schema than the caller expects.
    _REQUIRED_FUNCS = ("get_toc_prompts", "get_subcontrol_prompts")
    missing = [fn for fn in _REQUIRED_FUNCS if not hasattr(mod, fn)]
    if missing:
        import logging
        logging.getLogger(__name__).warning(
            f"Prompt module '{prompt_module}' missing functions: {missing}. "
            f"Callers will fall back to base prompts for those phases."
        )
    return mod


def get_toc_prompts(framework_name: str, content: str) -> tuple[str, str]:
    """Build system and user prompts for ToC extraction.

    Backward-compatible: uses base prompts with no framework-specific rules.
    For framework-specific prompts, use load_framework_prompts() instead.
    """
    return build_toc_prompts(framework_name, content, framework_specific_rules="")


def get_subcontrol_prompts(framework_name: str, content: str) -> tuple[str, str]:
    """Build system and user prompts for sub-control extraction.

    Backward-compatible: uses base prompts with no framework-specific rules.
    For framework-specific prompts, use load_framework_prompts() instead.
    """
    return build_subcontrol_prompts(framework_name, content, framework_specific_rules="")
