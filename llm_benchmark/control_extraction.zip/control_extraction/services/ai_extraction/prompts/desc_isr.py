"""
DESC ISR v3.1 — Framework-Specific Prompts (v10.0 — Production)
================================================================
Verified line-by-line against DESC_ISR_3_1_-EN.pdf (131 pages).

"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "DESC-ISR"

TOC_RULES = """\
CRITICAL — WHAT TO EXTRACT:
DESC-ISR's Table of Contents lists DOMAIN-level entries, not individual controls. \
Extract the 13 DOMAIN entries as the controls.

EXTRACTION RULES:
1. Find every "DOMAIN N" entry (DOMAIN 1 through DOMAIN 13) with its full name.
2. control_id: Use ONLY the domain number — "1", "2", ..., "13". \
Do NOT include the word "DOMAIN". Do NOT include the title.
3. title: The full domain name AFTER "DOMAIN N". Example: \
"DOMAIN 1  INFORMATION SECURITY MANAGEMENT AND GOVERNANCE" \
→ control_id="1", title="INFORMATION SECURITY MANAGEMENT AND GOVERNANCE"
4. page: The PRINTED page number from the dot-leader lines. \
The dot-leader section at the bottom of the page lists page numbers in the \
SAME order as the entries above. Match each domain to its page number by position.

MATCHING DOMAINS TO PAGE NUMBERS:
The TOC has two visual blocks. The top block lists entries (sections 1-9, domains, \
then sections 10-11). The bottom block has dot-leader lines with page numbers in the \
SAME sequence. Match each domain to its page number by position in the sequence. \
Count carefully to align each domain with its correct page number.

SKIP:
- Document sections (1. INTRODUCTION through 8. STRUCTURE)
- "9. DOMAINS OF INFORMATION SECURITY REGULATION" header itself
- "10. ORGANIZATIONS AND WORKS CONSULTED" and "11. APPENDIX"
- Page footers, page numbers, copyright lines

WRONG — pipeline filters out non-numeric IDs:
  {{"control_id": "DOMAIN 1", "title": "INFORMATION SECURITY MANAGEMENT AND GOVERNANCE", "page": 16}}
CORRECT:
  {{"control_id": "1", "title": "INFORMATION SECURITY MANAGEMENT AND GOVERNANCE", "page": 16}}

Expected: 13 entries (domains 1 through 13).\
"""


SUBCONTROL_RULES = """\
CRITICAL — READ BEFORE EXTRACTING:
1. "Extract ONLY these controls: N" means extract ALL main controls in \
domain N, each as its own separate extraction entry with control_id="N.Y". \
Example: "Extract ONLY these controls: 4" → output control_id="4.1", \
control_id="4.2", etc.
2. EVERY lettered item (A.–M.) MUST be its own child node. NEVER merge into \
parent text. Extract ALL of them, even across page breaks.
3. PDF artifact: some letters have text on next line ("E.\\nProtect..."). \
Rejoin: number="E", text="Protect collected evidence".

SKIP:
- "Dubai Government Entity" standalone lines
- "INFORMATION SECURITY REGULATION – VERSION 3.1" (page footer)
- Standalone page numbers, DOMAIN title pages, OBJECTIVE paragraphs

OUTPUT STRUCTURE:
For each main control X.Y, output ONE extraction:
  control_id = "X.Y" (e.g., "1.1", "4.2", "6.10")
  title = main control title stripped of "MAIN CONTROL – X.Y"
  sub_controls = all items under this main control (X.Y.Z level and below)
  sections: omit
Multiple main controls in the same domain → multiple extractions in the array.

NUMBER FORMAT:
Full document IDs: "4.1.1", "1.1.1.1". Letters: "A". Never local counters.

TITLE CLEANUP:
"MAIN CONTROL – 4.1 INCIDENT MANAGEMENT PLANNING:" → title="INCIDENT MANAGEMENT PLANNING"
"Main Control – 6.2 External Party Services Management:" → title="External Party Services Management"
Reconstruct hyphenation: "PER-\\nFORMANCE" → "PERFORMANCE".

TEXT RULES:
- Strip leading number/letter prefix and punctuation from text.
- ALL text MUST start with an uppercase letter.
- Bullets (•): merge into parent text, NOT separate nodes. OVERRIDES base prompt.

HIERARCHY — TWO PATTERNS:

PATTERN 1 — NESTED (1.1, 1.2, 5.2, 5.3, 6.1, 6.5, 6.7, 7.4, 8.1, 13.2):
"Sub Control – X.Y.Z Title:" → children X.Y.Z.W → children A–M.
Variants: "Sub Control X.Y.Z – Title:" (6.7.1, 6.7.2). \
"Sub control" lowercase 'c' (5.2.1, 5.2.2, 5.2.4, 6.1.3, 6.1.7).

PATTERN 2 — FLAT (all other main controls):
X.Y.Z directly under main control → children A–M.

CONSTRAINTS:
1. EVERY dotted ID (X.Y.Z / X.Y.Z.W) MUST be its own node. Never merge or split.
2. Do NOT renumber, invent, or modify IDs.
3. Two-digit segments exist: controls 6.10–6.12, sub-controls 6.3.11, 6.4.13.

EXAMPLE 1 — FLAT (Domain 4, partial):
INPUT:
MAIN CONTROL – 4.1 INCIDENT MANAGEMENT PLANNING:
Dubai Government Entity
4.1.1 Develops, distributes and maintains a documented policy and procedure for the management of information security incidents;
4.1.2 Establishes a competent and certified capability (incident response team) with the following key responsibilities:
A. Has knowledge on the incident and related processes;
B. Develop incident management plan, procedures;
C. Respond and Investigate incidents and determine the root cause;
D. Report and communicate action plan to relevant stakeholders;
E. Protect collected incident related evidence;
F. Identify and record lessons learned and any process improvement requirements.
MAIN CONTROL – 4.2 INFORMATION SECURITY INCIDENT REPORTING AND ESCALATION:
Dubai Government Entity
4.2.1 Assigns responsibility to all employees for reporting promptly any observed or suspected information security incidents;
4.2.2 Implements an escalation process for reporting high severity incidents.

OUTPUT:
{{"extractions":[{{"control_id":"4.1","title":"INCIDENT MANAGEMENT PLANNING","sub_controls":[{{"number":"4.1.1","text":"Develops, distributes and maintains a documented policy and procedure for the management of information security incidents;"}},{{"number":"4.1.2","text":"Establishes a competent and certified capability (incident response team) with the following key responsibilities:","children":[{{"number":"A","text":"Has knowledge on the incident and related processes;"}},{{"number":"B","text":"Develop incident management plan, procedures;"}},{{"number":"C","text":"Respond and Investigate incidents and determine the root cause;"}},{{"number":"D","text":"Report and communicate action plan to relevant stakeholders;"}},{{"number":"E","text":"Protect collected incident related evidence;"}},{{"number":"F","text":"Identify and record lessons learned and any process improvement requirements."}}]}}]}},{{"control_id":"4.2","title":"INFORMATION SECURITY INCIDENT REPORTING AND ESCALATION","sub_controls":[{{"number":"4.2.1","text":"Assigns responsibility to all employees for reporting promptly any observed or suspected information security incidents;"}},{{"number":"4.2.2","text":"Implements an escalation process for reporting high severity incidents."}}]}}]}}

WRONG — lettered children merged into parent text:
{{"number":"4.1.2","text":"Establishes a competent...responsibilities: A. Has knowledge...B. Develop..."}}

EXAMPLE 2 — NESTED (Domain 1, partial):
INPUT:
MAIN CONTROL – 1.1 ROLES AND RESPONSIBILITIES OF INFORMATION SECURITY:
The main goals of determining the roles and responsibilities are to clarify the roles of individuals and identify accountability.
Sub Control – 1.1.1 Board of Directors:
1.1.1.1 The board of directors should accept the responsibility of information security;
1.1.1.2 The entities board of directors is assigned the responsibility of overseeing a properly managed information security program.
Sub Control – 1.1.2 Director General/CEO:
1.1.2.1 The CEO or Director General has responsibility for:
A. Accepting and endorsing the overall responsibility of information security;
B. Enforcing organization wide information security management system;
C. Enforcing information security policies implementation across the entity.

OUTPUT:
{{"extractions":[{{"control_id":"1.1","title":"ROLES AND RESPONSIBILITIES OF INFORMATION SECURITY","sub_controls":[{{"number":"1.1.1","text":"Board of Directors","children":[{{"number":"1.1.1.1","text":"The board of directors should accept the responsibility of information security;"}},{{"number":"1.1.1.2","text":"The entities board of directors is assigned the responsibility of overseeing a properly managed information security program."}}]}},{{"number":"1.1.2","text":"Director General/CEO","children":[{{"number":"1.1.2.1","text":"The CEO or Director General has responsibility for:","children":[{{"number":"A","text":"Accepting and endorsing the overall responsibility of information security;"}},{{"number":"B","text":"Enforcing organization wide information security management system;"}},{{"number":"C","text":"Enforcing information security policies implementation across the entity."}}]}}]}}]}}]}}}\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
