"""
NIST Cybersecurity Framework (CSF) v2.0 - Framework-Specific Prompts

Profile: control_layout="annex", content_pages="15-23", expected_control_count=106
Pipeline: TOC skipped, discovery (106 IDs from hierarchy markers), page-group extraction

Hierarchy: 6 Functions, 22 Categories, 106 Subcategories.
Controls live ONLY in Appendix A (printed pp 15-23).
Appendix A has ONLY IDs + outcome statements. No Implementation Examples,
no Informative References (those are online-only, NOT in this PDF).

Output shape conforms to the framework-agnostic JSON schema shared with
UAE IAS and SAMA CSF prompts:
  - control_id is a bare code ("GV"), NOT "GOVERN (GV)".
  - title is the short Function name ("GOVERN"), NOT the description.
  - Function and Category descriptions live in sections{"Description": ...}.
  - sub_control.number is a bare code ("GV.OC"), sub_control.text is the name.
  - Subcategory (child) number is the full ID ("GV.OC-01").
This matters for compose_sub_control_id() in models.py: the token-prefix
check requires parent_id tokens to be a prefix of child number tokens (split
on "." and "-"). "GV" → "GV.OC" → "GV.OC-01" composes correctly.
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "NIST CSF 2.0"

# TOC - FALLBACK ONLY (annex layout skips this)

TOC_RULES = """\
NIST CSF 2.0 Appendix A is hierarchical (Function, Category, Subcategory) and \
the TOC does NOT list individual controls. This TOC path is a FALLBACK only; \
the primary path is discovery + subcontrol extraction.

If only the Table of Contents is visible:
1. Extract the 6 Function FAMILY entries (GOVERN, IDENTIFY, PROTECT, DETECT, \
RESPOND, RECOVER) with their printed page numbers. Return these as controls.

If Appendix A body content is visible instead:
1. Count ONLY subcategory IDs. Pattern: XX.YY-NN (e.g., GV.OC-01). \
Function headers and Category headers are containers, NOT counted here.
2. Numbering is NON-SEQUENTIAL. Gaps are intentional; do NOT fabricate \
missing IDs to fill them.

If no controls visible, return an empty controls list.\
"""

# SUBCONTROL - PRIMARY EXTRACTION PATH

SUBCONTROL_RULES = """\
SCHEMA (copy this shape exactly):
EXAMPLE:
{"extractions":[{"control_id":"GV","title":"GOVERN","sections":{"Description":"The organization's cybersecurity risk management strategy, expectations, and policy are established, communicated, and monitored."},"sub_controls":[{"number":"GV.OC","text":"Organizational Context","sections":{"Description":"The circumstances — mission, stakeholder expectations, dependencies, and legal, regulatory, and contractual requirements — surrounding the organization's cybersecurity risk management decisions are understood."},"children":[{"number":"GV.OC-01","text":"The organizational mission is understood and informs cybersecurity risk management."}]}]}]}

SHAPE RULES:
- control_id MUST be one of: "GV","ID","PR","DE","RS","RC" (bare code only).
- title is the Function name in ALL CAPS (GOVERN, IDENTIFY, PROTECT, DETECT, RESPOND, RECOVER).
- sub_control.number is the bare Category code ("GV.OC"); sub_control.text is the short Category name.
- child.number is the full Subcategory ID ("GV.OC-01"); child.text is the outcome statement after the colon.
- sections{"Description": "..."} is MANDATORY at Function and Category levels — OVERRIDES base "omit empty" rule.
- Children have NO sections (outcome is already in text).
- Do NOT include an "id" field — the pipeline computes IDs from parent + number.

SCOPE: Extract Appendix A only. It begins at "GOVERN (GV):" and ends after \
"RC.CO-04:". IGNORE Chapter 1-5 prose, publication refs (IR 8286*, SP 800-*), \
and acronyms (ERM, SCRM, C-SCRM, PRAM, SBOM).

INPUT FORMAT:
- Function header:    "GOVERN (GV): <description>"
- Category header:    "• Organizational Context (GV.OC): <description>"
- Subcategory bullet: "o GV.OC-01: <outcome>"  (leading "o " is a PDF bullet-font fallback — strip it)
Join continuation lines. Fix orphan hyphens ("respon-sibility" → "responsibility").

PAGE-WINDOW MODE (when "Extract ONLY the following controls: <ids>" is appended):
The requested IDs may be Subcategories (e.g. RS.MA-01..05) and the page \
window is small. Even in this mode you MUST return the FULL hierarchy \
needed to give the requested Subcategories context — do NOT return them \
as flat top-level entries.

For every requested Subcategory ID:
  1. Identify its parent Category code (the part before the trailing \
"-NN", e.g. "RS.MA" for "RS.MA-05") and its Function code (the part \
before the first ".", e.g. "RS").
  2. Locate the Category header line in the visible window text — the \
line matching "<Category Name> (<XX.YY>): <description>" — and copy \
the Category Name into sub_control.text and the description verbatim \
into sub_control.sections{"Description"}. If the Category header is \
NOT visible in the window, set sections{"Description"} to "" — never \
fabricate it.
  3. Locate the Function header line "<FUNCTION NAME> (<XX>): \
<description>" similarly. If missing, set Description to "".
  4. Emit the standard nested shape: extractions → Function → \
sub_controls (Categories) → children (the requested Subcategories).

Do NOT emit the requested Subcategory IDs at the top level (control_id \
must always be a 2-letter Function code). Do NOT omit the Category \
wrapper to "save tokens" — the Category Description is REQUIRED data, \
not optional context.

NON-SEQUENTIAL IDs: Extract ONLY subcategory IDs physically printed. Known \
gaps (non-exhaustive — trust the source): ID.AM-06, PR.AT-03..05, PR.DS-03..09, \
DE.CM-04/05/07/08, DE.AE-01/05, RS.AN-01/02/04/05, RS.CO-01/04/05, RS.MI-03, \
RC.CO-01/02.

WRONG:
- {"control_id":"IR8286A"} — publication ref, not a control.
- {"control_id":"SCRM"} — acronym from prose, not a control.
- {"control_id":"GOVERN (GV)"} — must be bare "GV".
- {"control_id":"GV","title":"The organization's cybersecurity..."} — description leaked into title; title is "GOVERN".
- {"number":"Organizational Context (GV.OC)"} — must be bare "GV.OC"; the name goes in text.
- {"number":"GV.OC","text":"The circumstances..."} — description leaked into text; text is "Organizational Context", description goes in sections.
- Omitting sections because you think it is optional — sections{"Description"} is mandatory at Function and Category levels.
- {"control_id":"RS.MA-05","title":"The criteria for..."} — Subcategory ID at the top level. control_id must be a Function code ("RS"), with the Subcategory nested under its Category under its Function.
- {"control_id":"RS","sub_controls":[{"number":"RS.MA-05","text":"..."}]} — Category wrapper "RS.MA" missing. Subcategories must always be nested inside their Category, not directly under the Function.
- {"number":"RS.MA","text":"Incident Management","sections":{}} — empty Category sections when the Category header line "Incident Management (RS.MA): Responses to detected..." is visible in the window. Copy the description verbatim.

VALIDATION (self-check before returning):
- extractions.length == 6
- control_ids == ["GV","ID","PR","DE","RS","RC"]
- Categories per Function: GV=6, ID=3, PR=5, DE=2, RS=4, RC=2 (total 22)
- Children per Function: GV=31, ID=21, PR=22, DE=11, RS=13, RC=8 (total 106)
Do NOT pad or trim to hit targets — under-extract before fabricating.\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
