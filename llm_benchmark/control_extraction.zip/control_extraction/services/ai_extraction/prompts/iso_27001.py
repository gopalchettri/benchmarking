"""
ISO/IEC 27001:2022 — Framework-Specific Prompts 

Profile: control_layout="annex", content_pages="11-18", expected_control_count=93
Pipeline: TOC skipped → discovery (93 IDs, auto-prefixed "A.") → page-group extraction

"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "ISO/IEC 27001:2022"

# ── TOC — FALLBACK ONLY (annex layout skips this) ────────────────────────────

TOC_RULES = """\
ISO 27001 TOC does not list individual controls. If Annex A content is visible:
1. Extract ONLY two-part numeric IDs (5.1, 6.3, 8.34).
2. Prefix ALL IDs with "A." — output "A.5.1" not "5.1".
3. SKIP theme headers (5, 6, 7, 8) and Clauses 1-10.
If no controls visible, return empty controls list.\
"""

# ── SUBCONTROL — PRIMARY EXTRACTION PATH ─────────────────────────────────────

SUBCONTROL_RULES = """\
RULES:
1. Prefix ALL control_ids with "A." — document prints "5.1", output "A.5.1". \
Omitting "A." silently drops the control.
2. sub_controls is ALWAYS []. ISO 27001 has NO sub-controls. \
This OVERRIDES the base "Omit empty lists" rule — include [] explicitly.
3. Do NOT hallucinate ISO 27002 content. "Purpose", "Guidance", "Other information" \
sections and sub-control items do NOT exist in 27001 Annex A.

SCOPE: Extract ONLY Annex A Table A.1 controls. SKIP Clauses 1–10, theme headers \
(bare "5", "6", "7", "8"), "Table A.1 (continued)", page artifacts, copyright lines.

INPUT FORMAT: Content arrives as markdown tables produced by pymupdf4llm:
- Rows: |id|title|statement| (e.g., |5.3|Segregation of duties|**Control**<br>...|)
- <br> tags represent PDF line breaks — NOT literal text. Remove them.
- **Control** (bold) is a label, NOT part of the statement. Strip it.
- Control 8.34 may appear as plain text outside the table — extract it the same way.

MAPPING:
- control_id: "A." + numeric ID (e.g., "A.5.3", "A.8.34").
- title: Control name from col2. Strip "Control" keyword if concatenated (seen in 7.8, 8.18). \
Remove <br> tags. Reconstruct <br>-split hyphenation: "secu-<br>rity" → "security".
- sections{"Control": "..."}: Statement text from col3 after stripping leading **Control**<br>. \
Remove <br> tags. Reconstruct hyphenation. Preserve "shall" vs "should" exactly.
- sub_controls: [] — always.

WRONG — 27002 hallucination (Purpose/Guidance do NOT exist in 27001):
{"control_id":"A.5.3","sections":{"Control":"...","Purpose":"...","Guidance":"..."},"sub_controls":[{"number":"a","text":"..."}]}

EXAMPLE:
INPUT ROW: |5.3|Segregation of duties|**Control**<br>Conflicting duties and conflicting areas of respon-<br>sibility shall be seg-<br>regated.|

OUTPUT:
{"extractions":[{"control_id":"A.5.3","title":"Segregation of duties","sections":{"Control":"Conflicting duties and conflicting areas of responsibility shall be segregated."},"sub_controls":[]}]}\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
