"""
Generic / Custom Framework — Fallback Prompts
==============================================
Used for custom or unknown frameworks configured via admin API.
No framework-specific rules — relies on the base prompt templates.
"""

import logging

from prompts.base import build_toc_prompts, build_subcontrol_prompts

logger = logging.getLogger(__name__)

FRAMEWORK_NAME = "Custom Framework"

_GENERIC_SUBCONTROL_RULES = """\
- Extract all numbered or lettered sub-items as sub_controls.
- Route any preamble / description text to sections{"Description": "..."}.
- Route any purpose / background / rationale text to sections{"Purpose": "..."}.
- Preserve all text verbatim. Do NOT rephrase, summarize, or truncate.
- NO ID FIELD: Do NOT include an "id" field in sub_control objects. Output only "number", "text", "children".

EXAMPLE (2.3):
INPUT:

2.3 Access Control

The organization shall implement controls to restrict access to information assets based on business need.

1. Establish an access control policy that defines:
   a. Scope of assets covered.
   b. Roles and access levels permitted.
   c. Approval and review process for access requests.
2. Enforce least-privilege principles for all user accounts.
3. Review and revoke access rights when employment status changes.

EXPECTED OUTPUT:
{"extractions": [{"control_id": "2.3", "title": "Access Control", "sections": {"Description": "The organization shall implement controls to restrict access to information assets based on business need."}, "sub_controls": [{"number": "1", "text": "Establish an access control policy that defines:", "children": [{"number": "a", "text": "Scope of assets covered."}, {"number": "b", "text": "Roles and access levels permitted."}, {"number": "c", "text": "Approval and review process for access requests."}]}, {"number": "2", "text": "Enforce least-privilege principles for all user accounts."}, {"number": "3", "text": "Review and revoke access rights when employment status changes."}]}]}\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    logger.info("Using generic fallback prompts for TOC extraction (no framework-specific rules)")
    return build_toc_prompts(FRAMEWORK_NAME, content, framework_specific_rules="")


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    logger.info("Using generic fallback prompts for sub-control extraction (no framework-specific rules)")
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, framework_specific_rules=_GENERIC_SUBCONTROL_RULES)
