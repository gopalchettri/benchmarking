"""
NCA Essential Cybersecurity Controls (ECC-2:2024) — Framework-Specific Prompts

4 domains, 28 subdomains, 108 main controls, 92 sub-controls.

Document structure:
  Pages 1-12:  Front matter (TLP, disclaimers, TOC, executive summary,
               introduction, objectives, scope, structure diagrams)
  Pages 13-31: Controls (ONLY extraction target)
    Domain 1: Cybersecurity Governance          (subdomains 1-1 through 1-10)
    Domain 2: Cybersecurity Defense             (subdomains 2-1 through 2-15)
    Domain 3: Cybersecurity Resilience          (subdomain  3-1)
    Domain 4: Third-Party and Cloud Computing   (subdomains 4-1, 4-2)
  Pages 32-55: Appendices A (terms), B (abbreviations), C (changelog from v1)

ID scheme (Figure 4, page 15):
  X-Y-Z-W  where X=domain, Y=subdomain, Z=main control, W=sub-control
  PDF prints sub-control IDs with dots (1.5.3.1) — normalize to hyphens (1-5-3-1).

Hierarchy mapping to JSON:
  depth 0: Domain       → controls[] entry (control_id "1", "2", "3", "4")
  depth 1: Subdomain    → sub_controls[] (number "1-1", "2-15")
  depth 2: Main control → children[] (number "1-1-1", "2-5-3")
  depth 3: Sub-control  → children[] (number "1-5-3-1", "2-5-3-9")

Pipeline notes:
  No lettered children (A/B/C) — all sub-controls are numeric.
  No Domain 5 — ICS/OT was removed in v2, moved to separate OTCC document.
  Appendix C contains v1→v2 changelog with old AND new text side-by-side.
  The pipeline MUST NOT extract from Appendix C or it will produce ghost controls.
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "NCA-ECC"


# ═══════════════════════════════════════════════════════════════════════════════
# TOC PROMPT
# ═══════════════════════════════════════════════════════════════════════════════
# NCA ECC TOC (page 7) lists section names WITHOUT numeric prefixes.
# Domain numbers (1-4) appear only as graphical icons on content pages.
# The pipeline infers domain number from subdomain ID prefixes during
# subcontrol extraction, not from TOC entries.

TOC_RULES = """\
FRAMEWORK-SPECIFIC RULES (NCA ECC v2):
- 4 domains numbered 1 through 4. No domain 5.
- Domain headers on content pages carry a circled number icon (1, 2, 3, 4) \
next to the domain name. Use ONLY the number as control_id.
- Expected: exactly 4 entries.

EXTRACT:
  Domain 1: "Cybersecurity Governance" 
  Domain 2: "Cybersecurity Defense" 
  Domain 3: "Cybersecurity Resilience" 
  Domain 4: "Third-Party and Cloud Computing Cybersecurity" 

SKIP: TLP section, Update and Review, Introduction, Objectives, \
Scope of Work, ECC Domains and Structure, List of Tables, List of Figures, \
Appendices (A, B, C).

WRONG — domain name used as control_id:
  {"control_id": "Cybersecurity Governance", "title": "Cybersecurity Governance"}
CORRECT:
  {"control_id": "1", "title": "Cybersecurity Governance"}\
"""


# ═══════════════════════════════════════════════════════════════════════════════
# SUBCONTROL PROMPT
# ═══════════════════════════════════════════════════════════════════════════════
# Each LLM call receives one domain's full page content and extracts it as
# a single ControlExtraction where:
#   control_id = domain number ("1", "2", "3", "4")
#   title = domain name
#   sub_controls = ALL subdomains (X-Y) within that domain
#     → children = main controls (X-Y-Z)
#       → children = sub-controls (X-Y-Z-W)
#
# Domain 2 is the largest (15 subdomains, pages 19-28). Ensure
# SUBCONTROL_MAX_TOKENS accommodates it.

SUBCONTROL_RULES = """\
CRITICAL — READ FIRST:
1. You will be told to "Extract ONLY these controls: N" where N is a domain \
number (1 through 4). Extract the ENTIRE domain N as a single control, with \
ALL its subdomains as sub_controls. Do NOT extract controls from other domains.
2. ID NORMALIZATION: The PDF prints sub-control IDs with DOTS (e.g., 1.5.3.1, \
2.5.3.8). Convert ALL dots to HYPHENS in your output. Every ID at every level \
must use hyphens: 1-5, 1-5-3, 1-5-3-1. Never output a dot-separated ID.
3. "Objective" rows appear after each subdomain header. Capture the Objective \
text in the subdomain's sections field: sections={"Objective": "..."}. \
Do NOT create a separate sub_control for the Objective.
4. STOP extraction at "Appendices" or "Appendix (A)". Pages after this contain \
terms, abbreviations, and a v1→v2 changelog with OLD control text that must \
NOT be extracted.
5. Do NOT stop early when content spans page breaks. Domain 2 spans ~10 pages. \
Extract ALL subdomains and controls within the domain boundary.

SCOPE:
- Valid domain numbers: 1, 2, 3, 4 ONLY. Domain 5 does NOT exist (removed in v2).
- Valid subdomain range: 1-1 through 1-10, 2-1 through 2-15, 3-1, 4-1, 4-2.
- 28 subdomains total across all 4 domains.

CONTROL_ID AND TITLE:
- control_id: ONLY the domain number ("1", "2", "3", or "4"). Never include \
the domain name in control_id.
- title: The domain name exactly as printed. Do NOT include the number.
WRONG: {"control_id": "Cybersecurity Defense", "title": "Cybersecurity Defense"}
CORRECT: {"control_id": "2", "title": "Cybersecurity Defense"}

HIERARCHY (3 nesting tiers inside each domain):

  Tier 1 — Subdomain (sub_controls[]):
    number="1-1", text="Cybersecurity Strategy", \
sections={"Objective": "To ensure that the action plans..."}

  Tier 2 — Main Control (children[]):
    number="1-1-1", text="The cybersecurity strategy of the entity shall be..."

  Tier 3 — Sub-Control (children[] of main control):
    number="1-5-3-1", text="At early stage of technology projects."

  There is NO Tier 4. Do NOT nest deeper.

FORMULAIC PATTERN — most subdomains follow this structure:
  X-Y-1: "...shall be identified, documented, and approved."  (define)
  X-Y-2: "...shall be implemented."                           (implement)
  X-Y-3: "...shall include the following as a minimum:"       (requirements list)
    X-Y-3-1 through X-Y-3-N: individual requirement items     (sub-controls)
  X-Y-4: "...shall be periodically reviewed."                 (review)
The sub-controls (Tier 3) are children of the "-3" control, NOT siblings of it.
Not all subdomains follow this exact count. Some have more or fewer main \
controls. Extract ALL controls within each subdomain regardless.

SPECIAL CASES:
- Subdomain 1-7: PDF prints header as "1.7" with a dot. Normalize to "1-7".
- Control 2-5-3-9 (DDoS): added in v2, uses hyphenated format in the PDF. \
Normalize like all others.
- Subdomain 1-7 has only 1 main control (1-7-1). This is correct, not missing data.
- Subdomain 3-1 is the only subdomain under Domain 3. This is correct.

TEXT RULES:
- Extract control text VERBATIM from the document. Do NOT rephrase.
- After stripping a number prefix, capitalize the first letter if it was \
lowercased due to mid-sentence continuation.
- Strip trailing periods only if inconsistent with the document.
- "shall" is the standard NCA language — preserve it exactly.

SKIP:
- Table headers ("Controls", "Control Reference Number", "Control Clauses")
- Page footers ("Document classification: Public", "TLP: White")
- Arabic text fragments (مقيد - محدود)
- Figure captions, table captions
- Any content after "Appendices" heading\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
