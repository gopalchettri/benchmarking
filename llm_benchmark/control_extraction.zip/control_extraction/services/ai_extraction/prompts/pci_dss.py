"""
PCI-DSS v4.0.1 — Framework-Specific Prompts
=============================================
12 Requirements, 250 leaf sub-requirements using dotted numbering.

Layout: 3-column table (Requirements | Testing Procedures | Guidance). PyMuPDF
flattens columns in reading order — use the heading words to re-segment.

Output shape conforms to the framework-agnostic JSON schema shared with
UAE IAS / SAMA CSF / NIST CSF / SWIFT CSCF prompts.
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "PCI-DSS v 4.0.1"

TOC_RULES = """\
- Requirements numbered Requirement 1 through Requirement 12.
- Sub-requirements use dotted numbering: 1.1.1, 6.2.3.1, 12.3.4.
- Extract leaf-level only — if 1.1 has children 1.1.1, 1.1.2, skip 1.1.
- Expected total: 250 leaf sub-requirements across Requirements 1-12.
- SKIP: Overview, Scope, appendices, summary tables.
- Strip "Requirement " prefix from control_id — output "1.1.1", not "Requirement 1.1.1".
"""

SUBCONTROL_RULES = """\
SCHEMA (copy this shape exactly):
EXAMPLE:
{"extractions":[{"control_id":"1.1.1","title":"Processes and mechanisms for installing and maintaining network security controls are defined and understood","sections":{"Defined Approach Requirement":"All security policies and operational procedures that are identified in Requirement 1 are:\\n• Documented.\\n• Kept up to date.\\n• In use.\\n• Known to all affected parties.","Customized Approach Objective":"Expectations, controls, and oversight for meeting activities within Requirement 1 are defined, understood, and adhered to by affected personnel.","Testing Procedures":"1.1.1 Examine documentation and interview personnel to verify that security policies and operational procedures identified in Requirement 1 are managed in accordance with all elements specified in this requirement.","Guidance":"Purpose: Requirement 1.1.1 is about effectively managing and maintaining the various policies and procedures specified throughout Requirement 1..."},"sub_controls":[]}]}

SHAPE RULES:
- control_id: bare dotted code ("1.1.1"). NO "Requirement " prefix.
- title: requirement sentence after the ID, trailing period stripped.
- sections keys (emit only those present in source):
    "Defined Approach Requirement"  ← text under "Defined Approach Requirements". Inline bullets (•) stay in the string as "\\n• item" — they are stem completions, NOT sub-controls.
    "Customized Approach Objective" ← verbatim.
    "Testing Procedures"            ← all text under "Defined Approach Testing Procedures". Concatenate lettered items (X.Y.Z.a, X.Y.Z.b) preserving their prefixes.
    "Applicability Notes"           ← verbatim if present.
    "Guidance"                      ← Guidance-column text. Merge "Purpose:", "Good Practice:", "Definitions:", "Examples:" sub-labels into this single string as inline prefixes.
- sub_controls: [] (ALMOST ALWAYS — inline bullets stay in the Requirement string). OVERRIDES base "omit empty". ONLY populate if the body itself has lettered sub-items (a./b./c.) — rare.
- No "id" field on sub_controls. Pipeline computes IDs from parent + number.

CRITICAL: Testing Procedure items (X.Y.Z.a, X.Y.Z.b) are HOW auditors verify, \
NOT what to implement. They go in sections{"Testing Procedures"} — NEVER as sub_controls.

INPUT: The PDF is a 3-column table flattened in reading order. Use heading \
words ("Defined Approach Requirements", "Defined Approach Testing Procedures", \
"Customized Approach Objective", "Applicability Notes", "Purpose", "Good \
Practice") to re-segment text into the correct sections keys.

WRONG:
- {"control_id":"Requirement 1.1.1"} — strip the prefix.
- Testing procedure as sub_control — must go in sections{"Testing Procedures"}.
- Inline bullet as sub_control — bullets stay in sections{"Defined Approach Requirement"}.\
"""


def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)


def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
