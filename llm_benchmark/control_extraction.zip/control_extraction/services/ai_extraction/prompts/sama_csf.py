"""
SAMA CSF v1.0 — Framework-Specific Prompts

36 extractable units: 32 subdomains (3.X.Y) + 4 sub-sections (3.2.1.1–3.2.1.4).
Sub-sections 3.2.1.1–3.2.1.4 are separate top-level controls.
Sub-control IDs are computed by the pipeline: 3.X.Y.N → 3.X.Y.N.a → 3.X.Y.N.a.i
"""

from prompts.base import build_toc_prompts, build_subcontrol_prompts

FRAMEWORK_NAME = "SAMA-CSF"

# Sub-sections not listed in the PDF's Table of Contents but present in the body.
# The pipeline injects these into the TOC entries so they appear in page groups
# and extraction constraints. Same knowledge as TOC Rule 2 and Subcontrol Rule 4.
EXTRA_TOC_IDS = {
    "3.2.1": ["3.2.1.1", "3.2.1.2", "3.2.1.3", "3.2.1.4"],
}

TOC_RULES = """\
1. SCOPE: Extract controls exclusively from Chapter 3.
2. EXTRACTION TARGETS: Extract ONLY the lowest-level nested sections in the hierarchy.
   - For ALL domains (3.1, 3.2, 3.3, 3.4): Extract the 3-part IDs (e.g., "3.1.1", "3.2.1", "3.3.2").
   - ALSO extract sub-sections 3.2.1.1, 3.2.1.2, 3.2.1.3, 3.2.1.4 as separate entries.
   - Expected total: 36 entries (32 subdomains + 4 sub-sections of 3.2.1).
3. TITLE FORMATTING: Preserve the title exactly as printed. Omit the numerical ID prefix from the title string itself.
4. CROSS-REFERENCES: Record cross-references exactly as they appear in the title. Do not attempt to resolve or trace them to other pages.
"""

SUBCONTROL_RULES = """\
1. SECTIONS MAPPING:
   - Map text under "Principle" to sections["Principle"].
   - Map text under "Objective" to sections["Objective"].
   - Do NOT create a "Description" section.
2. OCR ROBUSTNESS: Section headers may contain minor spacing or OCR artifacts (e.g., "P rinciple", "O bjective", "Control con siderations"). Map corrupted headers to their exact standardized key (e.g., "Principle", "Objective").
   EMPTY SECTIONS: If a section header (Principle, Objective) appears with NO body text before the next section header, OMIT that section from the output entirely.
3. CONTROL CONSIDERATIONS: All rules, statements, and lists under this heading belong exclusively in the `sub_controls` array.
4. SUB-SECTIONS OF 3.2.1: The document contains sub-sections 3.2.1.1 through 3.2.1.4. \
These ARE separate controls — extract each with its own control_id, title, \
Principle, Objective, and Control considerations.
   - 3.2.1 itself still has its own Control considerations — extract those under 3.2.1.
   - Do NOT nest 3.2.1.1–3.2.1.4 as sub_controls of 3.2.1.
5. PAGE-BREAK CONTINUITY: When a numbered sub-list (1, 2, 3, ...) begins under a lettered parent item (e.g., "c. approving:") on one page and continues on the next page, ALL continuation items are STILL children of that lettered parent. A page break does NOT end the parent scope. Do NOT promote continuation items to sibling level or invent new letter labels.
6. LETTERED SUB-ITEMS UNDER NUMBERED PARENTS: When a numbered item (e.g., "3.") is followed by lettered items (a, b, c...) before the next numbered item (e.g., "4."), those lettered items are CHILDREN of the numbered item, not siblings. This is the reverse of Rule 5 — the same nesting principle applies in both directions.
7. COMPLETENESS OF LETTERED SEQUENCES: When extracting lettered sub-items (a, b, c, d...), ensure ALL letters in the sequence are captured. Do not skip any. If text for a lettered item spans a page break, include the text from both pages.

EXAMPLE 1 (List Hierarchy without Prefixes):
INPUT:
3.1.4 Cyber Security Roles
Principle
Roles should be defined.
Objective
To document roles.
Control considerations
1. The Board has responsibility, including:
a. allocating budget;
b. approving charters.

EXPECTED OUTPUT (abridged for brevity):
{"extractions":[{"control_id":"3.1.4","title":"Cyber Security Roles","sections":{"Principle":"Roles should be defined.","Objective":"To document roles."},"sub_controls":[{"number":"1","text":"The Board has responsibility, including:","children":[{"number":"a","text":"allocating budget;"},{"number":"b","text":"approving charters."}]}]}]}

EXAMPLE 2 (Bullet Points without Prefixes):
INPUT:
3.2.3 Compliance
Principle
O bjective
To comply with standards.
Control considerations
The Organization should comply with:
PCI-DSS;
EMV technical standard.

EXPECTED OUTPUT (abridged for brevity):
{"extractions":[{"control_id":"3.2.3","title":"Compliance","sections":{"Objective":"To comply with standards."},"sub_controls":[{"number":"1","text":"The Organization should comply with:","children":[{"number":"1","text":"PCI-DSS;"},{"number":"2","text":"EMV technical standard."}]}]}]}

EXAMPLE 3 (Page-Break Continuation — numbered items 5-6 stay under lettered parent "c"):
INPUT:
2. The committee should be responsible for:
c. approving, communicating, supporting and monitoring:
1. the cyber security governance;
2. the cyber security strategy;
3. the cyber security policy;
4. cyber security programs;
5. cyber security risk management process;
6. the key risk indicators.

CORRECT OUTPUT:
{"number":"2","text":"The committee should be responsible for:","children":[{"number":"c","text":"approving, communicating, supporting and monitoring:","children":[{"number":"1","text":"the cyber security governance;"},{"number":"2","text":"the cyber security strategy;"},{"number":"3","text":"the cyber security policy;"},{"number":"4","text":"cyber security programs;"},{"number":"5","text":"cyber security risk management process;"},{"number":"6","text":"the key risk indicators."}]}]}

WRONG (do NOT do this — items 5-6 must NOT be promoted out of "c"):
{"number":"c","children":[1,2,3,4]},{"number":"d","text":"cyber security risk management process;"},{"number":"5","text":"..."}

EXAMPLE 4 (3.2.1 and 3.2.1.1 — separate controls, NOT nested):
INPUT:
3.2.1 Cyber Security Risk Management
Principle
A risk management process should be defined.
Objective
To ensure risks are managed.
Control considerations
1. The process should be defined and approved.
2. The process should focus on safeguarding assets.

3.2.1.1 Cyber Security Risk Identification
Principle
A risk identification methodology should be defined.
Objective
To identify cyber security risks.
Control considerations
1. Risk identification should cover all information assets.
2. A risk register should be maintained.

EXPECTED OUTPUT (two separate extractions):
{"extractions":[{"control_id":"3.2.1","title":"Cyber Security Risk Management","sections":{"Principle":"A risk management process should be defined.","Objective":"To ensure risks are managed."},"sub_controls":[{"number":"1","text":"The process should be defined and approved."},{"number":"2","text":"The process should focus on safeguarding assets."}]},{"control_id":"3.2.1.1","title":"Cyber Security Risk Identification","sections":{"Principle":"A risk identification methodology should be defined.","Objective":"To identify cyber security risks."},"sub_controls":[{"number":"1","text":"Risk identification should cover all information assets."},{"number":"2","text":"A risk register should be maintained."}]}]}

EXAMPLE 5 (Lettered children under a numbered parent — Rule 6):
INPUT:
3. A security event monitoring standard should be defined, approved and implemented.
a. the standard should address mandatory events to be monitored;
b. automated tools should be employed.
4. The security event management process should include requirements for:
a. establishment of a designated team;
b. continuous monitoring.

CORRECT OUTPUT:
{"number":"3","text":"A security event monitoring standard should be defined, approved and implemented.","children":[{"number":"a","text":"the standard should address mandatory events to be monitored;"},{"number":"b","text":"automated tools should be employed."}]},{"number":"4","text":"The security event management process should include requirements for:","children":[{"number":"a","text":"establishment of a designated team;"},{"number":"b","text":"continuous monitoring."}]}

WRONG (do NOT do this — "a" and "b" must NOT be siblings of "3"):
{"number":"3","text":"..."},{"number":"a","text":"..."},{"number":"b","text":"..."},{"number":"4","text":"..."}
"""

def get_toc_prompts(content: str) -> tuple[str, str]:
    return build_toc_prompts(FRAMEWORK_NAME, content, TOC_RULES)

def get_subcontrol_prompts(content: str) -> tuple[str, str]:
    return build_subcontrol_prompts(FRAMEWORK_NAME, content, SUBCONTROL_RULES)
