from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, APIRouter
from pydantic import BaseModel
from loguru import logger

from api.routes import router
from core.profile import close_profile_client
from jobs.handlers import cleanup_shared_resources
from shared_core.stream_client import publish_task
from shared_core.redis_client import fetch_job_state
from shared_core.middlewares.tracing import RequestTracingMiddleware
from shared_core.middlewares.rate_limiting import RateLimitingMiddleware
from shared_core.health import check_redis, check_llm_endpoint, enforce_startup_checks
from config import get_settings

settings = get_settings()

# ── OpenTelemetry bootstrap ──
from shared_core.telemetry import setup_telemetry, instrument_fastapi
setup_telemetry(service_name=settings.APP_NAME_AI_EXTRACTION)

# ── Logging Setup ──
from utils.logging_config import setup_logging
setup_logging(service_name=settings.APP_NAME_AI_EXTRACTION, environment=settings.ENVIRONMENT)
from shared_core.intercept_handler import install_intercept_handler
install_intercept_handler(["uvicorn", "uvicorn.access", "uvicorn.error", "fastapi"])

# ── Startup health checks ──
_startup_health: dict = {}


@asynccontextmanager
async def lifespan(_app: FastAPI):
    try:
        checks = {
            "redis": check_redis(settings.REDIS_URL),
        }
        # Check LLM endpoint reachability (non-critical — service boots even if cold)
        if settings.LLM_PROVIDER == "azure" and getattr(settings, "AZURE_OPENAI_ENDPOINT", None):
            checks["llm_endpoint"] = check_llm_endpoint(
                provider="Azure OpenAI",
                endpoint=settings.AZURE_OPENAI_ENDPOINT,
            )
        elif settings.LLM_PROVIDER == "ollama" and getattr(settings, "OLLAMA_BASE_URL", None):
            checks["llm_endpoint"] = check_llm_endpoint(
                provider="Ollama",
                endpoint=settings.OLLAMA_BASE_URL,
            )
        _startup_health.update(
            await enforce_startup_checks(
                service_name=settings.APP_NAME_AI_EXTRACTION,
                checks=checks,
                critical={"redis"},   # LLM is non-critical at startup
            )
        )
    except Exception as exc:
        logger.error(f"Lifespan startup failed: {exc!r}")
        raise
    yield
    # Clean up shared resources on shutdown to prevent connection leaks
    await close_profile_client()
    await cleanup_shared_resources()


app = FastAPI(title=settings.APP_NAME_AI_EXTRACTION, version=settings.APP_VERSION, lifespan=lifespan)
# Starlette middleware uses LIFO ordering: last added = first executed.
# Order below ensures: Tracing → Auth → Tenant → RateLimit (outermost to innermost).
app.add_middleware(
    RateLimitingMiddleware,
    max_requests=settings.GLOBAL_RATE_LIMIT_MAX_REQUESTS,
    window_seconds=settings.GLOBAL_RATE_LIMIT_WINDOW_SECONDS,
)
app.add_middleware(RequestTracingMiddleware)
instrument_fastapi(app)

# ── Health endpoint (live check) ──
@app.get("/health", tags=["Health"])
async def health():
    live_redis = await check_redis(settings.REDIS_URL)
    overall = "ok" if live_redis["status"] == "ok" else "degraded"
    return {
        "service": settings.APP_NAME_AI_EXTRACTION,
        "status":  overall,
        "checks":  {"redis": live_redis, **_startup_health},
    }


app.include_router(router)
