"""
Database Models
===============
SQLAlchemy models for the storage service.

Models:
- FrameworkProfileModel: Predefined compliance framework configurations
- CanonicalControlModel: Framework-agnostic extracted controls (universal schema)
- AuditLogModel: Immutable audit trail
- ExtractionJobModel: Persistent extraction job tracking
"""

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    BigInteger, Boolean, CheckConstraint, Column, DateTime, Float, Integer,
    String, Text, JSON, ForeignKey, Index, UniqueConstraint, text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID as PG_UUID
from sqlalchemy.orm import backref, declarative_base, relationship

Base = declarative_base()

# ── Dialect-aware column types ──
# On PostgreSQL: uses native UUID (16 bytes) and JSONB (pre-parsed, GIN-indexable).
# On other backends (MySQL, SQLite): falls back to String(36) and JSON.
UUIDType = String(36).with_variant(PG_UUID(as_uuid=False), "postgresql")
JSONType = JSON().with_variant(JSONB, "postgresql")


def _uuid() -> str:
    return str(uuid.uuid4())


class FrameworkProfileModel(Base):
    """Compliance framework configuration — simplified."""
    __tablename__ = "framework_profiles"

    # User input
    id = Column(UUIDType, primary_key=True, default=_uuid)
    name = Column(String(50), nullable=False, unique=True)
    display_name = Column(String(255), nullable=False)
    version = Column(String(50), nullable=False)
    # Auto-derived / seeded
    prompt_module = Column(String(100), nullable=False)
    control_layout = Column(String(20), nullable=True)   # toc_body | annex | matrix
    domain_mapping = Column(JSONType, nullable=True)

    # Seed audit
    content_hash = Column(String(32), nullable=True)
    seed_version = Column(String(20), nullable=True)
    seeded_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_profile_name_version", "name", "version"),
    )


class CanonicalControlModel(Base):
    """Framework-agnostic control representation — THE universal output format."""
    __tablename__ = "canonical_controls"

    id = Column(UUIDType, primary_key=True, default=_uuid)

    # Identity
    control_id_raw = Column(String(50), nullable=False)                 # "A.5.1"
    control_id_normalized = Column(String(200), nullable=False)         # "ISO27001-2022:A.5.1"

    # Hierarchy
    parent_id = Column(UUIDType, ForeignKey("canonical_controls.id", ondelete="CASCADE"), nullable=True)
    hierarchy_level = Column(Integer, nullable=False, default=0, server_default=text("0"))
    hierarchy_path = Column(String(500), nullable=True)                 # "/A.5/A.5.1"

    # Content
    title = Column(String(1000), nullable=False)
    description = Column(Text, nullable=True)
    sections = Column(JSONType, nullable=True)                          # {"Guidance": "...", "Objective": "..."}
    sub_controls = Column(JSONType, nullable=True)                      # Recursive SubControl tree

    # Classification
    domain_name = Column(String(255), nullable=True)                    # "Organizational Controls"

    # Provenance
    source_framework = Column(String(100), nullable=False)              # "ISO-27001"
    framework_version = Column(String(50), nullable=True)               # "2022"
    framework_profile_id = Column(UUIDType, ForeignKey("framework_profiles.id", ondelete="SET NULL"), nullable=True)
    job_id = Column(UUIDType, ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False)

    # Quality
    extraction_confidence = Column(Float, nullable=True)                # 0.0 to 1.0
    verbatim_verified = Column(Boolean, nullable=True)
    extraction_status = Column(String(20), nullable=False, default="machine_draft", server_default="machine_draft")
    verified_by = Column(UUIDType, nullable=True)                       # user who verified
    verified_at = Column(DateTime(timezone=True), nullable=True)        # when verification happened

    # Metadata
    metadata_json = Column(JSONType, nullable=True)
    source_pages = Column(String(100), nullable=True)                   # "15-25"
    llm_model = Column(String(100), nullable=True)                      # "gpt-4o", "llama3.2"
    source_pdf_hash = Column(String(64), nullable=True)                 # SHA-256 of source PDF

    # Timestamps
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    children = relationship("CanonicalControlModel", backref=backref("parent", remote_side=[id]))

    __table_args__ = (
        Index("ix_control_job", "job_id"),
        Index("ix_control_framework", "source_framework", "framework_version"),
        UniqueConstraint("job_id", "control_id_raw", name="uq_job_control"),
        Index("ix_control_job_raw", "job_id", "control_id_raw"),
        # PostgreSQL: GIN trigram index for ILIKE '%pattern%' search (requires: CREATE EXTENSION pg_trgm)
        Index("ix_control_title_trgm", "title",
              postgresql_using="gin", postgresql_ops={"title": "gin_trgm_ops"},
              mysql_length=255),
        CheckConstraint(
            "extraction_status IN ('machine_draft', 'human_verified', 'rejected')",
            name="ck_extraction_status",
        ),
    )


class AuditLogModel(Base):
    """Immutable audit trail for compliance operations."""
    __tablename__ = "audit_logs"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    action = Column(String(100), nullable=False)                        # "job.created", "profile.created"
    entity_type = Column(String(50), nullable=False)                    # "job", "profile", "control"
    entity_id = Column(UUIDType, nullable=False)
    details = Column(JSONType, nullable=True)
    user_id = Column(UUIDType, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_audit_action", "action"),
        Index("ix_audit_entity", "entity_type", "entity_id"),
        Index("ix_audit_created_at", "created_at"),
    )


# ── Extraction Job Tracking ──


class ExtractionJobModel(Base):
    """Persistent extraction job record (replaces ephemeral Redis state)."""
    __tablename__ = "jobs"

    id = Column(UUIDType, primary_key=True)                    # = job_id from pipeline (NOT auto-generated)
    framework = Column(String(100), nullable=False)
    framework_version = Column(String(50), nullable=True)
    framework_profile_id = Column(UUIDType, ForeignKey("framework_profiles.id", ondelete="SET NULL"), nullable=True)
    user_id = Column(UUIDType, nullable=True)

    status = Column(String(50), nullable=False, default="accepted", server_default="accepted")
    file_name = Column(String(500), nullable=True)
    file_hash = Column(String(64), nullable=True)              # SHA-256 of uploaded PDF
    blob_path = Column(String(1000), nullable=True)            # source PDF blob ref
    parsed_blob_path = Column(String(1000), nullable=True)     # parsed markdown blob ref
    raw_result_blob_path = Column(String(1000), nullable=True)       # raw extraction JSON blob ref
    canonical_result_blob_path = Column(String(1000), nullable=True) # canonical JSON blob ref
    controls_extracted = Column(Integer, nullable=False, default=0, server_default=text("0"))
    total_nodes = Column(Integer, nullable=False, default=0, server_default=text("0"))
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("ix_job_status", "status"),
        Index("ix_job_framework", "framework"),
        CheckConstraint(
            "status IN ('accepted', 'processing', 'extracting', 'completed', 'completed_empty', 'failed', 'partial')",
            name="ck_job_status",
        ),
    )
