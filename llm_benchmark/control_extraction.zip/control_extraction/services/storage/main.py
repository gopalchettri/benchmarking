"""
Storage & Aggregation Service
==============================
FastAPI service for persisting and querying extracted controls and framework profiles.

Port: 8003
Endpoints:
- /health                                         — Health check
- /api/v1/storage/{job_id}/results               — Get extraction results
- /api/v1/storage/controls/{control_id}          — Get single control
- /api/v1/storage/search                         — Search controls
- /api/v1/admin/framework-profiles               — CRUD for framework profiles
- /api/v1/admin/audit-logs                       — Query audit logs
"""

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import get_settings
from database import engine
from models import FrameworkProfileModel
from shared_core.middlewares.tracing import RequestTracingMiddleware
from shared_core.middlewares.rate_limiting import RateLimitingMiddleware
from shared_core.health import check_redis, check_database, enforce_startup_checks

# Route modules
from api.controls import router as controls_router
from api.profiles import router as profiles_router
from api.audit_logs import router as audit_logs_router
from api.jobs import router as jobs_router
from api.documents import router as documents_router

settings = get_settings()

# ── OpenTelemetry bootstrap ──
from shared_core.telemetry import setup_telemetry, instrument_fastapi
setup_telemetry(service_name=settings.APP_NAME_STORAGE)

# ── Logging Setup ──
from utils.logging_config import setup_logging
setup_logging(service_name=settings.APP_NAME_STORAGE, environment=settings.ENVIRONMENT)

# ── Intercept standard logging ──
from shared_core.intercept_handler import install_intercept_handler
install_intercept_handler(["uvicorn", "uvicorn.access", "uvicorn.error", "fastapi"])

# ── Startup health checks ──
_startup_health: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    checks = {
        "redis": check_redis(settings.REDIS_URL),
    }
    if settings.DB_BACKEND == "mysql" and settings.DATABASE_URL:
        checks["database"] = check_database(settings.DATABASE_URL)

    # Blob storage health check (non-critical)
    if settings.BLOB_BACKEND == "azure" and settings.AZURE_STORAGE_CONNECTION_STRING:
        from shared_core.health import check_azure_blob
        checks["blob_storage"] = check_azure_blob(
            settings.AZURE_STORAGE_CONNECTION_STRING,
            settings.AZURE_BLOB_CONTAINER_NAME,
        )

    _startup_health.update(
        await enforce_startup_checks(
            service_name=settings.APP_NAME_STORAGE,
            checks=checks,
            critical={"redis", "database"},
        )
    )

    # Seed predefined framework profiles (idempotent)
    if settings.DB_BACKEND == "mysql" and engine is not None:
        try:
            from seed.framework_profiles import seed_profiles
            await asyncio.to_thread(seed_profiles, engine=engine, model_class=FrameworkProfileModel, force=False)
        except Exception as e:
            logging.getLogger(__name__).error(f"Framework profile seeding failed: {e}")

    yield


app = FastAPI(title=settings.APP_NAME_STORAGE, version=settings.APP_VERSION, lifespan=lifespan)

# C-1: Use settings.CORS_ALLOWED_ORIGINS; disable credentials when wildcard
_cors_origins = settings.CORS_ALLOWED_ORIGINS
_cors_allow_credentials = "*" not in _cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=_cors_allow_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(RequestTracingMiddleware)
app.add_middleware(
    RateLimitingMiddleware,
    max_requests=settings.GLOBAL_RATE_LIMIT_MAX_REQUESTS,
    window_seconds=settings.GLOBAL_RATE_LIMIT_WINDOW_SECONDS,
)
instrument_fastapi(app)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Catch-all: ensures unhandled exceptions return JSON instead of crashing ASGI."""
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": f"{exc.status_code}: {exc.detail}"}
        )

    logging.getLogger(__name__).exception(f"Unhandled exception on {request.method} {request.url.path}")
    detail = str(exc) if settings.ENVIRONMENT != "production" else "Internal server error"
    return JSONResponse(status_code=500, content={"detail": detail})


@app.get("/health", tags=["Health"])
async def health():
    return {"service": settings.APP_NAME_STORAGE, "status": "ok", "checks": _startup_health}


# ── Register routers ──
app.include_router(controls_router)
app.include_router(profiles_router)
app.include_router(audit_logs_router)
app.include_router(jobs_router)
app.include_router(documents_router)
