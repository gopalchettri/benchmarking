"""
Storage Service — Redis Streams Worker
=======================================
Consumes messages from storage:stream and persists controls
via the database-agnostic repository port.

Also consumes audit:stream for audit log persistence.

Usage:
    python worker.py
"""

import asyncio
import io
import json
import os
import tempfile

from config import get_settings
from repositories import ExtractionPayload
from repository_factory import get_control_repo, get_audit_repo, get_blob_repo
from shared_core.stream_client import consume_stream
from shared_core.redis_client import update_job_state
from shared_core.constants import STATE_STORAGE_COMPLETED
from utils.logging_config import setup_logging, logger


settings = get_settings()
setup_logging(service_name=settings.APP_NAME_STORAGE + " Worker", environment=settings.ENVIRONMENT)

# Import async session factory (database.py handles DDL at import time)
if settings.DB_BACKEND in ("postgresql", "mysql"):
    from database import AsyncSessionLocal
    repo = get_control_repo(settings, session_maker=AsyncSessionLocal)
else:
    repo = get_control_repo(settings)

blob_repo = get_blob_repo(settings)


def _atomic_json_write(path: str, data: dict) -> None:
    """M-13: Write JSON atomically — write to temp file then os.replace to final path."""
    dir_name = os.path.dirname(path)
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
        os.replace(tmp_path, path)
    except Exception:
        # M-5: Clean up temp file on failure (Exception, not BaseException)
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


async def handle_store_controls(
    job_id: str,
    framework: str = "",
    framework_version: str = None,
    framework_profile_id: str = None,
    extractions: list = None,
    **kwargs,
):
    """
    Handler for 'store_controls' task on storage:stream.

    Receives extraction results from ai_extraction and persists them.
    """
    from shared_core.audit_client import log_audit

    logger.info(f"[Storage Worker] Received store_controls for job {job_id}, {len(extractions or [])} extractions")
    await log_audit(action="job.storage.started", entity_type="job", entity_id=job_id)

    # Ensure the parent jobs row exists before canonical_controls inserts.
    # This prevents FK failures if an earlier create/update call was skipped
    # or transiently failed upstream.
    from shared_core.job_client import create_job_record
    await create_job_record(
        job_id=job_id,
        framework=framework or "unknown",
        framework_version=framework_version or None,
        framework_profile_id=framework_profile_id or None,
    )

    if not extractions:
        logger.warning(f"[Storage Worker] No extractions for job {job_id}, skipping")
        await update_job_state(job_id, "completed_empty")
        return

    # Inject job-level fields into each extraction.
    # Uses setdefault so per-extraction overrides (if ever set) are preserved.
    llm_model = kwargs.get("llm_model")
    source_pdf_hash = kwargs.get("source_pdf_hash")
    for ex in extractions:
        if llm_model:
            ex.setdefault("llm_model", llm_model)
        if source_pdf_hash:
            ex.setdefault("source_pdf_hash", source_pdf_hash)

    payloads = [ExtractionPayload(**ex) for ex in extractions]

    # --- JSON Export ---
    # M-12: Define export_path before try block so except block can always reference it
    export_dir = getattr(settings, "OUTPUT_DIR", "./output")
    os.makedirs(export_dir, exist_ok=True)
    export_path = os.path.join(export_dir, f"{job_id}.json")

    raw_blob_path = None
    try:
        export_data = {
            "job_id": job_id,
            "framework": framework,
            "framework_version": framework_version,
            "extractions": extractions
        }
        _atomic_json_write(export_path, export_data)
        logger.info(f"[Storage Worker] Exported {len(extractions)} controls to {export_path}")

        # Upload raw JSON to blob storage
        raw_blob_path = f"{framework}/{job_id}/{job_id}_raw.json"
        raw_bytes = json.dumps(export_data, indent=2, ensure_ascii=False, default=str).encode("utf-8")
        await asyncio.to_thread(blob_repo.save_file, io.BytesIO(raw_bytes), raw_blob_path)
        logger.info(f"[Storage Worker] Uploaded raw JSON to blob: {raw_blob_path}")
    except Exception as e:
        logger.error(f"[Storage Worker] Failed to export/upload raw JSON for job {job_id}: {e}")
    # -------------------

    try:
        count = await repo.save_controls(
            job_id=job_id,
            framework=framework,
            framework_version=framework_version,
            framework_profile_id=framework_profile_id,
            extractions=payloads,
        )
        logger.info(f"[Storage Worker] Persisted {count} controls for job {job_id}")
        await update_job_state(job_id, STATE_STORAGE_COMPLETED)

        await log_audit(action="job.storage.completed", entity_type="job", entity_id=job_id, details={"controls_persisted": count})

        # --- Canonical JSON Export (post-DB) ---
        canonical_blob_path = None
        try:
            canonical_records = await repo.get_controls(job_id)
            canonical_path = os.path.join(export_dir, f"{job_id}_canonical.json")
            canonical_data = {
                "job_id": job_id,
                "framework": framework,
                "framework_version": framework_version,
                "count": len(canonical_records),
                "controls": canonical_records,
            }
            _atomic_json_write(canonical_path, canonical_data)
            logger.info(f"[Storage Worker] Canonical export: {len(canonical_records)} records → {canonical_path}")

            # Upload canonical JSON to blob storage
            canonical_blob_path = f"{framework}/{job_id}/{job_id}_canonical.json"
            canon_bytes = json.dumps(canonical_data, indent=2, ensure_ascii=False, default=str).encode("utf-8")
            await asyncio.to_thread(blob_repo.save_file, io.BytesIO(canon_bytes), canonical_blob_path)
            logger.info(f"[Storage Worker] Uploaded canonical JSON to blob: {canonical_blob_path}")
        except Exception as export_err:
            logger.error(f"[Storage Worker] Canonical JSON export failed for job {job_id}: {export_err}")
        # ----------------------------------------

        # Update persistent job record with final counts and result blob paths
        from shared_core.job_client import update_job_record
        from repositories.job_repo import count_nodes
        from datetime import datetime, timezone as tz
        total_nodes = sum(count_nodes(ex.get("sub_controls", [])) for ex in extractions)
        job_updates = dict(
            status="completed",
            controls_extracted=count,
            total_nodes=total_nodes,
            completed_at=datetime.now(tz.utc).isoformat(),
        )
        if raw_blob_path:
            job_updates["raw_result_blob_path"] = raw_blob_path
        if canonical_blob_path:
            job_updates["canonical_result_blob_path"] = canonical_blob_path
        await update_job_record(job_id, **job_updates)
    except Exception as e:
        logger.error(f"[Storage Worker] Failed to persist controls for job {job_id}: {e}")
        # M-8: Use standard state value; error detail is in the job record (line below)
        await update_job_state(job_id, "failed")
        from shared_core.job_client import update_job_record
        await update_job_record(job_id, status="failed", error_message=str(e)[:500])
        await log_audit(action="job.storage.failed", entity_type="job", entity_id=job_id, details={"error": str(e)[:500]})
        raise


# ── Audit event handler ──────────────────────────────────────────────────────

# Initialize audit repo
if settings.DB_BACKEND in ("postgresql", "mysql"):
    audit_repo = get_audit_repo(settings, session_maker=AsyncSessionLocal)
else:
    audit_repo = get_audit_repo(settings)


async def handle_audit_event(
    job_id: str = "",
    **event_data,
):
    """
    Handler for audit events on audit:stream.
    Persists audit events via AuditRepositoryPort.
    """
    try:
        details = event_data.get("details", {})
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except json.JSONDecodeError:
                details = {"raw": details}

        u_id = event_data.get("user_id")
        if not u_id:
            u_id = None

        audit_event = {
            "id": event_data.get("id", ""),
            "action": event_data.get("action", "unknown"),
            "entity_type": event_data.get("entity_type", ""),
            "entity_id": event_data.get("entity_id", ""),
            "user_id": u_id,
            "details": details,
            "created_at": event_data.get("created_at", ""),
        }
        await audit_repo.save_audit_event(audit_event)
        logger.debug(f"[Audit Worker] Persisted: {audit_event['action']}")
    except Exception as e:
        logger.error(f"[Audit Worker] Failed to persist audit event: {e}")
        # Don't re-raise — audit failures should not go to DLQ


async def main():
    logger.info("[Storage Worker] Starting Redis Streams consumers (storage + audit)")
    await asyncio.gather(
        consume_stream(
            stream=settings.STORAGE_STREAM,
            group=settings.STORAGE_GROUP,
            handlers={"store_controls": handle_store_controls},
        ),
        consume_stream(
            stream=settings.AUDIT_STREAM,
            group=settings.AUDIT_GROUP,
            handlers={"audit_event": handle_audit_event},
        ),
    )


if __name__ == "__main__":
    asyncio.run(main())
