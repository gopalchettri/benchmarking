"""
Repository Factory
==================
Selects the correct repository implementation based on DB_BACKEND setting.

Supported backends:
- postgresql: SQLAlchemy with PostgreSQL-specific optimizations (JSONB, native UUID)
- mysql: SQLAlchemy with MySQL (JSON, String UUID, case-insensitive LIKE)

Usage:
    from repository_factory import get_control_repo, get_profile_repo, get_audit_repo
    from repository_factory import get_job_repo

    control_repo = get_control_repo(settings, session_maker=AsyncSessionLocal)
    profile_repo = get_profile_repo(settings, session_maker=AsyncSessionLocal)
    audit_repo   = get_audit_repo(settings, session_maker=AsyncSessionLocal)
    job_repo     = get_job_repo(settings, session_maker=AsyncSessionLocal)
"""

from urllib.parse import quote_plus

from config import get_settings


def _get_repo(repo_name: str, settings=None, session_maker=None):
    """Internal helper to build a repo by name, following the backend dispatch pattern.

    """
    if settings is None:
        settings = get_settings()
    backend = settings.DB_BACKEND

    # Lazy imports to avoid circular dependencies and keep startup fast
    from repositories import (
        PostgresControlRepository, PostgresProfileRepository,
        MySQLControlRepository, MySQLProfileRepository,
    )
    from audit_repository import (
        PostgresAuditRepository, MySQLAuditRepository, MongoAuditRepository,
    )

    from repositories.job_repo import (
        PostgresJobRepository, MySQLJobRepository, MongoJobRepository,
    )

    _SQL_MAP = {
        "control":  (PostgresControlRepository, MySQLControlRepository),
        "profile":  (PostgresProfileRepository, MySQLProfileRepository),
        "audit":    (PostgresAuditRepository, MySQLAuditRepository),
        "job":      (PostgresJobRepository, MySQLJobRepository),
    }

    if backend in ("postgresql", "mysql"):
        if session_maker is None:
            raise ValueError(f"session_maker is required for {backend} backend")
        pg_cls, mysql_cls = _SQL_MAP[repo_name]
        cls = pg_cls if backend == "postgresql" else mysql_cls
        return cls(session_maker)
    else:
        raise ValueError(f"Unsupported DB_BACKEND: {backend}")


def get_control_repo(settings=None, session_maker=None):
    """Create a ControlRepository for the configured DB_BACKEND."""
    return _get_repo("control", settings, session_maker)


def get_profile_repo(settings=None, session_maker=None):
    """Create a ProfileRepository for the configured DB_BACKEND."""
    return _get_repo("profile", settings, session_maker)


def get_audit_repo(settings=None, session_maker=None):
    """Create an AuditRepository for the configured DB_BACKEND."""
    return _get_repo("audit", settings, session_maker)

def get_job_repo(settings=None, session_maker=None):
    """Create a JobRepository for the configured DB_BACKEND."""
    return _get_repo("job", settings, session_maker)


# ── Blob Storage Factory ──

def get_blob_repo(settings=None):
    """Create a FileStoragePort for the configured BLOB_BACKEND.

    Returns LocalBlobStorage when BLOB_BACKEND='local'.
    Returns AzureBlobStorage when BLOB_BACKEND='azure'.
    """
    if settings is None:
        settings = get_settings()
    backend = settings.BLOB_BACKEND

    if backend == "local":
        from shared_core.interfaces.storage_port import LocalBlobStorage
        return LocalBlobStorage(base_dir=settings.BLOB_STORAGE_DIR)

    if backend == "azure":
        from shared_core.interfaces.storage_port import AzureBlobStorage
        return AzureBlobStorage(
            connection_string=settings.AZURE_STORAGE_CONNECTION_STRING,
            container_name=settings.AZURE_BLOB_CONTAINER_NAME,
            connection_timeout=settings.BLOB_CONNECTION_TIMEOUT_SECONDS,
            read_timeout=settings.BLOB_READ_TIMEOUT_SECONDS,
            max_retries=settings.BLOB_MAX_RETRIES,
        )

    raise ValueError(f"Unsupported BLOB_BACKEND: {backend}")
