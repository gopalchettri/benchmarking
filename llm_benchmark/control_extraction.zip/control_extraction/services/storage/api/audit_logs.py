"""
Audit Log Endpoint
==================
Query audit logs with optional filtering.
"""

from typing import Optional

from fastapi import APIRouter, Depends

from config import get_settings
from audit_repository import AuditRepositoryPort
from api.dependencies import get_audit_repository, _MAX_PAGE_SIZE

settings = get_settings()
router = APIRouter(prefix=settings.API_V1_STR, tags=["Audit Logs"])


# H-6: Correct permission — audit_logs:read, not controls:read
@router.get("/admin/audit-logs")
async def list_audit_logs(
    action: Optional[str] = None,
    entity_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    limit: int = settings.API_DEFAULT_LIST_LIMIT,
    offset: int = 0,
    repo: AuditRepositoryPort = Depends(get_audit_repository),
):
    """Query audit logs with optional filtering."""
    # M-2: Clamp limit to prevent unbounded queries
    limit = min(max(1, limit), _MAX_PAGE_SIZE)
    offset = max(0, offset)
    logs = await repo.query_audit_logs(
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        limit=limit,
        offset=offset,
    )
    return {"audit_logs": logs, "count": len(logs)}
