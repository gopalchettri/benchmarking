"""
Shared Dependencies
===================
DI providers, UUID helpers, and constants used across all route modules.
"""

import uuid as _uuid

from fastapi import HTTPException

from config import get_settings
from database import AsyncSessionLocal
from repositories import ControlRepositoryPort, ProfileRepositoryPort
from audit_repository import AuditRepositoryPort
from shared_core.interfaces.storage_port import FileStoragePort
from repository_factory import (
    get_control_repo, get_profile_repo, get_audit_repo,
    get_job_repo,get_blob_repo,
)

settings = get_settings()

# ── Constants ──

_MAX_PAGE_SIZE = settings.API_MAX_PAGE_SIZE
_VALID_CONTROL_LAYOUTS = frozenset(settings.API_VALID_CONTROL_LAYOUTS)
_VALID_JOB_STATUSES = frozenset(settings.API_VALID_JOB_STATUSES)


# ── UUID validation ──

def _validate_uuid(v: str) -> str:
    """ Validate UUID format for request fields."""
    try:
        _uuid.UUID(v)
    except (ValueError, AttributeError):
        raise ValueError(f"Invalid UUID format: {v}")
    return v


def _require_uuid_path(value: str, param_name: str = "id") -> str:
    """ Validate UUID format on path parameters, raise 400 if invalid."""
    try:
        _uuid.UUID(value)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail=f"Invalid UUID format for {param_name}")
    return value


# ── DI providers ──

def get_control_repository() -> ControlRepositoryPort:
    return get_control_repo(settings, session_maker=AsyncSessionLocal)


def get_profile_repository() -> ProfileRepositoryPort:
    return get_profile_repo(settings, session_maker=AsyncSessionLocal)


def get_audit_repository() -> AuditRepositoryPort:
    return get_audit_repo(settings, session_maker=AsyncSessionLocal)


def get_job_repository():
    return get_job_repo(settings, session_maker=AsyncSessionLocal)


_blob_repo_instance = None


def get_blob_repository() -> FileStoragePort:
    global _blob_repo_instance
    if _blob_repo_instance is None:
        _blob_repo_instance = get_blob_repo(settings)
    return _blob_repo_instance
