"""
Document / Blob Storage Endpoints
==================================
Upload, download, list, delete, and inspect files in blob storage.
"""

import asyncio
import io
import logging
import os
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File, Query
from fastapi.responses import StreamingResponse

from config import get_settings
from shared_core.interfaces.storage_port import FileStoragePort
from shared_core.audit_client import log_audit
from api.dependencies import get_blob_repository

settings = get_settings()
router = APIRouter(prefix=settings.API_V1_STR, tags=["Documents"])


@router.post(
    "/documents/upload",
    status_code=201,
)
async def upload_document(
    request: Request,
    file: UploadFile = File(...),
    blob_prefix: Optional[str] = Query(None, description="Optional path prefix (e.g. 'iso_27001/job_123')"),
    repo: FileStoragePort = Depends(get_blob_repository),
):
    """Upload a file to blob storage."""
    content = await file.read(settings.BLOB_MAX_BYTES + 1)
    if len(content) > settings.BLOB_MAX_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File too large (max {settings.BLOB_MAX_BYTES // (1024 * 1024)} MB)",
        )

    filename = file.filename or "unnamed"
    if blob_prefix:
        target_path = f"{blob_prefix.strip('/')}/{filename}"
    else:
        target_path = filename

    file_obj = io.BytesIO(content)

    try:
        saved_path = await asyncio.to_thread(repo.save_file, file_obj, target_path)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logging.getLogger(__name__).exception(f"Upload failed for '{filename}'")
        detail = str(e) if settings.ENVIRONMENT != "production" else "Upload failed"
        raise HTTPException(status_code=500, detail=detail)

    user_id = getattr(request.state, "user_id", None)
    await log_audit(
        action="document.uploaded",
        entity_type="document",
        entity_id=saved_path,
        user_id=user_id,
        details={"size": len(content), "original_name": filename},
    )

    return {"blob_path": saved_path, "size": len(content)}


@router.get(
    "/documents/{blob_path:path}/metadata",
)
async def get_document_metadata(
    blob_path: str,
    repo: FileStoragePort = Depends(get_blob_repository),
):
    """Get metadata (size, existence) for a file in blob storage."""
    try:
        exists = await asyncio.to_thread(repo.file_exists, blob_path)
        size = 0
        if exists:
            size = await asyncio.to_thread(repo.get_file_size, blob_path)
        return {"blob_path": blob_path, "size": size, "exists": exists}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get(
    "/documents",
)
async def list_documents(
    prefix: Optional[str] = Query(None, description="Filter by blob path prefix"),
    limit: int = Query(
        settings.API_DOCUMENT_LIST_LIMIT,
        ge=1,
        le=settings.API_DOCUMENT_LIST_MAX_LIMIT,
        description="Max files to return",
    ),
    offset: int = Query(0, ge=0, description="Number of files to skip"),
    repo: FileStoragePort = Depends(get_blob_repository),
):
    """List files in blob storage, with optional prefix filter."""
    try:
        files = await asyncio.to_thread(repo.list_files, prefix or "")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    total = len(files)
    files = files[offset:offset + limit]
    return {"files": files, "count": len(files), "total": total}


@router.get(
    "/documents/download-url/{blob_path:path}",
)
async def get_download_url(
    blob_path: str,
    expiry: int = Query(
        settings.BLOB_DOWNLOAD_URL_EXPIRY_MINUTES,
        ge=1,
        le=settings.BLOB_DOWNLOAD_URL_MAX_EXPIRY_MINUTES,
        description="URL expiry in minutes (max 24h)",
    ),
    repo: FileStoragePort = Depends(get_blob_repository),
):
    """Generate a time-limited direct download URL for a blob file.

    For Azure: returns a SAS-signed URL for direct browser download.
    For local: returns a relative API path.
    """
    try:
        exists = await asyncio.to_thread(repo.file_exists, blob_path)
        if not exists:
            raise HTTPException(status_code=404, detail="File not found")
        url = await asyncio.to_thread(repo.generate_download_url, blob_path, expiry)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except HTTPException:
        raise
    except Exception as e:
        logging.getLogger(__name__).exception(f"SAS URL generation failed for '{blob_path}'")
        detail = str(e) if settings.ENVIRONMENT != "production" else "URL generation failed"
        raise HTTPException(status_code=500, detail=detail)

    return {"download_url": url, "expiry_minutes": expiry}


@router.get(
    "/documents/{blob_path:path}",
)
async def download_document(
    blob_path: str,
    repo: FileStoragePort = Depends(get_blob_repository),
):
    """Download a file from blob storage as a streaming response."""
    try:
        exists = await asyncio.to_thread(repo.file_exists, blob_path)
        if not exists:
            raise HTTPException(status_code=404, detail="File not found")
        content = await asyncio.to_thread(repo.read_file, blob_path)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logging.getLogger(__name__).exception(f"Download failed for '{blob_path}'")
        detail = str(e) if settings.ENVIRONMENT != "production" else "Download failed"
        raise HTTPException(status_code=500, detail=detail)

    ext = os.path.splitext(blob_path)[1].lower()
    media_type = settings.FILE_CONTENT_TYPE_MAP.get(ext, "application/octet-stream")
    filename = os.path.basename(blob_path)

    return StreamingResponse(
        io.BytesIO(content),
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.delete(
    "/documents/{blob_path:path}",
)
async def delete_document(
    blob_path: str,
    request: Request,
    repo: FileStoragePort = Depends(get_blob_repository),
):
    """Delete a file from blob storage."""
    try:
        deleted = await asyncio.to_thread(repo.delete_file, blob_path)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logging.getLogger(__name__).exception(f"Delete failed for '{blob_path}'")
        detail = str(e) if settings.ENVIRONMENT != "production" else "Delete failed"
        raise HTTPException(status_code=500, detail=detail)

    if not deleted:
        raise HTTPException(status_code=404, detail="File not found")

    user_id = getattr(request.state, "user_id", None)
    await log_audit(
        action="document.deleted",
        entity_type="document",
        entity_id=blob_path,
        user_id=user_id,
    )

    return {"deleted": True}
