"""
Job Endpoints
=============
Create, list, get, update extraction job records.
"""

import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator

from config import get_settings
from api.dependencies import (
    get_job_repository, _validate_uuid, _require_uuid_path,
    _MAX_PAGE_SIZE, _VALID_JOB_STATUSES,
)

settings = get_settings()
router = APIRouter(prefix=settings.API_V1_STR, tags=["Jobs"])


class JobCreateRequest(BaseModel):
    id: str
    framework: str = Field(max_length=100)
    framework_version: Optional[str] = Field(None, max_length=50)
    framework_profile_id: Optional[str] = None
    user_id: Optional[str] = None
    file_name: Optional[str] = Field(None, max_length=500)
    file_hash: Optional[str] = Field(None, max_length=64)
    blob_path: Optional[str] = Field(None, max_length=1000)

    @field_validator("id")
    @classmethod
    def check_uuid(cls, v: str) -> str:
        return _validate_uuid(v)


class JobUpdateRequest(BaseModel):
    status: Optional[str] = None
    controls_extracted: Optional[int] = Field(None, ge=0)
    total_nodes: Optional[int] = Field(None, ge=0)
    error_message: Optional[str] = Field(None, max_length=2000)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    parsed_blob_path: Optional[str] = Field(None, max_length=1000)
    raw_result_blob_path: Optional[str] = Field(None, max_length=1000)
    canonical_result_blob_path: Optional[str] = Field(None, max_length=1000)

    # M-11: Validate status against allowed values
    @field_validator("status")
    @classmethod
    def validate_status(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in _VALID_JOB_STATUSES:
            raise ValueError(f"status must be one of {_VALID_JOB_STATUSES}")
        return v


@router.post("/jobs", status_code=201)
async def create_job(
    job_data: JobCreateRequest,
    repo=Depends(get_job_repository),
):
    """Create a new extraction job record."""
    data = job_data.model_dump(exclude_none=True)
    try:
        result = await repo.create_job(data)
        return result
    except Exception as e:
        err_str = str(e).lower()
        if "integrityerror" in type(e).__name__.lower() or "duplicate" in err_str:
            raise HTTPException(status_code=409, detail="Job record already exists")
        logging.getLogger(__name__).error(f"POST /jobs failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to create job: {type(e).__name__}")


@router.get("/jobs")
async def list_jobs(
    framework: Optional[str] = None,
    status: Optional[str] = None,
    page: int = 1,
    page_size: int = settings.API_DEFAULT_JOB_PAGE_SIZE,
    repo=Depends(get_job_repository),
):
    """List extraction jobs with optional filters and pagination."""
    # H-7: Clamp page_size to max; M-4: floor page to 1
    page = max(1, page)
    page_size = min(max(1, page_size), _MAX_PAGE_SIZE)
    offset = (page - 1) * page_size
    jobs, total = await repo.list_jobs(
        framework=framework,
        status=status,
        limit=page_size,
        offset=offset,
    )
    return {"jobs": jobs, "total": total, "page": page, "page_size": page_size}


@router.get("/jobs/{job_id}")
async def get_job(
    job_id: str,
    repo=Depends(get_job_repository),
):
    """Get a single extraction job by ID."""
    _require_uuid_path(job_id, "job_id")
    job = await repo.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.patch("/jobs/{job_id}")
async def update_job(
    job_id: str,
    updates: JobUpdateRequest,
    repo=Depends(get_job_repository),
):
    """Update job status and counts (used by pipeline workers)."""
    _require_uuid_path(job_id, "job_id")
    data = updates.model_dump(exclude_none=True)
    if not data:
        raise HTTPException(status_code=400, detail="No fields to update")
    try:
        result = await repo.update_job(job_id, data)
    except Exception as e:
        logging.getLogger(__name__).error(
            f"PATCH /jobs/{job_id} failed with payload keys={list(data.keys())}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to update job: {type(e).__name__}",
        )
    if not result:
        raise HTTPException(status_code=404, detail="Job not found")
    return result
