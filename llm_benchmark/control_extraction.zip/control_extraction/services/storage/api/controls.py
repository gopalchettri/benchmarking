"""
Control Endpoints
=================
GET results, GET single control, GET search, POST merge (legacy).
"""

import json
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form

from config import get_settings
from repositories import ControlRepositoryPort, ExtractionPayload
from api.dependencies import get_control_repository, _require_uuid_path, _MAX_PAGE_SIZE

settings = get_settings()
router = APIRouter(prefix=settings.API_V1_STR, tags=["Controls"])


@router.get("/storage/{job_id}/results")
async def get_results(
    job_id: str,
    limit: int = settings.API_DEFAULT_LIST_LIMIT,
    offset: int = 0,
    repo: ControlRepositoryPort = Depends(get_control_repository),
):
    """Get extraction results for a job."""
    _require_uuid_path(job_id, "job_id")
    # M-3: Clamp limit to prevent unbounded queries
    limit = min(max(1, limit), _MAX_PAGE_SIZE)
    offset = max(0, offset)
    controls = await repo.get_controls(job_id=job_id, limit=limit, offset=offset)
    return {"job_id": job_id, "count": len(controls), "controls": controls}


@router.get("/storage/controls/{control_id}")
async def get_control(
    control_id: str,
    repo: ControlRepositoryPort = Depends(get_control_repository),
):
    """Get a single control by ID."""
    _require_uuid_path(control_id, "control_id")
    control = await repo.get_control_by_id(control_id=control_id)
    if not control:
        raise HTTPException(status_code=404, detail="Control not found")
    return control


# M-15: Add limit and offset query params to search endpoint
@router.get("/storage/search")
async def search_controls(
    framework: Optional[str] = None,
    query: Optional[str] = None,
    limit: int = settings.API_DEFAULT_SEARCH_LIMIT,
    offset: int = 0,
    repo: ControlRepositoryPort = Depends(get_control_repository),
):
    """Search controls with optional text filter."""
    # M-1: Clamp limit to prevent unbounded queries
    limit = min(max(1, limit), _MAX_PAGE_SIZE)
    offset = max(0, offset)
    results = await repo.search_controls(
        framework=framework, query=query,
        limit=limit, offset=offset,
    )
    return {"count": len(results), "controls": results}


@router.post("/storage/{job_id}/merge")
async def merge_extractions(
    job_id: str,
    framework: str = Form(""),
    framework_version: str = Form(""),
    framework_profile_id: str = Form(""),
    file: UploadFile = File(...),
    repo: ControlRepositoryPort = Depends(get_control_repository),
):
    """
    Legacy HTTP merge endpoint. Accepts a JSON file of extractions.
    Prefer the Redis Stream (storage:stream) path for production workloads.
    """
    _require_uuid_path(job_id, "job_id")
    try:
        # Enforce upload size limit to prevent OOM
        max_upload_bytes = settings.API_MERGE_UPLOAD_MAX_BYTES
        content = await file.read(max_upload_bytes + 1)
        if len(content) > max_upload_bytes:
            max_mb = max_upload_bytes / (1024 * 1024)
            raise HTTPException(status_code=413, detail=f"File too large (max {max_mb:.0f} MB)")
        extractions = json.loads(content)
        payloads = [ExtractionPayload(**ex) for ex in extractions]

        count = await repo.save_controls(
            job_id=job_id,
            framework=framework,
            framework_version=framework_version,
            framework_profile_id=framework_profile_id,
            extractions=payloads,
        )
        return {"job_id": job_id, "controls_saved": count}
    except Exception as e:
        if settings.ENVIRONMENT == "production":
            raise HTTPException(status_code=500, detail="Internal server error")
        raise HTTPException(status_code=500, detail=str(e))
