"""
Database Setup
==============
Engine creation, session factory, auto-create DB, extensions, schema migrations.

Requires MySQL 8.0.16+ (for CHECK constraint support) or PostgreSQL 12+.

Exports:
    async_engine     — SQLAlchemy async engine for runtime queries (None for MongoDB)
    AsyncSessionLocal — async sessionmaker for runtime sessions (None for MongoDB)
    engine           — SQLAlchemy sync engine for startup DDL only (None for MongoDB)
"""

import logging
import re

from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

from config import get_settings
from models import Base

settings = get_settings()
_log = logging.getLogger(__name__)

_IDENT_RE = re.compile(r'^[a-zA-Z0-9_]+$')


def _validate_identifier(name: str, kind: str = "identifier"):
    """Reject identifiers that could break out of backtick/double-quote quoting."""
    if not _IDENT_RE.match(name):
        raise ValueError(f"Invalid SQL {kind}: {name!r}")


def _to_sync_url(url: str) -> str:
    """Convert an async driver URL to its sync equivalent for startup DDL."""
    return (url
            .replace("mysql+asyncmy://", "mysql+pymysql://")
            .replace("postgresql+asyncpg://", "postgresql+psycopg2://"))


# ── MySQL idempotent migration helpers ──
# MySQL lacks ADD/DROP COLUMN IF [NOT] EXISTS, so we check information_schema first.

def _mysql_column_exists(conn, table: str, column: str) -> bool:
    return conn.execute(text(
        "SELECT 1 FROM information_schema.COLUMNS "
        "WHERE TABLE_SCHEMA = DATABASE() "
        "AND TABLE_NAME = :table AND COLUMN_NAME = :column"
    ), {"table": table, "column": column}).scalar() is not None


def _mysql_check_constraint_exists(conn, table: str, constraint: str) -> bool:
    """Check if a CHECK constraint exists (MySQL 8.0.16+)."""
    return conn.execute(text(
        "SELECT 1 FROM information_schema.TABLE_CONSTRAINTS "
        "WHERE TABLE_SCHEMA = DATABASE() "
        "AND TABLE_NAME = :table AND CONSTRAINT_NAME = :constraint "
        "AND CONSTRAINT_TYPE = 'CHECK'"
    ), {"table": table, "constraint": constraint}).scalar() is not None


_ALLOWED_COL_TYPES = re.compile(
    r'^(VARCHAR\(\d+\)|TEXT|INT|INTEGER|BIGINT|FLOAT|DOUBLE|BOOLEAN|'
    r'DATETIME(\(\d\))?|TIMESTAMP(\(\d\))?|DATE|JSON|BLOB)$', re.IGNORECASE
)


def _mysql_add_column(conn, table: str, column: str, col_type: str,
                      nullable: bool = True, default: str = None):
    """Idempotent ADD COLUMN for MySQL. `default` must be a raw SQL literal (e.g. "'value'")."""
    _validate_identifier(table, "table")
    _validate_identifier(column, "column")
    if not _ALLOWED_COL_TYPES.match(col_type):
        raise ValueError(f"Disallowed column type: {col_type}")
    if _mysql_column_exists(conn, table, column):
        return
    null_clause = "" if nullable else " NOT NULL"
    default_clause = f" DEFAULT {default}" if default is not None else ""
    conn.execute(text(
        f"ALTER TABLE `{table}` ADD COLUMN `{column}` {col_type}{null_clause}{default_clause}"
    ))


def _mysql_drop_column(conn, table: str, column: str):
    """Idempotent DROP COLUMN for MySQL."""
    _validate_identifier(table, "table")
    _validate_identifier(column, "column")
    if not _mysql_column_exists(conn, table, column):
        return
    conn.execute(text(f"ALTER TABLE `{table}` DROP COLUMN `{column}`"))


def _mysql_drop_check_constraint(conn, table: str, constraint: str):
    """Idempotent DROP CHECK constraint for MySQL 8.0.16+."""
    _validate_identifier(table, "table")
    _validate_identifier(constraint, "constraint")
    if not _mysql_check_constraint_exists(conn, table, constraint):
        return
    conn.execute(text(f"ALTER TABLE `{table}` DROP CHECK `{constraint}`"))


# ── Engine & Session Factory ──

engine = None           # sync engine for startup DDL (auto-create, create_all, migrations)
async_engine = None     # async engine for runtime queries
AsyncSessionLocal = None

if settings.DB_BACKEND in ("postgresql", "mysql"):
    # Sync engine for startup DDL (uses pymysql for MySQL)
    sync_url = _to_sync_url(settings.DATABASE_URL)
    engine_kwargs = {"pool_pre_ping": True}
    if settings.DB_BACKEND == "mysql":
        engine_kwargs["pool_recycle"] = settings.DB_POOL_RECYCLE_SECONDS

    # Auto-create PostgreSQL database if it doesn't exist
    if settings.DB_BACKEND == "postgresql":
        temp_engine = None
        try:
            url_obj = make_url(sync_url)
            db_name = url_obj.database
            if not db_name:
                raise ValueError("DATABASE_URL does not contain a database name")

            safe_name = re.sub(r'[^a-zA-Z0-9_]', '', db_name)
            if not safe_name:
                raise ValueError(f"Database name '{db_name}' sanitizes to empty string")
            if safe_name != db_name:
                _log.warning(f"Database name sanitized: '{db_name}' -> '{safe_name}'")

            temp_url = url_obj.set(database="postgres").render_as_string(hide_password=False)
            temp_engine = create_engine(temp_url, isolation_level="AUTOCOMMIT")

            with temp_engine.connect() as conn:
                existing_db = conn.execute(
                    text("SELECT 1 FROM pg_database WHERE datname = :dbname"),
                    {"dbname": db_name},
                ).scalar()
                if not existing_db:
                    conn.execute(text(f'CREATE DATABASE "{safe_name}"'))
                    _log.info(f"Auto-created PostgreSQL database: {safe_name}")
        except Exception as e:
            _log.warning(f"Failed to auto-create database: {e}")
        finally:
            if temp_engine is not None:
                temp_engine.dispose()

    # Auto-create MySQL database if it doesn't exist
    elif settings.DB_BACKEND == "mysql":
        temp_engine = None
        try:
            url_obj = make_url(sync_url)
            db_name = url_obj.database
            if not db_name:
                raise ValueError("DATABASE_URL does not contain a database name")

            safe_name = re.sub(r'[^a-zA-Z0-9_]', '', db_name)
            if not safe_name:
                raise ValueError(f"Database name '{db_name}' sanitizes to empty string")
            if safe_name != db_name:
                _log.warning(f"Database name sanitized: '{db_name}' -> '{safe_name}'")

            temp_url = url_obj.set(database="").render_as_string(hide_password=False)
            temp_engine = create_engine(temp_url, isolation_level="AUTOCOMMIT")

            with temp_engine.connect() as conn:
                conn.execute(text(
                    f"CREATE DATABASE IF NOT EXISTS `{safe_name}` "
                    f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
                ))
                _log.info(f"Ensured MySQL database exists: {safe_name}")
        except Exception as e:
            _log.warning(f"Failed to auto-create MySQL database: {e}")
        finally:
            if temp_engine is not None:
                temp_engine.dispose()

    # Sync engine for DDL (create_all, migrations)
    engine = create_engine(sync_url, **engine_kwargs)

    # Async engine for runtime queries
    async_engine_kwargs = {"pool_pre_ping": True}
    if settings.DB_BACKEND == "mysql":
        async_engine_kwargs["pool_recycle"] = settings.DB_POOL_RECYCLE_SECONDS
    async_engine = create_async_engine(settings.DATABASE_URL, **async_engine_kwargs)
    AsyncSessionLocal = async_sessionmaker(async_engine, expire_on_commit=False)

    try:
        # Create necessary PostgreSQL extensions BEFORE creating tables
        if settings.DB_BACKEND == "postgresql":
            with engine.connect() as conn:
                conn.execute(text("CREATE EXTENSION IF NOT EXISTS pg_trgm;"))
                conn.commit()

        Base.metadata.create_all(bind=engine)

        # Idempotent schema migrations for existing DBs.
        # Destructive cleanup is gated by config so production startup does not
        # silently drop legacy columns/tables unless an operator explicitly opts in.
        destructive_cleanup_enabled = settings.ENABLE_DESTRUCTIVE_SCHEMA_CLEANUP
        if settings.DB_BACKEND == "postgresql":
            _schema_migrations = [
                # canonical_controls
                "ALTER TABLE canonical_controls ADD COLUMN IF NOT EXISTS extraction_status VARCHAR(20) NOT NULL DEFAULT 'machine_draft';",
                "ALTER TABLE canonical_controls ADD COLUMN IF NOT EXISTS verified_by VARCHAR(36);",
                "ALTER TABLE canonical_controls ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;",
                "ALTER TABLE canonical_controls ADD COLUMN IF NOT EXISTS llm_model VARCHAR(100);",
                "ALTER TABLE canonical_controls ADD COLUMN IF NOT EXISTS source_pdf_hash VARCHAR(64);",
                # framework_profiles — add new columns
                "ALTER TABLE framework_profiles ADD COLUMN IF NOT EXISTS control_layout VARCHAR(20);",
                # Rename upload_id -> job_id in canonical_controls (v2 schema cleanup)
                """DO $$ BEGIN
                    IF EXISTS (SELECT 1 FROM information_schema.columns
                               WHERE table_name='canonical_controls' AND column_name='upload_id') THEN
                        ALTER TABLE canonical_controls RENAME COLUMN upload_id TO job_id;
                    END IF;
                END $$;""",
                # Add blob path columns to jobs table
                "ALTER TABLE jobs ADD COLUMN IF NOT EXISTS blob_path VARCHAR(1000);",
                "ALTER TABLE jobs ADD COLUMN IF NOT EXISTS parsed_blob_path VARCHAR(1000);",
                # Add FK from canonical_controls.job_id -> jobs.id (CASCADE)
                """DO $$ BEGIN
                    IF NOT EXISTS (
                        SELECT 1 FROM information_schema.table_constraints
                        WHERE constraint_name = 'fk_control_job_id'
                          AND table_name = 'canonical_controls'
                    ) THEN
                        ALTER TABLE canonical_controls
                            ADD CONSTRAINT fk_control_job_id
                            FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE;
                    END IF;
                END $$;""",
            ]
            _destructive_schema_migrations = [
                "ALTER TABLE canonical_controls DROP CONSTRAINT IF EXISTS ck_control_type;",
                "ALTER TABLE canonical_controls DROP COLUMN IF EXISTS control_type;",
                "ALTER TABLE canonical_controls DROP COLUMN IF EXISTS category;",
                "ALTER TABLE canonical_controls DROP COLUMN IF EXISTS is_synthetic;",
                "ALTER TABLE canonical_controls DROP COLUMN IF EXISTS tenant_id;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS control_id_pattern;",
                # framework_profiles — drop old columns
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS domain;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS region;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS lifecycle;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS domain_constraint;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS control_id_example;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS hierarchy_definition;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS expected_control_count;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS expected_control_range;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS expected_toc_range;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS max_hierarchy_depth;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS numbering_scheme;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS taxonomy_terms;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS toc_detection_hints;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS annex_markers;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS skip_sections;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS title_keywords;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS structural_signature;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS xlsx_column_mapping;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS is_global;",
                "ALTER TABLE framework_profiles DROP COLUMN IF EXISTS tenant_id;",
                # Drop old tenants-related tables and columns
                "ALTER TABLE jobs DROP COLUMN IF EXISTS tenant_id;",
                "ALTER TABLE audit_logs DROP COLUMN IF EXISTS tenant_id;",
                "DROP TABLE IF EXISTS user_tenant_roles;",
                "DROP TABLE IF EXISTS tenants;",
                # Drop unused RBAC auth tables (order matters: FKs first)
                "ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_user_id_fkey;",
                "DROP TABLE IF EXISTS user_roles;",
                "DROP TABLE IF EXISTS role_permissions;",
                "DROP TABLE IF EXISTS permissions;",
                "DROP TABLE IF EXISTS roles;",
                "DROP TABLE IF EXISTS users;",
            ]
            if destructive_cleanup_enabled:
                _schema_migrations.extend(_destructive_schema_migrations)
            else:
                _log.info("Destructive PostgreSQL schema cleanup disabled by configuration")
            with engine.begin() as conn:
                for stmt in _schema_migrations:
                    conn.execute(text(stmt))
            _log.info("Schema migrations applied successfully")

        elif settings.DB_BACKEND == "mysql":
            with engine.begin() as conn:
                # canonical_controls — add new columns
                _mysql_add_column(conn, "canonical_controls", "extraction_status",
                                  "VARCHAR(20)", nullable=False, default="'machine_draft'")
                _mysql_add_column(conn, "canonical_controls", "verified_by",
                                  "VARCHAR(36)")
                _mysql_add_column(conn, "canonical_controls", "verified_at",
                                  "DATETIME(6)")
                _mysql_add_column(conn, "canonical_controls", "llm_model",
                                  "VARCHAR(100)")
                _mysql_add_column(conn, "canonical_controls", "source_pdf_hash",
                                  "VARCHAR(64)")

                # framework_profiles — add new columns
                _mysql_add_column(conn, "framework_profiles", "control_layout",
                                  "VARCHAR(20)")

                # Rename upload_id -> job_id in canonical_controls (v2 schema cleanup)
                if _mysql_column_exists(conn, "canonical_controls", "upload_id"):
                    conn.execute(text(
                        "ALTER TABLE `canonical_controls` "
                        "RENAME COLUMN `upload_id` TO `job_id`"
                    ))

                if destructive_cleanup_enabled:
                    # canonical_controls — drop old constraint + columns
                    _mysql_drop_check_constraint(conn, "canonical_controls", "ck_control_type")
                    _mysql_drop_column(conn, "canonical_controls", "control_type")
                    _mysql_drop_column(conn, "canonical_controls", "category")
                    _mysql_drop_column(conn, "canonical_controls", "is_synthetic")
                    _mysql_drop_column(conn, "canonical_controls", "tenant_id")

                    _mysql_drop_column(conn, "framework_profiles", "control_id_pattern")
                    for col in (
                        "domain", "region", "lifecycle", "domain_constraint",
                        "control_id_example", "hierarchy_definition",
                        "expected_control_count", "expected_control_range",
                        "expected_toc_range", "max_hierarchy_depth",
                        "numbering_scheme", "taxonomy_terms",
                        "toc_detection_hints", "annex_markers",
                        "skip_sections", "title_keywords",
                        "structural_signature", "xlsx_column_mapping",
                        "is_global", "tenant_id",
                    ):
                        _mysql_drop_column(conn, "framework_profiles", col)

                    # Drop old tenants-related columns and tables
                    _mysql_drop_column(conn, "jobs", "tenant_id")
                    _mysql_drop_column(conn, "audit_logs", "tenant_id")
                    conn.execute(text("DROP TABLE IF EXISTS `user_tenant_roles`"))
                    conn.execute(text("DROP TABLE IF EXISTS `tenants`"))

                    # Drop unused RBAC auth tables (order matters: FKs first)
                    _fk_rows = conn.execute(text(
                        "SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE "
                        "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'jobs' "
                        "AND COLUMN_NAME = 'user_id' AND REFERENCED_TABLE_NAME = 'users'"
                    )).fetchall()
                    for row in _fk_rows:
                        conn.execute(text(f"ALTER TABLE `jobs` DROP FOREIGN KEY `{row[0]}`"))
                else:
                    _log.info("Destructive MySQL schema cleanup disabled by configuration")

                # Add blob path columns to jobs table
                _mysql_add_column(conn, "jobs", "blob_path", "VARCHAR(1000)")
                _mysql_add_column(conn, "jobs", "parsed_blob_path", "VARCHAR(1000)")
                _mysql_add_column(conn, "jobs", "raw_result_blob_path", "VARCHAR(1000)")
                _mysql_add_column(conn, "jobs", "canonical_result_blob_path", "VARCHAR(1000)")

                # Add FK from canonical_controls.job_id -> jobs.id (CASCADE)
                fk_exists = conn.execute(text(
                    "SELECT 1 FROM information_schema.TABLE_CONSTRAINTS "
                    "WHERE TABLE_SCHEMA = DATABASE() "
                    "AND TABLE_NAME = 'canonical_controls' "
                    "AND CONSTRAINT_NAME = 'fk_control_job_id'"
                )).scalar()
                if not fk_exists:
                    try:
                        conn.execute(text(
                            "ALTER TABLE `canonical_controls` "
                            "ADD CONSTRAINT `fk_control_job_id` "
                            "FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON DELETE CASCADE"
                        ))
                    except Exception as fk_err:
                        _log.warning(f"Could not add job_id FK (orphan rows may exist): {fk_err}")

            _log.info("MySQL schema migrations applied successfully")

    except Exception as e:
        _log.error(f"Table creation skipped/failed: {e}")
