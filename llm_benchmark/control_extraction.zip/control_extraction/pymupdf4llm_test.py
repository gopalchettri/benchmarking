"""
Manual pymupdf4llm markdown test utility.

Usage:
    py pymupdf4llm_test.py
    py pymupdf4llm_test.py path/to/file.pdf
    py pymupdf4llm_test.py path/to/file.pdf --preview-chars 2000

What it does:
    - extracts the PDF with pymupdf4llm in markdown mode
    - writes one combined markdown file with page markers
    - prints a short summary to the console
"""

from __future__ import annotations

import argparse
from pathlib import Path

import fitz
import pymupdf4llm


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Manually test pymupdf4llm markdown output.")
    parser.add_argument(
        "pdf",
        nargs="?",
        default=r"C:\Users\User\Documents\Development\control_extraction\frameworks\SAMA.pdf",
        help="Path to the PDF file",
    )
    parser.add_argument(
        "--preview-chars",
        type=int,
        default=1200,
        help="How many characters of the combined markdown preview to print",
    )
    parser.add_argument(
        "--no-layout",
        action="store_true",
        help="Disable pymupdf_layout even if it is installed",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    pdf_path = Path(args.pdf).resolve()
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    with fitz.open(pdf_path) as doc:
        if doc.is_encrypted:
            raise ValueError("PDF is password-protected. Provide an unencrypted PDF.")
        page_count = len(doc)

    layout_enabled = False
    layout_status = "disabled by flag" if args.no_layout else "not available"
    if not args.no_layout:
        try:
            import pymupdf.layout  # noqa: F401
            layout_enabled = True
            layout_status = "enabled"
        except ImportError:
            layout_status = "not installed"

    output_dir = Path(r"C:\Users\User\Documents\Development\control_extraction")
    output_dir.mkdir(parents=True, exist_ok=True)

    chunks = pymupdf4llm.to_markdown(str(pdf_path), page_chunks=True)
    page_map = {i + 1: chunk.get("text", "") for i, chunk in enumerate(chunks)}
    missing_pages = [pg for pg in range(1, page_count + 1) if pg not in page_map]

    combined_path = output_dir / f"{pdf_path.stem}_pymupdf4llm.md"
    total_chars = 0
    with combined_path.open("w", encoding="utf-8") as combined:
        for pg in range(1, page_count + 1):
            text = page_map.get(pg, "")
            stripped = text.strip()
            total_chars += len(stripped)
            if stripped:
                combined.write(f"{text}\n\n<!-- page={pg}/{page_count} -->\n\n")

    combined_text = combined_path.read_text(encoding="utf-8")

    print(f"PDF: {pdf_path}")
    print(f"Expected pages: {page_count}")
    print(f"pymupdf_layout: {layout_status}")
    print(f"pymupdf4llm pages: {len(page_map)}")
    print(f"Missing pages: {missing_pages if missing_pages else 'none'}")
    print(f"Combined markdown: {combined_path}")
    print(f"Total extracted chars: {total_chars:,}")
    print()
    print("Preview:")
    print("-" * 80)
    print(combined_text[: args.preview_chars])
    print("-" * 80)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
