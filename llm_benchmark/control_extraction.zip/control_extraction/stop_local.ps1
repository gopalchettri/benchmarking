# ============================================================
# Control Extraction - Local Stop Script
# Run from project root:
#   .\stop_local.ps1
# ============================================================

function Write-Header($msg) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

# ============================================================
# STEP 1 - Kill PowerShell host windows (spawned by run_local.ps1)
# ============================================================
Write-Header "STEP 1: Closing Service Terminal Windows"

$hostProcs = Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe' OR Name = 'pwsh.exe'" -ErrorAction SilentlyContinue
$closedWindows = 0

if ($hostProcs) {
    foreach ($proc in $hostProcs) {
        if ($proc.CommandLine -and $proc.ProcessId -ne $PID) {
            if ($proc.CommandLine -match "uvicorn main:app" -or $proc.CommandLine -match "worker\.py") {
                Write-Host "  [Window] Closing PID $($proc.ProcessId) ..." -ForegroundColor Yellow -NoNewline
                taskkill /F /T /PID $($proc.ProcessId) 2>&1 | Out-Null
                Write-Host " closed." -ForegroundColor Green
                $closedWindows++
            }
        }
    }
}

if ($closedWindows -eq 0) {
    Write-Host "  No service terminal windows found." -ForegroundColor Gray
}
else {
    Write-Host "  Closed $closedWindows terminal window(s)." -ForegroundColor Green
}

# ============================================================
# STEP 2 - Kill orphan processes on service ports (cleanup)
# ============================================================
Write-Header "STEP 2: Cleaning Up Service Ports"

$ports = @(8000, 8001, 8002, 8003)
$killedOrphans = 0

foreach ($port in $ports) {
    $tcpConnections = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if ($tcpConnections) {
        foreach ($conn in $tcpConnections) {
            if ($conn.OwningProcess -ne 0) {
                Write-Host "  [Port $port] Terminating orphan process $($conn.OwningProcess)..." -ForegroundColor Yellow
                Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
                $killedOrphans++
            }
        }
    }
    else {
        Write-Host "  [Port $port] Clear." -ForegroundColor Gray
    }
}

# ============================================================
# STEP 3 - Kill orphan worker processes (not bound to a port)
# ============================================================
Write-Header "STEP 3: Cleaning Up Worker Processes"

$pythonProcs = Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" -ErrorAction SilentlyContinue
$killedWorkers = 0

if ($pythonProcs) {
    foreach ($proc in $pythonProcs) {
        if ($proc.CommandLine -and ($proc.CommandLine -match "worker\.py" -or $proc.CommandLine -match "uvicorn")) {
            Write-Host "  [Worker/Uvicorn] Terminating PID $($proc.ProcessId)..." -ForegroundColor Yellow
            taskkill /F /T /PID $($proc.ProcessId) 2>&1 | Out-Null
            $killedWorkers++
        }
    }
}

if ($killedWorkers -eq 0) {
    Write-Host "  No orphan worker processes found." -ForegroundColor Gray
}
else {
    Write-Host "  Terminated $killedWorkers worker process(es)." -ForegroundColor Green
}

# ============================================================
# Done
# ============================================================
Write-Header "All services stopped!"
Write-Host "  Summary: $closedWindows windows closed, $($killedOrphans + $killedWorkers) orphan processes cleaned up." -ForegroundColor White
Write-Host ""
