"""
Configuration Module (Global)
=============================

Reads settings from .env file with search-order resolution:
  1. CLI --env-file argument
  2. DOTENV_PATH environment variable
  3. Parent directory search (up to 3 levels)

Uses pydantic-settings for validation and type coercion.
Thread-safe singleton pattern ensures all services share the same config.
"""

import os
import threading
import warnings
from pathlib import Path
from typing import Dict, List, Literal, Optional, Union
from urllib.parse import quote_plus

from pydantic import model_validator
from pydantic_settings import BaseSettings

# ── Auto-Scaling Ratios ─────────────────────────────────────────────────────
_AUTO_SUBCONTROL_RATIO = 0.128
_AUTO_MAX_OUTPUT_RATIO = 0.125
_AUTO_TOC_RATIO = 0.032
_AUTO_DISCOVERY_RATIO = 0.016
_MIN_CONTENT_BUDGET = 5000


class Settings(BaseSettings):
    """Application settings — all configurable via .env or environment variables."""

    # --- App Metadata ---
    APP_NAME_GATEWAY: str = "API Gateway / Orchestrator"
    APP_NAME_DOC_PROCESSING: str = "Document Processing Service"
    APP_NAME_AI_EXTRACTION: str = "AI Extraction Service"
    APP_NAME_STORAGE: str = "Storage & Aggregation Service"
    APP_VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: Literal["development", "production"] = "development"
    LOG_LEVEL: str = "INFO"

    # --- Infrastructure URLs ---
    DOC_SERVICE_URL: str = "http://localhost:8001"
    AI_SERVICE_URL: str = "http://localhost:8002"
    STORAGE_SERVICE_URL: str = "http://localhost:8003"
    
    # Blob storage configuration.
    # BLOB_BACKEND is the canonical selector. USE_AZURE_STORAGE is kept for
    # backward compatibility and is normalized to stay in sync automatically.
    # BLOB_MAX_BYTES and MAX_FILE_UPLOAD_BYTES should usually stay aligned.
    BLOB_BACKEND: Literal["local", "azure"] = "local"
    BLOB_STORAGE_DIR: str = "./storage"
    BLOB_MAX_BYTES: int = 100 * 1024 * 1024
    BLOB_CONNECTION_TIMEOUT_SECONDS: int = 15
    BLOB_READ_TIMEOUT_SECONDS: int = 120
    BLOB_MAX_RETRIES: int = 3
    BLOB_DOWNLOAD_URL_EXPIRY_MINUTES: int = 30
    BLOB_DOWNLOAD_URL_MAX_EXPIRY_MINUTES: int = 1440
    USE_AZURE_STORAGE: bool = False
    AZURE_STORAGE_CONNECTION_STRING: Optional[str] = None
    AZURE_BLOB_CONTAINER_NAME: str = "uaeccpm"
    FILE_CONTENT_TYPE_MAP: Dict[str, str] = {
        ".pdf": "application/pdf",
        ".json": "application/json",
        ".md": "text/markdown",
        ".txt": "text/plain",
        ".log": "text/plain",
        ".csv": "text/csv",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }

    # --- Local Dev Toggles ---
    USE_LOCAL_REDIS: bool = False
    LOCAL_REDIS_URL: str = "redis://localhost:6379/0"
    USE_LOCAL_DB: bool = False
    LOCAL_MYSQL_HOST: str = "localhost"
    LOCAL_MYSQL_PORT: int = 3306
    LOCAL_MYSQL_USER: str = "root"
    LOCAL_MYSQL_PASSWORD: str = ""

    # --- Redis ---
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_PASSWORD: Optional[str] = None
    REDIS_CLUSTER_MODE: bool = False
    REDIS_SSL_CERT_REQS: str = "none"
    REDIS_JOB_STATE_TTL_SECONDS: int = 86400
    REDIS_CLUSTER_MAX_CONNECTIONS: int = 50
    REDIS_STANDALONE_MAX_CONNECTIONS: int = 20
    REDIS_HEALTH_CHECK_INTERVAL_SECONDS: int = 30
    REDIS_STREAM_BATCH_SIZE: int = 10
    REDIS_STREAM_BLOCK_MS: int = 2000
    REDIS_STREAM_BACKOFF_INITIAL_SECONDS: float = 2.0
    REDIS_STREAM_BACKOFF_MAX_SECONDS: float = 60.0
    REDIS_STREAM_NOGROUP_LOG_INTERVAL_SECONDS: float = 60.0
    REDIS_PING_TIMEOUT_SECONDS: int = 3

    DOC_PROCESSING_STREAM: str = "doc_processing:stream"
    DOC_PROCESSING_GROUP: str = "doc_workers"
    AI_EXTRACTION_STREAM: str = "ai_extraction:stream"
    AI_EXTRACTION_GROUP: str = "ai_workers"
    STORAGE_STREAM: str = "storage:stream"
    STORAGE_GROUP: str = "storage_workers"
    AUDIT_STREAM: str = "audit:stream"
    AUDIT_GROUP: str = "audit_workers"

    # --- Database (MySQL/PostgreSQL/MSSQL) ---
    DB_BACKEND: Literal["postgresql", "mongodb", "mysql", "mssql"] = "mysql"
    DATABASE_URL: str = "" # Assembled by validator
    ENABLE_DESTRUCTIVE_SCHEMA_CLEANUP: bool = False
    MYSQL_USER: str = "root"
    MYSQL_PASSWORD: str = ""
    MYSQL_DB: str = "uaeccpm"
    MYSQL_HOST: str = "localhost"
    MYSQL_PORT: int = 3306
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "pass"
    POSTGRES_DB: str = "ccpm"
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    MONGODB_URL: Optional[str] = None
    MONGODB_DB_NAME: str = "ccpm"
    DB_POOL_RECYCLE_SECONDS: int = 3600

    # --- HTTP / Inter-service Communication ---
    DOWNSTREAM_HTTP_TIMEOUT_SECONDS: float = 30.0
    JOB_CLIENT_TIMEOUT_SECONDS: float = 10.0
    JOB_CLIENT_CREATE_MAX_RETRIES: int = 3
    JOB_CLIENT_RETRY_BASE_DELAY_SECONDS: float = 1.0
    ALERT_WEBHOOK_TIMEOUT_SECONDS: float = 10.0
    API_MAX_PAGE_SIZE: int = 100
    API_DEFAULT_LIST_LIMIT: int = 100
    API_DEFAULT_SEARCH_LIMIT: int = 500
    API_DEFAULT_JOB_PAGE_SIZE: int = 20
    API_DOCUMENT_LIST_LIMIT: int = 100
    API_DOCUMENT_LIST_MAX_LIMIT: int = 1000
    API_MERGE_UPLOAD_MAX_BYTES: int = 10 * 1024 * 1024
    API_VALID_CONTROL_LAYOUTS: List[str] = ["toc_body", "annex", "matrix"]
    API_VALID_JOB_STATUSES: List[str] = [
        "accepted",
        "processing",
        "extracting",
        "completed",
        "completed_empty",
        "failed",
        "partial",
    ]
    PROFILE_DOMAIN_MAPPING_MAX_ENTRIES: int = 200
    REPOSITORY_DEFAULT_CONTROL_LIMIT: int = 5000
    REPOSITORY_DEFAULT_SEARCH_LIMIT: int = 500
    DEFAULT_JOB_STATUS: str = "accepted"

    # --- LLM Provider ---
    LLM_PROVIDER: Literal["azure", "ollama"] = "azure"
    LLM_MODEL_CONTEXT_TOKENS: int = 128000
    LLM_MAX_OUTPUT_TOKENS: int = 0
    LLM_TEMPERATURE: float = 1.0
    LLM_REQUEST_TIMEOUT_SECONDS: int = 900
    LLM_REASONING_EFFORT: Literal["none", "minimal", "low", "medium", "high"] = "low"
    LLM_ENABLE_WARMUP: bool = True
    LLM_RETRY_MAX_RETRIES: int = 2
    LLM_RETRY_BASE_WAIT_SECONDS: float = 5.0
    LLM_RETRY_BACKOFF_FACTOR: float = 2.0

    # Azure OpenAI
    AZURE_OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_ENDPOINT: Optional[str] = None
    AZURE_OPENAI_DEPLOYMENT_NAME: Optional[str] = None
    AZURE_OPENAI_API_VERSION: Optional[str] = None
    ALERT_WEBHOOK_URL: Optional[str] = None

    # Ollama
    OLLAMA_BASE_URL: Optional[str] = None
    OLLAMA_API_KEY: Optional[str] = "ollama"
    OLLAMA_MODEL_NAME: Optional[str] = None
    OLLAMA_CONNECTION_POOL_SIZE: int = 3
    OLLAMA_KEEPALIVE_TIMEOUT: int = 600
    OLLAMA_NUM_BATCH: int = 512
    OLLAMA_REPEAT_PENALTY: float = 1.0
    OLLAMA_TOP_K: int = 1
    OLLAMA_TOP_P: float = 1.0
    TCP_KEEPALIVE_IDLE: int = 30
    TCP_KEEPALIVE_INTERVAL: int = 10
    TCP_KEEPALIVE_COUNT: int = 3

    # --- Rate Limiting & Upload Safeguards ---
    GLOBAL_RATE_LIMIT_MAX_REQUESTS: int = 50
    GLOBAL_RATE_LIMIT_WINDOW_SECONDS: int = 60
    MAX_FILE_UPLOAD_BYTES: int = 100 * 1024 * 1024
    # Sentinel defaults (0 / 0 / -1.0) mean "auto from model profile".
    # Any positive value is treated as an explicit override and wins over
    # the per-model registry in services/ai_extraction/llm/model_profiles.py.
    # An existing .env that sets these to positive numbers continues to
    # behave exactly as it did before the registry was introduced.
    LLM_RATE_LIMIT_RPM: float = 0.0
    LLM_RATE_LIMIT_BURST: int = 0
    LLM_RATE_LIMIT_MIN_INTERVAL: float = -1.0
    # Cap on concurrent in-flight LLM calls. Orthogonal to BURST (bucket
    # capacity). 0 = auto from model profile, falling back to BURST when
    # neither the env var nor the profile provides a value.
    LLM_MAX_INFLIGHT: int = 0
    # Trust X-Forwarded-For only when the direct peer is inside one of these CIDRs.
    TRUSTED_PROXY_CIDRS: List[str] = []
    CORS_ALLOWED_ORIGINS: List[str] = ["*"]
    API_ALLOWED_CONTENT_TYPES: List[str] = ["application/pdf"]
    API_ALLOWED_EXTENSIONS: List[str] = [".pdf"]
    KNOWN_FRAMEWORKS: List[str] = [
        "ISO-27001", "NIST-CSF", "PCI-DSS", "SWIFT-CSCF",
        "SAMA-CSF", "DESC-ISR", "ECC", "NCA-ECC", "UAE-IAS",
    ]

    # --- Extraction Parameters ---
    WINDOW_OVERLAP: int = 1
    DISCOVERY_WINDOW_SIZE: int = 4
    DISCOVERY_MAX_LLM_CALLS: int = 64
    SUBCONTROL_MAX_TOKENS: int = 0
    TOC_MAX_TOKENS: int = 0
    DISCOVERY_MAX_TOKENS: int = 0
    # Discovery and TOC are permissive pattern-matching passes ("find control
    # IDs / dot-leader entries"). They do NOT need deep reasoning. Reasoning
    # models waste 4-6k tokens per call on internal chain-of-thought when left
    # at the default effort level, which routinely truncates the output below
    # the visible ceiling. "minimal" keeps reasoning_tokens close to zero so
    # the entire budget is available for output. The TOC phase reads this
    # same setting for consistency.
    DISCOVERY_REASONING_EFFORT: Literal["none", "minimal", "low", "medium", "high"] = "minimal"
    # Sub-control extraction IS reasoning-heavy (nested sections, letter/number
    # sequences, cross-page continuation, stem-completion rules). It keeps the
    # project-wide LLM_REASONING_EFFORT by default (set to None to inherit).
    # Operators running on small-context reasoning models may reduce this to
    # "minimal" to trade some output quality for budget headroom — the
    # auto-rechunk-on-truncation path in _extract_group will still preserve
    # correctness on truncation.
    SUBCONTROL_REASONING_EFFORT: Optional[Literal["none", "minimal", "low", "medium", "high"]] = None
    # When a discovery window truncates (output hits the max_tokens ceiling
    # or the LLM raises a length-related exception), the scanner bisects the
    # window and re-scans each half. This adapts automatically to content
    # density and small context models — a 4-page window may split into
    # 2+2 or 1+1+1+1 without operator intervention.
    # Hard cap on recursion depth to prevent runaway; 3 means a 4-page window
    # can split at most to 1-page windows (4 → 2+2 → 1+1+1+1).
    DISCOVERY_MAX_SPLIT_DEPTH: int = 3
    PARSE_TYPE: Literal["docling", "OpenDataLoaderPDF", "fitz", "pdfplumber", "pymupdf4llm", "kreuzberg"] = "pymupdf4llm"
    PDF_MIN_CHARS_PER_PAGE: int = 100
    PDF_MAX_PAGES: int = 1000
    PDF_CONVERSION_TIMEOUT_SECONDS: int = 3600
    PDF_CONVERSION_TERMINATE_GRACE_SECONDS: int = 10
    # Internal neural-network batch size for the layout and table models
    # (how many page regions are passed to the model per forward pass).
    # Increasing this improves GPU utilisation; on CPU the docling default (4)
    # is near-optimal.  Values of 8-16 are reasonable for GPU deployments.
    PDF_DOCLING_BATCH_SIZE: int = 1
    PDF_DOCLING_NUM_THREADS: int = 1
    # Number of pages that docling's standard pipeline holds in-flight through
    # the preprocess → layout → table stages simultaneously.  Maps to
    # `docling.datamodel.settings.settings.perf.page_batch_size` (default 4).
    # Peak memory scales roughly linearly with this value; on CPU-only hosts,
    # high values cause std::bad_alloc during preprocess on image-heavy pages.
    # Recommended: 2 for CPU, 4-8 for GPU.
    PDF_DOCLING_PAGE_BATCH_SIZE: int = 1
    # Path to pre-downloaded docling model artifacts.
    # When set, docling loads models from this directory with no network calls.
    # Run `python services/doc_processing/download_models.py` to populate it,
    # then set DOCLING_ARTIFACTS_PATH=<that directory> in .env.
    # When empty, docling falls back to the HuggingFace hub cache (~/.cache/huggingface).
    DOCLING_ARTIFACTS_PATH: str = ""
    DOCLING_DEGENERATE_THRESHOLD: float = 0.30
    PDF_DOCLING_CPU_NUM_THREADS: int = 1
    PDF_DOCLING_CPU_BATCH_SIZE: int = 1
    PDF_DOCLING_CPU_PAGE_BATCH_SIZE: int = 1
    PDF_DOCLING_CUDA_NUM_THREADS: int = 4
    PDF_DOCLING_CUDA_BATCH_SIZE: int = 8
    PDF_DOCLING_CUDA_PAGE_BATCH_SIZE: int = 4
    PDF_DOCLING_MPS_NUM_THREADS: int = 4
    PDF_DOCLING_MPS_BATCH_SIZE: int = 4
    PDF_DOCLING_MPS_PAGE_BATCH_SIZE: int = 4
    PDF_DOCLING_XPU_NUM_THREADS: int = 4
    PDF_DOCLING_XPU_BATCH_SIZE: int = 4
    PDF_DOCLING_XPU_PAGE_BATCH_SIZE: int = 4
    POST_EXTRACTION_MAX_DEPTH: int = 10
    CHUNK_CONTEXT_RATIO: float = 0.75
    CHUNK_PROMPT_OVERHEAD_TOKENS: int = 2600
    SUBCONTROL_MIN_CONTENT_CHARS: int = 100
    TOC_DEFAULT_PAGES: str = "batch"
    SECTION_FWD_OVERLAP_THRESHOLD: float = 0.85
    SECTION_REV_OVERLAP_THRESHOLD: float = 0.85
    SECTION_MIN_WORDS_FOR_OVERLAP: int = 30
    SECTION_NGRAM_SIZE: int = 8
    BLUEPRINT_CACHE_TTL_DAYS: int = 30

    # --- DLQ and SAGA ---
    DLQ_MAX_DELIVERY_ATTEMPTS: int = 5
    SAGA_RETRY_ATTEMPTS: int = 3
    SAGA_RETRY_MIN_WAIT: int = 1
    SAGA_RETRY_MAX_WAIT: int = 10

    # --- Logging and Monitoring ---
    LOG_TRUNCATE_BODY: bool = True
    LOG_TRUNCATE_SYSTEM_PROMPT: int = 0
    LOG_TRUNCATE_USER_PROMPT: int = 0
    LOG_TRUNCATE_LLM_OUTPUT: int = 0
    LOG_TRUNCATE_JSON_ERROR: int = 500
    LOG_ROTATION_SIZE: str = "10 MB"
    LOG_RETENTION_DAYS: int = 30
    AUTODETECT_CONFIDENCE_THRESHOLD: float = 0.85
    FRAMEWORK_DETECTION_MAX_SCAN_CHARS: int = 50000
    PROFILE_FETCH_TIMEOUT_SECONDS: int = 10
    OUTPUT_DIR: str = "./output"
    HEALTH_DB_POOL_TIMEOUT_SECONDS: int = 3
    HEALTH_DB_POOL_SIZE: int = 1
    HEALTH_DB_CONNECT_TIMEOUT_SECONDS: int = 3
    HEALTH_LLM_ENDPOINT_TIMEOUT_SECONDS: float = 4.0
    HEALTH_HTTP_SERVICE_TIMEOUT_SECONDS: float = 3.0
    JAVA_DETECTION_TIMEOUT_SECONDS: float = 10.0
    # Per-document timeout for the OpenDataLoaderPDF Java CLI.  The outer
    # subprocess timeout (PDF_CONVERSION_TIMEOUT_SECONDS, default 3600s)
    # eventually kills a wedged ODL run, but this parser-level timeout
    # lets the orchestrator fail fast and try another parser rather than
    # burning the whole subprocess budget on a single hang.
    OPENDATALOADER_TIMEOUT_SECONDS: float = 300.0
    # Minimum markdown size below which ODL output is treated as
    # degenerate (e.g. scanned/image-only PDF where the Java pipeline
    # produced no extractable text).  Triggers a RuntimeError so the
    # orchestrator can escalate rather than emit an all-empty document.
    OPENDATALOADER_MIN_OUTPUT_CHARS: int = 100
    OTEL_EXPORTER_OTLP_ENDPOINT: str = ""
    OTEL_ENABLED: bool = True
    OTEL_EXPORTER_OTLP_INSECURE: bool = True

    @model_validator(mode="after")
    def assemble_urls(self):
        # Blob storage backend normalization.
        # Keep legacy USE_AZURE_STORAGE and canonical BLOB_BACKEND aligned so
        # older modules and newer modules see the same effective backend.
        if self.BLOB_BACKEND == "azure" or self.USE_AZURE_STORAGE:
            self.BLOB_BACKEND = "azure"
            self.USE_AZURE_STORAGE = True
        else:
            self.BLOB_BACKEND = "local"
            self.USE_AZURE_STORAGE = False

        # Redis
        if self.USE_LOCAL_REDIS:
            self.REDIS_URL = self.LOCAL_REDIS_URL
            self.REDIS_CLUSTER_MODE = False
            self.REDIS_PASSWORD = None
        if self.REDIS_PASSWORD and "@" not in self.REDIS_URL:
            parts = self.REDIS_URL.split("://")
            if len(parts) == 2:
                self.REDIS_URL = f"{parts[0]}://:{quote_plus(self.REDIS_PASSWORD)}@{parts[1]}"

        # Database
        if self.USE_LOCAL_DB and self.DB_BACKEND == "mysql":
            self.MYSQL_HOST = self.LOCAL_MYSQL_HOST
            self.MYSQL_PORT = self.LOCAL_MYSQL_PORT
            self.MYSQL_USER = self.LOCAL_MYSQL_USER
            self.MYSQL_PASSWORD = self.LOCAL_MYSQL_PASSWORD

        if not self.DATABASE_URL:
            if self.DB_BACKEND == "mysql":
                self.DATABASE_URL = (
                    f"mysql+asyncmy://{quote_plus(self.MYSQL_USER)}:{quote_plus(self.MYSQL_PASSWORD)}"
                    f"@{self.MYSQL_HOST}:{self.MYSQL_PORT}/{self.MYSQL_DB}?charset=utf8mb4"
                )
            elif self.DB_BACKEND == "postgresql":
                self.DATABASE_URL = (
                    f"postgresql+asyncpg://{quote_plus(self.POSTGRES_USER)}:{quote_plus(self.POSTGRES_PASSWORD)}"
                    f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
                )
        return self

    @model_validator(mode="after")
    def auto_derive_tokens(self):
        ctx = self.LLM_MODEL_CONTEXT_TOKENS
        if self.SUBCONTROL_MAX_TOKENS == 0:
            self.SUBCONTROL_MAX_TOKENS = int(ctx * _AUTO_SUBCONTROL_RATIO)
        if self.LLM_MAX_OUTPUT_TOKENS == 0:
            self.LLM_MAX_OUTPUT_TOKENS = int(ctx * _AUTO_MAX_OUTPUT_RATIO)
        if self.TOC_MAX_TOKENS == 0:
            self.TOC_MAX_TOKENS = int(ctx * _AUTO_TOC_RATIO)
        if self.DISCOVERY_MAX_TOKENS == 0:
            self.DISCOVERY_MAX_TOKENS = int(ctx * _AUTO_DISCOVERY_RATIO)
        return self

    model_config = {"env_file_encoding": "utf-8", "extra": "ignore"}


# --- Resolution Logic ---
_SEARCH_PATHS = [
    Path(__file__).resolve().parent / ".env",
    Path(__file__).resolve().parent.parent / ".env",
    Path(__file__).resolve().parent.parent.parent / ".env",
]

def resolve_env_file(cli_path: Optional[str] = None) -> Optional[str]:
    if cli_path and Path(cli_path).exists(): return cli_path
    if (e := os.environ.get("DOTENV_PATH")) and Path(e).exists(): return e
    for p in _SEARCH_PATHS:
        if p.exists(): return str(p)
    return None

_settings_instance: Optional[Settings] = None
_settings_lock = threading.Lock()

def get_settings(env_file: Optional[str] = None) -> Settings:
    global _settings_instance
    if _settings_instance: return _settings_instance
    with _settings_lock:
        if _settings_instance: return _settings_instance
        resolved = resolve_env_file(env_file)
        _settings_instance = Settings(_env_file=resolved) if resolved else Settings()
        
        # Validate critical provider config at startup — fail fast
        config_errors = validate_config(_settings_instance)
        if config_errors:
            # We log warnings in development but don't strictly crash here
            # to allow initial status reporting
            for err in config_errors:
                warnings.warn(f"Configuration Warning: {err}")
                
        return _settings_instance

def validate_config(settings: Settings) -> List[str]:
    errs = []
    if settings.LLM_PROVIDER == "azure":
        if not all([settings.AZURE_OPENAI_API_KEY, settings.AZURE_OPENAI_ENDPOINT, settings.AZURE_OPENAI_DEPLOYMENT_NAME]):
            errs.append("Missing Azure OpenAI credentials")
    elif settings.LLM_PROVIDER == "ollama" and not settings.OLLAMA_BASE_URL:
        errs.append("Missing Ollama base URL")
    return errs
