"""
Manual Docling markdown test utility.

Usage:
    py docling_test.py
    py docling_test.py path/to/file.pdf
    py docling_test.py path/to/file.pdf --preview-chars 2000

What it does:
    - extracts the PDF with Docling
    - writes one combined markdown file with page markers preserved by Docling
    - prints a short summary to the console
"""

from __future__ import annotations

import argparse
import os
import tempfile
import time
from pathlib import Path

import fitz


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Manually test Docling markdown output.")
    parser.add_argument(
        "pdf",
        nargs="?",
        default=r"C:\Users\User\Documents\Development\control_extraction\frameworks\SAMA.pdf",
        help="Path to the PDF file",
    )
    parser.add_argument(
        "--preview-chars",
        type=int,
        default=1200,
        help="How many characters of the markdown preview to print",
    )
    parser.add_argument(
        "--threads",
        type=int,
        default=1,
        help="CPU threads for Docling/OpenMP. Lower values reduce memory pressure.",
    )
    parser.add_argument(
        "--enable-ocr",
        action="store_true",
        help="Enable OCR. Leave off for digitally generated PDFs like SAMA to save memory.",
    )
    parser.add_argument(
        "--enable-tables",
        action="store_true",
        help="Enable table structure extraction. Leave off to reduce memory usage.",
    )
    parser.add_argument(
        "--page-range",
        default="",
        help="Optional 1-based inclusive page range like 1-25 or 26-56.",
    )
    return parser.parse_args()


def parse_page_range(page_range: str, total_pages: int) -> tuple[int, int] | None:
    if not page_range:
        return None
    if "-" not in page_range:
        raise ValueError("page range must look like 1-25")
    start_s, end_s = page_range.split("-", 1)
    start = int(start_s.strip())
    end = int(end_s.strip())
    if start < 1 or end < start or end > total_pages:
        raise ValueError(f"invalid page range {page_range!r} for PDF with {total_pages} pages")
    return start, end


def build_subset_pdf(pdf_path: Path, start_page: int, end_page: int) -> Path:
    subset_doc = fitz.open()
    try:
        with fitz.open(pdf_path) as src:
            subset_doc.insert_pdf(src, from_page=start_page - 1, to_page=end_page - 1)
        tmp = tempfile.NamedTemporaryFile(prefix="docling_subset_", suffix=".pdf", delete=False)
        tmp_path = Path(tmp.name)
        tmp.close()
        subset_doc.save(tmp_path)
        return tmp_path
    finally:
        subset_doc.close()


def main() -> int:
    args = parse_args()
    os.environ["OMP_NUM_THREADS"] = str(max(1, args.threads))

    from docling.datamodel.accelerator_options import AcceleratorDevice, AcceleratorOptions
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions
    from docling.document_converter import DocumentConverter, PdfFormatOption

    pdf_path = Path(args.pdf).resolve()
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    with fitz.open(pdf_path) as doc:
        if doc.is_encrypted:
            raise ValueError("PDF is password-protected. Provide an unencrypted PDF.")
        page_count = len(doc)

    selected_range = parse_page_range(args.page_range, page_count)
    output_dir = Path(r"C:\Users\User\Documents\Development\control_extraction")
    output_dir.mkdir(parents=True, exist_ok=True)
    suffix = "_Docling.md"
    source_for_docling = pdf_path
    temp_subset_path: Path | None = None
    if selected_range:
        start_page, end_page = selected_range
        temp_subset_path = build_subset_pdf(pdf_path, start_page, end_page)
        source_for_docling = temp_subset_path
        suffix = f"_Docling_p{start_page}-{end_page}.md"
    output_path = output_dir / f"{pdf_path.stem}{suffix}"

    pipeline_options = PdfPipelineOptions()
    pipeline_options.do_ocr = args.enable_ocr
    pipeline_options.do_table_structure = args.enable_tables
    pipeline_options.accelerator_options = AcceleratorOptions(
        num_threads=max(1, args.threads),
        device=AcceleratorDevice.CPU,
    )

    converter = DocumentConverter(
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        }
    )

    started_at = time.perf_counter()
    try:
        result = converter.convert(str(source_for_docling))
        md_content = result.document.export_to_markdown()
        elapsed_seconds = time.perf_counter() - started_at
    finally:
        if temp_subset_path is not None and temp_subset_path.exists():
            temp_subset_path.unlink(missing_ok=True)

    output_path.write_text(md_content, encoding="utf-8")

    page_markers = md_content.count("<!-- page=")

    print(f"PDF: {pdf_path}")
    print(f"Expected pages: {page_count}")
    print(f"Selected range: {args.page_range or 'all'}")
    print(f"Docling page markers: {page_markers}")
    print(f"Threads: {max(1, args.threads)}")
    print(f"OCR enabled: {args.enable_ocr}")
    print(f"Table extraction enabled: {args.enable_tables}")
    print(f"Combined markdown: {output_path}")
    print(f"Total extracted chars: {len(md_content):,}")
    print(f"Elapsed seconds: {elapsed_seconds:.2f}")
    print()
    print("Preview:")
    print("-" * 80)
    print(md_content[: args.preview_chars])
    print("-" * 80)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
