"""
Redis Client Utilities
=======================
Async Redis client for lightweight job-state key-value tracking.
Task queuing is handled by Redis Streams (shared_core/stream_client.py).
"""
import re
from typing import Union
import redis.asyncio as aioredis
from redis.asyncio.cluster import RedisCluster

from shared_core.constants import (
    STATE_QUEUED, STATE_DOC_PROCESSING, STATE_AI_EXTRACTION,
    STATE_MERGE, STATE_COMPLETED, STATE_AI_EXTRACTION_FAILED,
    STATE_DOC_PROCESSING_FAILED, STATE_STORAGE_FAILED,
    STATE_STORAGE_COMPLETED,
)

# Allowed characters in job_id: UUID hex, hyphens, underscores
_JOB_ID_PATTERN = re.compile(r'^[a-zA-Z0-9_-]{1,128}$')

# Valid states that can be stored via update_job_state
_VALID_STATES = frozenset({
    STATE_QUEUED, STATE_DOC_PROCESSING, STATE_AI_EXTRACTION,
    STATE_MERGE, STATE_COMPLETED, STATE_AI_EXTRACTION_FAILED,
    STATE_DOC_PROCESSING_FAILED, STATE_STORAGE_FAILED,
    STATE_STORAGE_COMPLETED,
})

_shared_client: Union[aioredis.Redis, RedisCluster, None] = None


def _get_redis_url() -> str:
    from config import get_settings
    return get_settings().REDIS_URL


def get_async_redis_client() -> Union[aioredis.Redis, RedisCluster]:
    """Returns an async, string-decoded Redis client (standalone or cluster)."""
    global _shared_client
    if _shared_client is None:
        from config import get_settings
        settings = get_settings()
        url = settings.REDIS_URL
        if settings.REDIS_CLUSTER_MODE:
            _shared_client = RedisCluster.from_url(
                url,
                decode_responses=True,
                ssl_cert_reqs=settings.REDIS_SSL_CERT_REQS,
                max_connections=settings.REDIS_CLUSTER_MAX_CONNECTIONS,
                health_check_interval=settings.REDIS_HEALTH_CHECK_INTERVAL_SECONDS,
                socket_keepalive=True,
            )
        else:
            pool = aioredis.ConnectionPool.from_url(
                url,
                decode_responses=True,
                max_connections=settings.REDIS_STANDALONE_MAX_CONNECTIONS,
                health_check_interval=settings.REDIS_HEALTH_CHECK_INTERVAL_SECONDS,
            )
            _shared_client = aioredis.Redis(connection_pool=pool)
    return _shared_client


def _validate_job_id(job_id: str) -> None:
    """Validate job_id format to prevent Redis key injection."""
    if not job_id or not _JOB_ID_PATTERN.match(job_id):
        raise ValueError(f"Invalid job_id format: {job_id!r}")


async def update_job_state(job_id: str, state: str):
    """Async utility for standardised job state updates."""
    _validate_job_id(job_id)
    if state not in _VALID_STATES:
        raise ValueError(f"Invalid state: {state!r}. Must be one of: {_VALID_STATES}")
    from config import get_settings
    settings = get_settings()
    client = get_async_redis_client()
    await client.set(f"job_state:{job_id}", state, ex=settings.REDIS_JOB_STATE_TTL_SECONDS)


async def fetch_job_state(job_id: str) -> str:
    """Async utility for standardised job state retrieval."""
    _validate_job_id(job_id)
    client = get_async_redis_client()
    return await client.get(f"job_state:{job_id}")


async def close_pool() -> None:
    """Gracefully close the module-level Redis connection pool."""
    global _shared_client
    if _shared_client is not None:
        await _shared_client.aclose()
        _shared_client = None
