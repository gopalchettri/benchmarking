"""
Rate Limiting Middleware
========================
Atomic Redis-based rate limiting with in-memory fallback.
"""

import ipaddress
import time
from collections import defaultdict

from fastapi import Request, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import redis.asyncio as redis_async

from config import get_settings
from utils.logging_config import logger

settings = get_settings()

# Lua script for atomic increment + conditional expire.
# Returns the new count.  Sets TTL only on the first request in the window.
_RATE_LIMIT_LUA = """
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local window = tonumber(ARGV[2])

local current = redis.call('INCR', key)
if current == 1 then
    redis.call('EXPIRE', key, window)
end
return current
"""


class RateLimitingMiddleware(BaseHTTPMiddleware):
    """
    Evaluates global API rate limits using the shared Redis instance.
    Falls back to in-memory counters when Redis is unavailable.
    """

    _SKIP_PATHS = frozenset({"/health"})

    def __init__(self, app: ASGIApp, max_requests: int = 50, window_seconds: int = 60):
        super().__init__(app)
        self.max_requests = max_requests
        self.window_seconds = window_seconds

        # Async Redis client/cluster
        if settings.REDIS_CLUSTER_MODE:
            from redis.asyncio.cluster import RedisCluster
            self.redis_client = RedisCluster.from_url(
                settings.REDIS_URL,
                decode_responses=True,
                ssl_cert_reqs=settings.REDIS_SSL_CERT_REQS,
                max_connections=50,
            )
            self.is_cluster = True
        else:
            self.redis_pool = redis_async.ConnectionPool.from_url(
                settings.REDIS_URL, decode_responses=True, max_connections=20
            )
            self.redis_client = None  # Will be created per request
            self.is_cluster = False

        self._lua_sha: str | None = None

        # In-memory fallback when Redis is down
        # {ip: (count, window_start_time)}
        self._fallback_counts: dict[str, tuple[int, float]] = defaultdict(lambda: (0, 0.0))

        # Parse trusted proxy CIDRs once at startup
        self._trusted_proxies: list[ipaddress.IPv4Network | ipaddress.IPv6Network] = []
        for cidr in getattr(settings, "TRUSTED_PROXY_CIDRS", []):
            try:
                self._trusted_proxies.append(ipaddress.ip_network(cidr, strict=False))
            except ValueError:
                logger.warning(f"Invalid TRUSTED_PROXY_CIDR: {cidr}")

    def _get_client_ip(self, request: Request) -> str:
        """ Only trust X-Forwarded-For when direct peer is a trusted proxy."""
        direct_ip = request.client.host if request.client else "unknown"

        if not self._trusted_proxies:
            return direct_ip

        try:
            peer = ipaddress.ip_address(direct_ip)
        except ValueError:
            return direct_ip

        is_trusted = any(peer in net for net in self._trusted_proxies)
        if is_trusted:
            forwarded = request.headers.get("X-Forwarded-For")
            if forwarded:
                return forwarded.split(",")[0].strip()

        return direct_ip

    _EVICTION_INTERVAL = 300  # Evict stale entries every 5 minutes

    def _fallback_check(self, ip: str) -> bool:
        """ In-memory rate check. Returns True if request is allowed."""
        now = time.monotonic()
        count, window_start = self._fallback_counts[ip]

        # Periodically evict stale entries to prevent unbounded growth
        if not hasattr(self, '_last_eviction'):
            self._last_eviction = now
        if now - self._last_eviction > self._EVICTION_INTERVAL:
            self._last_eviction = now
            stale = [k for k, (_, ws) in self._fallback_counts.items()
                     if now - ws > self.window_seconds * 2]
            for k in stale:
                del self._fallback_counts[k]

        if now - window_start > self.window_seconds:
            # New window
            self._fallback_counts[ip] = (1, now)
            return True

        if count >= self.max_requests:
            return False

        self._fallback_counts[ip] = (count + 1, window_start)
        return True

    async def dispatch(self, request: Request, call_next):
        if request.url.path in self._SKIP_PATHS:
            return await call_next(request)

        ip_addr = self._get_client_ip(request)
        key = f"rate_limit:{ip_addr}"

        try:
            if self.is_cluster:
                client = self.redis_client
            else:
                client = redis_async.Redis(connection_pool=self.redis_pool)

            # Atomic Lua eval — no separate ping needed (M-10)
            if self._lua_sha is None:
                self._lua_sha = await client.script_load(_RATE_LIMIT_LUA)

            try:
                current = await client.evalsha(
                    self._lua_sha, 1, key, self.max_requests, self.window_seconds
                )
            except redis_async.ResponseError as lua_err:
                if "NOSCRIPT" in str(lua_err):
                    # Script evicted from Redis cache (failover/restart) — reload
                    self._lua_sha = await client.script_load(_RATE_LIMIT_LUA)
                    current = await client.evalsha(
                        self._lua_sha, 1, key, self.max_requests, self.window_seconds
                    )
                else:
                    raise

            if int(current) > self.max_requests:
                return JSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content={"detail": "Rate limit exceeded. Try again later."},
                )

        except Exception as exc:
            # Redis unavailable — use in-memory fallback
            logger.warning(f"Redis rate-limit unavailable ({exc}), using in-memory fallback")
            self._lua_sha = None  # Reset so we re-load on reconnect
            if not self._fallback_check(ip_addr):
                return JSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content={"detail": "Rate limit exceeded. Try again later."},
                )

        return await call_next(request)
