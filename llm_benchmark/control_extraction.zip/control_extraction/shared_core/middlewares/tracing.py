import uuid
import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from utils.logging_config import logger

class RequestTracingMiddleware(BaseHTTPMiddleware):
    """
    Injects a correlation ID (`X-Request-ID`) into all HTTP streams
    and logs request execution time.
    """
    def __init__(self, app: ASGIApp):
        super().__init__(app)

    async def dispatch(self, request: Request, call_next):
        req_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        
        start_time = time.monotonic()
        
        # Inject the ID into request state so downstream functions can retrieve it
        request.state.request_id = req_id
        
        response = await call_next(request)
        
        process_time = time.monotonic() - start_time
        response.headers["X-Process-Time"] = str(process_time)
        response.headers["X-Request-ID"] = req_id
        
        logger.info(
            f"Req: {req_id} | Path: {request.url.path} | "
            f"Method: {request.method} | Status: {response.status_code} | "
            f"Latency: {process_time:.4f}s"
        )
        
        return response
