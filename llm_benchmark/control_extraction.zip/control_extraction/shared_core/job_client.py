"""
Job Status Client
==================
Lightweight async client that updates extraction job status in the
persistent jobs table via the storage service HTTP API.

Usage::

    from shared_core.job_client import update_job_record

    await update_job_record(job_id, status="processing", started_at=now_iso())

All errors are swallowed with a warning log — job tracking must NEVER
break the extraction pipeline.
"""

import asyncio
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from utils.logging_config import logger


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _get_url_base() -> str:
    """Build the storage service base URL (e.g. http://localhost:8003/api/v1)."""
    from config import get_settings
    settings = get_settings()
    return f"{settings.STORAGE_SERVICE_URL}{settings.API_V1_STR}"


def _get_job_client_settings():
    from config import get_settings
    return get_settings()


async def create_job_record(
    job_id: str,
    framework: str,
    user_id: Optional[str] = None,
    file_name: Optional[str] = None,
    file_hash: Optional[str] = None,
    blob_path: Optional[str] = None,
    framework_version: Optional[str] = None,
    framework_profile_id: Optional[str] = None,
) -> bool:
    """Create a new job record in the persistent jobs table.

    Retries up to the configured max retries with exponential backoff on
    transient failures to prevent silent data loss.

    Returns True if the record was created successfully, False otherwise.
    Errors are logged but never raised — job tracking must not break the pipeline.
    """
    import httpx
    settings = _get_job_client_settings()

    url = f"{_get_url_base()}/jobs"

    payload: Dict[str, Any] = {
        "id": job_id,
        "framework": framework,
    }
    if user_id:
        payload["user_id"] = user_id
    if file_name:
        payload["file_name"] = file_name
    if file_hash:
        payload["file_hash"] = file_hash
    if blob_path:
        payload["blob_path"] = blob_path
    if framework_version:
        payload["framework_version"] = framework_version
    if framework_profile_id:
        payload["framework_profile_id"] = framework_profile_id

    last_error = None
    for attempt in range(settings.JOB_CLIENT_CREATE_MAX_RETRIES):
        try:
            async with httpx.AsyncClient(timeout=settings.JOB_CLIENT_TIMEOUT_SECONDS) as client:
                resp = await client.post(url, json=payload)
                if resp.status_code == 201:
                    logger.info(f"[JobClient] Created job record: {job_id}")
                    return True
                elif resp.status_code == 409:
                    # Record already exists (duplicate create) — treat as success
                    logger.debug(f"[JobClient] Job record {job_id} already exists (409)")
                    return True
                else:
                    last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
                    logger.warning(
                        f"[JobClient] Create job returned {resp.status_code} "
                        f"(attempt {attempt + 1}/{settings.JOB_CLIENT_CREATE_MAX_RETRIES}): {resp.text[:200]}"
                    )
        except Exception as e:
            last_error = str(e)
            logger.warning(
                f"[JobClient] Create job failed (attempt {attempt + 1}/{settings.JOB_CLIENT_CREATE_MAX_RETRIES}): {e}"
            )

        # Exponential backoff before retry (skip delay on last attempt)
        if attempt < settings.JOB_CLIENT_CREATE_MAX_RETRIES - 1:
            delay = settings.JOB_CLIENT_RETRY_BASE_DELAY_SECONDS * (2 ** attempt)
            await asyncio.sleep(delay)

    logger.error(
        f"[JobClient] Failed to create job record {job_id} after "
        f"{settings.JOB_CLIENT_CREATE_MAX_RETRIES} attempts. Last error: {last_error}"
    )
    return False


async def fetch_job_record(job_id: str) -> Optional[dict]:
    """Fetch an existing job record from the storage service.

    Returns the job record dict, or None if not found (404).
    Raises on non-404 HTTP errors.
    """
    try:
        import httpx
        settings = _get_job_client_settings()
        url = f"{_get_url_base()}/jobs/{job_id}"

        async with httpx.AsyncClient(timeout=settings.JOB_CLIENT_TIMEOUT_SECONDS) as client:
            resp = await client.get(url)
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        logger.warning(f"[JobClient] Failed to fetch job record {job_id}: {e}")
        raise


async def update_job_record(
    job_id: str,
    **updates: Any,
) -> None:
    """Update a job record in the persistent jobs table.

    Accepts any combination of: status, controls_extracted, total_nodes,
    error_message, started_at, completed_at.

    If the job record does not exist (404), auto-creates it with the
    framework from the updates or "unknown", then applies the update.
    This prevents silent data loss when create_job_record fails.

    Fire-and-forget — errors are logged but never raised.
    """
    if not updates:
        return
    try:
        import httpx
        settings = _get_job_client_settings()
        url = f"{_get_url_base()}/jobs/{job_id}"

        async with httpx.AsyncClient(timeout=settings.JOB_CLIENT_TIMEOUT_SECONDS) as client:
            resp = await client.patch(url, json=updates)
            if resp.status_code == 200:
                logger.debug(f"[JobClient] Updated job {job_id}: {list(updates.keys())}")
            elif resp.status_code == 404:
                logger.warning(
                    f"[JobClient] Job {job_id} not found in DB — "
                    f"attempting to create record before update"
                )
                # Auto-create the missing job record, then retry the update.
                # This recovers from failed create_job_record calls.
                framework = updates.pop("framework", None) or "unknown"
                created = await create_job_record(
                    job_id=job_id,
                    framework=framework,
                )
                if created:
                    # Re-apply the original updates (including any status change)
                    retry_resp = await client.patch(url, json=updates)
                    if retry_resp.status_code == 200:
                        logger.info(
                            f"[JobClient] Auto-created + updated job {job_id}: "
                            f"{list(updates.keys())}"
                        )
                    else:
                        logger.warning(
                            f"[JobClient] Auto-created job {job_id} but update failed: "
                            f"{retry_resp.status_code}: {retry_resp.text[:200]}"
                        )
                else:
                    logger.warning(
                        f"[JobClient] Could not auto-create job {job_id} — "
                        f"update dropped: {list(updates.keys())}"
                    )
            else:
                logger.warning(f"[JobClient] Update job returned {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        logger.warning(f"[JobClient] Failed to update job record (non-fatal): {e}")
