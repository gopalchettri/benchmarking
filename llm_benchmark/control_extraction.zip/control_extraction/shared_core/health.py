"""
Shared Health Check Utilities
==============================
Provides individual async check functions for every external dependency.
Each function returns a (status, message) tuple.

Used:
  1. At FastAPI startup (lifespan) — blocks the service from accepting traffic
     if a critical dependency is unavailable.
  2. At GET /health — returns a live dependency map to orchestrators & probes.

Registered checks per service
-------------------------------
  api_gateway    : Redis, Azure Blob Storage (if configured), downstream services
  doc_processing : Redis
  ai_extraction  : Redis, LLM endpoint
  storage        : Redis, MySQL
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, Dict

import redis.asyncio as _aioredis

from utils.logging_config import logger


CheckResult = Dict[str, Any]   # {"status": "ok"|"degraded"|"error", "latency_ms": int, "detail": str}


# ─── Individual check primitives ─────────────────────────────────────────────



async def check_redis(url: str) -> CheckResult:
    """Ping Redis and verify version supports Streams (>= 5.0)."""
    t0 = time.monotonic()
    try:
        from shared_core.redis_client import get_async_redis_client
        client = get_async_redis_client()
        await client.ping()
        info = await client.info("server")
        
        # Handle both standalone info dict and cluster mode nested info dict
        if info and "redis_version" not in info:
            try:
                first_node = next(iter(info.values()))
                version = first_node.get("redis_version", "unknown")
            except StopIteration:
                version = "unknown"
        else:
            version = info.get("redis_version", "unknown")
            
        major = int(version.split(".")[0]) if version != "unknown" else 0
        streams_ok = major >= 5
        return {
            "status":    "ok" if streams_ok else "degraded",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    f"Redis {version}" + (" — Streams supported" if streams_ok else " — Streams require >= 5.0"),
        }
    except Exception as exc:
        return {
            "status":    "error",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    str(exc),
        }
    except Exception as exc:
        logger.error(f"Redis health check failed: {exc}")
        return {
            "status":    "error",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    str(exc),
        }


_health_db_engine = None
_health_db_url: str | None = None


async def check_database(database_url: str) -> CheckResult:
    """Open a connection and run SELECT 1 against any SQLAlchemy-supported database."""
    global _health_db_engine, _health_db_url
    t0 = time.monotonic()
    try:
        from config import get_settings
        from sqlalchemy import text, create_engine
        settings = get_settings()

        # Convert async driver URLs to sync equivalents for the health check
        sync_url = database_url.replace("mysql+asyncmy://", "mysql+pymysql://").replace("postgresql+asyncpg://", "postgresql+psycopg2://")

        # Reuse engine across calls; recreate if URL changes
        if _health_db_engine is None or _health_db_url != sync_url:
            if _health_db_engine is not None:
                _health_db_engine.dispose()
            _health_db_engine = create_engine(
                sync_url,
                pool_timeout=settings.HEALTH_DB_POOL_TIMEOUT_SECONDS,
                pool_size=settings.HEALTH_DB_POOL_SIZE,
                connect_args={"connect_timeout": settings.HEALTH_DB_CONNECT_TIMEOUT_SECONDS},
            )
            _health_db_url = sync_url

        def _sync_check():
            with _health_db_engine.connect() as conn:
                conn.execute(text("SELECT 1"))

        backend = database_url.split("://")[0].split("+")[0] if "://" in database_url else "unknown"
        await asyncio.to_thread(_sync_check)
        return {
            "status":    "ok",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    f"Database ({backend}) reachable — SELECT 1 succeeded",
        }
    except Exception as exc:
        logger.error(f"Database health check failed: {exc}")
        return {
            "status":    "error",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    str(exc),
        }


async def check_azure_blob(connection_string: str, container_name: str) -> CheckResult:
    """Verify the Azure Blob Storage container is accessible."""
    t0 = time.monotonic()
    try:
        def _sync_check():
            from azure.storage.blob import BlobServiceClient
            client = BlobServiceClient.from_connection_string(connection_string)
            container = client.get_container_client(container_name)
            # list_blobs with max_results=1 is a cheap existence check
            list(container.list_blobs(results_per_page=1).__iter__())

        await asyncio.to_thread(_sync_check)
        return {
            "status":    "ok",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    f"Azure Blob container '{container_name}' reachable",
        }
    except Exception as exc:
        return {
            "status":    "error",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    str(exc),
        }


async def check_llm_endpoint(provider: str, endpoint: str) -> CheckResult:
    """
    Light connectivity check against the LLM API endpoint.
    Does NOT send a real LLM request — just validates TCP + TLS reachability.
    """
    import httpx
    t0 = time.monotonic()
    try:
        from config import get_settings
        settings = get_settings()
        async with httpx.AsyncClient(timeout=settings.HEALTH_LLM_ENDPOINT_TIMEOUT_SECONDS) as client:
            resp = await client.get(endpoint)
            # Any HTTP response (even 401 Unauthorized) means the host is reachable
            return {
                "status":    "ok",
                "latency_ms": round((time.monotonic() - t0) * 1000),
                "detail":    f"{provider} endpoint reachable (HTTP {resp.status_code})",
            }
    except Exception as exc:
        return {
            "status":    "error",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    str(exc),
        }


async def check_http_service(name: str, url: str) -> CheckResult:
    """Check that a downstream microservice's /health endpoint responds."""
    import httpx
    t0 = time.monotonic()
    try:
        from config import get_settings
        settings = get_settings()
        async with httpx.AsyncClient(timeout=settings.HEALTH_HTTP_SERVICE_TIMEOUT_SECONDS) as client:
            resp = await client.get(url)
            ok = resp.status_code == 200
            return {
                "status":    "ok" if ok else "degraded",
                "latency_ms": round((time.monotonic() - t0) * 1000),
                "detail":    f"{name} responded HTTP {resp.status_code}",
            }
    except Exception as exc:
        return {
            "status":    "error",
            "latency_ms": round((time.monotonic() - t0) * 1000),
            "detail":    f"{name} unreachable: {exc}",
        }


# ─── Startup enforcer ────────────────────────────────────────────────────────

async def enforce_startup_checks(
    service_name: str,
    checks: Dict[str, Any],          # {"label": check_coroutine}
    critical: set[str] | None = None,  # set of label names that must be "ok"
) -> Dict[str, CheckResult]:
    """
    Run all checks concurrently at service startup.

    If any *critical* check returns status != "ok", log a fatal error and
    raise RuntimeError so uvicorn shuts the process down immediately rather
    than serving traffic against a broken dependency.

    Args:
        service_name : human-readable service name for log messages
        checks       : dict of label → awaitable check coroutine
        critical     : set of labels that are non-negotiable (default: all)
    """
    if critical is None:
        critical = set(checks.keys())

    labels  = list(checks.keys())
    coros   = list(checks.values())
    results_raw = await asyncio.gather(*coros, return_exceptions=True)

    results: Dict[str, CheckResult] = {}
    failures = []

    for label, raw in zip(labels, results_raw):
        if isinstance(raw, Exception):
            result: CheckResult = {"status": "error", "latency_ms": 0, "detail": str(raw)}
        else:
            result = raw

        results[label] = result
        emoji = "✅" if result["status"] == "ok" else ("⚠️" if result["status"] == "degraded" else "❌")
        logger.info(f"[{service_name}] startup check {emoji} {label}: {result['detail']} ({result['latency_ms']}ms)")

        if label in critical and result["status"] == "error":
            failures.append(label)

    if failures:
        msg = f"[{service_name}] CRITICAL dependencies unavailable: {failures}. Refusing to start."
        logger.error(msg)
        raise RuntimeError(msg)

    return results
