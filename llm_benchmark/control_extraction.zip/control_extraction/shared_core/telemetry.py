"""
OpenTelemetry Bootstrap
=======================
Initialises the global TracerProvider once at service startup.

Usage in any FastAPI service main.py:
    from shared_core.telemetry import setup_telemetry, instrument_fastapi
    setup_telemetry(service_name="api_gateway")
    instrument_fastapi(app)

Configuration (via .env / environment variables):
    OTEL_EXPORTER_OTLP_ENDPOINT  → gRPC collector endpoint (e.g. "http://otel-collector:4317")
    OTEL_SERVICE_NAME             → override the service name string
    OTEL_ENABLED                  → "true" / "false" (default: true when endpoint is set)
"""

from __future__ import annotations

from typing import Optional

from utils.logging_config import logger


def setup_telemetry(service_name: str) -> None:
    """
    Configure and register the global OTLP TracerProvider.

    If OTEL_EXPORTER_OTLP_ENDPOINT is not set, this is a no-op so local dev
    works without an OpenTelemetry collector.

    Args:
        service_name: human-readable name of this microservice
    """
    from config import get_settings
    settings = get_settings()
    endpoint = settings.OTEL_EXPORTER_OTLP_ENDPOINT
    enabled = settings.OTEL_ENABLED

    if not endpoint or not enabled:
        logger.info(f"[OTEL] Telemetry disabled for '{service_name}' (no OTEL_EXPORTER_OTLP_ENDPOINT set).")
        return

    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

        resource = Resource.create({"service.name": service_name})
        provider = TracerProvider(resource=resource)

        exporter = OTLPSpanExporter(endpoint=endpoint, insecure=settings.OTEL_EXPORTER_OTLP_INSECURE)
        provider.add_span_processor(BatchSpanProcessor(exporter))

        trace.set_tracer_provider(provider)
        logger.info(f"[OTEL] TracerProvider initialised → endpoint={endpoint}, service={service_name}")

    except ImportError as exc:
        logger.warning(f"[OTEL] opentelemetry-sdk not installed — tracing skipped: {exc}")
    except Exception as exc:
        logger.error(f"[OTEL] Failed to initialise telemetry: {exc}")


def instrument_fastapi(app) -> None:
    """
    Auto-instrument a FastAPI application with OpenTelemetry spans.

    Every incoming request will automatically produce a span including:
      - HTTP method, route, status code
      - X-Request-ID as a span attribute
      - Exception details on failure

    Args:
        app: FastAPI application instance
    """
    try:
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        FastAPIInstrumentor.instrument_app(app)
        logger.info("[OTEL] FastAPI auto-instrumentation active.")
    except ImportError:
        logger.warning("[OTEL] opentelemetry-instrumentation-fastapi not installed — skipping.")
    except Exception as exc:
        logger.error(f"[OTEL] FastAPI instrumentation failed: {exc}")


def instrument_httpx() -> None:
    """
    Auto-instrument all outbound httpx requests with OTLP spans.

    Wraps the global httpx client so every external HTTP call (e.g.
    to the Azure OpenAI endpoint or inter-service webhooks) emits a span.
    """
    try:
        from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
        HTTPXClientInstrumentor().instrument()
        logger.info("[OTEL] HTTPX auto-instrumentation active.")
    except ImportError:
        logger.warning("[OTEL] opentelemetry-instrumentation-httpx not installed — skipping.")
    except Exception as exc:
        logger.error(f"[OTEL] HTTPX instrumentation failed: {exc}")


def get_tracer(name: str = "control_extraction"):
    """
    Return a named tracer from the globally registered provider.
    Falls back to a no-op tracer if telemetry is disabled.
    """
    try:
        from opentelemetry import trace
        return trace.get_tracer(name)
    except ImportError:
        class _NoOp:
            def start_as_current_span(self, *_, **__):
                import contextlib
                return contextlib.nullcontext()
        return _NoOp()
