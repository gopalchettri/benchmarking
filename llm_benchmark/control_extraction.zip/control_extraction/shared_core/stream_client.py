"""
Redis Streams Task Queue
========================
Lightweight task dispatching and consumption using Redis Streams.

Requires: Redis OSS >= 5.0  (redis-py 5.x, redis.asyncio)

Design
------
Each microservice has its own stream:
    doc_processing:stream   — PDF extraction tasks
    ai_extraction:stream    — LLM extraction tasks
    storage:stream          — Control persistence tasks

Publishers write with XADD; consumers read with XREADGROUP so:
  * Messages are persistent  (survive consumer restart)
  * Each message is ACKed after successful processing
  * Unacked messages are reclaimed by other workers (PEL)
  * After MAX_DELIVERY_ATTEMPTS failures, messages go to DLQ

Usage
-----
Dispatching (from FastAPI routes):
    from shared_core.stream_client import publish_task
    job_id = await publish_task("doc_processing:stream", "process_pdf", {
        "pdf_path": "...", "framework": "NIST"
    })

Consuming (in worker process):
    from shared_core.stream_client import consume_stream
    await consume_stream("doc_processing:stream", "doc_workers", handlers={
        "process_pdf": my_handler_fn
    })
"""
from __future__ import annotations

import asyncio
import json
import uuid
import socket
from typing import Any, Callable, Coroutine, Dict

import redis.asyncio as aioredis
from utils.logging_config import logger


def _get_max_delivery_attempts() -> int:
    from config import get_settings
    return get_settings().DLQ_MAX_DELIVERY_ATTEMPTS


def _get_stream_settings():
    from config import get_settings
    return get_settings()


# ─── Publisher ────────────────────────────────────────────────────────────────

async def publish_task(
    stream: str,
    task_name: str,
    payload: Dict[str, Any],
    job_id: str | None = None,
) -> str:
    """
    Append a task message to a Redis Stream.

    Args:
        stream:     Redis stream key (e.g. "doc_processing:stream")
        task_name:  Logical task identifier (e.g. "process_pdf")
        payload:    JSON-serialisable dict of task arguments
        job_id:     Optional correlation id; generated if not supplied

    Returns:
        job_id (str) — also stored as a field in the stream message
    """
    job_id = job_id or str(uuid.uuid4())
    from shared_core.redis_client import get_async_redis_client
    # H-2: Reuse module-level connection client instead of per-call connections
    client = get_async_redis_client()
    try:
        message_id = await client.xadd(
            stream,
            {
                "task":    task_name,
                "job_id":  job_id,
                # L-11: default=str handles UUIDs, datetimes, etc.
                "payload": json.dumps(payload, default=str, ensure_ascii=False),
            },
            # H-6: Increased from 1000 to 10000 to prevent job loss under burst load.
            # 10K entries at ~1KB each ≈ 10MB Redis memory — acceptable safety net.
            maxlen=10000,
            approximate=True,  # ~ operator: O(1), evicts only when needed
        )
        logger.info(f"[Streams] Published → stream={stream}  task={task_name}  job_id={job_id}  msg={message_id}")
    finally:
        pass  # Global client, don't close
    return job_id


# ─── DLQ Publisher ────────────────────────────────────────────────────────────

async def _publish_to_dlq(
    client: aioredis.Redis,
    original_stream: str,
    msg_id: str,
    task_name: str,
    job_id: str,
    payload: str,
    error: str,
) -> None:
    """Send a poison-pill message to the Dead Letter Queue stream."""
    dlq_stream = "dlq:stream"
    # M-8: Cap DLQ stream to prevent unbounded growth.
    # DLQ entries should be monitored and drained by ops.
    await client.xadd(
        dlq_stream,
        {
            "original_stream": original_stream,
            "original_msg_id": msg_id,
            "task": task_name,
            "job_id": job_id,
            "payload": payload,
            "error": error[:2000],
            "delivery_attempts": str(_get_max_delivery_attempts()),
        },
        maxlen=5000,
        approximate=True,
    )
    logger.warning(
        f"[Streams] DLQ → stream={dlq_stream}  task={task_name}  job_id={job_id}  "
        f"original_msg={msg_id}  error={error[:200]}"
    )


# ─── Consumer ─────────────────────────────────────────────────────────────────

async def _ensure_group(client: aioredis.Redis, stream: str, group: str) -> None:
    """Create the consumer group if it does not already exist."""
    try:
        await client.xgroup_create(stream, group, id="0", mkstream=True)
        logger.info(f"[Streams] Created consumer group '{group}' on stream '{stream}'")
    except aioredis.ResponseError as e:
        if "BUSYGROUP" not in str(e):
            raise   # only suppress "group already exists" error


def _is_nogroup_error(exc: Exception) -> bool:
    """Return True if the exception is a Redis NOGROUP error."""
    return isinstance(exc, aioredis.ResponseError) and "NOGROUP" in str(exc)


async def _get_delivery_count(
    client: aioredis.Redis,
    stream: str,
    group: str,
    msg_id: str,
) -> int:
    """Get the delivery count for a message from XPENDING detail."""
    try:
        pending = await client.xpending_range(stream, group, min=msg_id, max=msg_id, count=1)
        if pending:
            # pending_range returns list of dicts with 'times_delivered' key
            entry = pending[0]
            return entry.get("times_delivered", 1)
    except Exception as e:
        # M-5: Log delivery count lookup failures instead of silently swallowing
        logger.warning(f"[Streams] Failed to get delivery count for msg={msg_id}: {e}")
    return 1


async def consume_stream(
    stream: str,
    group: str,
    handlers: Dict[str, Callable[..., Coroutine]],
    batch_size: int | None = None,
    block_ms: int | None = None,
    shutdown_event: asyncio.Event | None = None,
) -> None:
    """
    Durable stream consumer loop using XREADGROUP.

    Reads messages from `stream` in consumer group `group`.
    Dispatches each message to the matching handler coroutine.
    ACKs the message on success; on failure, checks delivery count
    and routes to DLQ after MAX_DELIVERY_ATTEMPTS.

    Args:
        stream:         Redis stream key
        group:          Consumer group name
        handlers:       Mapping of task_name → async handler coroutine
        batch_size:     Messages per XREADGROUP call
        block_ms:       Milliseconds to block waiting for new messages
        shutdown_event: Optional event to signal graceful shutdown (M-3)
    """
    consumer_name = f"{socket.gethostname()}-{uuid.uuid4().hex[:8]}"
    settings = _get_stream_settings()
    batch_size = batch_size if batch_size is not None else settings.REDIS_STREAM_BATCH_SIZE
    block_ms = block_ms if block_ms is not None else settings.REDIS_STREAM_BLOCK_MS
    from shared_core.redis_client import get_async_redis_client
    # L-3: Use the centralised global connection pool singleton
    client = get_async_redis_client()
    max_attempts = _get_max_delivery_attempts()

    await _ensure_group(client, stream, group)
    logger.info(f"[Streams] Consumer '{consumer_name}' listening on stream={stream} group={group}")

    try:
        # M-4: Recover pending messages from PEL before consuming new ones
        logger.info(f"[Streams] Recovering pending messages from PEL...")
        try:
            pending_results = await client.xreadgroup(
                groupname=group,
                consumername=consumer_name,
                streams={stream: "0"},  # "0" = read from PEL (pending entries)
                count=batch_size,
            )
            if pending_results:
                for _stream_name, messages in pending_results:
                    for msg_id, fields in messages:
                        if not fields:
                            # Empty fields means already-acked placeholder; skip
                            continue
                        task_name = fields.get("task", "")
                        job_id = fields.get("job_id", "")
                        raw_payload = fields.get("payload", "{}")
                        logger.info(f"[Streams] Re-processing pending msg={msg_id} task={task_name}")

                        try:
                            payload = json.loads(raw_payload)
                        except json.JSONDecodeError:
                            logger.error(f"[Streams] Bad JSON in pending msg={msg_id}")
                            await client.xack(stream, group, msg_id)
                            continue

                        handler = handlers.get(task_name)
                        if not handler:
                            await client.xack(stream, group, msg_id)
                            continue

                        try:
                            payload.pop("job_id", None)
                            await handler(job_id=job_id, **payload)
                            await client.xack(stream, group, msg_id)
                            await client.xdel(stream, msg_id)
                            logger.info(f"[Streams] ACK+DEL (recovered) task={task_name} job_id={job_id}")
                        except Exception as exc:
                            logger.error(f"[Streams] FAIL (recovered) task={task_name}: {exc}")
                            delivery_count = await _get_delivery_count(client, stream, group, msg_id)
                            if delivery_count >= max_attempts:
                                await _publish_to_dlq(client, stream, msg_id, task_name, job_id, raw_payload, str(exc))
                                await client.xack(stream, group, msg_id)
                                await client.xdel(stream, msg_id)  # H-5: mirror main loop — remove after DLQ routing
        except Exception as exc:
            if _is_nogroup_error(exc):
                logger.warning(
                    f"[Streams] NOGROUP during PEL recovery — recreating group '{group}' on '{stream}'"
                )
                try:
                    await _ensure_group(client, stream, group)
                    logger.info(f"[Streams] Group '{group}' recreated. Skipping PEL (no pending in new group).")
                except Exception as recreate_exc:
                    logger.error(f"[Streams] Failed to recreate group during PEL recovery: {recreate_exc}")
            else:
                logger.warning(f"[Streams] PEL recovery failed: {exc}")

        # Exponential backoff for consecutive errors
        _backoff_seconds = settings.REDIS_STREAM_BACKOFF_INITIAL_SECONDS
        _BACKOFF_MAX = settings.REDIS_STREAM_BACKOFF_MAX_SECONDS

        # Rate-limit NOGROUP recovery logs to avoid spam if something
        # repeatedly deletes the group (misconfigured script, key eviction)
        _nogroup_recover_count = 0
        _nogroup_last_log_time = 0.0
        _NOGROUP_LOG_INTERVAL = settings.REDIS_STREAM_NOGROUP_LOG_INTERVAL_SECONDS

        # Main consumer loop
        while not (shutdown_event and shutdown_event.is_set()):
            try:
                results = await client.xreadgroup(
                    groupname=group,
                    consumername=consumer_name,
                    streams={stream: ">"},   # ">" = only new, undelivered messages
                    count=batch_size,
                    block=block_ms,
                )

                # Successful xreadgroup — group exists, connection healthy
                if _backoff_seconds > settings.REDIS_STREAM_BACKOFF_INITIAL_SECONDS:
                    logger.debug(
                        f"[Streams] Connection recovered, resetting backoff from {_backoff_seconds:.0f}s"
                    )
                _backoff_seconds = settings.REDIS_STREAM_BACKOFF_INITIAL_SECONDS

                if not results:
                    continue

                for _stream_name, messages in results:
                    for msg_id, fields in messages:
                        task_name = fields.get("task", "")
                        job_id    = fields.get("job_id", "")
                        raw_payload = fields.get("payload", "{}")

                        try:
                            payload = json.loads(raw_payload)
                        except json.JSONDecodeError:
                            logger.error(f"[Streams] Bad JSON payload in msg={msg_id}")
                            await client.xack(stream, group, msg_id)
                            await client.xdel(stream, msg_id)
                            continue

                        handler = handlers.get(task_name)
                        if not handler:
                            logger.warning(f"[Streams] No handler for task='{task_name}', skipping msg={msg_id}")
                            await client.xack(stream, group, msg_id)
                            await client.xdel(stream, msg_id)
                            continue

                        try:
                            logger.info(f"[Streams] Running task={task_name}  job_id={job_id}  msg={msg_id}")
                            payload.pop("job_id", None)
                            await handler(job_id=job_id, **payload)
                            await client.xack(stream, group, msg_id)
                            await client.xdel(stream, msg_id)
                            logger.info(f"[Streams] ACK+DEL  task={task_name}  job_id={job_id}  msg={msg_id}")
                        except Exception as exc:
                            logger.error(f"[Streams] FAIL task={task_name} job_id={job_id}: {exc}")

                            # Check delivery count for DLQ routing
                            delivery_count = await _get_delivery_count(client, stream, group, msg_id)
                            if delivery_count >= max_attempts:
                                await _publish_to_dlq(
                                    client, stream, msg_id, task_name,
                                    job_id, raw_payload, str(exc),
                                )
                                await client.xack(stream, group, msg_id)
                                await client.xdel(stream, msg_id)
                                logger.warning(
                                    f"[Streams] Message {msg_id} moved to DLQ after "
                                    f"{delivery_count} attempts"
                                )
                            # else: leave in PEL for redelivery

            except asyncio.CancelledError:
                logger.info("[Streams] Consumer shutting down...")
                break
            except aioredis.ResponseError as exc:
                if _is_nogroup_error(exc):
                    _nogroup_recover_count += 1
                    _now = asyncio.get_running_loop().time()
                    try:
                        await _ensure_group(client, stream, group)
                        if _now - _nogroup_last_log_time >= _NOGROUP_LOG_INTERVAL:
                            logger.warning(
                                f"[Streams] NOGROUP recovered — recreated group '{group}' on '{stream}'"
                                + (f" ({_nogroup_recover_count} recoveries)" if _nogroup_recover_count > 1 else "")
                            )
                            _nogroup_last_log_time = _now
                        _backoff_seconds = settings.REDIS_STREAM_BACKOFF_INITIAL_SECONDS
                        continue
                    except Exception as recreate_exc:
                        logger.error(
                            f"[Streams] Failed to recreate group '{group}': {recreate_exc}. "
                            f"Retrying in {_backoff_seconds:.0f}s..."
                        )
                        await asyncio.sleep(_backoff_seconds)
                        _backoff_seconds = min(_backoff_seconds * 2, _BACKOFF_MAX)
                else:
                    logger.error(
                        f"[Streams] Redis protocol error: {exc}. "
                        f"Retrying in {_backoff_seconds:.0f}s..."
                    )
                    await asyncio.sleep(_backoff_seconds)
                    _backoff_seconds = min(_backoff_seconds * 2, _BACKOFF_MAX)
            except (aioredis.ConnectionError, ConnectionError, OSError) as exc:
                logger.warning(
                    f"[Streams] Connection lost: {exc}. "
                    f"Retrying in {_backoff_seconds:.0f}s..."
                )
                await asyncio.sleep(_backoff_seconds)
                _backoff_seconds = min(_backoff_seconds * 2, _BACKOFF_MAX)
            except Exception as exc:
                logger.error(
                    f"[Streams] Consumer error: {exc}. "
                    f"Retrying in {_backoff_seconds:.0f}s..."
                )
                await asyncio.sleep(_backoff_seconds)
                _backoff_seconds = min(_backoff_seconds * 2, _BACKOFF_MAX)
    finally:
        pass  # Client is singleton, no longer close here


async def close_publisher_pool() -> None:
    """Gracefully close the module-level publisher connection pool. (Delegated)"""
    from shared_core.redis_client import close_pool
    await close_pool()
