"""
Loguru InterceptHandler
========================
Bridges stdlib logging → loguru so all libraries (uvicorn, fastapi, httpx, etc.)
emit structured loguru records.

Usage (in each service's main.py):
    from shared_core.intercept_handler import install_intercept_handler
    install_intercept_handler()
"""
import logging


class InterceptHandler(logging.Handler):
    """Route stdlib log records to loguru."""

    def emit(self, record):
        from loguru import logger

        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        frame, depth = logging.currentframe(), 2
        while frame is not None and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


def install_intercept_handler(
    logger_names: list[str] | None = None,
    level: int = logging.INFO,
) -> None:
    """Install InterceptHandler on the root logger and named loggers.

    Args:
        logger_names: Additional logger names to patch (e.g. ["uvicorn", "fastapi"]).
        level: Logging level for the root handler.
    """
    logging.basicConfig(handlers=[InterceptHandler()], level=level, force=True)
    for name in (logger_names or []):
        log = logging.getLogger(name)
        log.handlers = [InterceptHandler()]
        log.propagate = False
