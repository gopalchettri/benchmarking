# Centralizing all magic strings and queues into one place
import uuid

# ── Auth namespace ──
AUTH_NAMESPACE = uuid.UUID("a1b2c3d4-e5f6-7890-abcd-ef1234567890")

QUEUE_DOC_PROCESSING = "doc_processing"
QUEUE_AI_EXTRACTION = "ai_extraction"

STATE_QUEUED = "File Uploaded / Queued"
STATE_DOC_PROCESSING = "Starting Document Processing"
STATE_AI_EXTRACTION = "AI Extraction Running"
STATE_MERGE = "Merging to Storage Database"
STATE_COMPLETED = "AI Control Extraction Completed"
STATE_AI_EXTRACTION_FAILED = "AI Extraction Failed"
STATE_DOC_PROCESSING_FAILED = "Document Processing Failed"
STATE_STORAGE_FAILED = "Storage Failed"
STATE_STORAGE_COMPLETED = "Completed"

# Extraction review status — lifecycle of a machine-extracted control record
EXTRACTION_STATUS_MACHINE_DRAFT  = "machine_draft"   # just extracted by LLM, awaiting human review
EXTRACTION_STATUS_HUMAN_VERIFIED = "human_verified"  # reviewed and confirmed correct by a human
EXTRACTION_STATUS_REJECTED       = "rejected"        # reviewed and flagged as wrong; needs correction
