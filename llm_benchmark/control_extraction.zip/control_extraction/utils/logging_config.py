"""
Logging Configuration

Sets up structured logging for the Sub-Control Extraction Tool using Loguru.

Two modes:
- Development: colored, human-readable console output
- Production: JSON-structured output (for log aggregation tools like ELK/Loki)

Per-job logging:
  Each extraction job gets its own dedicated log file at:
    logs/jobs/{file_name}_{job_id}.log
  This makes it easy to find and review logs for a specific document.
"""

import re
import sys
from pathlib import Path
from typing import Optional, Dict
from loguru import logger
import json

__all__ = ["logger", "console", "setup_logging", "start_job_logging", "stop_job_logging", "get_job_logger"]

# Track active job log handlers for cleanup
_job_log_handlers: Dict[str, int] = {}


def _safe_console_sink(message: str) -> None:
    """Write console logs without crashing on non-UTF-8 Windows terminals."""
    try:
        sys.stdout.write(message)
    except UnicodeEncodeError:
        encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
        safe_message = message.encode(encoding, errors="backslashreplace").decode(encoding)
        sys.stdout.write(safe_message)
    sys.stdout.flush()


def setup_logging(service_name: str, log_level: str = "INFO", environment: str = "development", log_dir: Optional[str] = None):
    """
    Configures structured JSON logging for production or colored logging for development.

    Logs are written to:
    - Console (stdout)
    - File: logs/{service_name}.log (with rotation)

    Args:
        service_name: Name of the service for log identification
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        environment: 'production' or 'development'
        log_dir: Optional custom log directory path
    """
    logger.remove()  # Remove default handler

    # Determine log directory
    if log_dir:
        logs_path = Path(log_dir)
    else:
        # Default: create 'logs' directory in project root (control_extraction/)
        logs_path = Path(__file__).parent.parent / "logs"

    logs_path.mkdir(parents=True, exist_ok=True)

    # Sanitize service name for log filename
    safe_service_name = re.sub(r'[^\w\-.]', '_', service_name)
    log_file = logs_path / f"{safe_service_name}.log"

    # Console logging
    if environment.lower() == "production":
        # JSON Structured Logging for production
        def sink(message):
            record = message.record
            log_entry = {
                "timestamp": record["time"].isoformat(),
                "level": record["level"].name,
                "message": record["message"],
                "service": service_name,
                "module": record["name"],
                "function": record["function"],
                "line": record["line"],
                "extra": record["extra"],
            }
            if record["exception"]:
                log_entry["exception"] = str(record["exception"])
            sys.stdout.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
            sys.stdout.flush()  # M-5: prevent log loss on crash in buffered container stdout

        logger.add(sink, level=log_level)
    else:
        # Development Logging (Human Readable) - Console
        def console_format(record):
            fmt = "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> "
            if "job_id" in record["extra"]:
                fmt += "| <magenta>[{extra[job_id]}]</magenta> "
            fmt += "- <level>{message}</level>\n"
            return fmt

        logger.add(_safe_console_sink, format=console_format, level=log_level)

    # Get rotation/retention from config (with fallbacks for early init)
    try:
        from config import get_settings
        _settings = get_settings()
        rotation = _settings.LOG_ROTATION_SIZE
        retention = _settings.LOG_RETENTION_DAYS
    except Exception:
        from config import Settings
        rotation = Settings.model_fields["LOG_ROTATION_SIZE"].default
        retention_days = Settings.model_fields["LOG_RETENTION_DAYS"].default
        retention = f"{retention_days} days"

    def file_format(record):
        fmt = "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} "
        if "job_id" in record["extra"]:
            fmt += "| [{extra[job_id]}] "
        fmt += "- {message}\n"
        return fmt

    # File logging (always enabled) - with rotation
    logger.add(
        str(log_file),
        format=file_format,
        level=log_level,
        rotation=rotation,
        retention=retention,
        compression="zip",  # Compress rotated logs
        encoding="utf-8",
        enqueue=True,       # Thread-safe async writing
    )

    logger.info(f"Logging initialized for {service_name} in {environment} mode")
    logger.info(f"Log file: {log_file}")


def start_job_logging(
    job_id: str,
    file_name: str = "unknown",
    log_dir: Optional[str] = None,
    log_level: str = "DEBUG",
) -> str:
    """
    Start per-job logging. Creates a dedicated log file for this job.

    Log file path: logs/jobs/{file_name}_{job_id}.log

    Args:
        job_id: Unique job/document identifier
        file_name: Name of the file being processed (e.g., PDF filename without extension)
        log_dir: Optional custom log directory
        log_level: Logging level for job logs (default DEBUG for detailed tracing)

    Returns:
        Path to the job log file
    """
    # Sanitize inputs for filesystem safety
    safe_file_name = re.sub(r'[^\w\-.]', '_', file_name) or "unknown"
    safe_job_id = re.sub(r'[^\w\-.]', '_', job_id) or "unknown_job"

    # Determine log directory structure: logs/jobs/
    base_path = Path(log_dir) if log_dir else Path(__file__).parent.parent / "logs"
    job_log_path = base_path / "jobs"
    job_log_path.mkdir(parents=True, exist_ok=True)

    log_file = job_log_path / f"{safe_file_name}_{safe_job_id}.log"

    def job_file_format(record):
        fmt = "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} "
        if "job_id" in record["extra"]:
            fmt += "| [{extra[job_id]}] "
        fmt += "- {message}\n"
        return fmt

    # Add handler for this job — logs all messages during job execution
    handler_id = logger.add(
        str(log_file),
        format=job_file_format,
        level=log_level,
        encoding="utf-8",
        enqueue=True,
    )

    # Track handler for cleanup
    _job_log_handlers[job_id] = handler_id

    logger.info(f"Started job logging: {log_file}")
    return str(log_file)


def stop_job_logging(job_id: str) -> None:
    """
    Stop per-job logging and remove the handler.

    Args:
        job_id: Unique job/document identifier
    """
    if job_id in _job_log_handlers:
        handler_id = _job_log_handlers.pop(job_id)
        try:
            logger.remove(handler_id)
            logger.info(f"Stopped job logging for: {job_id}")
        except ValueError:
            pass  # Handler already removed


def console(msg: str, level: str = "info") -> None:
    """Log a message at the given level.

    Use this instead of bare ``print()`` so messages are captured by log
    aggregation in production. The logger sink already writes to stdout —
    calling print() separately would produce duplicate unstructured output
    in JSON log mode. (L-1)

    Args:
        msg: Message to log.
        level: Log level — "info", "warning", "error", "debug".
    """
    getattr(logger, level, logger.info)(msg)


def get_job_logger(job_id: str):
    """
    Get a logger bound with the job_id for context.

    Usage:
        job_log = get_job_logger("doc_123")
        job_log.info("Processing started")
    """
    return logger.bind(job_id=job_id)
