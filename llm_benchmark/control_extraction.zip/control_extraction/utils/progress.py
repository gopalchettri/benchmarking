"""
Phase-level progress reporting for long-running pipeline jobs.

Two services (`doc_processing`, `ai_extraction`) run multi-phase async work.
Existing loguru logs capture every detail but are too dense to read as a
"how far am I" view. This module adds a thin progress layer on top:

  - Each major phase is wrapped with ``tracker.phase("Loading PDF", weight=10)``.
  - A weighted % is printed at phase start AND end, including the elapsed
    seconds for the just-completed phase.
  - Long phases can call ``tracker.tick(current, total, label)`` to show
    sub-progress (e.g. "Group 5/27 extracted").
  - Output goes to stdout with a visible bracketed-bar format so it stands
    out from the dense INFO log lines streaming around it.

Format (single line, terminal-friendly):

  [████████░░░░░░░░░░░░  40%] ai_extraction · 27241589 ▸ TOC extraction (start)
  [██████████░░░░░░░░░░  50%] ai_extraction · 27241589 ▸ TOC extracted (32 entries) — 3.8s

Backward compatible: every existing logger.info() call continues to fire;
the tracker is purely additive. If callers don't use it, nothing changes.

This module deliberately has zero non-stdlib dependencies so it can be
imported from any service without pulling in loguru / rich / tqdm.
"""

from __future__ import annotations

import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterator, Optional


_BAR_WIDTH = 20  # number of cells in the progress bar


@dataclass
class _Phase:
    name: str
    weight: int  # contribution to overall % when complete
    started_at: float = 0.0
    ended_at: float = 0.0


@dataclass
class PhaseTracker:
    """Weighted multi-phase progress reporter.

    Args:
        service: Short service name shown in every line ("doc_processing").
        job_id:  Job UUID; only the first 8 chars are shown.
        phases:  Ordered list of (name, weight) tuples. Weights should sum
                 to 100 — the tracker normalises if they don't.

    Usage:
        tracker = PhaseTracker("ai_extraction", job_id, [
            ("Load profile", 5),
            ("Load blob", 5),
            ("TOC extraction", 15),
            ("Control extraction", 60),
            ("Post-processing", 10),
            ("Persist results", 5),
        ])

        with tracker.phase("Load profile"):
            await fetch_profile(...)

        # OR for sub-progress:
        with tracker.phase("Control extraction") as p:
            for i, group in enumerate(groups, 1):
                await extract(group)
                p.tick(i, len(groups), label=f"group {group.id}")
    """

    service: str
    job_id: str
    phases: list[tuple[str, int]]
    _phases: list[_Phase] = field(default_factory=list, init=False)
    _current_idx: int = field(default=-1, init=False)
    _started_at: float = field(default=0.0, init=False)

    def __post_init__(self) -> None:
        total = sum(w for _, w in self.phases) or 1
        # Re-normalise so weights sum to 100 even if caller's list doesn't.
        self._phases = [
            _Phase(name=n, weight=int(round(w * 100 / total))) for n, w in self.phases
        ]
        self._started_at = time.monotonic()
        self._emit(0, "started", elapsed=None)

    @contextmanager
    def phase(self, name: str) -> Iterator["PhaseTracker"]:
        """Enter a named phase. Emits start + end lines with elapsed time.

        If ``name`` doesn't match any registered phase, the phase still
        runs but its weight is 0 (no % advance). This keeps the tracker
        forgiving of drift between code and the registered phase list.
        """
        idx = next((i for i, p in enumerate(self._phases) if p.name == name), -1)
        if idx == -1:
            # Unknown phase — emit without advancing %.
            self._emit_message(self._completed_pct(), f"{name} (start)", None)
            yield self
            self._emit_message(self._completed_pct(), f"{name} (done)", None)
            return

        phase = self._phases[idx]
        self._current_idx = idx
        phase.started_at = time.monotonic()
        self._emit(self._completed_pct(), f"{name} (start)", elapsed=None)
        try:
            yield self
        finally:
            phase.ended_at = time.monotonic()
            elapsed = phase.ended_at - phase.started_at
            self._emit(
                self._completed_pct_through(idx),
                f"{name} (done)",
                elapsed=elapsed,
            )
            self._current_idx = -1

    def tick(self, current: int, total: int, label: str = "") -> None:
        """Sub-progress within the active phase.

        ``current`` and ``total`` describe sub-units (e.g. 5 of 27 page
        groups). The bar shows the *interpolated* overall %: completed
        prior phases + (current/total) of the active phase's weight.
        """
        if self._current_idx == -1 or total <= 0:
            return
        phase = self._phases[self._current_idx]
        ratio = max(0.0, min(1.0, current / total))
        completed_before = sum(p.weight for p in self._phases[: self._current_idx])
        pct = completed_before + ratio * phase.weight
        self._emit(pct, f"{phase.name} ({current}/{total}{(' — ' + label) if label else ''})", elapsed=None)

    def done(self, summary: str = "") -> None:
        """Mark overall completion. Emits a 100% line with total elapsed."""
        elapsed = time.monotonic() - self._started_at
        msg = f"complete{(' — ' + summary) if summary else ''}"
        self._emit(100, msg, elapsed=elapsed)

    # ── internal helpers ─────────────────────────────────────────────

    def _completed_pct(self) -> float:
        # Sum of weights of phases fully completed (ended_at > 0).
        return float(sum(p.weight for p in self._phases if p.ended_at > 0))

    def _completed_pct_through(self, idx: int) -> float:
        # Sum of weights through (and including) phase ``idx``.
        return float(sum(p.weight for p in self._phases[: idx + 1]))

    def _emit(self, pct: float, label: str, elapsed: Optional[float]) -> None:
        self._emit_message(pct, label, elapsed)

    def _emit_message(self, pct: float, label: str, elapsed: Optional[float]) -> None:
        pct = max(0.0, min(100.0, pct))
        filled = int(round(pct / 100.0 * _BAR_WIDTH))
        bar = "█" * filled + "░" * (_BAR_WIDTH - filled)
        short_id = (self.job_id or "")[:8] or "--------"
        suffix = f" — {elapsed:.1f}s" if elapsed is not None else ""
        line = f"[{bar} {pct:5.1f}%] {self.service} · {short_id} ▸ {label}{suffix}\n"
        try:
            sys.stdout.write(line)
            sys.stdout.flush()
        except UnicodeEncodeError:
            # Non-UTF-8 Windows terminals: degrade gracefully.
            encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
            sys.stdout.write(line.encode(encoding, errors="backslashreplace").decode(encoding))
            sys.stdout.flush()
