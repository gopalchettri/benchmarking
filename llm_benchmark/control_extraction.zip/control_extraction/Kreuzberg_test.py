"""
Manual Kreuzberg markdown test utility.

Usage:
    py services/doc_processing/Kreuzberg_test.py path/to/file.pdf
    py services/doc_processing/Kreuzberg_test.py path/to/file.pdf --preview-chars 2000
    # py Kreuzberg_test.py


What it does:
    - extracts the PDF with Kreuzberg in markdown mode
    - writes one combined markdown file with page markers
    - prints a short summary to the console
"""

from __future__ import annotations

import argparse
from pathlib import Path

import fitz
from kreuzberg import ExtractionConfig, PageConfig, extract_file_sync


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Manually test Kreuzberg markdown output.")
    parser.add_argument(
        "pdf",
        nargs="?",
        default=r"C:\Users\User\Documents\Development\control_extraction\frameworks\SAMA.pdf",
        help="Path to the PDF file",
    )
    parser.add_argument(
        "--preview-chars",
        type=int,
        default=1200,
        help="How many characters of the combined markdown preview to print",
    )
    return parser.parse_args()


def page_number_and_content(page) -> tuple[int, str]:
    """Normalize Kreuzberg page entries across dict/object return shapes."""
    if isinstance(page, dict):
        return int(page["page_number"]), page.get("content", "")
    return int(page.page_number), getattr(page, "content", "")


def main() -> int:
    args = parse_args()
    pdf_path = Path(args.pdf).resolve()
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    with fitz.open(pdf_path) as doc:
        if doc.is_encrypted:
            raise ValueError("PDF is password-protected. Provide an unencrypted PDF.")
        page_count = len(doc)

    output_dir = Path(r"C:\Users\User\Documents\Development\control_extraction")
    output_dir.mkdir(parents=True, exist_ok=True)

    config = ExtractionConfig(
        output_format="markdown",
        pages=PageConfig(extract_pages=True),
    )
    result = extract_file_sync(str(pdf_path), config=config)
    pages = result.pages or []
    page_map = {
        page_number: content
        for page_number, content in (page_number_and_content(page) for page in pages)
    }
    missing_pages = [pg for pg in range(1, page_count + 1) if pg not in page_map]

    combined_path = output_dir / f"{pdf_path.stem}_Kreuzberg.md"
    total_chars = 0
    with combined_path.open("w", encoding="utf-8") as combined:
        for pg in range(1, page_count + 1):
            text = page_map.get(pg, "")
            stripped = text.strip()
            total_chars += len(stripped)
            if stripped:
                combined.write(f"{text}\n\n<!-- page={pg}/{page_count} -->\n\n")

    combined_text = combined_path.read_text(encoding="utf-8")

    print(f"PDF: {pdf_path}")
    print(f"Expected pages: {page_count}")
    print(f"Kreuzberg pages: {len(page_map)}")
    print(f"Missing pages: {missing_pages if missing_pages else 'none'}")
    print(f"Combined markdown: {combined_path}")
    print(f"Total extracted chars: {total_chars:,}")
    print()
    print("Preview:")
    print("-" * 80)
    print(combined_text[: args.preview_chars])
    print("-" * 80)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
