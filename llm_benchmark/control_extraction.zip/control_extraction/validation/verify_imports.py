r"""
Targeted static import verification for the current microservice layout.
Run with: .\venv\Scripts\python.exe validation\verify_imports.py
"""
import importlib.util
import os
import sys

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
STORAGE = os.path.join(BASE, "services", "storage")
AI_EXT = os.path.join(BASE, "services", "ai_extraction")
DOC_PROC = os.path.join(BASE, "services", "doc_processing")
SHARED = os.path.join(BASE, "shared_core")

for path in (BASE, SHARED):
    if path not in sys.path:
        sys.path.insert(0, path)

PASS = 0
FAIL = 0


def check(label, fn):
    global PASS, FAIL
    try:
        fn()
        print(f"  [PASS] {label}")
        PASS += 1
    except Exception as exc:
        print(f"  [FAIL] {label}")
        print(f"         {type(exc).__name__}: {exc}")
        FAIL += 1


def _load_module(module_name: str, path: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


print("=" * 60)
print("Layer 0: config.py")
print("=" * 60)
from config import get_settings

settings = get_settings()
print(f"  [PASS] config.py  env={settings.ENVIRONMENT}  provider={settings.LLM_PROVIDER}")

check("config - DB_BACKEND setting exists", lambda: getattr(settings, "DB_BACKEND"))
check("config - MAX_FILE_UPLOAD_BYTES = 100MB", lambda: (
    None if settings.MAX_FILE_UPLOAD_BYTES == 104857600 else (_ for _ in ()).throw(
        AssertionError(f"Expected 104857600, got {settings.MAX_FILE_UPLOAD_BYTES}")
    )
))
check("config - BLOB_MAX_BYTES = 100MB", lambda: (
    None if settings.BLOB_MAX_BYTES == 104857600 else (_ for _ in ()).throw(
        AssertionError(f"Expected 104857600, got {settings.BLOB_MAX_BYTES}")
    )
))
check("config - BLOB_READ_TIMEOUT_SECONDS = 120", lambda: (
    None if settings.BLOB_READ_TIMEOUT_SECONDS == 120 else (_ for _ in ()).throw(
        AssertionError(f"Expected 120, got {settings.BLOB_READ_TIMEOUT_SECONDS}")
    )
))
check("config - DOCLING_ARTIFACTS_PATH setting exists", lambda: getattr(settings, "DOCLING_ARTIFACTS_PATH") is not None)
check("config - DLQ_MAX_DELIVERY_ATTEMPTS setting exists", lambda: getattr(settings, "DLQ_MAX_DELIVERY_ATTEMPTS"))

print()
print("=" * 60)
print("Layer 1: shared_core")
print("=" * 60)
check("storage_port - LocalBlobStorage", lambda: __import__("shared_core.interfaces.storage_port", fromlist=["LocalBlobStorage"]))
check("storage_port - AzureBlobStorage", lambda: __import__("shared_core.interfaces.storage_port", fromlist=["AzureBlobStorage"]))
check("telemetry - setup_telemetry, instrument_fastapi, instrument_httpx, get_tracer", lambda: __import__("shared_core.telemetry", fromlist=["setup_telemetry"]))
check("middlewares.tracing", lambda: __import__("shared_core.middlewares.tracing", fromlist=["RequestTracingMiddleware"]))
check("middlewares.rate_limiting", lambda: __import__("shared_core.middlewares.rate_limiting", fromlist=["RateLimitingMiddleware"]))

print()
print("=" * 60)
print("Layer 2: ai_extraction service")
print("=" * 60)


def _check_ai_models():
    mod = _load_module("ai_models_verify", os.path.join(AI_EXT, "models.py"))
    assert hasattr(mod, "ExtractionsWrapper")
    assert hasattr(mod, "SubControl")
    assert hasattr(mod, "ControlExtraction")
    required_fields = {"control_id", "title", "sections", "sub_controls", "source_pages"}
    assert required_fields.issubset(set(mod.ControlExtraction.model_fields))


def _check_ai_prompts():
    if AI_EXT not in sys.path:
        sys.path.insert(0, AI_EXT)
    import importlib

    prompts = importlib.import_module("prompts")
    assert hasattr(prompts, "get_subcontrol_prompts")
    assert hasattr(prompts, "get_toc_prompts")
    assert hasattr(prompts, "load_framework_prompts")


check("models - SubControl, ControlExtraction, ExtractionsWrapper", _check_ai_models)
check("prompts - get_subcontrol_prompts, get_toc_prompts, load_framework_prompts", _check_ai_prompts)

print()
print("=" * 60)
print("Layer 3: storage service")
print("=" * 60)


def _check_storage_models():
    mod = _load_module("storage_models_verify", os.path.join(STORAGE, "models.py"))
    assert hasattr(mod, "FrameworkProfileModel")
    assert hasattr(mod, "CanonicalControlModel")
    assert hasattr(mod, "AuditLogModel")


check("storage/models - FrameworkProfileModel, CanonicalControlModel, AuditLogModel", _check_storage_models)

print()
print("=" * 60)
print("Layer 4: doc_processing service")
print("=" * 60)


def _check_doc_pdf_extractor():
    mod = _load_module("doc_pdf_extractor_verify", os.path.join(DOC_PROC, "pdf_extractor.py"))
    assert hasattr(mod, "PDFExtractor")


check("pdf_extractor - PDFExtractor", _check_doc_pdf_extractor)

print()
print("=" * 60)
total = PASS + FAIL
print(f"RESULT: {PASS}/{total} checks passed ({FAIL} failed)")
print("=" * 60)
sys.exit(0 if FAIL == 0 else 1)
