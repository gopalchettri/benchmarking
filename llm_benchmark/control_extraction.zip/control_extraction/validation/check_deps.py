import re
import sys, asyncio
sys.path.insert(0, '.')
sys.path.insert(0, 'shared_core')

from config import get_settings
settings = get_settings()


def _mask_url(url: str) -> str:
    """Mask credentials in connection URLs for safe display."""
    return re.sub(r'://([^:]*):([^@]*)@', r'://\1:****@', url)


def _ensure_mysql_database() -> bool:
    """Auto-create the MySQL database if it doesn't exist. Returns True if created."""
    if settings.DB_BACKEND != "mysql":
        return False
    try:
        import pymysql
        conn = pymysql.connect(
            host=settings.MYSQL_HOST,
            port=settings.MYSQL_PORT,
            user=settings.MYSQL_USER,
            password=settings.MYSQL_PASSWORD,
        )
        cur = conn.cursor()
        db_name = re.sub(r'[^a-zA-Z0-9_]', '', settings.MYSQL_DB)
        cur.execute(
            f"CREATE DATABASE IF NOT EXISTS `{db_name}` "
            f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


async def main():
    from shared_core.health import check_redis, check_database

    print("=" * 55)
    print("  Dependency Health Check")
    print("=" * 55)

    # Redis
    r = await check_redis(settings.REDIS_URL)
    mark = "OK" if r['status'] == 'ok' else "FAIL"
    print(f"\n  [{mark}] Redis")
    print(f"       URL     : {_mask_url(settings.REDIS_URL)}")
    print(f"       Detail  : {r['detail']}")
    print(f"       Latency : {r['latency_ms']} ms")

    # MySQL
    p = await check_database(settings.DATABASE_URL)
    if p['status'] == 'ok':
        mark = "OK"
        detail = p['detail']
    else:
        # Auto-create the database if it's just missing
        if "does not exist" in p['detail'].lower() or "unknown database" in p['detail'].lower():
            if _ensure_mysql_database():
                # Re-check after creation
                p = await check_database(settings.DATABASE_URL)
                if p['status'] == 'ok':
                    mark = "OK"
                    detail = f"{p['detail']} (database was auto-created)"
                else:
                    mark = "FAIL"
                    detail = p['detail']
            else:
                mark = "FAIL"
                detail = p['detail']
        else:
            mark = "FAIL"
            detail = p['detail']

    print(f"\n  [{mark}] MySQL")
    print(f"       URL     : {_mask_url(settings.DATABASE_URL)}")
    print(f"       Detail  : {detail}")
    print(f"       Latency : {p['latency_ms']} ms")

    print("\n" + "=" * 55)
    overall = "ok" if r['status'] == 'ok' and p['status'] == 'ok' else "degraded"
    print(f"  Overall: {overall.upper()}")
    print("=" * 55)

asyncio.run(main())
