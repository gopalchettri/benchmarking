"""
Extraction Validation Script

Validates a JSON extraction output file for structural correctness,
hierarchy consistency, and framework-specific expectations.

Usage (from project root):
    python -m validation.validate_extraction output/SAMA_CSF_20260225_165801.json
    python -m validation.validate_extraction output/SAMA_CSF_20260225_165801.json --verbose
    python -m validation.validate_extraction output/SAMA_CSF_20260225_165801.json --strict
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Set

# Add project root to path so models.py is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models import ExtractionResult, SubControl, count_all_sub_controls


# ---------------------------------------------------------------------------
# Issue tracking
# ---------------------------------------------------------------------------

class Issue:
    """A single validation issue."""
    def __init__(self, control_id: str, level: str, check: str, detail: str):
        self.control_id = control_id
        self.level = level        # "ERROR" or "WARN"
        self.check = check        # short category label
        self.detail = detail


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def flatten_sub_controls(scs: List[SubControl]) -> List[SubControl]:
    """Recursively flatten sub-controls."""
    flat: List[SubControl] = []
    for sc in scs:
        flat.append(sc)
        flat.extend(flatten_sub_controls(sc.children))
    return flat


def collect_ids(scs: List[SubControl]) -> List[str]:
    """Collect all sub-control IDs recursively."""
    return [sc.id for sc in flatten_sub_controls(scs)]


def numbering_scheme(items: List[str]) -> str:
    """Classify a set of number labels: 'numeric', 'alpha', 'roman', or 'mixed'."""
    if not items:
        return "empty"
    # Allow dot-separated compound numbers like "4.1", "4.2.6"
    numeric = all(re.match(r'^[\d.]+$', n) for n in items)
    alpha = all(re.match(r'^[a-zA-Z]$', n) for n in items)
    roman = all(re.match(r'^[ivxlcdm]+$', n.lower()) for n in items)
    if numeric:
        return "numeric"
    if alpha:
        return "alpha"
    if roman:
        return "roman"
    return "mixed"


# ---------------------------------------------------------------------------
# Check functions
# ---------------------------------------------------------------------------

def check_structural(result: ExtractionResult) -> List[Issue]:
    """Framework-agnostic structural checks."""
    issues: List[Issue] = []
    seen_ids: Set[str] = set()

    for ext in result.extractions:
        cid = ext.control_id

        # Duplicate control_id
        if cid in seen_ids:
            issues.append(Issue(cid, "ERROR", "dup-control", f"Duplicate control_id: {cid}"))
        seen_ids.add(cid)

        # Empty required fields
        if not ext.title.strip():
            issues.append(Issue(cid, "ERROR", "empty-title", "Title is empty"))
        if not ext.control_statement.strip():
            issues.append(Issue(cid, "ERROR", "empty-stmt", "control_statement is empty"))

        # source_pages
        if not ext.source_pages:
            issues.append(Issue(cid, "WARN", "no-pages", "source_pages is empty"))

        # verbatim check
        if ext.verbatim_verified is not True:
            issues.append(Issue(cid, "WARN", "verbatim", f"verbatim_verified={ext.verbatim_verified}"))

        # control_statement == sub_control text
        cs_norm = ext.control_statement.strip().rstrip(".").lower()
        for sc in ext.sub_controls:
            sc_norm = sc.text.strip().rstrip(".").lower()
            if cs_norm and cs_norm == sc_norm:
                issues.append(Issue(cid, "ERROR", "stmt-dup",
                    f"control_statement identical to sub_control {sc.id}"))

        # Sections that duplicate sub_controls text (framework-agnostic)
        if ext.sub_controls:
            sc_texts = " ".join(
                sc.text.lower() for sc in flatten_sub_controls(ext.sub_controls)
            )
            sc_words = set(sc_texts.split())
            for key, value in ext.sections.items():
                sec_words = set(value.lower().split())
                if len(sec_words) >= 20 and sc_words:
                    overlap = len(sec_words & sc_words) / len(sec_words)
                    if overlap > 0.4:
                        issues.append(Issue(cid, "WARN", "section-overlap",
                            f"Section '{key}' has {overlap:.0%} word overlap "
                            f"with sub_controls — may be duplicated"))

        # Sub-control ID prefix
        all_scs = flatten_sub_controls(ext.sub_controls)
        sc_ids_seen: Set[str] = set()
        for sc in all_scs:
            if not sc.id.startswith(cid):
                issues.append(Issue(cid, "ERROR", "id-prefix",
                    f"Sub-control {sc.id} doesn't start with parent {cid}"))
            if sc.id in sc_ids_seen:
                issues.append(Issue(cid, "ERROR", "dup-sc-id",
                    f"Duplicate sub_control ID: {sc.id}"))
            sc_ids_seen.add(sc.id)

        # total_sub_controls match
        actual = count_all_sub_controls(ext.sub_controls)
        if ext.total_sub_controls != actual:
            issues.append(Issue(cid, "ERROR", "count-mismatch",
                f"total_sub_controls={ext.total_sub_controls} but actual={actual}"))

    return issues


def check_hierarchy(result: ExtractionResult) -> List[Issue]:
    """Check parent-child ID consistency and numbering schemes."""
    issues: List[Issue] = []

    def check_level(cid: str, parent_id: str, children: List[SubControl], depth: int):
        if not children:
            return

        # Check number field matches terminal segment of ID
        for sc in children:
            # The ID should end with the number (after last separator).
            # For simple numbers like "a", the terminal of "3.1.4.4.a" is "a".
            # For compound numbers like "4.1", the ID "3.3.13.4.1" ends with "4.1"
            # so we check if the ID ends with ".{number}" or equals the number.
            if sc.id and sc.number:
                if not sc.id.endswith(f".{sc.number}") and sc.id != sc.number:
                    issues.append(Issue(cid, "WARN", "id-number",
                        f"{sc.id}: doesn't end with number '{sc.number}'"))

            # Children IDs should start with parent sc.id
            for child in sc.children:
                if not child.id.startswith(sc.id):
                    issues.append(Issue(cid, "ERROR", "child-prefix",
                        f"Child {child.id} doesn't start with parent {sc.id}"))

            check_level(cid, sc.id, sc.children, depth + 1)

        # Check for mixed numbering at the same level
        numbers = [sc.number for sc in children]
        scheme = numbering_scheme(numbers)
        if scheme == "mixed":
            issues.append(Issue(cid, "WARN", "mixed-numbers",
                f"Mixed numbering at level under {parent_id}: {numbers}"))

    for ext in result.extractions:
        check_level(ext.control_id, ext.control_id, ext.sub_controls, 0)

    return issues


def check_sections(result: ExtractionResult) -> List[Issue]:
    """Check section content quality."""
    issues: List[Issue] = []
    numbered_pattern = re.compile(r'^\s*(\d+[\.\)]\s|[a-z][\.\)]\s|\([a-z]\)\s)', re.IGNORECASE)

    for ext in result.extractions:
        for key, value in ext.sections.items():
            if not key.strip():
                issues.append(Issue(ext.control_id, "ERROR", "empty-sec-key",
                    "Section has empty key"))
            if not value.strip():
                issues.append(Issue(ext.control_id, "ERROR", "empty-sec-val",
                    f"Section '{key}' has empty value"))
                continue

            # Check if section text is mostly numbered items (should be in sub_controls)
            lines = [l for l in value.split("\n") if l.strip()]
            if len(lines) >= 3:
                numbered_lines = sum(1 for l in lines if numbered_pattern.match(l.strip()))
                ratio = numbered_lines / len(lines)
                if ratio > 0.5:
                    issues.append(Issue(ext.control_id, "WARN", "numbered-section",
                        f"Section '{key}' has {ratio:.0%} numbered lines "
                        f"({numbered_lines}/{len(lines)}) — may belong in sub_controls"))

    return issues


def check_parent_contamination(result: ExtractionResult) -> List[Issue]:
    """Detect parent/domain-level entries that should have been filtered."""
    issues: List[Issue] = []
    all_ids = {e.control_id for e in result.extractions}

    for ext in result.extractions:
        cid = ext.control_id
        for other_id in all_ids:
            if other_id == cid:
                continue
            if other_id.startswith(cid):
                remainder = other_id[len(cid):]
                if remainder and remainder[0] in '.-(/: _':
                    issues.append(Issue(cid, "WARN", "parent-entry",
                        f"'{cid}' appears to be a parent of '{other_id}' "
                        f"-- should it be a top-level extraction?"))
                    break

    return issues


def check_sama_specific(result: ExtractionResult) -> List[Issue]:
    """SAMA-specific checks — only run if framework name contains 'SAMA'."""
    if "SAMA" not in result.framework_name.upper():
        return []

    issues: List[Issue] = []

    # ToC vs processed count
    if result.total_controls_in_toc is not None:
        diff = result.controls_processed - result.total_controls_in_toc
        if diff < 0:
            issues.append(Issue("GLOBAL", "ERROR", "toc-missing",
                f"Processed {result.controls_processed} but ToC has "
                f"{result.total_controls_in_toc} — {-diff} controls missing"))
        elif diff > 2:
            issues.append(Issue("GLOBAL", "WARN", "toc-extra",
                f"Processed {result.controls_processed} vs ToC "
                f"{result.total_controls_in_toc} — {diff} extra"))

    # Every SAMA control should have Principle and Objective
    for ext in result.extractions:
        sec_keys = {k.lower() for k in ext.sections}
        if "principle" not in sec_keys:
            issues.append(Issue(ext.control_id, "WARN", "no-principle",
                "Missing 'Principle' section (expected for SAMA)"))
        if "objective" not in sec_keys:
            issues.append(Issue(ext.control_id, "WARN", "no-objective",
                "Missing 'Objective' section (expected for SAMA)"))

    return issues


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

def print_report(
    result: ExtractionResult,
    all_issues: List[Issue],
    verbose: bool = False,
):
    """Print a formatted validation report."""
    # Color codes
    RED = "\033[91m"
    YELLOW = "\033[93m"
    GREEN = "\033[92m"
    BOLD = "\033[1m"
    RESET = "\033[0m"

    total_sc = sum(count_all_sub_controls(e.sub_controls) for e in result.extractions)
    errors = [i for i in all_issues if i.level == "ERROR"]
    warns = [i for i in all_issues if i.level == "WARN"]

    # Header
    print(f"\n{BOLD}{'='*70}{RESET}")
    print(f"{BOLD}  Extraction Validation Report{RESET}")
    print(f"{BOLD}{'='*70}{RESET}")
    print(f"  Framework:    {result.framework_name}")
    print(f"  Controls:     {result.controls_processed}")
    print(f"  Sub-controls: {total_sc}")
    print(f"  ToC expected: {result.total_controls_in_toc or 'N/A'}")
    print(f"  Errors:       {RED}{len(errors)}{RESET}" if errors else f"  Errors:       {GREEN}0{RESET}")
    print(f"  Warnings:     {YELLOW}{len(warns)}{RESET}" if warns else f"  Warnings:     {GREEN}0{RESET}")
    print()

    # Per-control summary table
    issues_by_ctrl: Dict[str, List[Issue]] = {}
    for issue in all_issues:
        issues_by_ctrl.setdefault(issue.control_id, []).append(issue)

    print(f"  {BOLD}{'CTRL':<12} {'TITLE':<40} {'SC':>4} {'SECTIONS':<25} {'STATUS'}{RESET}")
    print(f"  {'-'*12} {'-'*40} {'-'*4} {'-'*25} {'-'*10}")

    for ext in result.extractions:
        sc_count = count_all_sub_controls(ext.sub_controls)
        sec_list = ", ".join(ext.sections.keys()) if ext.sections else "(none)"
        if len(sec_list) > 24:
            sec_list = sec_list[:22] + ".."

        ctrl_issues = issues_by_ctrl.get(ext.control_id, [])
        ctrl_errors = [i for i in ctrl_issues if i.level == "ERROR"]
        ctrl_warns = [i for i in ctrl_issues if i.level == "WARN"]

        if ctrl_errors:
            status = f"{RED}FAIL ({len(ctrl_errors)}E){RESET}"
        elif ctrl_warns:
            status = f"{YELLOW}WARN ({len(ctrl_warns)}W){RESET}"
        else:
            status = f"{GREEN}PASS{RESET}"

        title_display = ext.title[:39] if len(ext.title) > 39 else ext.title
        print(f"  {ext.control_id:<12} {title_display:<40} {sc_count:>4} {sec_list:<25} {status}")

        # Show issues for this control
        if ctrl_issues and (verbose or ctrl_errors):
            for issue in ctrl_issues:
                color = RED if issue.level == "ERROR" else YELLOW
                print(f"    {color}{issue.level:<5}{RESET} [{issue.check}] {issue.detail}")

    # Global issues
    global_issues = issues_by_ctrl.get("GLOBAL", [])
    if global_issues:
        print(f"\n  {BOLD}Global Issues:{RESET}")
        for issue in global_issues:
            color = RED if issue.level == "ERROR" else YELLOW
            print(f"    {color}{issue.level:<5}{RESET} [{issue.check}] {issue.detail}")

    # Footer
    print(f"\n{'='*70}")
    if errors:
        print(f"  {RED}{BOLD}FAILED{RESET} — {len(errors)} error(s), {len(warns)} warning(s)")
    elif warns:
        print(f"  {YELLOW}{BOLD}PASSED with warnings{RESET} — {len(warns)} warning(s)")
    else:
        print(f"  {GREEN}{BOLD}PASSED{RESET} — all checks clean")
    print(f"{'='*70}\n")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def validate(json_path: str, verbose: bool = False, strict: bool = False) -> int:
    """Run all validation checks and return exit code (0=pass, 1=fail)."""
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    result = ExtractionResult.model_validate(data)

    all_issues: List[Issue] = []
    all_issues.extend(check_structural(result))
    all_issues.extend(check_hierarchy(result))
    all_issues.extend(check_sections(result))
    all_issues.extend(check_parent_contamination(result))
    all_issues.extend(check_sama_specific(result))

    print_report(result, all_issues, verbose=verbose)

    errors = [i for i in all_issues if i.level == "ERROR"]
    warns = [i for i in all_issues if i.level == "WARN"]

    if errors:
        return 1
    if strict and warns:
        return 1
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Validate extraction JSON output")
    parser.add_argument("json_file", help="Path to the extraction JSON file")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Show per-control detail even for passing controls")
    parser.add_argument("--strict", "-s", action="store_true",
                        help="Treat warnings as errors (exit code 1)")
    args = parser.parse_args()

    sys.exit(validate(args.json_file, verbose=args.verbose, strict=args.strict))
