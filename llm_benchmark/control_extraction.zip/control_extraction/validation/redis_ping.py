import redis, sys
from config import get_settings

settings = get_settings()
try:
    r = redis.Redis.from_url(
        settings.REDIS_URL,
        socket_connect_timeout=settings.REDIS_PING_TIMEOUT_SECONDS,
        decode_responses=True,
    )
    pong = r.ping()
    info = r.info('server')
    version = info['redis_version']
    mode = info['redis_mode']
    print(f'[OK] Redis connected  version={version}  mode={mode}')
    # Test Streams API (requires Redis >= 5.0)
    r.xadd('_test_stream', {'k': 'v'})
    r.delete('_test_stream')
    print('[OK] Redis Streams XADD works (Redis Streams supported)')
    print('[OK] All checks passed - ready for use')
except Exception as e:
    print(f'[FAIL] {e}')
    sys.exit(1)
