"""Tests for JWT auth middleware.

STATUS: Skipped — `shared_core.middlewares.auth` does not exist in the
current codebase. The `shared_core.middlewares` package currently ships
only `rate_limiting.py` and `tracing.py`. JWT auth was part of an earlier
design that was removed or deferred. Unskip once the `auth` middleware
module is added back.
"""

import pytest

pytest.skip(
    "shared_core.middlewares.auth module not present in current codebase; "
    "see module docstring.",
    allow_module_level=True,
)

from fastapi import FastAPI, Request  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from shared_core.middlewares.auth import JWTAuthMiddleware, PUBLIC_PATHS  # noqa: E402


def _make_app(jwt_secret=None):
    """Create a minimal FastAPI app with JWT middleware."""
    app = FastAPI()
    app.add_middleware(JWTAuthMiddleware, jwt_secret=jwt_secret)

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/api/v1/test")
    async def test_endpoint(request: Request):
        return {
            "user_id": getattr(request.state, "user_id", None),
            "roles": getattr(request.state, "roles", []),
        }

    return app


class TestJWTAuthMiddleware:
    """JWT authentication middleware tests."""

    def test_public_paths_skip_auth(self):
        app = _make_app(jwt_secret="secret")
        client = TestClient(app)
        resp = client.get("/health")
        assert resp.status_code == 200

    def test_dev_mode_no_secret(self):
        """When JWT_SECRET is None, dev mode: no auth, no elevated roles."""
        app = _make_app(jwt_secret=None)
        client = TestClient(app)
        resp = client.get("/api/v1/test")
        assert resp.status_code == 200
        data = resp.json()
        assert data["user_id"] == "dev-user"
        assert data["roles"] == []

    def test_valid_jwt_token(self):
        """Valid JWT token extracts user_id and roles."""
        import jwt
        secret = "test-secret-key"
        token = jwt.encode(
            {"sub": "user123", "roles": ["analyst"]},
            secret,
            algorithm="HS256",
        )
        app = _make_app(jwt_secret=secret)
        client = TestClient(app)
        resp = client.get("/api/v1/test", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["user_id"] == "user123"
        assert "analyst" in data["roles"]
