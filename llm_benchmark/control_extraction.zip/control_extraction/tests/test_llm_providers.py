from types import SimpleNamespace

import pytest

from config import Settings
from llm.providers import AzureOpenAIProvider


def _fake_response(
    *,
    content: str | None,
    finish_reason: str,
    prompt_tokens: int,
    completion_tokens: int,
    refusal: str | None = None,
):
    usage = SimpleNamespace(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens,
    )
    message = SimpleNamespace(content=content, refusal=refusal)
    choice = SimpleNamespace(message=message, finish_reason=finish_reason)
    return SimpleNamespace(choices=[choice], usage=usage)


class _FakeChatCompletions:
    def __init__(self, responses):
        self._responses = list(responses)
        self.calls = []

    async def create(self, **kwargs):
        self.calls.append(kwargs)
        if not self._responses:
            raise AssertionError("No fake responses left for Azure client")
        return self._responses.pop(0)


class _FakeAzureClient:
    def __init__(self, responses):
        self.chat = SimpleNamespace(completions=_FakeChatCompletions(responses))


def _make_provider(settings: Settings, responses) -> AzureOpenAIProvider:
    provider = object.__new__(AzureOpenAIProvider)
    provider.config = settings
    provider.deployment = settings.AZURE_OPENAI_DEPLOYMENT_NAME
    provider.model_context_tokens = settings.LLM_MODEL_CONTEXT_TOKENS
    provider.max_output_tokens = settings.LLM_MAX_OUTPUT_TOKENS
    provider.azure_client = _FakeAzureClient(responses)
    provider.client = None
    return provider


@pytest.mark.asyncio
async def test_azure_uses_temperature_from_settings_when_model_supports_it():
    settings = Settings(
        AZURE_OPENAI_API_KEY="test-key",
        AZURE_OPENAI_ENDPOINT="https://example.openai.azure.com",
        AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4o-mini",
        AZURE_OPENAI_API_VERSION="2024-12-01-preview",
        LLM_TEMPERATURE=0.35,
        LLM_REASONING_EFFORT="low",
    )
    provider = _make_provider(
        settings,
        responses=[
            _fake_response(
                content='{"controls":[]}',
                finish_reason="stop",
                prompt_tokens=50,
                completion_tokens=25,
            ),
        ],
    )

    await provider._execute_inference("system prompt", "user prompt", 256)

    calls = provider.azure_client.chat.completions.calls
    assert len(calls) == 1
    assert calls[0]["temperature"] == 0.35


@pytest.mark.asyncio
async def test_azure_retries_empty_content_when_completion_budget_is_exhausted():
    settings = Settings(
        AZURE_OPENAI_API_KEY="test-key",
        AZURE_OPENAI_ENDPOINT="https://example.openai.azure.com",
        AZURE_OPENAI_DEPLOYMENT_NAME="gpt-5-mini",
        AZURE_OPENAI_API_VERSION="2024-12-01-preview",
        LLM_TEMPERATURE=1.0,
        LLM_REASONING_EFFORT="low",
        LLM_MAX_OUTPUT_TOKENS=4096,
    )
    provider = _make_provider(
        settings,
        responses=[
            _fake_response(
                content=None,
                finish_reason="length",
                prompt_tokens=994,
                completion_tokens=2048,
            ),
            _fake_response(
                content='{"controls":[]}',
                finish_reason="stop",
                prompt_tokens=994,
                completion_tokens=512,
            ),
        ],
    )

    content, parsed_content, prompt_tokens, completion_tokens, total_tokens = await provider._execute_inference(
        "system prompt",
        "user prompt",
        2048,
    )

    assert content == '{"controls":[]}'
    assert parsed_content == {}
    assert prompt_tokens == 994
    assert completion_tokens == 512
    assert total_tokens == 1506

    calls = provider.azure_client.chat.completions.calls
    assert len(calls) == 2
    assert "temperature" not in calls[0]
    assert calls[0]["max_completion_tokens"] == 2048
    assert calls[0]["reasoning_effort"] == "low"
    assert "temperature" not in calls[1]
    assert calls[1]["max_completion_tokens"] == 4096
    assert calls[1]["reasoning_effort"] == "minimal"


def test_settings_accept_minimal_reasoning_effort():
    settings = Settings(LLM_REASONING_EFFORT="minimal")
    assert settings.LLM_REASONING_EFFORT == "minimal"
