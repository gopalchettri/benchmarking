"""Tests for discovery window auto-split on truncation.

The discovery phase scans body pages in windows looking for control IDs.
When a reasoning model (gpt-5-mini, o1, o3, ...) is used with a tight
DISCOVERY_MAX_TOKENS ceiling, the response can truncate mid-JSON. The
scanner detects this and bisects the window rather than retrying the
whole call at a larger budget.

These tests cover:
  - The truncation heuristic (_looks_like_truncation)
  - Per-call success / truncation / hard-error classification
  - Recursive window bisection with parallel halves
  - Terminal condition on 1-page windows (accept partial)
  - Max-split-depth safeguard
  - Dedup of merged results from sibling sub-windows
  - reasoning_effort='minimal' is actually passed to the provider

We don't hit real Azure here; we drive a fake provider that returns
canned LLMResponse objects or raises canned exceptions per window.
"""
from __future__ import annotations

import asyncio
import os
import sys
from types import SimpleNamespace
from typing import Any, Optional

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "services", "ai_extraction"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "shared_core"))

from core.exceptions import EmptyResponseError, UnparseableJSONError
from extraction import discovery as disco
from extraction.discovery import (
    _looks_like_truncation,
    discover_controls_from_body,
)


# ────────────────────────────────────────────────────────────────────────
# Heuristic tests — cheap, no fixtures needed
# ────────────────────────────────────────────────────────────────────────


class TestLooksLikeTruncation:
    """Verify the truncation classifier catches real-world error messages
    and rejects unrelated failures."""

    def test_max_tokens_phrase(self):
        assert _looks_like_truncation(
            Exception("The output is incomplete due to max_tokens length limit")
        ) is True

    def test_max_completion_tokens_phrase(self):
        assert _looks_like_truncation(
            Exception("max_completion_tokens reached")
        ) is True

    def test_finish_reason_length(self):
        assert _looks_like_truncation(
            Exception("finish_reason='length' completion_tokens=6144")
        ) is True

    def test_unrelated_connection_error(self):
        assert _looks_like_truncation(
            Exception("Connection refused by remote host")
        ) is False

    def test_unrelated_auth_error(self):
        assert _looks_like_truncation(
            Exception("401 Unauthorized")
        ) is False

    def test_case_insensitive(self):
        assert _looks_like_truncation(
            Exception("MAX_TOKENS length limit")
        ) is True


# ────────────────────────────────────────────────────────────────────────
# Fake provider + rate limiter for end-to-end discovery tests
# ────────────────────────────────────────────────────────────────────────


class _FakeRateLimiter:
    """No-op rate limiter."""

    async def acquire(self) -> None:
        return None


class _FakeLLMResponse:
    """Stand-in for llm.providers.LLMResponse."""

    def __init__(self, *, content: dict, truncated: bool = False):
        self.content = content
        self.prompt_tokens = 100
        self.completion_tokens = 200
        self.total_tokens = 300
        self.model = "fake"
        self.truncated = truncated


class _FakeProvider:
    """Scripted provider that returns canned responses per window key.

    The script maps (w_start, w_end) → either an LLMResponse or an
    Exception instance to raise. Each call records what was invoked.
    """

    def __init__(self, script: dict[tuple[int, int], Any]):
        self.script = dict(script)
        self.calls: list[dict[str, Any]] = []
        self.model_name = "fake-model"

    async def generate_json_with_metrics(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model=None,
        reasoning_effort: Optional[str] = None,
    ) -> _FakeLLMResponse:
        # Extract the page range from the user prompt. Discovery prompts
        # wrap content in [PAGE N] headers; find the first and last.
        import re
        page_nums = [int(m.group(1)) for m in re.finditer(r"\[PAGE (\d+)\]", user_prompt)]
        key = (min(page_nums), max(page_nums)) if page_nums else (0, 0)
        self.calls.append({
            "key": key,
            "max_tokens": max_tokens,
            "reasoning_effort": reasoning_effort,
        })
        if key not in self.script:
            raise AssertionError(f"No scripted response for window {key}")
        canned = self.script[key]
        if isinstance(canned, Exception):
            raise canned
        return canned


def _make_config(
    *,
    window_size: int = 4,
    discovery_max_tokens: int = 2048,
    context_tokens: int = 128_000,
    max_split_depth: int = 3,
    rate_burst: int = 5,
    reasoning: str = "minimal",
    overlap: int = 1,
    max_calls: int = 64,
) -> SimpleNamespace:
    return SimpleNamespace(
        WINDOW_OVERLAP=overlap,
        DISCOVERY_WINDOW_SIZE=window_size,
        DISCOVERY_MAX_LLM_CALLS=max_calls,
        DISCOVERY_MAX_TOKENS=discovery_max_tokens,
        LLM_MODEL_CONTEXT_TOKENS=context_tokens,
        LLM_RATE_LIMIT_BURST=rate_burst,
        DISCOVERY_REASONING_EFFORT=reasoning,
        DISCOVERY_MAX_SPLIT_DEPTH=max_split_depth,
    )


def _make_content(pages: list[int]) -> str:
    """Build a content string with page markers that split_by_page_markers
    will key correctly. Each page gets a short prose body so it's not empty."""
    parts = []
    for p in pages:
        parts.append(f"Content for page {p}. Control X.{p}.1 text here.\n\n<!-- page={p}/{max(pages)} -->")
    return "\n\n".join(parts)


def _ok(*control_ids_pages: tuple[str, int], truncated: bool = False) -> _FakeLLMResponse:
    """Shortcut for a successful LLM response with the given controls."""
    return _FakeLLMResponse(
        content={
            "controls": [
                {"control_id": cid, "title": f"Title for {cid}", "page": pg}
                for cid, pg in control_ids_pages
            ]
        },
        truncated=truncated,
    )


# ────────────────────────────────────────────────────────────────────────
# End-to-end discovery tests
# ────────────────────────────────────────────────────────────────────────


class TestDiscoverySplit:
    """Exercise the full discover_controls_from_body flow with fake provider."""

    @pytest.mark.asyncio
    async def test_no_split_on_clean_response(self):
        """Single successful call per window → no splits, no retries."""
        content = _make_content([1, 2, 3, 4])
        script = {
            (1, 4): _ok(("A.1.1", 1), ("A.1.2", 2), ("A.2.1", 3), ("A.2.2", 4)),
        }
        provider = _FakeProvider(script)
        # window_size > page count → one window (1-4) with no trailing.
        cfg = _make_config(window_size=5, overlap=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=4,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        # Exactly one LLM call — no split.
        assert len(provider.calls) == 1
        assert provider.calls[0]["key"] == (1, 4)
        assert provider.calls[0]["reasoning_effort"] == "minimal"
        # 4 distinct controls returned.
        assert toc.total_controls == 4

    @pytest.mark.asyncio
    async def test_single_split_on_truncated_response(self):
        """A 4-page window that returns truncated → split into (1-2)+(3-4)."""
        content = _make_content([1, 2, 3, 4])
        script = {
            # Top-level call truncates with partial results.
            (1, 4): _ok(("A.1.1", 1), truncated=True),
            # Split halves succeed cleanly.
            (1, 2): _ok(("A.1.1", 1), ("A.1.2", 2)),
            (3, 4): _ok(("A.2.1", 3), ("A.2.2", 4)),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=5, overlap=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=4,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        # 3 calls: original + 2 halves.
        keys = [c["key"] for c in provider.calls]
        assert (1, 4) in keys
        assert (1, 2) in keys
        assert (3, 4) in keys
        assert len(keys) == 3
        # Merged dedupes A.1.1 (present in both the truncated parent and the left half).
        assert toc.total_controls == 4

    @pytest.mark.asyncio
    async def test_split_on_instructor_length_exception(self):
        """An exception with 'max_tokens' in its message triggers split,
        not hard failure."""
        content = _make_content([1, 2])
        script = {
            (1, 2): Exception("The output is incomplete due to max_tokens length limit"),
            (1, 1): _ok(("A.1.1", 1)),
            (2, 2): _ok(("A.1.2", 2)),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=3, overlap=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=2,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        keys = [c["key"] for c in provider.calls]
        assert (1, 2) in keys
        assert (1, 1) in keys
        assert (2, 2) in keys
        assert toc.total_controls == 2

    @pytest.mark.asyncio
    async def test_nested_split_on_repeated_truncation(self):
        """A 4-page window that truncates, AND each half also truncates.
        Expect splits down to 1-page windows."""
        content = _make_content([1, 2, 3, 4])
        script = {
            (1, 4): _ok(truncated=True),
            (1, 2): _ok(truncated=True),
            (3, 4): _ok(truncated=True),
            (1, 1): _ok(("A.1.1", 1)),
            (2, 2): _ok(("A.1.2", 2)),
            (3, 3): _ok(("A.2.1", 3)),
            (4, 4): _ok(("A.2.2", 4)),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=5, overlap=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=4,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        keys = [c["key"] for c in provider.calls]
        for expected in [(1, 4), (1, 2), (3, 4), (1, 1), (2, 2), (3, 3), (4, 4)]:
            assert expected in keys, f"Missing call for {expected}"
        assert toc.total_controls == 4

    @pytest.mark.asyncio
    async def test_one_page_terminal_accepts_partial_on_truncation(self):
        """1-page window that still truncates → keep partial, no further split."""
        content = _make_content([1])
        script = {
            (1, 1): _ok(("A.1.1", 1), truncated=True),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=1, overlap=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=1,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        # Only one call — can't split a 1-page window.
        assert len(provider.calls) == 1
        # Partial entries are preserved.
        assert toc.total_controls == 1

    @pytest.mark.asyncio
    async def test_max_split_depth_bounds_recursion(self):
        """When depth limit is 0, a truncated response keeps partial results
        without splitting."""
        content = _make_content([1, 2, 3, 4])
        script = {
            (1, 4): _ok(("A.1.1", 1), truncated=True),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=5, overlap=0, max_split_depth=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=4,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        # No splits → exactly one call.
        assert len(provider.calls) == 1
        # Partial entries are preserved.
        assert toc.total_controls == 1

    @pytest.mark.asyncio
    async def test_hard_error_not_treated_as_truncation(self):
        """A non-length exception should be a hard failure — NOT trigger
        split-and-retry. Here we have 2 windows; failing only one means the
        50% circuit breaker doesn't trip, so discovery returns partial TOC."""
        content = _make_content([1, 2, 3, 4])
        script = {
            # First window fails with non-truncation error; second succeeds.
            (1, 4): Exception("Connection refused"),
            (4, 4): _ok(("A.2.2", 4)),
        }
        provider = _FakeProvider(script)
        # Default window_size=4 + minimum overlap=1 produces 2 windows:
        # (1-4) and (4-4). We want exactly this layout for the test.
        cfg = _make_config(window_size=4)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=4,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        # Only 2 calls total (failing window does not retry via split).
        assert len(provider.calls) == 2
        keys = [c["key"] for c in provider.calls]
        assert (1, 4) in keys
        assert (4, 4) in keys
        # Only the 2nd window's entry makes it into the TOC.
        assert toc.total_controls == 1
        assert toc.controls[0].control_id == "A.2.2"

    @pytest.mark.asyncio
    async def test_circuit_breaker_trips_on_majority_hard_failures(self):
        """When more than half the windows fail with non-truncation errors,
        discovery raises RuntimeError rather than returning mostly-empty TOC.
        This is the circuit-breaker behavior that pre-dates the split fix."""
        content = _make_content([1, 2, 3, 4])
        script = {
            (1, 4): Exception("Connection refused"),
            (4, 4): Exception("Another connection failure"),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=4)
        with pytest.raises(RuntimeError, match="windows failed"):
            await discover_controls_from_body(
                provider=provider,
                framework_name="Fake",
                content=content,
                start_page=1,
                end_page=4,
                rate_limiter=_FakeRateLimiter(),
                config=cfg,
                framework_profile=None,
            )

    @pytest.mark.asyncio
    async def test_empty_response_error_with_max_tokens_triggers_split(self):
        """EmptyResponseError whose message mentions max_tokens → split."""
        content = _make_content([1, 2])
        script = {
            (1, 2): EmptyResponseError("finish_reason=length, completion_tokens=2048, max_tokens=2048"),
            (1, 1): _ok(("A.1.1", 1)),
            (2, 2): _ok(("A.1.2", 2)),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=3, overlap=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=2,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        keys = [c["key"] for c in provider.calls]
        assert (1, 2) in keys
        assert (1, 1) in keys
        assert (2, 2) in keys
        assert toc.total_controls == 2

    @pytest.mark.asyncio
    async def test_reasoning_effort_passed_to_every_call(self):
        """reasoning_effort='minimal' must be forwarded on both top-level
        and sub-window calls."""
        content = _make_content([1, 2])
        script = {
            (1, 2): _ok(truncated=True),
            (1, 1): _ok(("A.1.1", 1)),
            (2, 2): _ok(("A.1.2", 2)),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=2, reasoning="minimal")
        await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=2,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        efforts = {c["reasoning_effort"] for c in provider.calls}
        assert efforts == {"minimal"}

    @pytest.mark.asyncio
    async def test_dedup_across_split_branches(self):
        """When the truncated parent emits partial entries that are ALSO
        returned by the split halves, dedup keeps one copy per (id, page)."""
        content = _make_content([1, 2, 3, 4])
        script = {
            (1, 4): _ok(("A.1.1", 1), ("A.1.2", 2), truncated=True),
            (1, 2): _ok(("A.1.1", 1), ("A.1.2", 2)),  # overlap with parent
            (3, 4): _ok(("A.2.1", 3), ("A.2.2", 4)),
        }
        provider = _FakeProvider(script)
        cfg = _make_config(window_size=4, overlap=0)
        toc = await discover_controls_from_body(
            provider=provider,
            framework_name="Fake",
            content=content,
            start_page=1,
            end_page=4,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        assert toc.total_controls == 4
        ids = sorted(c.control_id for c in toc.controls)
        assert ids == ["A.1.1", "A.1.2", "A.2.1", "A.2.2"]
