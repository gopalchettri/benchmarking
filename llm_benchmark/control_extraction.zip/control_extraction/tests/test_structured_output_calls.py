import pytest

from config import Settings
from extraction.discovery import discover_controls_from_body
from extraction.toc import extract_toc_from_text
from llm.providers import LLMResponse
from models import ControlListWrapper


class _FakeRateLimiter:
    def __init__(self):
        self.calls = 0

    async def acquire(self):
        self.calls += 1


class _FakeProvider:
    def __init__(self, content):
        self.content = content
        self.calls = []
        self.model_name = "gpt-5-mini"

    async def generate_json_with_metrics(
        self,
        system_prompt,
        user_prompt,
        max_tokens,
        response_model=None,
        reasoning_effort=None,
    ):
        # reasoning_effort is accepted for API parity with the real provider
        # (added to enable discovery/TOC to override per-phase); recorded here
        # so tests can assert on its value if they care.
        self.calls.append(
            {
                "system_prompt": system_prompt,
                "user_prompt": user_prompt,
                "max_tokens": max_tokens,
                "response_model": response_model,
                "reasoning_effort": reasoning_effort,
            }
        )
        return LLMResponse(
            content=self.content,
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model=self.model_name,
        )


@pytest.mark.asyncio
async def test_extract_toc_uses_instructor_response_model():
    provider = _FakeProvider(
        {
            "controls": [
                {"control_id": "A.5.1", "title": "Policies for information security", "page": 13}
            ]
        }
    )
    limiter = _FakeRateLimiter()
    settings = Settings(TOC_MAX_TOKENS=512)

    toc = await extract_toc_from_text(
        provider=provider,
        framework_name="ISO 27001",
        content="A.5.1 Policies for information security .......... 13",
        pages="1-1",
        rate_limiter=limiter,
        config=settings,
        framework_profile=None,
    )

    assert provider.calls
    assert provider.calls[0]["response_model"] is ControlListWrapper
    assert toc.total_controls == 1
    assert toc.controls[0].control_id == "A.5.1"
    assert limiter.calls == 1


@pytest.mark.asyncio
async def test_discovery_uses_instructor_response_model(sample_profile_dict):
    provider = _FakeProvider(
        {
            "controls": [
                {"control_id": "A.5.1", "title": "Policies for information security", "page": 1}
            ]
        }
    )
    limiter = _FakeRateLimiter()
    settings = Settings(
        DISCOVERY_MAX_TOKENS=512,
        DISCOVERY_WINDOW_SIZE=4,
        WINDOW_OVERLAP=1,
        LLM_RATE_LIMIT_BURST=2,
    )

    toc = await discover_controls_from_body(
        provider=provider,
        framework_name="ISO 27001",
        content="<!-- page=1/1 -->\nA.5.1 Policies for information security\n",
        start_page=1,
        end_page=1,
        rate_limiter=limiter,
        config=settings,
        framework_profile=sample_profile_dict,
    )

    assert provider.calls
    assert provider.calls[0]["response_model"] is ControlListWrapper
    assert toc.total_controls == 1
    assert toc.controls[0].control_id == "A.5.1"
    assert limiter.calls == 1
