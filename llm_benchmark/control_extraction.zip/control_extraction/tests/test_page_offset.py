"""Tests for core/page_offset.py — page offset detection and application."""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'services', 'ai_extraction'))

from core.page_offset import (
    detect_page_offset,
    apply_offset_to_page_range,
    apply_offset_to_toc_entries,
    resolve_page_offset,
    split_by_page_markers,
    PageOffsetUndetermined,
    _detect_page_offset_opt,
)
from core.document import parse_page_range


# ── Helper: build page_texts with realistic footer patterns ──────────────────

def _build_pages_standalone(offset: int, num_pages: int = 20) -> dict[int, str]:
    """Build page_texts where footer is a standalone number (plain text)."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 1:
            # Front-matter pages with roman numerals (no digit detection)
            pages[physical] = f"Front matter content\n\niv"
        else:
            pages[physical] = f"Body content for page {printed}\n\n{printed}"
    return pages


def _build_pages_bold_standalone(offset: int, num_pages: int = 20) -> dict[int, str]:
    """Build page_texts where footer is bold markdown (ISO 27001 odd pages)."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 1:
            pages[physical] = f"Front matter\n\n**iv**"
        else:
            pages[physical] = f"Body content\n\n**{printed}**"
    return pages


def _build_pages_trailing(offset: int, num_pages: int = 20) -> dict[int, str]:
    """Build page_texts with UAE IAS-style footer (number at end of line)."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 0:
            pages[physical] = "Cover page content"
        else:
            pages[physical] = f"Body content\n\n**Document Classification: Open** **{printed}**"
    return pages


def _build_pages_iso_mixed(offset: int, num_pages: int = 26) -> dict[int, str]:
    """Build page_texts mimicking ISO 27001's alternating footer format."""
    pages = {}
    for physical in range(1, num_pages + 1):
        printed = physical - offset
        if printed < 1:
            # Front matter with roman numerals
            pages[physical] = f"Front matter\n\n© ISO/IEC 2022 – All rights reserved **\ufeff** iii"
        elif printed % 2 == 1:
            # Odd printed pages: standalone bold number on its own line
            pages[physical] = (
                f"**ISO/IEC 27001:2022(E)**\n\nBody content\n\n"
                f"© ISO/IEC 2022 – All rights reserved **\ufeff**\n\ufeff\n\n\n**{printed}**"
            )
        else:
            # Even printed pages: bold number embedded in copyright line
            pages[physical] = (
                f"**ISO/IEC 27001:2022(E)**\n\nBody content\n\n"
                f"**{printed}** **\ufeff** © ISO/IEC 2022 – All rights reserved"
            )
    return pages


# ═══════════════════════════════════════════════════════════════════════════════
# detect_page_offset
# ═══════════════════════════════════════════════════════════════════════════════

class TestDetectPageOffset:
    """Test offset detection across different footer formats."""

    def test_empty_dict(self):
        assert detect_page_offset({}) == 0

    def test_too_few_samples(self):
        pages = {1: "Content\n\n1", 2: "Content\n\n2"}
        assert detect_page_offset(pages, min_samples=5) == 0

    def test_standalone_plain_numbers(self):
        pages = _build_pages_standalone(offset=4, num_pages=20)
        assert detect_page_offset(pages) == 4

    def test_standalone_bold_numbers(self):
        """ISO 27001 odd pages: **3** on its own line."""
        pages = _build_pages_bold_standalone(offset=6, num_pages=20)
        assert detect_page_offset(pages) == 6

    def test_trailing_numbers_uae_ias(self):
        """UAE IAS: Document Classification: Open 1."""
        pages = _build_pages_trailing(offset=4, num_pages=20)
        assert detect_page_offset(pages) == 4

    def test_iso_mixed_format(self):
        """ISO 27001 with alternating odd (standalone bold) and even (embedded) footers."""
        pages = _build_pages_iso_mixed(offset=6, num_pages=26)
        result = detect_page_offset(pages)
        assert result == 6

    def test_zero_offset(self):
        """No front matter — printed == physical."""
        pages = _build_pages_standalone(offset=0, num_pages=20)
        assert detect_page_offset(pages) == 0

    def test_no_page_numbers_returns_zero(self):
        """Pages with no detectable numbers (e.g., DESC ISR with only headers)."""
        pages = {
            i: f"Some body text\n\nMore content here."
            for i in range(1, 25)
        }
        assert detect_page_offset(pages) == 0

    def test_low_agreement_returns_zero(self):
        """Scattered offsets with no consensus should return 0."""
        pages = {}
        # Each page has a different standalone number producing different offsets
        for i in range(1, 25):
            pages[i] = f"Content\n\n{i * 3}"  # offsets: 1-3=-2, 2-6=-4, etc. all different
        assert detect_page_offset(pages) == 0

    def test_negative_offset_rejected(self):
        """Physical < printed should never produce a positive offset."""
        pages = {}
        for i in range(1, 20):
            pages[i] = f"Content\n\n{i + 10}"  # printed > physical → negative offset
        assert detect_page_offset(pages) == 0

    def test_large_offset_rejected(self):
        """Offset > 50 should be rejected by guard."""
        pages = {}
        for i in range(60, 80):
            pages[i] = f"Content\n\n{i - 55}"  # offset=55 > 50 guard
        assert detect_page_offset(pages) == 0

    def test_footer_checked_before_header(self):
        """Footer page number should win over a chapter number in the header.

        This scenario (chapter number '3' alone in header, real page number in
        footer) is produced by visual-order parsers (pymupdf4llm, kreuzberg)
        where footers are always at the end of the text.  Docling uses
        content-stream order which requires a separate header-first strategy.
        """
        pages = {}
        for i in range(5, 25):
            printed = i - 4
            # Header has chapter number "3", footer has real page number
            pages[i] = f"3\nChapter Three Content\n\nBody text\n\nMore text\n\n{printed}"
        assert detect_page_offset(pages, parse_type="pymupdf4llm") == 4

    def test_bom_characters_stripped(self):
        """Zero-width chars (\ufeff) should not interfere with detection."""
        pages = {}
        for i in range(5, 25):
            printed = i - 4
            pages[i] = f"Body content\n\n\ufeff**{printed}**\ufeff"
        assert detect_page_offset(pages) == 4

    def test_version_numbers_not_false_positive(self):
        """VERSION 3.1 trailing '1' produces inconsistent offsets → no consensus."""
        pages = {}
        for i in range(1, 25):
            pages[i] = (
                f"{i} INFORMATION SECURITY REGULATION – VERSION 3.1\n"
                f"Body content for page {i}"
            )
        assert detect_page_offset(pages) == 0


# ═══════════════════════════════════════════════════════════════════════════════
# apply_offset_to_page_range
# ═══════════════════════════════════════════════════════════════════════════════

class TestApplyOffsetToPageRange:
    """Test page range adjustment."""

    def test_basic_range(self):
        assert apply_offset_to_page_range("11-18", 6) == "17-24"

    def test_single_page(self):
        assert apply_offset_to_page_range("11", 4) == "15"

    def test_zero_offset_returns_original(self):
        assert apply_offset_to_page_range("11-18", 0) == "11-18"

    def test_empty_string_returns_original(self):
        assert apply_offset_to_page_range("", 4) == ""

    def test_none_returns_none(self):
        assert apply_offset_to_page_range(None, 4) is None

    def test_batch_returns_original(self):
        """Non-numeric input should not crash."""
        assert apply_offset_to_page_range("batch", 4) == "batch"

    def test_non_numeric_returns_original(self):
        assert apply_offset_to_page_range("abc-def", 4) == "abc-def"

    def test_en_dash_normalized(self):
        """En-dash (\u2013) should be treated as a regular hyphen."""
        assert apply_offset_to_page_range("11\u201318", 6) == "17-24"

    def test_em_dash_normalized(self):
        """Em-dash (\u2014) should be treated as a regular hyphen."""
        assert apply_offset_to_page_range("11\u201418", 6) == "17-24"

    def test_spaces_around_dash(self):
        assert apply_offset_to_page_range("11 - 18", 6) == "17-24"

    def test_negative_result_returns_original(self):
        """Offset that produces page < 1 should return original."""
        assert apply_offset_to_page_range("1-5", 0) == "1-5"
        result = apply_offset_to_page_range("1-5", -2)
        # offset is falsy when negative? No, -2 is truthy. But guard 0 <= offset <= 50 is in detect only.
        # apply_offset doesn't guard against negative offset — it guards negative result.
        # With offset=-2: 1 + (-2) = -1 < 1 → returns original
        assert result == "1-5"


# ═══════════════════════════════════════════════════════════════════════════════
# apply_offset_to_toc_entries
# ═══════════════════════════════════════════════════════════════════════════════

class _FakeTOCEntry:
    """Minimal stand-in for TOCEntry (avoids importing the full model)."""
    def __init__(self, control_id: str, page: int | None):
        self.control_id = control_id
        self.page = page


class TestApplyOffsetToTocEntries:
    """Test in-place TOC entry adjustment."""

    def test_basic_adjustment(self):
        entries = [_FakeTOCEntry("A.5.1", 11), _FakeTOCEntry("A.5.2", 12)]
        count = apply_offset_to_toc_entries(entries, 6)
        assert count == 2
        assert entries[0].page == 17
        assert entries[1].page == 18

    def test_none_pages_skipped(self):
        entries = [_FakeTOCEntry("A.5.1", None), _FakeTOCEntry("A.5.2", 12)]
        count = apply_offset_to_toc_entries(entries, 6)
        assert count == 1
        assert entries[0].page is None
        assert entries[1].page == 18

    def test_zero_offset_no_change(self):
        entries = [_FakeTOCEntry("A.5.1", 11)]
        count = apply_offset_to_toc_entries(entries, 0)
        assert count == 0
        assert entries[0].page == 11

    def test_empty_list(self):
        assert apply_offset_to_toc_entries([], 6) == 0

    def test_none_list(self):
        assert apply_offset_to_toc_entries(None, 6) == 0


class TestResolvePageOffset:
    """Prefer trustworthy offsets while allowing zero-value recovery."""

    def test_uses_detected_offset_when_known_is_missing(self):
        pages = _build_pages_standalone(offset=6, num_pages=20)
        assert resolve_page_offset(pages, None) == 6

    def test_preserves_nonzero_known_offset(self):
        pages = _build_pages_standalone(offset=4, num_pages=20)
        assert resolve_page_offset(pages, 6) == 6

    def test_recovers_from_false_zero_known_offset(self):
        pages = _build_pages_standalone(offset=6, num_pages=20)
        assert resolve_page_offset(pages, 0) == 6

    def test_keeps_zero_when_no_reliable_detection_exists(self):
        pages = {
            i: f"Some body text\n\nMore content here."
            for i in range(1, 25)
        }
        assert resolve_page_offset(pages, 0) == 0

    def test_invalid_known_offset_falls_back_to_detection(self):
        pages = _build_pages_standalone(offset=4, num_pages=20)
        assert resolve_page_offset(pages, "bad-value") == 4


# ═══════════════════════════════════════════════════════════════════════════════
# Regression coverage for fixed bugs
# ═══════════════════════════════════════════════════════════════════════════════

class TestBugRegressionSplitByPageMarkers:
    """Bug 2: split_by_page_markers must key chunks by the marker's own page
    number, not by an off-by-one counter. Previously, content of page 5 was
    silently misfiled into pages[1] when the first marker was <!-- page=5/T -->.
    """

    def test_first_marker_not_page_one_keys_chunk_correctly(self):
        md = (
            "[content of page 5]\n<!-- page=5/100 -->\n"
            "[content of page 6]\n<!-- page=6/100 -->\n"
            "[tail]"
        )
        pages = split_by_page_markers(md)
        assert sorted(pages.keys()) == [5, 6, 7]
        assert "[content of page 5]" in pages[5]
        assert "[content of page 6]" in pages[6]
        assert "[tail]" in pages[7]

    def test_sequential_markers_happy_path_preserved(self):
        md = (
            "pg1 body\n<!-- page=1/3 -->\n"
            "pg2 body\n<!-- page=2/3 -->\n"
            "pg3 body\n<!-- page=3/3 -->"
        )
        pages = split_by_page_markers(md)
        assert sorted(pages.keys()) == [1, 2, 3]
        assert "pg1 body" in pages[1]
        assert "pg2 body" in pages[2]
        assert "pg3 body" in pages[3]

    def test_no_markers_single_page_fallback(self):
        assert split_by_page_markers("unpaginated content") == {
            1: "unpaginated content"
        }

    def test_empty_input(self):
        assert split_by_page_markers("") == {}

    def test_tail_after_last_marker_goes_to_last_plus_one(self):
        md = "pg1 body\n<!-- page=1/2 -->\npg2 body"
        pages = split_by_page_markers(md)
        assert sorted(pages.keys()) == [1, 2]
        assert "pg1 body" in pages[1]
        assert "pg2 body" in pages[2]

    def test_non_contiguous_markers_do_not_invent_missing_pages(self):
        md = "a\n<!-- page=1/10 -->\nb\n<!-- page=5/10 -->\nc"
        pages = split_by_page_markers(md)
        # Only the pages the markers actually named, plus tail.
        # No invented pages 2, 3, 4.
        assert sorted(pages.keys()) == [1, 5, 6]


class TestBugRegressionDetectionEarlyBreak:
    """Bug 1: detect_page_offset previously broke out of the per-page scan
    after extracting the first number, even if its offset was out-of-range.
    Years in dated footers (e.g. '01 July 2024') then silently prevented
    detection of the actual page number on the next line.
    """

    def test_year_before_page_number_does_not_block_detection(self):
        pages = {}
        for printed in range(1, 11):
            physical = printed + 4  # offset=4
            pages[physical] = (
                f"Body content\nMore text\n01 July 2024\n{printed}"
            )
        assert detect_page_offset(pages, parse_type="pymupdf4llm") == 4

    def test_copyright_year_does_not_block_detection(self):
        pages = {}
        for printed in range(1, 11):
            physical = printed + 4
            pages[physical] = (
                f"Body prose\nMore prose\n"
                f"\u00a92024 Company LLC\nPage {printed} of 10"
            )
        assert detect_page_offset(pages, parse_type="pymupdf4llm") == 4

    def test_out_of_range_body_number_does_not_block_later_valid_number(self):
        pages = {}
        for printed in range(1, 11):
            physical = printed + 4
            pages[physical] = (
                f"Intro text\nReference: see item 9999\n"
                f"Page footer marker\n{printed}"
            )
        assert detect_page_offset(pages, parse_type="pymupdf4llm") == 4


class TestBugRegressionStrictModeSemantics:
    """Bug 3: strict mode previously raised PageOffsetUndetermined even for
    documents with a genuine, confidently-detected offset of 0. The fix
    distinguishes 'detector inconclusive' (None) from 'detector confident
    zero' — only the former raises under strict=True.
    """

    def test_strict_mode_accepts_confident_zero_offset(self):
        pages = _build_pages_standalone(offset=0, num_pages=14)
        # strict=True must NOT raise on a genuinely-aligned document.
        assert resolve_page_offset(
            pages, None, parse_type="pymupdf4llm", strict=True
        ) == 0

    def test_strict_mode_raises_on_inconclusive_detection(self):
        pages = {i: "prose with no numbers anywhere" for i in range(1, 25)}
        with pytest.raises(PageOffsetUndetermined) as exc_info:
            resolve_page_offset(
                pages, None, parse_type="pymupdf4llm", strict=True
            )
        assert exc_info.value.page_count == 24
        assert exc_info.value.parse_type == "pymupdf4llm"

    def test_detect_opt_returns_none_on_inconclusive(self):
        pages = {i: "no numbers here" for i in range(1, 25)}
        assert _detect_page_offset_opt(
            pages, parse_type="pymupdf4llm"
        ) is None

    def test_detect_opt_returns_zero_on_confident_zero(self):
        pages = _build_pages_standalone(offset=0, num_pages=14)
        assert _detect_page_offset_opt(
            pages, parse_type="pymupdf4llm"
        ) == 0

    def test_detect_opt_returns_nonzero_on_confident_nonzero(self):
        pages = _build_pages_standalone(offset=4, num_pages=20)
        assert _detect_page_offset_opt(
            pages, parse_type="pymupdf4llm"
        ) == 4


class TestTocNumberingModes:
    """Integration-style coverage for the toc_numbering dual-mode feature.

    The pipeline accepts two numbering systems for toc_start_page /
    toc_end_page:

      "printed"  (default) — the page numbers printed in the document's TOC.
                             Offset is applied to convert to physical indices.
      "physical"           — the PDF reader's page counter (physical indices).
                             Used as-is; no offset applied.

    content_pages is ALWAYS printed (read from the TOC entries themselves);
    offset is applied unconditionally.

    These tests simulate the offset-application logic in
    ai_extraction/core/storage.py without requiring real blobs, so they run
    fast and cover the decision matrix completely.
    """

    @staticmethod
    def _apply(toc_pages: str, content_pages: str, offset: int,
               mode: str) -> tuple[str, str]:
        """Mirror the branch in load_content_from_blob exactly."""
        if mode == "physical":
            toc_phys = toc_pages
            content_phys = apply_offset_to_page_range(content_pages, offset)
        else:  # "printed" (default)
            toc_phys = apply_offset_to_page_range(toc_pages, offset)
            content_phys = apply_offset_to_page_range(content_pages, offset)
        return toc_phys, content_phys

    # --- Scenario: PCI DSS (offset=4, user typed printed, default mode) ---

    def test_printed_mode_applies_offset_to_toc_and_content(self):
        """User types printed pages from TOC. Both toc and content get offset."""
        toc_phys, content_phys = self._apply("7-23", "40-387", offset=4, mode="printed")
        assert toc_phys == "11-27"
        assert content_phys == "44-391"

    # --- Scenario: NIST CSF (offset=5, TOC on roman-numeral page, physical mode) ---

    def test_physical_mode_keeps_toc_unchanged_applies_offset_to_content(self):
        """User types physical TOC page (avoids roman-numeral trap), content
        is still printed from TOC entries — only content gets offset."""
        toc_phys, content_phys = self._apply("4-4", "1-23", offset=5, mode="physical")
        assert toc_phys == "4-4"      # TOC page unchanged (was already physical)
        assert content_phys == "6-28"  # content offset applied

    # --- Scenario: SWIFT CSCF (offset=0, either mode is equivalent) ---

    def test_zero_offset_both_modes_identical(self):
        printed_out = self._apply("2-3", "29-94", offset=0, mode="printed")
        physical_out = self._apply("2-3", "29-94", offset=0, mode="physical")
        assert printed_out == physical_out == ("2-3", "29-94")

    # --- Content always gets offset, regardless of mode ---

    def test_content_always_gets_offset_in_physical_mode(self):
        """Content is read from the TOC (printed), so offset always applies
        to content — even when toc_numbering is physical."""
        _, content_phys = self._apply("4-4", "15-23", offset=5, mode="physical")
        assert content_phys == "20-28"

    def test_content_always_gets_offset_in_printed_mode(self):
        _, content_phys = self._apply("1-5", "15-23", offset=5, mode="printed")
        assert content_phys == "20-28"

    # --- TOC differs between modes ---

    def test_toc_differs_between_modes_when_offset_nonzero(self):
        """Same input numbers under each mode yield different physical slices
        for the TOC. This is the core behavioural difference."""
        toc_printed, _ = self._apply("4-4", "1-23", offset=5, mode="printed")
        toc_physical, _ = self._apply("4-4", "1-23", offset=5, mode="physical")
        assert toc_printed == "9-9"       # 4 + 5 = 9 (treated as printed)
        assert toc_physical == "4-4"       # as-is (already physical)
        assert toc_printed != toc_physical  # the whole point of the flag


class TestTierFourFallbackActiveWhenFooterScanFails:
    """Storage.py must pass markdown_text to resolve_page_offset so that
    tier 4 (self-discovered TOC anchors) runs when tier 2 (footer/header
    scan) is inconclusive. Without this, documents like NIST CSF that have
    roman-numeral page numbers in front matter and no ASCII digits in body
    footers silently get offset=0.
    """

    def test_tier_4_recovers_offset_for_nist_like_markdown(self):
        """Simulate NIST-CSF-style parsed markdown: printed TOC on physical
        page 4, body chapters at physical 6+. Roman-numeral front matter
        means tier 2 (footer scan) cannot find ASCII page numbers — only
        tier 4 (self-discovered TOC anchors) can recover the offset.

        Body text deliberately omits any digits that could fake out tier 2
        so we exercise the pure tier-4 path.
        """
        md_parts = []
        # Physical pages 1-3: pure prose front matter, no digits of any kind
        md_parts.append(
            "Front matter prose without numbers.\n\n<!-- page=1/32 -->\n\n"
        )
        md_parts.append(
            "More front matter prose.\n\n<!-- page=2/32 -->\n\n"
        )
        md_parts.append(
            "Acknowledgments section prose.\n\n<!-- page=3/32 -->\n\n"
        )
        # Physical page 4 = printed Table of Contents with dot-leader entries
        md_parts.append(
            "# Table of Contents\n\n"
            "Cybersecurity Framework Overview ............... 1\n"
            "Introduction to the CSF Core ................... 3\n"
            "Introduction to CSF Profiles and Tiers ........ 10\n"
            "Appendix A CSF Core ............................ 15\n\n"
            "<!-- page=4/32 -->\n\n"
        )
        md_parts.append(
            "Preface prose only.\n\n<!-- page=5/32 -->\n\n"
        )
        # Body chapters — heading text matches TOC entries (tier 4 anchor match)
        md_parts.append(
            "# Cybersecurity Framework Overview\n\n"
            "Body prose for the first chapter.\n\n"
            "<!-- page=6/32 -->\n\n"
        )
        md_parts.append(
            "Further chapter one prose.\n\n"
            "<!-- page=7/32 -->\n\n"
        )
        md_parts.append(
            "# Introduction to the CSF Core\n\n"
            "Chapter two prose.\n\n"
            "<!-- page=8/32 -->\n"
        )
        full_markdown = "".join(md_parts)
        pages = split_by_page_markers(full_markdown)

        # Without markdown_text: tier 4 is never invoked.
        # Tier 2 is also inconclusive here (no digits in prose footers).
        # Result: offset=0 (falsely, because detector had no signal).
        result_without = resolve_page_offset(
            pages, 0, parse_type="docling"
        )
        assert result_without == 0

        # With markdown_text: tier 4 discovers TOC anchors, cross-checks
        # against body headings, recovers the true offset of 5.
        result_with = resolve_page_offset(
            pages, 0, parse_type="docling", markdown_text=full_markdown
        )
        assert result_with == 5

    def test_tier_4_skipped_when_tier_2_already_confident(self):
        """If the footer scan succeeds, tier 4 is a no-op — we don't wastefully
        run anchor discovery on every call."""
        pages = _build_pages_standalone(offset=4, num_pages=20)
        # Works with or without markdown_text (tier 2 wins either way).
        assert resolve_page_offset(pages, 0, parse_type="pymupdf4llm") == 4
        assert resolve_page_offset(
            pages, 0, parse_type="pymupdf4llm", markdown_text="irrelevant"
        ) == 4


class TestParsePageRangeZeroSemantics:
    """Gap 3: parse_page_range must return None for '0-0' (API's "no TOC"
    convention) rather than (0, 0). Previously the _slice function clamped
    start to max(1, ...) and silently grabbed page 1 as if it were the TOC.
    """

    def test_zero_zero_means_no_toc(self):
        """'0-0' is the API sentinel for "no TOC" — must be None, not (0, 0)."""
        assert parse_page_range("0-0") is None

    def test_single_zero_means_no_range(self):
        assert parse_page_range("0") is None

    def test_empty_string_is_none(self):
        assert parse_page_range("") is None

    def test_batch_sentinel_is_none(self):
        assert parse_page_range("batch") is None

    def test_zero_in_range_is_invalid(self):
        """Any range containing 0 (other than '0-0') is invalid — pages are 1-indexed."""
        with pytest.raises(ValueError, match="1-indexed"):
            parse_page_range("0-10")

    def test_valid_range_preserved(self):
        assert parse_page_range("11-18") == (11, 18)

    def test_valid_single_page_preserved(self):
        assert parse_page_range("7") == (7, 7)

    def test_en_dash_normalized(self):
        assert parse_page_range("11\u201318") == (11, 18)

    def test_start_greater_than_end_raises(self):
        with pytest.raises(ValueError, match="start .* > end"):
            parse_page_range("18-11")
