"""Tests for framework auto-detection logic."""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'services', 'doc_processing')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from framework_detector import (
    detect_framework,
    _compute_keyword_score,
    DetectionResult,
)


# ── Sample Profiles ──────────────────────────────────────────────────────────

ISO_PROFILE = {
    "id": "profile-iso-27001",
    "name": "ISO-27001",
    "display_name": "ISO/IEC 27001:2022",
}

PCI_PROFILE = {
    "id": "profile-pci-dss",
    "name": "PCI-DSS",
    "display_name": "PCI-DSS v4.0.1",
}

NIST_PROFILE = {
    "id": "profile-nist-csf",
    "name": "NIST-CSF",
    "display_name": "NIST CSF 2.0",
}

ALL_PROFILES = [ISO_PROFILE, PCI_PROFILE, NIST_PROFILE]


class TestKeywordScore:
    def test_all_keywords_match(self):
        text = "This document describes ISO/IEC 27001 and ISO 27001 requirements"
        score, matches = _compute_keyword_score(text.lower(), ["ISO/IEC 27001", "ISO 27001"])
        assert score == 1.0
        assert len(matches) == 2

    def test_partial_keyword_match(self):
        text = "ISO/IEC 27001 compliance document"
        score, matches = _compute_keyword_score(text.lower(), ["ISO/IEC 27001", "ISO 27001"])
        assert score == 0.5
        assert len(matches) == 1

    def test_no_keywords_match(self):
        text = "This is about PCI DSS v4.0.1"
        score, matches = _compute_keyword_score(text.lower(), ["ISO/IEC 27001", "ISO 27001"])
        assert score == 0.0
        assert len(matches) == 0

    def test_case_insensitive(self):
        text = "iso/iec 27001 STANDARD"
        score, _ = _compute_keyword_score(text.lower(), ["ISO/IEC 27001"])
        assert score == 1.0

    def test_empty_keywords(self):
        score, matches = _compute_keyword_score("some text", [])
        assert score == 0.0
        assert matches == []


class TestDetectFramework:
    def test_detects_iso_27001(self):
        text = (
            "ISO/IEC 27001:2022 Information Security Management\n"
            "A.5.1 Policies for information security\n"
            "A.5.2 Information security roles\n"
            "A.6.1 Screening\n"
            "A.6.2 Terms\n"
            "A.7.1 Physical security\n"
        )
        result = detect_framework(text, ALL_PROFILES, confidence_threshold=0.7)
        assert result.detected
        assert result.selected_profile_name == "ISO-27001"
        assert result.confidence >= 0.7

    def test_detects_nist_csf(self):
        text = (
            "NIST Cybersecurity Framework CSF 2.0\n"
            "GV.OC-01 Organizational context\n"
            "PR.AC-01 Access control\n"
            "DE.CM-01 Continuous monitoring\n"
            "RS.AN-01 Analysis\n"
            "RC.RP-01 Recovery planning\n"
        )
        result = detect_framework(text, ALL_PROFILES, confidence_threshold=0.7)
        assert result.detected
        assert result.selected_profile_name == "NIST-CSF"

    def test_no_detection_when_ambiguous(self):
        text = "Generic compliance document with no framework keywords and no IDs"
        result = detect_framework(text, ALL_PROFILES, confidence_threshold=0.85)
        assert not result.detected
        assert result.candidates  # still returns candidates

    def test_threshold_respected(self):
        text = "ISO 27001 mentioned once but no control IDs"
        result_high = detect_framework(text, ALL_PROFILES, confidence_threshold=0.99)
        assert not result_high.detected

    def test_empty_profiles(self):
        result = detect_framework("some text", [], confidence_threshold=0.85)
        assert not result.detected
        assert result.candidates == []

    def test_candidates_sorted_by_confidence(self):
        text = (
            "PCI DSS Payment Card Industry Data Security Standard\n"
            "1.1 Install firewall\n1.2 Configure\n1.3 Restrict\n1.4 Block\n1.5 Monitor\n"
        )
        result = detect_framework(text, ALL_PROFILES, confidence_threshold=0.5)
        assert result.detected
        assert result.selected_profile_name == "PCI-DSS"
        # Verify sorted descending
        for i in range(len(result.candidates) - 1):
            assert result.candidates[i].confidence >= result.candidates[i + 1].confidence
