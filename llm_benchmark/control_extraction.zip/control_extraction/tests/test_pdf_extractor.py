"""Tests for doc_processing/pdf_extractor.py helpers."""

import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from pdf_extractor import PDFExtractor


PAGE_BREAK = "<!-- __DOC_PROCESSING_PAGE_BREAK__ -->"


def test_split_docling_batch_markdown_uses_page_break_placeholder():
    markdown = f"First page\n\n{PAGE_BREAK}\n\nSecond page"

    parts = PDFExtractor._split_docling_batch_markdown(markdown, expected_pages=2)

    assert parts == ["First page", "Second page"]


def test_split_docling_batch_markdown_preserves_empty_pages():
    markdown = f"First page\n\n{PAGE_BREAK}\n\n{PAGE_BREAK}\n\nThird page"

    parts = PDFExtractor._split_docling_batch_markdown(markdown, expected_pages=3)

    assert parts == ["First page", "", "Third page"]


def test_split_docling_batch_markdown_falls_back_to_trailing_page_markers():
    markdown = "First page\n\n<!-- page=7/8 -->\n\nSecond page\n\n<!-- page=8/8 -->"

    parts = PDFExtractor._split_docling_batch_markdown(markdown, expected_pages=2)

    assert parts == ["First page", "Second page"]


def test_split_docling_batch_markdown_returns_none_when_boundaries_missing():
    markdown = "Only one undivided chunk"

    parts = PDFExtractor._split_docling_batch_markdown(markdown, expected_pages=2)

    assert parts is None


def test_load_output_infers_total_pages(tmp_path):
    job_dir = tmp_path / "framework" / "job-123"
    job_dir.mkdir(parents=True)
    (job_dir / "combined.md").write_text("Page 1\n\n<!-- page=1/2 -->\n\nPage 2\n\n<!-- page=2/2 -->", encoding="utf-8")
    (job_dir / "pg_1.txt").write_text("Page 1", encoding="utf-8")
    (job_dir / "pg_2.txt").write_text("Page 2", encoding="utf-8")

    extractor = PDFExtractor(SimpleNamespace(PDF_DOCLING_BATCH_SIZE=8, SUBCONTROL_MIN_CONTENT_CHARS=0))

    extractor.load_output(job_dir)

    assert extractor.get_total_pages() == 2
    assert extractor.get_job_dir() == job_dir.resolve()
    assert extractor.get_combined_markdown_path() == (job_dir / "combined.md").resolve()


def test_load_output_rejects_missing_pages(tmp_path):
    job_dir = tmp_path / "framework" / "job-456"
    job_dir.mkdir(parents=True)
    (job_dir / "combined.md").write_text("Page 1\n\n<!-- page=1/2 -->", encoding="utf-8")
    (job_dir / "pg_1.txt").write_text("Page 1", encoding="utf-8")

    extractor = PDFExtractor(SimpleNamespace(PDF_DOCLING_BATCH_SIZE=8, SUBCONTROL_MIN_CONTENT_CHARS=0))

    with pytest.raises(ValueError, match="missing page files"):
        extractor.load_output(job_dir, total_pages=2)


# ═══════════════════════════════════════════════════════════════════════════════
# Bug A regression: year-in-header early-break in detect_page_offset_from_pdf
# ═══════════════════════════════════════════════════════════════════════════════
#
# Before the fix, the scan broke after extracting the first number from a header
# line. On dated PDFs (PCI DSS, SWIFT, NIST all have "June 2024" / "February 26,
# 2024" / "01 July 2024" in their headers), the year was extracted as a page
# number, failed the plausibility check (0 <= offset <= 50), and the loop broke
# without trying later candidate lines. Result: detector silently returned 0 on
# every dated PDF in the frameworks/ directory.

FRAMEWORKS_DIR = Path(__file__).parent.parent / "frameworks"


class TestDetectPageOffsetFromPdfRegression:
    """Regression suite for Bug A (year-early-break). Runs against the real
    PDFs under frameworks/ when present, skips otherwise."""

    @pytest.mark.skipif(
        not (FRAMEWORKS_DIR / "PCI-DSS-v4_0_1.pdf").exists(),
        reason="PCI-DSS-v4_0_1.pdf not in frameworks/",
    )
    def test_pci_dss_detects_offset_4(self):
        """PCI DSS v4.0.1 has 4 pages of front matter; header reads 'June 2024'
        followed by '©2006-2024 PCI Security Standards Council...'. Before the
        fix, detector bailed on the year and returned 0. Offset is 4."""
        pdf = str(FRAMEWORKS_DIR / "PCI-DSS-v4_0_1.pdf")
        assert PDFExtractor.detect_page_offset_from_pdf(pdf) == 4

    @pytest.mark.skipif(
        not (FRAMEWORKS_DIR / "SWIFT CSCF_v2025_20240701.pdf").exists(),
        reason="SWIFT CSCF PDF not in frameworks/",
    )
    def test_swift_cscf_detects_offset_0(self):
        """SWIFT CSCF 2025 has no front matter that shifts page numbers;
        printed == physical. Header contains '01 July 2024' which must be
        skipped as out-of-range."""
        pdf = str(FRAMEWORKS_DIR / "SWIFT CSCF_v2025_20240701.pdf")
        assert PDFExtractor.detect_page_offset_from_pdf(pdf) == 0

    @pytest.mark.skipif(
        not (FRAMEWORKS_DIR / "NIST.CSF 2.0.pdf").exists(),
        reason="NIST CSF PDF not in frameworks/",
    )
    def test_nist_csf_returns_zero_when_pdf_lacks_ascii_page_numbers(self):
        """NIST CSF 2.0 uses roman-numeral page numbers (i, ii, iii, iv) in
        front matter and no ASCII digits in body headers/footers. The PDF-level
        detector cannot determine the offset from this PDF — correctly returns
        0, relying on the markdown-level TOC-anchor fallback in ai_extraction."""
        pdf = str(FRAMEWORKS_DIR / "NIST.CSF 2.0.pdf")
        # The important assertion is that detection does not CRASH and does
        # not return a garbage offset. Returning 0 here is the honest result;
        # the downstream markdown fallback recovers the real offset.
        assert PDFExtractor.detect_page_offset_from_pdf(pdf) == 0


class TestDetectPageOffsetFromPdfSynthetic:
    """Synthetic inputs — portable, runs even without the frameworks/ fixtures."""

    def test_try_extract_rejects_noise_before_valid_number(self):
        """Verify _try_extract_printed_page_number extracts the trailing number
        even when a line starts with noise — the real regression driver."""
        # Standalone number strategy
        assert PDFExtractor._try_extract_printed_page_number("29") == 29
        # Trailing number strategy — year-like values are technically valid
        # but out-of-range offsets in the detector will reject them.
        assert PDFExtractor._try_extract_printed_page_number("June 2024") == 2024
        assert PDFExtractor._try_extract_printed_page_number("no number") is None
