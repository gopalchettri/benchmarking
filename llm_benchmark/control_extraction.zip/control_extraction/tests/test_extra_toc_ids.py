"""Tests for _inject_extra_toc_ids — TOC enrichment from prompt module EXTRA_TOC_IDS."""

import os
import sys

import pytest

# Ensure ai_extraction is first on sys.path so its models.py wins over storage's.
_AI_DIR = os.path.join(
    os.path.dirname(__file__), "..", "services", "ai_extraction"
)
sys.path.insert(0, os.path.abspath(_AI_DIR))

from models import TOCEntry  # noqa: E402
from extraction.controls import _inject_extra_toc_ids  # noqa: E402


# ── Helpers ──────────────────────────────────────────────────────────────────

def _toc(control_id: str, page: int | None = None) -> TOCEntry:
    return TOCEntry(control_id=control_id, title=f"Title {control_id}", page=page)


# ── Tests ────────────────────────────────────────────────────────────────────

class TestInjectExtraTocIds:
    """EXTRA_TOC_IDS injection from prompt module."""

    def test_injects_missing_children(self):
        """Missing child IDs are injected with parent's page number."""
        entries = [_toc("3.2.1", page=19)]
        extra = {"3.2.1": ["3.2.1.1", "3.2.1.2", "3.2.1.3", "3.2.1.4"]}

        result = _inject_extra_toc_ids(entries, extra)

        ids = [e.control_id for e in result]
        assert "3.2.1" in ids
        assert "3.2.1.1" in ids
        assert "3.2.1.2" in ids
        assert "3.2.1.3" in ids
        assert "3.2.1.4" in ids
        assert len(result) == 5
        # Injected entries share parent's page
        for e in result:
            if e.control_id.startswith("3.2.1."):
                assert e.page == 19

    def test_no_duplicates_when_already_present(self):
        """If child IDs are already in TOC, they are NOT duplicated."""
        entries = [
            _toc("3.2.1", page=19),
            _toc("3.2.1.1", page=19),
            _toc("3.2.1.2", page=20),
            _toc("3.2.1.3", page=20),
            _toc("3.2.1.4", page=21),
        ]
        extra = {"3.2.1": ["3.2.1.1", "3.2.1.2", "3.2.1.3", "3.2.1.4"]}

        result = _inject_extra_toc_ids(entries, extra)

        assert len(result) == 5  # No duplicates added

    def test_partial_presence_injects_only_missing(self):
        """Only missing children are injected."""
        entries = [
            _toc("3.2.1", page=19),
            _toc("3.2.1.1", page=19),
            # 3.2.1.2 and 3.2.1.3 missing
            _toc("3.2.1.4", page=21),
        ]
        extra = {"3.2.1": ["3.2.1.1", "3.2.1.2", "3.2.1.3", "3.2.1.4"]}

        result = _inject_extra_toc_ids(entries, extra)

        ids = [e.control_id for e in result]
        assert len(result) == 5
        assert ids.count("3.2.1.2") == 1
        assert ids.count("3.2.1.3") == 1

    def test_empty_extra_ids_returns_unchanged(self):
        """Empty extra_ids dict returns entries unchanged."""
        entries = [_toc("3.2.1", page=19)]

        result = _inject_extra_toc_ids(entries, {})

        assert result is entries
        assert len(result) == 1

    def test_parent_missing_from_toc_skips_injection(self):
        """If parent ID is not in TOC, children are NOT injected."""
        entries = [_toc("3.1.1", page=13)]
        extra = {"3.2.1": ["3.2.1.1", "3.2.1.2"]}

        result = _inject_extra_toc_ids(entries, extra)

        assert len(result) == 1  # Nothing injected

    def test_parent_without_page_number_skips(self):
        """If parent has no page number, children are NOT injected."""
        entries = [_toc("3.2.1", page=None)]
        extra = {"3.2.1": ["3.2.1.1", "3.2.1.2"]}

        result = _inject_extra_toc_ids(entries, extra)

        assert len(result) == 1
