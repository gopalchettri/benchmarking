"""Tests for prompt module loading and per-framework prompts."""

import pytest


class TestPromptLoader:
    """Verify load_framework_prompts and backward-compatible API."""

    def test_load_framework_prompts(self):
        from prompts import load_framework_prompts
        module = load_framework_prompts("prompts.iso_27001")
        assert hasattr(module, "get_toc_prompts")
        assert hasattr(module, "get_subcontrol_prompts")

    def test_backward_compatible_get_toc_prompts(self):
        from prompts import get_toc_prompts
        system, user = get_toc_prompts("ISO 27001", "sample content")
        assert isinstance(system, str)
        assert isinstance(user, str)
        assert len(system) > 0
        assert len(user) > 0

    def test_backward_compatible_get_subcontrol_prompts(self):
        from prompts import get_subcontrol_prompts
        system, user = get_subcontrol_prompts("ISO 27001", "sample content")
        assert isinstance(system, str)
        assert isinstance(user, str)

    def test_sanitize_framework_name(self):
        from prompts.base import _sanitize_framework_name
        assert _sanitize_framework_name("ISO 27001:2022") == "ISO 270012022"
        assert _sanitize_framework_name("NIST CSF (v2.0)") == "NIST CSF (v2.0)"
        # Strip injection attempts
        assert "<script>" not in _sanitize_framework_name("ISO<script>alert(1)</script>")


class TestPerFrameworkPrompts:
    """Verify each framework prompt module has the required interface."""

    FRAMEWORK_MODULES = [
        "prompts.iso_27001",
        "prompts.nist_csf",
        "prompts.pci_dss",
        "prompts.swift_cscf",
        "prompts.desc_isr",
        "prompts.ecc",
        "prompts.nca_ecc_2",
        "prompts.sama_csf",
        "prompts.uae_ias",
        "prompts.generic",
    ]

    @pytest.mark.parametrize("module_name", FRAMEWORK_MODULES)
    def test_module_has_toc_prompts(self, module_name):
        from prompts import load_framework_prompts
        mod = load_framework_prompts(module_name)
        assert hasattr(mod, "get_toc_prompts"), f"{module_name} missing get_toc_prompts"

    @pytest.mark.parametrize("module_name", FRAMEWORK_MODULES)
    def test_module_has_subcontrol_prompts(self, module_name):
        from prompts import load_framework_prompts
        mod = load_framework_prompts(module_name)
        assert hasattr(mod, "get_subcontrol_prompts"), f"{module_name} missing get_subcontrol_prompts"

    @pytest.mark.parametrize("module_name", FRAMEWORK_MODULES)
    def test_module_returns_string_tuples(self, module_name):
        from prompts import load_framework_prompts
        mod = load_framework_prompts(module_name)
        system, user = mod.get_toc_prompts("test content")
        assert isinstance(system, str) and isinstance(user, str)
        system, user = mod.get_subcontrol_prompts("test content")
        assert isinstance(system, str) and isinstance(user, str)
