"""Tests for extraction.id_pattern — ID pattern auto-derivation."""

import re
import pytest

from extraction.id_pattern import (
    _classify_segment,
    derive_id_pattern,
    _try_separator,
    _pre_filter,
    detect_normalization_prefix,
)


class TestClassifySegment:
    """Tests for _classify_segment including force_type parameter."""

    def test_all_identical_digits_literal(self):
        assert _classify_segment(["3", "3", "3"]) == "3"

    def test_all_identical_digits_force_type(self):
        """force_type=True skips literal, returns \\d+ for digits."""
        assert _classify_segment(["3", "3", "3"], force_type=True) == r"\d+"

    def test_single_digit_literal(self):
        assert _classify_segment(["3"]) == "3"

    def test_single_digit_force_type(self):
        """Single digit with force_type → \\d+ (not literal '3')."""
        assert _classify_segment(["3"], force_type=True) == r"\d+"

    def test_single_alpha_force_type(self):
        """Single alpha with force_type → [A-Z]+ (not literal 'A')."""
        assert _classify_segment(["A"], force_type=True) == r"[A-Z]+"

    def test_single_lower_alpha_force_type(self):
        assert _classify_segment(["a"], force_type=True) == r"[a-z]+"

    def test_all_identical_alpha_literal(self):
        assert _classify_segment(["A", "A", "A"]) == "A"

    def test_all_identical_alpha_force_type(self):
        assert _classify_segment(["A", "A", "A"], force_type=True) == r"[A-Z]+"

    def test_varied_digits(self):
        """Multiple different digits → \\d+ regardless of force_type."""
        assert _classify_segment(["1", "2", "3"]) == r"\d+"
        assert _classify_segment(["1", "2", "3"], force_type=True) == r"\d+"

    def test_varied_upper_alpha(self):
        assert _classify_segment(["A", "B", "C"]) == r"[A-Z]+"

    def test_mixed_alphanumeric(self):
        assert _classify_segment(["A1", "B2", "C3"]) == r"[A-Za-z0-9]+"

    def test_empty_list(self):
        assert _classify_segment([]) == r"[A-Za-z0-9]+"

    def test_force_type_false_is_default(self):
        """Default behavior (no force_type) matches original literal behavior."""
        assert _classify_segment(["3", "3"]) == "3"


class TestDeriveIdPatternSingleDepth:
    """Existing single-depth behavior must be preserved (backwards compat)."""

    def test_sama_csf_current(self):
        """SAMA CSF with 32 three-part IDs → existing pattern."""
        ids = [f"3.{d}.{c}" for d in range(1, 5) for c in range(1, 9)]
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_iso_27001(self):
        """ISO 27001 — all 3-part A.X.Y IDs."""
        ids = [f"A.5.{i}" for i in range(1, 38)] + [f"A.8.{i}" for i in range(1, 35)]
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_ecc_hyphenated(self):
        """ECC — 3-part hyphenated IDs."""
        ids = [f"{d}-{s}-{c}" for d in range(1, 6) for s in range(1, 4) for c in range(1, 8)]
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_desc_isr_two_part(self):
        """DESC ISR — 2-part X.Y IDs."""
        ids = [f"{d}.{c}" for d in range(1, 14) for c in range(1, 6)]
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_too_few_ids(self):
        """Fewer than min_ids returns empty string."""
        assert derive_id_pattern(["1.1", "2.2"]) == ""

    def test_empty_list(self):
        assert derive_id_pattern([]) == ""


class TestDeriveIdPatternMultiDepth:
    """New multi-depth behavior — the core feature being added."""

    def test_sama_csf_with_four_part(self):
        """SAMA CSF: 32 three-part + 4 four-part IDs → pattern matches both."""
        three_part = [f"3.{d}.{c}" for d in range(1, 5) for c in range(1, 9)]
        four_part = ["3.2.1.1", "3.2.1.2", "3.2.1.3", "3.2.1.4"]
        ids = three_part + four_part
        pattern = derive_id_pattern(ids)
        assert pattern, "Should derive a pattern for mixed-depth IDs"
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_99_plus_1(self):
        """99 three-part + 1 four-part → both match."""
        three_part = [f"3.{d}.{c}" for d in range(1, 13) for c in range(1, 9)][:99]
        four_part = ["3.2.1.1"]
        ids = three_part + four_part
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        # The 1 four-part ID must match
        assert compiled.match("3.2.1.1")
        # Other four-part IDs should also match (generic pattern, not literal)
        assert compiled.match("3.2.1.2"), "Pattern must be generic, not literal"
        assert compiled.match("5.9.8.7"), "Pattern must be generic for minority depth"
        # Three-part IDs must still match
        for cid in three_part[:5]:
            assert compiled.match(cid)

    def test_three_depths(self):
        """IDs with 3, 4, and 5 parts → all three depths accepted."""
        three_part = [f"1.{d}.{c}" for d in range(1, 6) for c in range(1, 8)]
        four_part = [f"1.2.1.{c}" for c in range(1, 5)]
        five_part = ["1.2.1.1.1", "1.2.1.1.2", "1.2.1.1.3"]
        ids = three_part + four_part + five_part
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_shorter_minority(self):
        """Majority 4-part + minority 3-part → both accepted."""
        four_part = [f"1.{d}.{s}.{c}" for d in range(1, 4) for s in range(1, 4) for c in range(1, 8)]
        three_part = ["1.1.1", "1.2.1", "1.3.1"]
        ids = four_part + three_part
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_non_adjacent_depths(self):
        """2-part + 4-part (non-adjacent depths) → both accepted."""
        two_part = [f"{d}.{c}" for d in range(1, 6) for c in range(1, 8)]
        four_part = [f"1.1.{s}.{c}" for s in range(1, 4) for c in range(1, 4)]
        ids = two_part + four_part
        pattern = derive_id_pattern(ids)
        assert pattern
        compiled = re.compile(pattern)
        for cid in ids:
            assert compiled.match(cid), f"Pattern should match {cid}"

    def test_dominant_precision_preserved(self):
        """Dominant depth still uses literal match for identical segments."""
        # All 3-part IDs start with "3" → dominant should use literal "3"
        ids = [f"3.{d}.{c}" for d in range(1, 5) for c in range(1, 9)]
        four_part = ["3.2.1.1", "3.2.1.2"]
        all_ids = ids + four_part
        pattern = derive_id_pattern(all_ids)
        compiled = re.compile(pattern)
        # "3.1.1" should match (dominant depth)
        assert compiled.match("3.1.1")
        # "4.1.1" should NOT match (dominant uses literal "3")
        assert not compiled.match("4.1.1"), "Dominant depth should use literal '3'"
        # "4.2.1.1" SHOULD match (minority depth uses generic \\d+)
        assert compiled.match("4.2.1.1"), "Minority depth should be generic"


class TestPreFilter:
    """Verify noise pre-filter."""

    def test_removes_table_refs(self):
        ids = ["Table 1", "3.1.1", "3.1.2"]
        result = _pre_filter(ids)
        assert "Table 1" not in result
        assert "3.1.1" in result

    def test_removes_long_entries(self):
        ids = ["x" * 31, "3.1.1"]
        result = _pre_filter(ids)
        assert len(result) == 1


class TestDetectNormalizationPrefix:
    """Verify prefix detection for discovery mode."""

    def test_iso_prefix(self):
        dm = {"A.5": "Org", "A.6": "People", "A.7": "Physical", "A.8": "Tech"}
        raw = ["5.1", "5.2", "6.1"]
        assert detect_normalization_prefix(dm, raw) == "A."

    def test_no_prefix_needed(self):
        dm = {"3.1": "Gov", "3.2": "Risk"}
        raw = ["3.1.1", "3.2.1"]
        assert detect_normalization_prefix(dm, raw) == ""
