"""Regression tests for deterministic sub-control ID composition."""

import os
import sys

# Ensure ai_extraction is first on sys.path so its modules win over storage's.
_AI_DIR = os.path.join(
    os.path.dirname(__file__), "..", "services", "ai_extraction"
)
sys.path.insert(0, os.path.abspath(_AI_DIR))

from extraction.controls import SubControlExtractor  # noqa: E402
from models import compose_sub_control_id  # noqa: E402


def test_compose_sub_control_id_keeps_dot_qualified_numbers():
    assert compose_sub_control_id("1.1", "1.1.1") == "1.1.1"


def test_compose_sub_control_id_keeps_hyphen_qualified_numbers():
    assert compose_sub_control_id("1-5-3", "1-5-3-1") == "1-5-3-1"


def test_compose_sub_control_id_keeps_mixed_separator_same_hierarchy():
    assert compose_sub_control_id("1.5.3", "1-5-3-1") == "1-5-3-1"


def test_compose_sub_control_id_appends_short_numbers_and_letters():
    assert compose_sub_control_id("A.5.1", "a") == "A.5.1.a"
    assert compose_sub_control_id("1-1-1", "2") == "1-1-1.2"


def test_parse_sub_controls_preserves_nca_ecc_hyphen_hierarchy():
    extractor = SubControlExtractor.__new__(SubControlExtractor)
    raw = [
        {
            "number": "1-1",
            "text": "Cybersecurity Strategy",
            "children": [
                {
                    "number": "1-1-1",
                    "text": "Main control text",
                    "children": [
                        {
                            "number": "1-1-1-1",
                            "text": "Nested control text",
                            "children": [],
                        }
                    ],
                }
            ],
        }
    ]

    parsed = extractor._parse_sub_controls(raw, parent_id="1")

    assert parsed[0].id == "1-1"
    assert parsed[0].children[0].id == "1-1-1"
    assert parsed[0].children[0].children[0].id == "1-1-1-1"


def test_parse_sub_controls_keeps_existing_dotted_behavior():
    extractor = SubControlExtractor.__new__(SubControlExtractor)
    raw = [
        {
            "number": "1",
            "text": "Parent item",
            "children": [
                {"number": "a", "text": "Letter child", "children": []},
            ],
        }
    ]

    parsed = extractor._parse_sub_controls(raw, parent_id="A.5.1")

    assert parsed[0].id == "A.5.1.1"
    assert parsed[0].children[0].id == "A.5.1.1.a"
