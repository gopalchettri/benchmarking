"""
Tests for job repository and job-related utilities.
"""
import pytest
from repositories.job_repo import count_nodes, JobRepositoryPort


class TestCountNodes:
    """Test the recursive node counter for sub_controls trees."""

    def test_empty_list(self):
        assert count_nodes([]) == 0

    def test_none(self):
        assert count_nodes(None) == 0

    def test_flat_list(self):
        nodes = [
            {"number": "a", "text": "first"},
            {"number": "b", "text": "second"},
            {"number": "c", "text": "third"},
        ]
        assert count_nodes(nodes) == 3

    def test_nested_children(self):
        nodes = [
            {
                "number": "a",
                "text": "parent",
                "sub_controls": [
                    {"number": "i", "text": "child1", "sub_controls": []},
                    {"number": "ii", "text": "child2", "sub_controls": [
                        {"number": "1", "text": "grandchild"}
                    ]},
                ],
            },
        ]
        # 1 parent + 2 children + 1 grandchild = 4
        assert count_nodes(nodes) == 4

    def test_deeply_nested(self):
        # Build a chain of depth 5
        node = {"number": "5", "text": "leaf"}
        for i in range(4, 0, -1):
            node = {"number": str(i), "text": f"level-{i}", "sub_controls": [node]}
        assert count_nodes([node]) == 5

    def test_no_children_key(self):
        """Nodes without a 'sub_controls' key should count as leaf nodes."""
        nodes = [{"number": "a", "text": "leaf"}]
        assert count_nodes(nodes) == 1


class TestJobRepositoryPort:
    """Verify the abstract port defines expected methods."""

    def test_abstract_methods(self):
        abstract_methods = {m for m in dir(JobRepositoryPort) if not m.startswith("_")}
        expected = {"create_job", "get_job", "update_job", "list_jobs", "delete_job"}
        assert expected.issubset(abstract_methods)

    def test_cannot_instantiate(self):
        with pytest.raises(TypeError):
            JobRepositoryPort()
