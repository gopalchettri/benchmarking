"""End-to-end smoke test for the LLM extraction pipeline with telemetry.

Verifies that across all three LLM phases — discovery, TOC, and sub-control
— the split-on-truncation path fires correctly AND emits the expected
telemetry signals (counters/log-lines).

We drive each phase with a fake provider that returns scripted truncation
patterns so we can assert every branch of the split/merge/dedup logic runs
end-to-end without hitting real Azure.
"""
from __future__ import annotations

import os
import sys
from types import SimpleNamespace
from typing import Any, Optional

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "services", "ai_extraction"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "shared_core"))

from core.exceptions import EmptyResponseError
from extraction import discovery as disco
from extraction import toc as toc_mod
from extraction.discovery import discover_controls_from_body
from extraction.toc import extract_toc_from_text
from llm import metrics as metrics_mod


# ────────────────────────────────────────────────────────────────────────
# Scripted fakes — same shape as test_discovery_split.py for familiarity
# ────────────────────────────────────────────────────────────────────────


class _FakeRateLimiter:
    async def acquire(self) -> None:
        return None


class _FakeLLMResponse:
    def __init__(self, *, content: dict, truncated: bool = False):
        self.content = content
        self.prompt_tokens = 100
        self.completion_tokens = 200
        self.total_tokens = 300
        self.model = "fake"
        self.truncated = truncated


class _ScriptedProvider:
    """Returns canned responses by sequence (discovery path) or by key
    lookup for TOC (single-call per content block)."""

    def __init__(self, responses: list[Any] | dict[tuple[int, int], Any]):
        self._responses = responses
        self.calls: list[dict[str, Any]] = []
        self.model_name = "fake-model"

    async def generate_json_with_metrics(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        response_model=None,
        reasoning_effort: Optional[str] = None,
    ) -> _FakeLLMResponse:
        import re
        pages = [int(m.group(1)) for m in re.finditer(r"\[PAGE (\d+)\]", user_prompt)]
        key = (min(pages), max(pages)) if pages else None
        self.calls.append({
            "key": key,
            "max_tokens": max_tokens,
            "reasoning_effort": reasoning_effort,
        })
        if isinstance(self._responses, dict):
            if key not in self._responses:
                # Fall back to a 0-length page range key for TOC
                marker_counts = user_prompt.count("<!-- page=")
                alt_key = ("blob", marker_counts)
                if alt_key in self._responses:
                    canned = self._responses[alt_key]
                else:
                    raise AssertionError(
                        f"No scripted response for window {key} or blob-key {alt_key}"
                    )
            else:
                canned = self._responses[key]
        else:
            if not self._responses:
                raise AssertionError("No scripted responses left")
            canned = self._responses.pop(0)
        if isinstance(canned, Exception):
            raise canned
        return canned


def _make_config(**overrides) -> SimpleNamespace:
    defaults = dict(
        WINDOW_OVERLAP=1,
        DISCOVERY_WINDOW_SIZE=4,
        DISCOVERY_MAX_LLM_CALLS=64,
        DISCOVERY_MAX_TOKENS=2048,
        TOC_MAX_TOKENS=4096,
        LLM_MODEL_CONTEXT_TOKENS=128_000,
        LLM_RATE_LIMIT_BURST=5,
        DISCOVERY_REASONING_EFFORT="minimal",
        SUBCONTROL_REASONING_EFFORT=None,
        DISCOVERY_MAX_SPLIT_DEPTH=3,
        PARSE_TYPE="docling",
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _discovery_content(pages: list[int]) -> str:
    parts = []
    for p in pages:
        parts.append(f"Body content for page {p}. Control X.{p}.1 text.\n\n<!-- page={p}/{max(pages)} -->")
    return "\n\n".join(parts)


def _toc_content(entries: list[tuple[str, int, int]]) -> str:
    """Build TOC content with dot-leader entries spread across pages.

    entries: (control_id, printed_page, physical_marker_page)
    """
    # Assemble per-physical-page content
    by_page: dict[int, list[str]] = {}
    for cid, printed, phys in entries:
        by_page.setdefault(phys, []).append(f"{cid} Title {cid} ........ {printed}")
    parts = []
    for phys in sorted(by_page):
        body = "\n".join(by_page[phys])
        parts.append(f"{body}\n\n<!-- page={phys}/{max(by_page)} -->")
    return "\n\n".join(parts)


def _ok_discovery(*ids_pages, truncated=False):
    return _FakeLLMResponse(
        content={
            "controls": [
                {"control_id": cid, "title": f"T{cid}", "page": pg}
                for cid, pg in ids_pages
            ]
        },
        truncated=truncated,
    )


def _ok_toc(*ids_pages, truncated=False):
    return _FakeLLMResponse(
        content={
            "controls": [
                {"control_id": cid, "title": f"T{cid}", "page": pg}
                for cid, pg in ids_pages
            ]
        },
        truncated=truncated,
    )


# ────────────────────────────────────────────────────────────────────────
# Telemetry capture — collect structured log lines without OTel
# ────────────────────────────────────────────────────────────────────────


class _MetricLog:
    """Captures [Metrics] lines emitted by llm.metrics so tests can assert
    specific phase/outcome combinations fired."""

    def __init__(self):
        self.records: list[str] = []

    def __enter__(self):
        # Reset OTel meters so tests don't pollute each other's state.
        metrics_mod.reset_for_tests()
        # Patch the logger that llm.metrics uses to also append to our list.
        self._original_debug = metrics_mod.logger.debug
        self._original_info = metrics_mod.logger.info
        self._original_warn = metrics_mod.logger.warning

        def _tap(fn):
            def wrapped(msg, *args, **kwargs):
                if "[Metrics]" in str(msg):
                    self.records.append(str(msg))
                return fn(msg, *args, **kwargs)
            return wrapped

        metrics_mod.logger.debug = _tap(self._original_debug)
        metrics_mod.logger.info = _tap(self._original_info)
        metrics_mod.logger.warning = _tap(self._original_warn)
        return self

    def __exit__(self, *exc):
        metrics_mod.logger.debug = self._original_debug
        metrics_mod.logger.info = self._original_info
        metrics_mod.logger.warning = self._original_warn
        metrics_mod.reset_for_tests()

    def count(self, predicate) -> int:
        return sum(1 for r in self.records if predicate(r))


# ────────────────────────────────────────────────────────────────────────
# End-to-end tests
# ────────────────────────────────────────────────────────────────────────


class TestEndToEndDiscovery:
    """Discovery phase fires the right telemetry through the split path."""

    @pytest.mark.asyncio
    async def test_success_path_emits_ok_call_no_split_no_truncation(self):
        content = _discovery_content([1, 2, 3, 4])
        script = {(1, 4): _ok_discovery(("A.1.1", 1), ("A.1.2", 2))}
        provider = _ScriptedProvider(script)
        cfg = _make_config(DISCOVERY_WINDOW_SIZE=5, WINDOW_OVERLAP=0)

        with _MetricLog() as log:
            toc = await discover_controls_from_body(
                provider=provider,
                framework_name="PCI-DSS",
                content=content,
                start_page=1,
                end_page=4,
                rate_limiter=_FakeRateLimiter(),
                config=cfg,
                framework_profile=None,
            )
        # One LLM call, no splits, no truncations, outcome=ok
        assert toc.total_controls == 2
        assert log.count(lambda r: "llm_call phase=discovery outcome=ok" in r) == 1
        assert log.count(lambda r: "split phase=discovery" in r) == 0
        assert log.count(lambda r: "truncation phase=discovery" in r) == 0

    @pytest.mark.asyncio
    async def test_split_path_emits_truncation_plus_split_metrics(self):
        content = _discovery_content([1, 2, 3, 4])
        script = {
            (1, 4): _ok_discovery(("A.1.1", 1), truncated=True),
            (1, 2): _ok_discovery(("A.1.1", 1), ("A.1.2", 2)),
            (3, 4): _ok_discovery(("A.2.1", 3), ("A.2.2", 4)),
        }
        provider = _ScriptedProvider(script)
        cfg = _make_config(DISCOVERY_WINDOW_SIZE=5, WINDOW_OVERLAP=0)

        with _MetricLog() as log:
            toc = await discover_controls_from_body(
                provider=provider,
                framework_name="PCI-DSS",
                content=content,
                start_page=1,
                end_page=4,
                rate_limiter=_FakeRateLimiter(),
                config=cfg,
                framework_profile=None,
            )
        assert toc.total_controls == 4
        # 3 LLM calls total (parent truncated + 2 halves ok)
        assert log.count(lambda r: "llm_call phase=discovery outcome=truncated" in r) == 1
        assert log.count(lambda r: "llm_call phase=discovery outcome=ok" in r) == 2
        # One split (depth=1) and one non-terminal truncation recorded
        assert log.count(lambda r: "split phase=discovery depth=1" in r) == 1
        assert log.count(lambda r: "truncation phase=discovery terminal=False" in r) == 1
        # No terminal truncation (both halves recovered)
        assert log.count(lambda r: "truncation phase=discovery terminal=True" in r) == 0

    @pytest.mark.asyncio
    async def test_framework_label_propagates_to_metrics(self):
        content = _discovery_content([1, 2])
        script = {(1, 2): _ok_discovery(("X.1", 1))}
        provider = _ScriptedProvider(script)
        cfg = _make_config(DISCOVERY_WINDOW_SIZE=3, WINDOW_OVERLAP=0)

        with _MetricLog() as log:
            await discover_controls_from_body(
                provider=provider,
                framework_name="NIST-CSF",
                content=content,
                start_page=1,
                end_page=2,
                rate_limiter=_FakeRateLimiter(),
                config=cfg,
                framework_profile=None,
            )
        assert log.count(lambda r: "framework=NIST-CSF" in r) >= 1


class TestEndToEndToc:
    """TOC phase fires split-on-truncation + telemetry."""

    @pytest.mark.asyncio
    async def test_success_path_single_call_no_split(self):
        content = _toc_content([
            ("A.1", 1, 1),
            ("A.2", 2, 1),
            ("B.1", 3, 2),
            ("B.2", 4, 2),
        ])
        # TOC makes a single call with the entire content → match by marker count
        script = {
            ("blob", 2): _ok_toc(
                ("A.1", 1), ("A.2", 2), ("B.1", 3), ("B.2", 4),
            ),
        }
        provider = _ScriptedProvider(script)
        cfg = _make_config()

        with _MetricLog() as log:
            toc = await extract_toc_from_text(
                provider=provider,
                framework_name="PCI-DSS",
                content=content,
                pages="1-2",
                rate_limiter=_FakeRateLimiter(),
                config=cfg,
                framework_profile=None,
            )
        assert toc.total_controls == 4
        assert log.count(lambda r: "llm_call phase=toc outcome=ok" in r) == 1
        assert log.count(lambda r: "split phase=toc" in r) == 0

    @pytest.mark.asyncio
    async def test_truncation_path_splits_and_merges(self):
        """Parent TOC call truncates; each half succeeds; results merged+deduped."""
        content = _toc_content([
            ("A.1", 1, 1),
            ("A.2", 2, 1),
            ("B.1", 3, 2),
            ("B.2", 4, 2),
        ])
        # Parent (2 markers) truncates with partial entries.
        # After split, each half has 1 marker and succeeds.
        script = {
            ("blob", 2): _ok_toc(("A.1", 1), truncated=True),
            ("blob", 1): _ok_toc(("B.2", 4)),  # Will be returned by BOTH halves — deduped
        }
        provider = _ScriptedProvider(script)
        cfg = _make_config()

        with _MetricLog() as log:
            toc = await extract_toc_from_text(
                provider=provider,
                framework_name="PCI-DSS",
                content=content,
                pages="1-2",
                rate_limiter=_FakeRateLimiter(),
                config=cfg,
                framework_profile=None,
            )
        # Parent emitted A.1 (partial); halves each returned B.2 → deduped to 2 total
        ids = sorted(e.control_id for e in toc.controls)
        assert ids == ["A.1", "B.2"]
        # Telemetry: 1 truncation (non-terminal), 1 split, 3 calls (parent + 2 halves)
        assert log.count(lambda r: "llm_call phase=toc" in r) == 3
        assert log.count(lambda r: "split phase=toc depth=1" in r) == 1
        assert log.count(lambda r: "truncation phase=toc terminal=False" in r) == 1

    @pytest.mark.asyncio
    async def test_terminal_truncation_single_marker_content(self):
        """Single-page TOC that truncates → cannot split → terminal truncation
        with partial entries preserved."""
        # Only 1 page marker → _split_toc_content_by_pages returns None
        content = "A.1 Title ........ 1\nA.2 Title ........ 2\n<!-- page=1/1 -->"
        script = {
            ("blob", 1): _ok_toc(("A.1", 1), truncated=True),
        }
        provider = _ScriptedProvider(script)
        cfg = _make_config()

        with _MetricLog() as log:
            toc = await extract_toc_from_text(
                provider=provider,
                framework_name="PCI-DSS",
                content=content,
                pages="1-1",
                rate_limiter=_FakeRateLimiter(),
                config=cfg,
                framework_profile=None,
            )
        # Partial A.1 preserved
        assert toc.total_controls == 1
        # Only 1 LLM call (couldn't split)
        assert log.count(lambda r: "llm_call phase=toc outcome=truncated" in r) == 1
        assert log.count(lambda r: "split phase=toc" in r) == 0
        # Terminal truncation recorded
        assert log.count(lambda r: "truncation phase=toc terminal=True" in r) == 1


class TestReasoningEffortEndToEnd:
    """Verify reasoning_effort is passed through all three phases correctly."""

    @pytest.mark.asyncio
    async def test_discovery_passes_minimal_reasoning(self):
        content = _discovery_content([1, 2])
        script = {(1, 2): _ok_discovery(("A.1", 1))}
        provider = _ScriptedProvider(script)
        cfg = _make_config(DISCOVERY_WINDOW_SIZE=3, WINDOW_OVERLAP=0)

        await discover_controls_from_body(
            provider=provider,
            framework_name="Test",
            content=content,
            start_page=1,
            end_page=2,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        assert all(c["reasoning_effort"] == "minimal" for c in provider.calls)

    @pytest.mark.asyncio
    async def test_toc_passes_minimal_reasoning(self):
        content = _toc_content([("A.1", 1, 1), ("A.2", 2, 2)])
        script = {("blob", 2): _ok_toc(("A.1", 1), ("A.2", 2))}
        provider = _ScriptedProvider(script)
        cfg = _make_config()

        await extract_toc_from_text(
            provider=provider,
            framework_name="Test",
            content=content,
            pages="1-2",
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        assert provider.calls[0]["reasoning_effort"] == "minimal"

    @pytest.mark.asyncio
    async def test_discovery_respects_custom_reasoning_override(self):
        """Operator can override DISCOVERY_REASONING_EFFORT via config."""
        content = _discovery_content([1, 2])
        script = {(1, 2): _ok_discovery(("A.1", 1))}
        provider = _ScriptedProvider(script)
        cfg = _make_config(
            DISCOVERY_WINDOW_SIZE=3, WINDOW_OVERLAP=0,
            DISCOVERY_REASONING_EFFORT="low",
        )

        await discover_controls_from_body(
            provider=provider,
            framework_name="Test",
            content=content,
            start_page=1,
            end_page=2,
            rate_limiter=_FakeRateLimiter(),
            config=cfg,
            framework_profile=None,
        )
        assert all(c["reasoning_effort"] == "low" for c in provider.calls)
