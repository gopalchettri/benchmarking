# ============================================================
# Control Extraction - Reset Redis (Development Only)
# Flushes all job states, blueprints, rate limits, and streams.
# Run from project root:
#   .\reset_redis.ps1
# ============================================================

$CONTAINER = "redis-local"

function Write-Header($msg) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

# ── Check Redis is running ──────────────────────────────────
$redisRunning = docker ps --filter "name=$CONTAINER" --filter "status=running" -q
if (-not $redisRunning) {
    Write-Host "[ERROR] Redis container '$CONTAINER' is not running." -ForegroundColor Red
    Write-Host "  Start it with: docker run -d --name $CONTAINER -p 6379:6379 redis:7-alpine" -ForegroundColor Gray
    exit 1
}

# ── Helper: run redis-cli command ───────────────────────────
function Invoke-RedisCli {
    param([string]$cmd)
    $result = docker exec $CONTAINER redis-cli $cmd.Split(" ")
    return $result
}

# ── Show current state before flush ─────────────────────────
Write-Header "Current Redis State"

$dbSize = Invoke-RedisCli "DBSIZE"
Write-Host "  Total keys: $dbSize" -ForegroundColor White

$keyPatterns = @("job_state:*", "blueprint:*", "rate_limit:*")
foreach ($pattern in $keyPatterns) {
    $keys = Invoke-RedisCli "KEYS $pattern"
    $count = if ($keys) { ($keys | Measure-Object).Count } else { 0 }
    Write-Host "  $pattern  ->  $count keys" -ForegroundColor Gray
}

$streams = @("doc_processing:stream", "ai_extraction:stream", "storage:stream", "audit:stream", "dlq:stream")
foreach ($s in $streams) {
    $len = Invoke-RedisCli "XLEN $s"
    Write-Host "  $s  ->  $len messages" -ForegroundColor Gray
}

# ── Flush all keys ──────────────────────────────────────────
Write-Header "Flushing Redis"

Write-Host "  [1/3] Deleting key-value entries..." -ForegroundColor Yellow
foreach ($pattern in $keyPatterns) {
    $keys = Invoke-RedisCli "KEYS $pattern"
    if ($keys) {
        foreach ($k in $keys) {
            if ($k.Trim()) {
                Invoke-RedisCli "DEL $($k.Trim())" | Out-Null
            }
        }
        $count = ($keys | Where-Object { $_.Trim() } | Measure-Object).Count
        Write-Host "    Deleted $count keys matching $pattern" -ForegroundColor Green
    }
    else {
        Write-Host "    No keys matching $pattern" -ForegroundColor Gray
    }
}

Write-Host "  [2/3] Destroying streams..." -ForegroundColor Yellow
foreach ($s in $streams) {
    $exists = Invoke-RedisCli "EXISTS $s"
    if ($exists -eq "1") {
        Invoke-RedisCli "DEL $s" | Out-Null
        Write-Host "    Deleted $s" -ForegroundColor Green
    }
    else {
        Write-Host "    $s does not exist (skipped)" -ForegroundColor Gray
    }
}

Write-Host "  [3/3] Verifying..." -ForegroundColor Yellow
$remaining = Invoke-RedisCli "DBSIZE"
Write-Host "    Remaining keys: $remaining" -ForegroundColor White

# ── Done ────────────────────────────────────────────────────
Write-Header "Redis Reset Complete"
Write-Host "  All job states, blueprints, rate limits, and streams deleted." -ForegroundColor Green
Write-Host "  Streams will be auto-recreated when workers start." -ForegroundColor Gray
Write-Host ""
