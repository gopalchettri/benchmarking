"""
Framework Registry Publisher
==============================
Loads framework definitions into the database via atomic upserts.

Usage:
  python seed/framework_profiles.py --validate-only   # check data, no DB
  python seed/framework_profiles.py --dry-run         # preview writes
  python seed/framework_profiles.py                   # write to DB
  python seed/framework_profiles.py --force           # force overwrite

Exit codes: 0=ok  1=validation/config error  2=DB error  3=unexpected  130=Ctrl+C
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import inspect as sa_inspect
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker

from seed.builders import build_profiles
from seed.builders._helpers import _UUID_SEEDS

logger = logging.getLogger(__name__)

SEED_VERSION = "2.0.0"  # v2: simplified profile schema

_HASHABLE_DB_COLUMNS: frozenset[str] = frozenset({
    "name", "display_name", "version", "prompt_module",
    "control_layout", "domain_mapping",
})


# =============================================================================
# VALIDATION
# =============================================================================

class SeedValidationError(Exception):
    """Raised when profile data fails validation. Message lists ALL failures."""
    pass


def _hash(profile: dict[str, Any]) -> str:
    """SHA-256 fingerprint of the DB-column subset of a profile (32 hex chars)."""
    clean = {k: v for k, v in sorted(profile.items()) if k in _HASHABLE_DB_COLUMNS}
    return hashlib.sha256(json.dumps(clean, sort_keys=True, default=str).encode()).hexdigest()[:32]


def _validate(profiles: list[dict[str, Any]]) -> list[str]:
    """
    Validate all profiles before any DB interaction. Collects ALL errors before
    raising, so everything can be fixed in one pass.

    Returns non-fatal warnings. Raises SeedValidationError on any fatal error.
    """
    errors: list[str] = []
    warnings: list[str] = []
    seen_ids: set[str] = set()
    seen_bkeys: set[tuple[str, str]] = set()

    required = ("id", "name", "display_name", "version", "prompt_module")

    for idx, p in enumerate(profiles):
        tag = p.get("name", f"[{idx}]")
        pid = p.get("id", "")

        for f in required:
            if p.get(f) is None or p.get(f) == "":
                errors.append(f"{tag}: missing required field '{f}'")

        if pid in seen_ids:
            errors.append(f"{tag}: duplicate UUID {pid}")
        seen_ids.add(pid)

        try:
            uuid.UUID(pid)
        except (ValueError, AttributeError):
            errors.append(f"{tag}: malformed UUID '{pid}'")

        bk = (p.get("name", ""), p.get("version", ""))
        if bk in seen_bkeys:
            errors.append(f"{tag}: duplicate business key {bk}")
        seen_bkeys.add(bk)

        name = p.get("name", "")
        ver = p.get("version", "")
        if f"{name}:{ver}" not in _UUID_SEEDS:
            warnings.append(f"{tag}: no _UUID_SEEDS entry for '{name}:{ver}'.")

    if errors:
        raise SeedValidationError(
            f"Validation failed ({len(errors)} error(s)):\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    return warnings


# =============================================================================
# SEED ENGINE — private helpers
# =============================================================================

def _resolve_engine_and_model(engine, model_class):
    """Phase 2: Connect to DB and resolve model class."""
    if engine is None:
        from config import get_settings
        from sqlalchemy import create_engine as _ce
        engine = _ce(get_settings().DATABASE_URL, isolation_level="REPEATABLE READ")
    if model_class is None:
        from services.storage.models import FrameworkProfileModel
        model_class = FrameworkProfileModel
    return engine, model_class


def _check_schema(engine, model_class) -> bool:
    """Phase 3: Verify table and columns exist. Returns has_audit."""
    inspector = sa_inspect(engine)
    tbl = model_class.__tablename__
    if not inspector.has_table(tbl):
        raise RuntimeError(f"Table '{tbl}' missing. Run: alembic upgrade head")
    db_cols = {c["name"] for c in inspector.get_columns(tbl)}
    missing = {"id", "name", "display_name", "version"} - db_cols
    if missing:
        raise RuntimeError(f"Table '{tbl}' missing columns: {missing}. Run: alembic upgrade head")
    has_audit = not ({"content_hash", "seed_version", "seeded_at"} - db_cols)
    if not has_audit:
        logger.warning("Audit columns missing. Drift detection disabled.")
    return has_audit


def _load_existing(session, model_class, has_audit: bool) -> dict:
    """Phase 4: Fetch all existing profiles in one query. Returns {(name,ver): (id, hash)}."""
    cols = [model_class.id, model_class.name, model_class.version]
    if has_audit:
        cols.append(model_class.content_hash)
    existing = {}
    for r in session.query(*cols).all():
        existing[(r[1], r[2])] = (r[0], r[3] if has_audit else None)
    return existing


def _check_fk_orphans(profiles: list, existing: dict, force: bool) -> None:
    """Raise SeedValidationError if any UUID changed for an already-stored profile."""
    for p in profiles:
        prev = existing.get((p["name"], p["version"]))
        if prev and prev[0] != p["id"]:
            msg = (
                f"{p['name']}: UUID changed DB={prev[0]} -> seed={p['id']}. "
                f"FK references will orphan. Fix _UUID_SEEDS or migrate FKs."
            )
            if force:
                logger.warning("FORCED: %s", msg)
            else:
                raise SeedValidationError(msg)


def _upsert_one(ws, engine, model_class, p: dict, existing: dict,
                has_audit: bool, force: bool, dry_run: bool, result: dict) -> None:
    """Phase 5 (single profile): compute hash, decide CREATE/UPDATE/SKIP, execute."""
    label  = p["name"]
    pid    = p["id"]
    h      = _hash(p)
    prev   = existing.get((p["name"], p["version"]))
    is_new = prev is None

    row = {**p}
    if has_audit:
        row.update(content_hash=h, seed_version=SEED_VERSION, seeded_at=datetime.now(timezone.utc))
    valid_cols = {c.name for c in model_class.__table__.columns}
    row = {k: v for k, v in row.items() if k in valid_cols}

    if dry_run:
        if is_new:
            act = "CREATE"; result["created"] += 1
        elif has_audit and not force and prev and prev[1] == h:
            act = "SKIP";   result["skipped"] += 1
        else:
            act = "UPDATE"; result["updated"] += 1
        logger.info("[DRY] %-8s %-16s hash=%s", act, label, h[:12])
        return

    update_cols = {k: v for k, v in row.items() if k != "id"}

    if engine.dialect.name == "postgresql":
        from sqlalchemy.dialects.postgresql import insert as pg_insert
        stmt = pg_insert(model_class).values(**row)
        update_set = {
            c.name: stmt.excluded[c.name]
            for c in model_class.__table__.columns
            if c.name != "id" and c.name in row
        }
        where = (model_class.__table__.c.content_hash != stmt.excluded.content_hash) if (has_audit and not force) else None
        stmt = stmt.on_conflict_do_update(index_elements=["id"], set_=update_set,
                                          **({} if where is None else {"where": where}))
        affected = ws.execute(stmt).rowcount
    else:
        from sqlalchemy import update as sa_update, insert as sa_insert
        existing_row = ws.get(model_class, pid)
        if existing_row is not None:
            if has_audit and not force and getattr(existing_row, "content_hash", None) == h:
                affected = 0
            else:
                ws.execute(sa_update(model_class).where(model_class.id == pid).values(**update_cols))
                affected = 1
        else:
            ws.execute(sa_insert(model_class).values(**row))
            affected = 1

    if affected == 0:
        result["skipped"] += 1; logger.debug("SKIP: %s", label)
    elif is_new:
        result["created"] += 1; logger.info("CREATE: %s hash=%s", label, h[:12])
    else:
        result["updated"] += 1; logger.info("UPDATE: %s hash=%s", label, h[:12])


def _verify_writes(Session, profiles: list, model_class) -> None:
    """Phase 6: Confirm written rows are readable. Non-fatal if this fails."""
    try:
        with Session() as s:
            actual = s.query(model_class).count()
            expected = len(profiles)
            if actual < expected:
                logger.warning("Post-check: expected >= %d, got %d", expected, actual)
            else:
                logger.info("Post-check: %d in DB", actual)
            found = s.query(model_class.id).filter(model_class.id.in_([p["id"] for p in profiles])).count()
            if found != expected:
                logger.warning("ID check: seeded %d, found %d", expected, found)
            else:
                logger.info("ID check: all %d verified", found)
    except Exception:
        logger.warning("Post-seed verification failed", exc_info=True)


# =============================================================================
# SEED ENGINE — public entry point
# =============================================================================

def seed_profiles(
    engine=None,
    *,
    model_class=None,
    dry_run: bool = False,
    validate_only: bool = False,
    force: bool = False,
) -> dict[str, Any]:
    """
    Publish framework profiles to the registry via atomic upserts.

    Returns {"created", "updated", "skipped", "total", "warnings", "seed_version"}.
    Raises SeedValidationError, SQLAlchemyError, or RuntimeError on failure.
    """
    profiles = build_profiles()
    result: dict[str, Any] = {
        "created": 0, "updated": 0, "skipped": 0,
        "total": len(profiles), "warnings": [], "seed_version": SEED_VERSION,
    }

    logger.info("Validating %d profiles (v%s) ...", len(profiles), SEED_VERSION)
    warnings = _validate(profiles)
    result["warnings"] = warnings
    for w in warnings:
        logger.warning("  %s", w)
    logger.info("Validation passed (%d warnings).", len(warnings))
    if validate_only:
        return result

    engine, model_class = _resolve_engine_and_model(engine, model_class)
    has_audit = _check_schema(engine, model_class)
    Session = sessionmaker(bind=engine)
    session = Session()
    try:
        existing = _load_existing(session, model_class, has_audit)
        _check_fk_orphans(profiles, existing, force)

        with Session() as ws, ws.begin():
            for p in profiles:
                _upsert_one(ws, engine, model_class, p, existing, has_audit, force, dry_run, result)

        logger.info("Done (v%s): %d created, %d updated, %d skipped, %d total",
                    SEED_VERSION, result["created"], result["updated"], result["skipped"], result["total"])
        _verify_writes(Session, profiles, model_class)

    except SQLAlchemyError:
        logger.error("DB error", exc_info=True); raise
    except SeedValidationError:
        raise
    except Exception:
        logger.error("Unexpected error", exc_info=True); raise
    finally:
        session.close()

    return result


# =============================================================================
# CLI
# =============================================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Publish framework profiles to the registry.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Database URL is read from config (never CLI args).\n\n"
            "Examples:\n"
            "  python seed/framework_profiles.py --validate-only\n"
            "  python seed/framework_profiles.py --dry-run -v\n"
            "  python seed/framework_profiles.py --force\n"
        ),
    )
    parser.add_argument("--dry-run",       action="store_true", help="Preview without writing.")
    parser.add_argument("--validate-only", action="store_true", help="Validate only; no DB needed.")
    parser.add_argument("--force",         action="store_true", help="Override hash-skip; allow UUID changes.")
    parser.add_argument("-v", "--verbose", action="store_true", help="Debug-level logging.")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    code = 0
    try:
        r = seed_profiles(dry_run=args.dry_run, validate_only=args.validate_only,
                          force=args.force)
        if r["warnings"]:
            logger.warning("Done with %d warning(s).", len(r["warnings"]))
    except SeedValidationError as e:
        logger.error(str(e));                        code = 1
    except RuntimeError as e:
        logger.error("Config: %s", e);              code = 1
    except SQLAlchemyError:
        logger.error("DB error — see traceback.");   code = 2
    except KeyboardInterrupt:
        logger.info("Interrupted.");                 code = 130
    except Exception:
        logger.error("Fatal", exc_info=True);        code = 3

    raise SystemExit(code)


if __name__ == "__main__":
    main()
