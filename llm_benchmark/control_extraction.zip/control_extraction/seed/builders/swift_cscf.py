"""SWIFT Customer Security Controls Framework (CSCF) v2025 — 32 controls, 7 objectives."""
from typing import Any

from ._helpers import _uuid, ControlLayout


def _build_swift_cscf() -> dict[str, Any]:
    return {
        "id":                 _uuid("SWIFT-CSCF", "2025"),
        "name":               "SWIFT-CSCF",
        "display_name":       "SWIFT Customer Security Controls Framework v2025",
        "version":            "2025",
        "prompt_module":      "prompts.swift_cscf",
        "control_layout":     ControlLayout.TOC_BODY,
        "domain_mapping": {
            "1": "Restrict Internet Access and Protect Critical Systems from General IT Environment",
            "2": "Reduce Attack Surface and Vulnerabilities",
            "3": "Physically Secure the Environment",
            "4": "Prevent Compromise of Credentials",
            "5": "Manage Identities and Separate Privileges",
            "6": "Detect Anomalous Activity to Systems or Transaction Records",
            "7": "Plan for Incident Response and Information Sharing",
        },
    }
