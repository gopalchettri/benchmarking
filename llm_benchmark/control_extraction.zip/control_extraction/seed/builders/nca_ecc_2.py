"""NCA Essential Cybersecurity Controls ECC-2:2024 — 108 main controls, 4 domains, KSA."""
from typing import Any

from ._helpers import _uuid, ControlLayout


def _build_nca_ecc_2() -> dict[str, Any]:
    return {
        "id":                 _uuid("NCA-ECC", "2"),
        "name":               "NCA-ECC",
        "display_name":       "NCA ECC v2",
        "version":            "2",
        "prompt_module":      "prompts.nca_ecc_2",
        "control_layout":     ControlLayout.TOC_BODY,
        "domain_mapping": {
            "1": "Cybersecurity Governance",
            "2": "Cybersecurity Defense",
            "3": "Cybersecurity Resilience",
            "4": "Third-Party and Cloud Computing Cybersecurity",
        },
    }