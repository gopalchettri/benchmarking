"""UAE Information Assurance Standard v2.1 — 15 families (M1–M6, T1–T9)."""
from typing import Any

from ._helpers import _uuid, ControlLayout


def _build_uae_ias() -> dict[str, Any]:
    return {
        "id":                 _uuid("UAE-IAS", "2.1"),
        "name":               "UAE-IAS",
        "display_name":       "UAE Information Assurance Standard",
        "version":            "2.1",
        "prompt_module":      "prompts.uae_ias",
        "control_layout":     ControlLayout.TOC_BODY,
        "domain_mapping": {
            "M1": "Strategy and Planning",
            "M2": "Information Security Risk Management",
            "M3": "Awareness and Training",
            "M4": "Human Resource Security",
            "M5": "Compliance",
            "M6": "Performance Evaluation and Improvement",
            "T1": "Information Asset Management",
            "T2": "Physical and Environmental Security",
            "T3": "Operations Management",
            "T4": "Network Security",
            "T5": "Identity and Access Management",
            "T6": "Third-Party Security",
            "T7": "Information System Acquisition, Development, and Maintenance",
            "T8": "Information Security Incident Management",
            "T9": "Information Systems Continuity Management",
        },
    }
