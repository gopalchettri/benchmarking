"""
Shared helpers for framework profile builders.

Provides deterministic UUID generation from framework name + version,
and the ControlLayout enum for document structure classification.
"""
import uuid
from enum import Enum


class ControlLayout(str, Enum):
    """Where controls/subcontrols are structurally located in the source document.

    Used as a pipeline router — the extraction orchestrator checks control_layout
    to dispatch to the correct parser strategy without conditional guessing.
    """
    TOC_BODY = "toc_body"   # Controls are main-body sections, navigable via TOC
    ANNEX    = "annex"      # Controls live in Annex/Appendix, main body is ISMS/governance
    MATRIX   = "matrix"     # Controls delivered as spreadsheet, database, or web matrix


# ── UUID Seeds ────────────────────────────────────────────────────────────────
# Maps "NAME:VERSION" to the seed string used for deterministic UUID generation.
#
# CRITICAL: These strings MUST NEVER CHANGE after production deploy.
# Every FK reference in the database points to the UUIDs derived from them.
# Changing a seed silently orphans all those references.
#
# Adding a new framework: add an entry here FIRST, then write its builder.
_UUID_SEEDS: dict[str, str] = {
    "ISO-27001:2022":   "iso-27001-2022",
    "NIST-CSF:2.0":     "nist-csf-2.0",
    "PCI-DSS:4.0.1":    "pci-dss-4.0.1",
    "SWIFT-CSCF:2025":  "swift-cscf-2025",
    "DESC-ISR:3.1":     "desc-isr-3.1",    
    "NCA-ECC:2":        "nca-ecc-2",
    "SAMA-CSF:1.0":     "sama-csf",        # NOTE: original v1 used no version suffix
    "UAE-IAS:2.1":      "uae-ias-2.1",
}


def _uuid(name: str, version: str) -> str:
    """Return a deterministic UUID for a framework. Crashes if seed is missing."""
    key = f"{name}:{version}"
    if key not in _UUID_SEEDS:
        raise RuntimeError(
            f"No UUID seed for '{key}'. Add to _UUID_SEEDS before deploying."
        )
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, _UUID_SEEDS[key]))
