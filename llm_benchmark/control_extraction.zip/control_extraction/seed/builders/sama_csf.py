"""SAMA Cyber Security Framework v1.0 — 36 extraction units, KSA."""
from typing import Any

from ._helpers import _uuid, ControlLayout


def _build_sama_csf() -> dict[str, Any]:
    return {
        "id":                 _uuid("SAMA-CSF", "1.0"),
        "name":               "SAMA-CSF",
        "display_name":       "SAMA Cyber Security Framework",
        "version":            "1.0",
        "prompt_module":      "prompts.sama_csf",
        "control_layout":     ControlLayout.TOC_BODY,
        "domain_mapping": {
            "3.1": "Cyber Security Leadership and Governance",
            "3.2": "Cyber Security Risk Management and Compliance",
            "3.3": "Cyber Security Operations and Technology",
            "3.4": "Third Party Cyber Security",
        },
    }
