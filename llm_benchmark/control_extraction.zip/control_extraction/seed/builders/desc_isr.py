"""DESC Information Security Regulation v3.1 — 71 main controls, 13 domains, UAE."""
from typing import Any

from ._helpers import _uuid, ControlLayout


def _build_desc_isr() -> dict[str, Any]:
    return {
        "id":                 _uuid("DESC-ISR", "3.1"),
        "name":               "DESC-ISR",
        "display_name":       "DESC ISR v3.1",
        "version":            "3.1",
        "prompt_module":      "prompts.desc_isr",
        "control_layout":     ControlLayout.TOC_BODY,
        "domain_mapping": {
            "1":  "Information Security Management and Governance",
            "2":  "Information and Information Assets Management",
            "3":  "Information Security Risk Management",
            "4":  "Incident and Problem Management",
            "5":  "Access Control",
            "6":  "Operations, Systems and Communication Management",
            "7":  "Business Continuity Planning",
            "8":  "Information Systems Acquisition, Development and Management",
            "9":  "Environmental and Physical Security",
            "10": "Roles and Responsibilities of Human Resources",
            "11": "Compliance and Audit",
            "12": "Information Security Assurance and Performance Assessment",
            "13": "Cloud Security",
        },
    }
