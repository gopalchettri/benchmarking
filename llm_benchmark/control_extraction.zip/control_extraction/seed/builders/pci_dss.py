"""PCI-DSS v4.0.1 — 12 Requirements, 250 leaf sub-requirements.

Profile: control_layout="toc_body", expected_control_count=250
Pipeline: TOC (leaf-level dotted IDs, e.g. 1.1.1, 12.3.4) → page-group extraction.

Sub-requirements live inline within the main document body, not an annex, so
TOC_BODY is the correct layout. Each leaf control (X.Y.Z) renders as a 3-column
table (Defined Approach Requirements | Testing Procedures | Guidance) that the
prompt re-segments into the framework-agnostic sections{...} shape.

Domain mapping covers the 12 top-level Requirements. Titles are taken verbatim
from the PDF's "Requirement N:" headers.
"""
from typing import Any

from ._helpers import _uuid, ControlLayout


def _build_pci_dss() -> dict[str, Any]:
    return {
        "id":                 _uuid("PCI-DSS", "4.0.1"),
        "name":               "PCI-DSS",
        "display_name":       "PCI-DSS v4.0.1",
        "version":            "4.0.1",
        "prompt_module":      "prompts.pci_dss",
        "control_layout":     ControlLayout.TOC_BODY,
        "domain_mapping": {
            "1":  "Install and Maintain Network Security Controls",
            "2":  "Apply Secure Configurations to All System Components",
            "3":  "Protect Stored Account Data",
            "4":  "Protect Cardholder Data with Strong Cryptography During Transmission Over Open, Public Networks",
            "5":  "Protect All Systems and Networks from Malicious Software",
            "6":  "Develop and Maintain Secure Systems and Software",
            "7":  "Restrict Access to System Components and Cardholder Data by Business Need to Know",
            "8":  "Identify Users and Authenticate Access to System Components",
            "9":  "Restrict Physical Access to Cardholder Data",
            "10": "Log and Monitor All Access to System Components and Cardholder Data",
            "11": "Test Security of Systems and Networks Regularly",
            "12": "Support Information Security with Organizational Policies and Programs",
        },
    }
