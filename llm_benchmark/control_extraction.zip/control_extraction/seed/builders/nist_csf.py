"""NIST Cybersecurity Framework (CSF) v2.0 — 106 subcategories, 6 Functions.

Profile: control_layout="annex", expected_control_count=106
Pipeline: TOC skipped (subcategories are NOT in the printed TOC — they
          live only in Appendix A) -> discovery scans body pages with
          strict ID regex -> page-group extraction.

Appendix A spans PDF physical pages 21-28 (printed pages 15-23 once the
~5-page offset for the front matter is applied).  The 106 subcategories
distribute roughly:
  - Function GOVERN (GV):  32 subcategories (5 categories)
  - Function IDENTIFY (ID): 21 subcategories (3 categories)
  - Function PROTECT (PR): 22 subcategories (5 categories)
  - Function DETECT (DE):  11 subcategories (2 categories)
  - Function RESPOND (RS): 13 subcategories (4 categories)
  - Function RECOVER (RC):  8 subcategories (2 categories)
"""
from typing import Any

from ._helpers import _uuid, ControlLayout


def _build_nist_csf() -> dict[str, Any]:
    return {
        "id":                 _uuid("NIST-CSF", "2.0"),
        "name":               "NIST-CSF",
        "display_name":       "NIST Cybersecurity Framework (CSF) 2.0",
        "version":            "2.0",
        "prompt_module":      "prompts.nist_csf",
        # ANNEX layout: skip TOC extraction (NIST CSF's TOC only lists the
        # 5 main chapters + 3 appendices; subcategories are not enumerated
        # there).  Discovery mode scans Appendix A body pages with the
        # strict ID regex below — far fewer false positives than letting
        # the TOC extractor's auto-derived pattern absorb prose acronyms.
        "control_layout":     ControlLayout.ANNEX,
        "domain_mapping": {
            "GV": "Govern",
            "ID": "Identify",
            "PR": "Protect",
            "DE": "Detect",
            "RS": "Respond",
            "RC": "Recover",
        },
    }
