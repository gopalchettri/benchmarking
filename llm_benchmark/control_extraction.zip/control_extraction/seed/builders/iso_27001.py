"""ISO/IEC 27001:2022 — 93 controls, 4 themes (A.5–A.8)."""
from typing import Any

from ._helpers import _uuid, ControlLayout

"""
Profile: control_layout="annex", content_pages="11-18", expected_control_count=93
Pipeline: TOC skipped → discovery (93 IDs, auto-prefixed "A.") → page-group extraction

"""

def _build_iso_27001() -> dict[str, Any]:
    return {
        "id":                 _uuid("ISO-27001", "2022"),
        "name":               "ISO-27001",
        "display_name":       "ISO/IEC 27001:2022",
        "version":            "2022",
        "prompt_module":      "prompts.iso_27001",
        "control_layout":     ControlLayout.ANNEX,
        "domain_mapping": {
            "A.5": "Organizational controls",
            "A.6": "People controls",
            "A.7": "Physical controls",
            "A.8": "Technological controls",
        },
    }
